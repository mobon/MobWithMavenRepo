package com.mobwith.sdk;

import static android.content.Context.POWER_SERVICE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestArticle;
import com.mobwith.sdk.api.MWRequestFrameClick;
import com.mobwith.sdk.api.MWRequestFrameImpression;
import com.mobwith.sdk.api.MWRequestGetViewType;
import com.mobwith.sdk.api.MWRequestReloadInterval;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerWithArticleCallback;
import com.mobwith.sdk.custom.witharticle.BannerWithArticleViewModel;
import com.mobwith.sdk.custom.witharticle.BannerWithArticleViewModel.ViewType;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataImageModel;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.AdDataResponseDataModel;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.MWViewTypeResponseModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.MobwithArticleModel;
import com.mobwith.sdk.models.MobwithConfigModel;
import com.mobwith.sdk.models.MobwithConfigResponseModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

/**
 * 배너 광고와 함께 기사(Article) 정보를 표시하는 커스텀 View 입니다.
 * Mobwith SDK의 일부로, 일반 배너 광고 기능에 더하여 기사 콘텐츠를 함께 로드하고 표시하는 기능을 제공합니다.
 * 광고 요청, 로드, 미디에이션, 자동 새로고침, 기사 로드 및 UI 업데이트 등의 복합적인 기능을 수행합니다.
 */
public class MobwithBannerWithArticleView extends RelativeLayout implements MWCommonRequestInterface {

    private final int MIN_INTERVAL = 60;

    private final Context mContext;
    private iBannerWithArticleCallback mIBannerAdCallback = null;


    private MediationManager mediationManager;
    private AdapterObject mBannerAdapter;
    private boolean isSendedCallback;
    private String mSessionId;
    private String mScriptNo;
    private String mArticleUnitID;

    private int mInterval = 0;
    private int mServerInterval = -999;
    private Handler mScheduleHandler;
    private boolean viewVisible;


    private boolean isInLoading = false;
    private boolean isInLoadArticle = false;


    private BannerWithArticleViewModel bannerWithArticleViewModel = new BannerWithArticleViewModel();
    private FrameLayout containerFrameLayout;

    MobwithArticleModel articleModel;

    private MobwithAdCategoryModel mobwithAdCategoryModel;

    /**
     * 배너 광고와 함께 기사(Article) 정보를 표시하는 커스텀 View 입니다.
     * Mobwith SDK의 일부로, 일반 배너 광고 기능에 더하여 기사 콘텐츠를 함께 로드하고 표시하는 기능을 제공합니다.
     * 광고 요청, 로드, 미디에이션, 자동 새로고침, 기사 로드 및 UI 업데이트 등의 복합적인 기능을 수행합니다.
     */
    public MobwithBannerWithArticleView(Context context) {
        super(context);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }

    /**
     * XML 레이아웃 파일에서 MobwithBannerWithArticleView를 사용할 때 호출되는 생성자입니다.
     *
     * @param context 컨텍스트.
     * @param attrs   XML 레이아웃에서 정의된 속성들.
     */
    public MobwithBannerWithArticleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        this.isInLoading = false;
    }

    /**
     * XML 레이아웃 파일에서 MobwithBannerWithArticleView를 사용하며, 기본 스타일을 적용할 때 호출되는 생성자입니다.
     *
     * @param context  컨텍스트.
     * @param attrs    XML 레이아웃에서 정의된 속성들.
     * @param defStyle 기본 스타일 속성 리소스 ID.
     */
    public MobwithBannerWithArticleView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        this.isInLoading = false;
    }

    /**
     * 배너 광고의 Unit ID(광고 단위 ID)를 설정합니다.
     *
     * @param unitId 배너 광고 Unit Id.
     * @return MobwithBannerWithArticleView 자기 자신을 반환하여 메소드 체이닝을 가능하게 합니다.
     * @throws NullPointerException (현재 코드에서는 명시적 예외 발생 없음)
     */
    public MobwithBannerWithArticleView setBannerUnitId(String unitId) throws NullPointerException {
        try {
            mScriptNo = unitId;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    /**
     * 광고 새로고침 간격(interval)을 설정합니다.
     * 설정된 간격이 0이 아니고 MIN_INTERVAL보다 작으면 MIN_INTERVAL로 강제 설정됩니다.
     *
     * @param interval 광고 새로고침 간격 (초). 0으로 설정하면 자동 새로고침을 사용하지 않습니다.
     * @return MobwithBannerWithArticleView 자기 자신을 반환하여 메소드 체이닝을 가능하게 합니다.
     */
    public MobwithBannerWithArticleView setInterval(int interval) {
        try {
            if (interval != 0 && interval < MIN_INTERVAL) {
                mInterval = MIN_INTERVAL;
            } else {
                mInterval = interval;

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return this;
    }

    /**
     * 특정 광고 카테고리 모델을 설정합니다. (예: 후후 앱 등 특정 서비스 연동 시 사용)
     *
     * @param mobwithAdCategoryModel 광고 카테고리 정보.
     */
    public MobwithBannerWithArticleView setMobwithAdCategoryModel(MobwithAdCategoryModel mobwithAdCategoryModel) {
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        return this;
    }

    /**
     * View의 윈도우 가시성 변경 시 호출됩니다.
     * View가 화면에서 사라지면 현재 광고의 onPause()를, 다시 보이면 onResume()을 호출합니다.
     *
     * @param visibility View의 새로운 가시성 상태.
     */
    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        LogPrint.d("onWindowVisibilityChanged = " + visibility);

        if (mBannerAdapter != null) {
            if (visibility == View.GONE) {
                viewVisible = false;
                mBannerAdapter.onPause();
            } else if (visibility == View.VISIBLE) {
                viewVisible = true;
                mBannerAdapter.onResume();
            }
        }

        super.onWindowVisibilityChanged(visibility);
    }

    /**
     * View의 크기를 측정할 때 호출됩니다.
     * (주석: 현재 특별한 로직 없이 부모 클래스의 메소드를 호출하고 있습니다.)
     *
     * @param widthMeasureSpec  가로 크기 측정 명세.
     * @param heightMeasureSpec 세로 크기 측정 명세.
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * View의 윈도우 포커스 변경 시 호출됩니다.
     * (주석: 현재 특별한 로직 없이 부모 클래스의 메소드를 호출하고 있습니다.)
     *
     * @param hasWindowFocus 윈도우 포커스 여부.
     */
    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        LogPrint.d("hasWindowFocus = " + hasWindowFocus);
        super.onWindowFocusChanged(hasWindowFocus);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    /**
     * `MobwithBannerWithArticleView`의 초기화 작업을 수행합니다.
     * Mobwith SDK를 초기화하고, 광고와 기사를 담을 컨테이너 FrameLayout을 설정합니다.
     */
    private void onInit() {
        setGravity(Gravity.CENTER);

        MobwithSDK.initSDK(mContext);

        containerFrameLayout = new FrameLayout(mContext);
//        containerFrameLayout.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        containerFrameLayout.setLayoutParams(new FrameLayout.LayoutParams((int) mContext.getResources().getDimension(R.dimen.rect_banner_width_360), (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_100)));

        this.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /**
     * 실제 적용될 광고 새로고침 간격을 반환합니다.
     * 서버에서 받은 간격(mServerInterval)이 유효하면 그 값을 따르고,
     * 그렇지 않으면 사용자가 설정한 간격(mInterval)을 따릅니다.
     * 0이 아닌 간격이 MIN_INTERVAL보다 작으면 MIN_INTERVAL로 조정됩니다.
     *
     * @return 실제 적용될 광고 새로고침 간격 (초).
     */
    private int getRealInterval() {
        int realInterval = 0;

        if (mServerInterval >= 0) {
            if (mServerInterval != 0 && mServerInterval < MIN_INTERVAL) {
                realInterval = MIN_INTERVAL;
            } else {
                realInterval = mServerInterval;
            }
        } else {
            realInterval = mInterval;
        }

        return realInterval;
    }

    /**
     * 광고 자동 새로고침 스케줄을 설정합니다.
     * 기존 스케줄이 있다면 취소하고 새로 설정합니다.
     * 실제 적용될 간격은 getRealInterval()을 통해 가져옵니다.
     */
    private void bannerSchedule() {

        if (mScheduleHandler == null) {
            LogPrint.d("RefreshHnadler - Create New Scheduler");
            mScheduleHandler = new Handler(Looper.getMainLooper());
        } else {
            LogPrint.d("RefreshHnadler - Remove Old Schedule");
            stopScheduler();
        }

        int interval = getRealInterval();
        LogPrint.d("RefreshHnadler - New Schedule Add : " + interval);
        mScheduleHandler.postDelayed(runnableCode, (interval * 1000L));
    }

    /**
     * 현재 진행 중인 광고 자동 새로고침 스케줄을 중지합니다.
     */
    private void stopScheduler() {
        if (mScheduleHandler != null) {
            mScheduleHandler.removeCallbacks(runnableCode);
        }
    }


    private long prev_scheduleTime;
    private int waitCount;
    private boolean isPaused = false;
    /**
     * 광고 자동 새로고침을 수행하는 Runnable 객체입니다.
     * 화면이 켜져 있고, 광고 로드 콜백이 한 번이라도 전송된 경우,
     * 그리고 이전 스케줄 시간으로부터 실제 인터벌만큼 시간이 경과했을 때 광고를 새로고침(loadAd 호출)합니다.
     * 그렇지 않으면 다음 스케줄을 다시 예약합니다.
     * 특정 횟수 이상 대기하면 새로고침을 중단할 수 있습니다.
     */
    private final Runnable runnableCode = new Runnable() {
        @SuppressLint("InvalidWakeLockTag")
        @Override
        public void run() {
            LogPrint.d("RefreshHnadler - Runnable start");

            if (mScheduleHandler != null) {
                PowerManager powerManager = (PowerManager) mContext.getSystemService(POWER_SERVICE);
                LogPrint.d("RefreshHnadler - Refresh Start");

                if (powerManager.isScreenOn() && (isSendedCallback)) {
                    waitCount = 0;
                    if (System.currentTimeMillis() - prev_scheduleTime >= getRealInterval() * 1000L) {
                        prev_scheduleTime = System.currentTimeMillis();
                        LogPrint.d("RefreshHnadler - Refresh");
                        loadAd();
                    } else {
                        LogPrint.d("RefreshHnadler - Retry " + System.currentTimeMillis() + "," + prev_scheduleTime + "," + (System.currentTimeMillis() - prev_scheduleTime) + "," + getRealInterval() * 1000);
                        bannerSchedule();
                    }
                } else {
                    if (++waitCount > 100) {
                        LogPrint.d("RefreshHnadler - Not Refresh, Count is " + waitCount);
                        return;
                    }

                    bannerSchedule();
                }
            } else {
                if (++waitCount > 100) {
                    LogPrint.d("RefreshHnadler - Stop Refresh Handler " + waitCount);
                    return;
                }

                LogPrint.d("RefreshHnadler - Not Refresh, Count is " + waitCount);
                bannerSchedule();
            }
        }
    };

    /**
     * 광고 자동 새로고침 스케줄을 일시 중지하고, 현재 광고 어댑터의 onPause()를 호출합니다.
     */
    public void stop() {
        if (mScheduleHandler != null) {
            LogPrint.d("RefreshHnadler - Pause");
            isPaused = true;
            mScheduleHandler.removeCallbacks(runnableCode);
        }

        if (mBannerAdapter != null) {
            mBannerAdapter.onPause();
        }
    }

    /**
     * 일시 중지된 광고 자동 새로고침 스케줄을 다시 시작하고, 현재 광고 어댑터의 onResume()을 호출합니다.
     * 실제 새로고침 간격이 0보다 크고, 이전에 일시 중지된 상태였을 때만 스케줄을 다시 시작합니다.
     */
    public void restart() {
        if (getRealInterval() > 0 && isPaused) {
            LogPrint.d("RefreshHnadler - Restart");
            isPaused = false;
            bannerSchedule();
        }

        if (mBannerAdapter != null) {
            mBannerAdapter.onResume();
        }
    }

    /**
     * 광고 로드를 시작합니다.
     * 이미 로딩 중이면 중복 실행을 방지합니다.
     * 기존 스케줄을 중지하고 `excuteLoadAd()`를 호출하여 실제 광고 로드 로직을 수행합니다.
     */
    public void loadAd() {
        if (isInLoading) {
            return;
        }

        isInLoading = true;

        stopScheduler();
        excuteLoadAd();
    }

    /**
     * 실제 광고 로드 로직을 실행합니다.
     * 먼저 서버로부터 광고 설정(특히 새로고침 간격)을 가져옵니다.
     * 서버 설정 로드가 성공하든 실패하든 `requestFrameCodeAnLoadAd()`를 호출하여 다음 단계를 진행합니다.
     */
    private void excuteLoadAd() {

        if (mServerInterval == -999 || (mInterval > 0 && mServerInterval < 0)) {

            MWRequestReloadInterval.requestWith(mContext, mScriptNo, new MobWithApiResponseCallback<MobwithConfigResponseModel>() {
                @Override
                public void onSuccess(MobwithConfigResponseModel response) {
                    MainThreadHandler.post(() -> {
                        MobwithConfigModel configModel = response.getConfigModel(mScriptNo);

                        if (configModel != null) {
                            mServerInterval = configModel.refreshInterval;
                        }

                        requestFrameCodeAnLoadAd();
                    });
                }

                @Override
                public void onFailure(Exception e) {
                    MainThreadHandler.post(() -> {
                        requestFrameCodeAnLoadAd();
                    });
                }
            });
        } else {
            requestFrameCodeAnLoadAd();
        }

    }

    /**
     * 광고 View의 타입을 서버로부터 가져온 후, 그 타입에 맞는 레이아웃을 설정하고
     * 기사 로드 및 실제 배너 광고 로드를 진행합니다.
     */
    private void requestFrameCodeAnLoadAd() {

        new MWRequestGetViewType(mContext, mScriptNo).execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                String data = response;

                try {
                    JSONObject jsonObject = new JSONObject(data);
                    MWViewTypeResponseModel model = new MWViewTypeResponseModel(jsonObject);

                    ViewType viewType = model.getViewType();
                    bannerWithArticleViewModel.loadView(mContext, viewType, containerFrameLayout);

                    loadArticle();
                    realLoadAd();
                } catch (Exception e) {
                    responseFailMessage(Key.NOFILL);
                }
            }

            @Override
            public void onFailure(IOException e) {
                responseFailMessage(Key.NOFILL);
            }
        });

    }

    /**
     * 실제 배너 광고 목록을 요청하고, 미디에이션을 통해 광고를 로드하여 View에 표시합니다.
     * 네트워크 연결 상태를 확인하고, 연결되지 않았으면 실패 콜백을 호출합니다.
     * 자동 새로고침 간격이 설정되어 있으면 다음 스케줄을 예약합니다.
     */
    private void realLoadAd() {
        mSessionId = "";
        isSendedCallback = false;

        if (getRealInterval() > 0) {
            bannerSchedule();
        }


        if (!Utils.isConnectNetwork(mContext)) {
            MainThreadHandler.post(() -> {
                if (mIBannerAdCallback != null) {
                    LogPrint.d("banner loadAd noConnectNetwork");
                    if (!isSendedCallback) {
                        isSendedCallback = true;
                        mIBannerAdCallback.onLoadedAdInfo(false, "noConnectNetwork");

                    }
                    stopScheduler();
                }
            });

            isInLoading = false;
            return;
        }


        MWRequestSortList requestSortList = new MWRequestSortList(mContext, mScriptNo);
        requestSortList.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                String data = response;

                try {
                    JSONObject jsonObject = new JSONObject(data);
                    SortListResponse sortList = new SortListResponse(jsonObject);

                    if (!sortList.isSuccess()) {
                        responseFailMessage(Key.NOFILL);
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    sendSortListImpression(mContext, mScriptNo, sortList.advrtsPrdtCode, mSessionId);

                    mediationManager = new MediationManager(mContext, sortList.data, BannerType.NATIVE_AD, mobwithAdCategoryModel, bannerWithArticleViewModel.toNativeAdViewItem(mContext), false);
                    mediationManager.LoadMediation(new iMobonMediationCallback() {
                        @Override
                        public void onLoadedAdData(String data, final AdapterObject adapter) {
                            if (adapter != null) {
                                LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
                            } else {
                                LogPrint.d("onLoadedAdData : NoAdapter : " + data);
                            }
                            isInLoading = false;
                        }

                        @Override
                        public void onAdAdapter(AdapterObject adapter) {
                            mBannerAdapter = adapter;
                            MMAdData adData = adapter.getAdData();
                            if (adData != null && adData.jsonData != null && !adData.jsonData.isEmpty()) {
                                MainThreadHandler.post(() -> {
                                    updateUIWith(adData);

                                    if (!isSendedCallback) {
                                        isSendedCallback = true;
                                        if (mIBannerAdCallback != null) {
                                            mIBannerAdCallback.onLoadedAdInfo(true, "");
                                        }
                                    }

                                    removeAllViews();

                                    containerFrameLayout.removeAllViews();
                                    containerFrameLayout.addView(bannerWithArticleViewModel.getAdView());

                                    addView(containerFrameLayout);
                                    updateArticleUI();
                                });
                            } else if (adapter instanceof JsonAdapter) {
                                onAdFailedToLoad(adapter, Key.NOFILL);
                            } else {

                                MainThreadHandler.post(() -> {
                                    removeAllViews();
                                    addView(containerFrameLayout);

                                    bannerWithArticleViewModel.updateArticleTextView(containerFrameLayout.findViewById(R.id.t_articleTitle));

                                    if (mBannerAdapter != null) {
                                        if (!mBannerAdapter.getName().contains("MOBON")) {
                                            ImageView infoMark = containerFrameLayout.findViewById(R.id.img_mark);
                                            if (infoMark != null) {
                                                infoMark.setVisibility(View.INVISIBLE);
                                            }
                                        }
                                    }

                                    updateArticleUI();

                                    if (!isSendedCallback) {
                                        isSendedCallback = true;
                                        if (mIBannerAdCallback != null) {
                                            mIBannerAdCallback.onLoadedAdInfo(true, "");
                                        }
                                    }

                                });

                                try {
                                    AdDataModel adDataModel = new AdDataModel(jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0));
                                    CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
                                } catch (Exception e) {
                                    LogPrint.d(e.getMessage());
                                }

                                MWRequestFrameImpression.requestWith(
                                        mContext,
                                        mScriptNo,
                                        bannerWithArticleViewModel.getCurrentViewType().toString(),
                                        sortList.advrtsPrdtCode,
                                        mSessionId);
                            }

                            isInLoading = false;
                        }

                        @Override
                        public void onAdRequest(AdapterObject adapter) {
                            sendDspImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
                            if (adapter != null) {
                                LogPrint.d("onAdFailedToLoad : " + adapter.getName());
                            }
                            responseFailMessage(Key.NOFILL);
                        }

                        @Override
                        public void onAdFailedAdapterName(AdapterObject adapter) {
                            sendPassBackImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdClicked() {
                            if (mIBannerAdCallback != null) {
                                mIBannerAdCallback.onAdClicked();
                            }

                            MWRequestFrameClick.requestWith(
                                    mContext,
                                    mScriptNo,
                                    bannerWithArticleViewModel.getCurrentViewType().toString(),
                                    sortList.advrtsPrdtCode,
                                    mSessionId);
                        }

                        @Override
                        public void onAdImpression() {
                        }

                        @Override
                        public void onAppFinish() {
                        }

                        @Override
                        public void onAdDisplayed() {
                        }

                        @Override
                        public void onAdComplete() {
                        }

                        @Override
                        public void onAdSkip() {
                        }

                        @Override
                        public void onAdClosed() {
                        }

                        @Override
                        public void onAdCancel() {
                        }

                        @Override
                        public void onAdFailedToOpen() {
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    responseFailMessage(e.getLocalizedMessage());
                }
            }

            @Override
            public void onFailure(IOException e) {
                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());
                responseFailMessage(e.getLocalizedMessage());
            }
        });
    }

    private void responseFailMessage(String message) {
        MainThreadHandler.post(() -> {
            if (mIBannerAdCallback != null && !isSendedCallback) {
                isSendedCallback = true;
                mIBannerAdCallback.onLoadedAdInfo(false, message);
            }
        });

        stopScheduler();
        isInLoading = false;
    }

    private void responseSuccessMessage() {
        MainThreadHandler.post(() -> {
            if (!isSendedCallback) {
                isSendedCallback = true;

                if (mIBannerAdCallback != null) {
                    mIBannerAdCallback.onLoadedAdInfo(true, "");
                }
            }
        });


        isInLoading = false;
    }

    /**
     * 서버로부터 기사(Article) 정보를 요청하고, 성공 시 UI에 반영합니다.
     * 이미 기사 로딩 중이면 중복 실행을 방지합니다.
     */
    void loadArticle() {
        if (isInLoadArticle) {
            return;
        }
        isInLoadArticle = true;

        MWRequestArticle requestArticle = new MWRequestArticle(mContext, mArticleUnitID);
        requestArticle.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) {
                MainThreadHandler.post(() -> {

                    try {
                        String responseData = response;

                        JSONObject jsonObject = new JSONObject(responseData);
                        JSONObject data = jsonObject.optJSONObject("data");
                        if (data == null) {
                            isInLoadArticle = false;
                            return;
                        }

                        articleModel = new MobwithArticleModel(data);
                        updateArticleUI();
                    } catch (Exception e) {
                        LogPrint.e(e.getLocalizedMessage());
//                        sendErrorCallbackForArticle(e.getLocalizedMessage());
                    }

                    isInLoadArticle = false;
                });
            }

            @Override
            public void onFailure(IOException e) {
                MainThreadHandler.post(() -> {
                    LogPrint.e(e.getLocalizedMessage());
//                    sendErrorCallbackForArticle(e.getLocalizedMessage());
                });

                isInLoadArticle = false;
            }
        });

    }

    /**
     * SortList의 다음 광고를 보여줍니다.
     */
    public void showNextAd() {
        if (mediationManager != null) {
            mediationManager.next();
        }
    }

    /**
     * View 및 관련 리소스를 정리합니다.
     * 광고 새로고침 스케줄 중지, 어댑터 리소스 해제, View 제거 등을 수행합니다.
     * Activity나 Fragment의 onDestroy() 시점에 호출하여 메모리 누수를 방지해야 합니다.
     */
    public void destroyAd() {
        stopScheduler();

        MainThreadHandler.post(() -> {
            try {
                if (mBannerAdapter != null) {
                    mBannerAdapter.onPause();
                    mBannerAdapter.destroy();
                    mBannerAdapter = null;
                }

                removeAllViews();
            } catch (Exception e) {
                LogPrint.d("DestroyAd() Error : " + e.getLocalizedMessage());
            }
        });
    }

    /**
     * 광고 데이터(MMAdData)를 사용하여 광고 UI를 업데이트합니다.
     * ViewModel을 통해 광고 제목, 본문, 아이콘, 이미지 등을 설정합니다.
     *
     * @param adData 광고 데이터.
     */
    private void updateUIWith(MMAdData adData) {
        MainThreadHandler.post(() -> {

            AdDataResponseModel model = null;
            try {
                JSONObject jsonObject = new JSONObject(adData.jsonData);
                model = new AdDataResponseModel(jsonObject);
            } catch (JSONException e) {
                responseFailMessage("NO FILL");
                return;
            }

            AdDataResponseDataModel dataModel = model.getData();

            final String logoUrl = dataModel.getLogoUrl();
            final String logoDefault = dataModel.getLogoDefault();
            final String impUrl = dataModel.getImpUrl();

            AdDataModel adDataModel = dataModel.getFirstAd();
            if (adDataModel == null) {
                responseFailMessage("NO FILL");
                return;
            }

            AdDataImageModel imageModel = adDataModel.getAdImageModel();

            sendImpressionWith(mContext, adDataModel.getCustom08(), impUrl);
            CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);

            String pcode = adDataModel.getpCode();
            String purl = adDataModel.getpUrl();

            String title = "";
            String desc = "";
            String thumbnailUrl = "";

            if (TextUtils.isEmpty(pcode)) {     //비상품
                thumbnailUrl = TextUtils.isEmpty(adDataModel.getaLogoDefault()) ? adDataModel.getpImg() : adDataModel.getaLogoDefault();
                title = TextUtils.isEmpty(adDataModel.getpNm()) ? adDataModel.getaTitle() : adDataModel.getpNm();
                desc = TextUtils.isEmpty(adDataModel.getaDesc3()) ? adDataModel.getDesc() : adDataModel.getaDesc3();
            } else {      //상품
                thumbnailUrl = adDataModel.getpImg();
                title = adDataModel.getpNm();
                desc = adDataModel.getPrice();
            }


            bannerWithArticleViewModel.setTitle(title);
            bannerWithArticleViewModel.setDesc(desc);

            bannerWithArticleViewModel.setThumbnailImage(mContext, thumbnailUrl);


            //info mark
            boolean isLogoAvailable = logoUrl != null && !logoUrl.isEmpty();
            bannerWithArticleViewModel.setInfoMarkShow(isLogoAvailable);

            if (isLogoAvailable) {
                bannerWithArticleViewModel.setInfoMarkImage(mContext, logoDefault);
                bannerWithArticleViewModel.setInfoMarkClickListener(v -> {
                    Utils.getBrowserPackageName(mContext, logoUrl, null);
                });
            }

            //광고 클릭 처리
            bannerWithArticleViewModel.setAdClickListener(v -> {
                Utils.getBrowserPackageName(mContext, purl, null);

                if (mIBannerAdCallback != null) {
                    mIBannerAdCallback.onAdClicked();
                }

                MWRequestFrameClick.requestWith(
                        mContext,
                        mScriptNo,
                        bannerWithArticleViewModel.getCurrentViewType().toString(),
                        adDataModel.getAdvrtsReplcCode(),
                        mSessionId);
                CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
            });

            MWRequestFrameImpression.requestWith(
                    mContext,
                    mScriptNo,
                    bannerWithArticleViewModel.getCurrentViewType().toString(),
                    adDataModel.getAdvrtsReplcCode(),
                    mSessionId);

            CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
        });
    }

    /**
     * 로드된 기사(Article) 정보를 ViewModel을 통해 UI에 반영합니다.
     * 기사 제목, 언론사명, 이미지 등을 설정합니다.
     */
    private void updateArticleUI() {
        if (articleModel == null) {
            return;
        }

        bannerWithArticleViewModel.setArticle(articleModel.title);

        bannerWithArticleViewModel.setArticleClickListener(v -> {
            Utils.getBrowserPackageName(mContext, articleModel.linkUrl, null);
            mIBannerAdCallback.onArticleClicked();
        });


        bannerWithArticleViewModel.requestFocusForMarquee();
    }

    /**
     * 배너 광고의 라이프사이클 이벤트 및 사용자 상호작용에 대한 콜백 리스너를 설정합니다.
     *
     * @param pMobonAdCallback iBannerCallback 구현 객체.
     */
    public void setAdListener(iBannerWithArticleCallback pMobonAdCallback) {
        mIBannerAdCallback = pMobonAdCallback;
    }


    @Override
    public int getDescendantFocusability() {
        return super.getDescendantFocusability();
    }


}
