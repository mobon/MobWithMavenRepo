package com.mobwith.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.RelativeLayout;

import com.mobwith.VastParser.adsplay.VastClient;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.R;
import com.mobwith.sdk.api.MWRequestJsonAd;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.mobvideo.MixerVideoListResponseModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VideoAdapter extends AdapterObject {

    // region Constants
    private static final String CACHED_VIDEO_FILE = "mobwithsdk_cached_video.mp4";
    private static final int DOWNLOAD_BUFFER_SIZE = 8 * 1024;
    private static final long THUMBNAIL_FRAME_US = 500_000L;
    private static final long PROGRESS_INTERVAL_MS = 100L;
    private static final long PLAY_RETRY_INTERVAL_MS = 100L;

    private static final String NO_AD = "NO AD";
    private static final String NO_FILL = "NO FILL";
    private static final String ERROR_PREFIX = "ERROR : ";
    // endregion

    // region Listeners / callbacks
    public interface OnVideoListener {
        void onReady(boolean isReady);
    }

    public interface OnVideoClickListener {
        void onClick();
    }

    public interface ThumbnailCallback {
        void onThumbnailReady(Bitmap bitmap);
    }

    private MediationAdListener mediationAdListener;
    private OnVideoListener videoListener;
    // endregion

    // region State
    private final Context mContext;
    private final String exlItlMemo;
    private final String siteNo;
    private final String isParallel;
    private final String adBname;

    private RelativeLayout mMainLayout;
    private TextureView textureView;

    private VastClient vastClient;
    private MediaPlayer mediaPlayer;

    private String mBannerType;
    private boolean isRewardAdLoaded;
    public boolean isPointBanner;

    private String mediaUrl = null;
    private String pUrl = "";
    private File cachedVideoFile = null;

    private boolean isSurfaceTextureAvailable = false;
    private boolean isLoop = false;
    private boolean isMute = false;
    private boolean pauseByLifeCycle = false;

    private Bitmap thumbnailBitmap = null;

    private final ExecutorService backgroundExecutor = Executors.newSingleThreadExecutor();
    // endregion

    public VideoAdapter(final Context context, String name, String unitId,
                        String exlItlMemo, String AdType, MMAdData adData, boolean isTestMode,
                        String siteNo, String isParallel, String adBname) {
        super(name, unitId, AdType, adData, isTestMode);
        mContext = context;
        mAdType = MediationAdSize.REWARD_VIDEO;
        this.exlItlMemo = exlItlMemo;
        this.siteNo = siteNo;
        this.isParallel = isParallel;
        this.adBname = adBname;
    }

    // region Public configuration API
    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    public void setOnVideoListener(OnVideoListener listener) {
        this.videoListener = listener;
    }

    public void setLoop(boolean isLoop) {
        this.isLoop = isLoop;
    }

    public void setMuteMode(boolean isMute) {
        this.isMute = isMute;
    }
    // endregion

    // region Load entry points
    public void load(String adtype) {
        mBannerType = adtype;
        isRewardAdLoaded = false;

        if (BannerType.REWARD_VIDEO.equals(mBannerType)) {
            isPointBanner = true;
        }

        MWRequestJsonAd.request(mContext, getName(), siteNo, getUnitId(), exlItlMemo, isParallel, adBname,
                new MobWithApiResponseCallback<MixerVideoListResponseModel>() {
                    @Override
                    public void onSuccess(MixerVideoListResponseModel response) {
                        if (response == null || response.getFirstVastXML().isEmpty()) {
                            sendOnAdFailedToLoad(NO_AD);
                            return;
                        }
                        loadFromVastXml(response.getFirstVastXML(), false);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        LogPrint.d("api error : " + e.getLocalizedMessage());
                        sendOnAdFailedToLoad(NO_FILL);
                    }
                });
    }

    public void initVideoAd(String videoAd, String pUrl, OnVideoListener listener) {
        videoListener = listener;
        vastClient = new VastClient();
        this.pUrl = pUrl;
        this.mediaUrl = videoAd;

        if (!isMediaPlayable(videoAd)) {
            sendOnAdFailedToLoad(NO_AD);
            return;
        }
        setLayout();
        prepareVideo();
    }

    public void initVastVideo(String vastXml, OnVideoListener listener) {
        LogPrint.d("initVastVideo : " + vastXml);
        videoListener = listener;
        loadFromVastXml(vastXml, true);
    }

    /**
     * Parses VAST XML, builds the layout, and prepares the video for playback.
     *
     * @param failWithNoFill when true a parse error reports NO_FILL, otherwise the raw error.
     */
    private void loadFromVastXml(String vastXml, boolean failWithNoFill) {
        vastClient = new VastClient();
        vastClient.parseXml(vastXml, new VastClient.VASTLoadListener() {
            @Override
            public void onVASTLoaded() {
                setLayout();
                mediaUrl = vastClient.getMediaFileUrl();
                LogPrint.d("mediaUrl : " + mediaUrl);

                if (isMediaPlayable(mediaUrl)) {
                    prepareVideo();
                } else {
                    sendOnAdFailedToLoad(NO_AD);
                }
            }

            @Override
            public void onError(Exception e) {
                String reason = failWithNoFill ? NO_FILL : "ERROR";
                sendOnAdFailedToLoad(reason + " : " + e.getLocalizedMessage());
            }
        });
    }
    // endregion

    // region Callback dispatch (always on main thread)
    private void sendOnLoadAd() {
        MainThreadHandler.post(() -> {
            isRewardAdLoaded = true;
            if (videoListener != null) {
                videoListener.onReady(true);
            }
            if (mediationAdListener != null) {
                mediationAdListener.onAdLoaded();
            }
        });
    }

    private void sendOnAdFailedToLoad(String message) {
        LogPrint.d("video load failed : " + message);
        MainThreadHandler.post(() -> {
            isRewardAdLoaded = false;
            // 실패를 알리지 않으면 호출부가 아무 UI 도 그리지 못한 채 대기하게 됩니다.
            if (videoListener != null) {
                videoListener.onReady(false);
            }
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad(message);
            }
        });
    }
    // endregion

    // region Layout
    private void setLayout() {
        mMainLayout = new RelativeLayout(mContext);
        mMainLayout.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT));
        mMainLayout.setGravity(Gravity.CENTER);
        mMainLayout.setBackgroundColor(Color.TRANSPARENT);

        View.inflate(mContext, R.layout.mobwith_mixer_video_layout, mMainLayout);


        isSurfaceTextureAvailable = false;
        textureView = mMainLayout.findViewById(R.id.textureView);
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
                isSurfaceTextureAvailable = true;
                attachSurface(surface);
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
                LogPrint.d("onSurfaceTextureSizeChanged : " + width + " / " + height);
                // 뷰 크기가 바뀌면 이전 크기 기준으로 계산해 둔 영상 비율 보정을 다시 적용합니다.
                if (mediaPlayer != null) {
                    applyAspectFitRatio(mediaPlayer.getVideoWidth(), mediaPlayer.getVideoHeight());
                }
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                isSurfaceTextureAvailable = false;
                LogPrint.d("onSurfaceTextureDestroyed");
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
        });
    }

    private void attachSurface(SurfaceTexture surface) {
        if (mediaPlayer != null && surface != null) {
            mediaPlayer.setSurface(new Surface(surface));
        }
    }
    // endregion

    // region Lifecycle
    public boolean show() {
        return false;
    }

    public Object getAdView() {
        return mMainLayout;
    }

    @Override
    public boolean isLoaded() {
        return isRewardAdLoaded;
    }

    @Override
    public void destroy() {
        try {
            if (mMainLayout != null){
                ViewParent parent = mMainLayout.getParent();
                if (parent instanceof ViewGroup){
                    ViewGroup group = (ViewGroup) mMainLayout.getParent();
                    group.removeView(mMainLayout);
                }
            }
            reset();
            backgroundExecutor.shutdownNow();
        } catch (Exception e){
            e.printStackTrace();
        }
        super.destroy();
    }

    @Override
    public void close() {
        if (vastClient != null) {
            vastClient.closeAd();
        }
    }

    public void reset() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (vastClient != null) {
            vastClient.resetTracking();
        }
    }
    // endregion

    // region Video preparation
    private void prepareVideo() {
        LogPrint.d("prepareVideo");
        final String videoUrl = mediaUrl;
        cachedVideoFile = new File(mContext.getCacheDir(), CACHED_VIDEO_FILE);

        backgroundExecutor.execute(() -> {
            if (!downloadTo(videoUrl, cachedVideoFile)) {
                sendOnAdFailedToLoad(ERROR_PREFIX + "video download failed");
                return;
            }
            MainThreadHandler.post(this::initMediaPlayer);
        });
    }

    private boolean downloadTo(String url, File destination) {
        try (InputStream input = new URL(url).openStream();
             FileOutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[DOWNLOAD_BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = input.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
            return true;
        } catch (IOException e) {
            LogPrint.d("video download error : " + e.getLocalizedMessage());
            return false;
        }
    }

    private void initMediaPlayer() {
        try {
            LogPrint.d("initMediaPlayer");
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(cachedVideoFile.getPath());
            mediaPlayer.setOnPreparedListener(this::onMediaPrepared);
            mediaPlayer.setOnErrorListener(this::onMediaError);
            mediaPlayer.setOnCompletionListener(mp -> {
                LogPrint.d("MediaPlayer Completion");
                if (vastClient != null) {
                    vastClient.completeAd();
                }
            });
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            LogPrint.d("IOException : " + e.getLocalizedMessage());
            sendOnAdFailedToLoad(ERROR_PREFIX + e.getLocalizedMessage());
        }
    }

    private void onMediaPrepared(MediaPlayer mp) {
        try {
            LogPrint.d("onMediaPrepared");
            SurfaceTexture texture = textureView != null ? textureView.getSurfaceTexture() : null;
            if (texture != null) {
                LogPrint.d("onSurfaceTextureAvailable");
                isSurfaceTextureAvailable = true;
                attachSurface(texture);
            }

            getThumbnail(bitmap -> {
                if (bitmap != null) {
                    thumbnailBitmap = bitmap;
                }
            });

            sendOnLoadAd();
        } catch (Exception e){
            sendOnAdFailedToLoad(e.getMessage());
        }
    }

    private boolean onMediaError(MediaPlayer mp, int what, int extra) {
        LogPrint.d("MediaPlayer Error : " + what + " / " + extra);
        if (vastClient != null) {
            vastClient.sendError();
        }
        stopVideo();
        reset();
        sendOnAdFailedToLoad("Error in play video");
        return true;
    }
    // endregion

    // region Playback controls
    public void playVideo() {
        if (!isSurfaceTextureAvailable || mediaPlayer == null) {
            MainThreadHandler.postDelayed(this::playVideo, PLAY_RETRY_INTERVAL_MS);
            return;
        }

        if (vastClient != null) {
            vastClient.sendImpression();
        }

        adjustAspectFitRatio(mediaPlayer.getVideoWidth(), mediaPlayer.getVideoHeight());

        pauseByLifeCycle = false;
        mediaPlayer.setLooping(isLoop);

        // Video 광고 시 백그라운드 검정색
        if (isLoop) {
            mMainLayout.findViewById(R.id.root).setBackgroundColor(Color.BLACK);
        }

        if (isMute) {
            mediaPlayer.setVolume(0.0f, 0.0f);
        }

        mediaPlayer.start();
        LogPrint.d("playVideo : started " + mediaPlayer.getVideoWidth() + " x " + mediaPlayer.getVideoHeight()
                + " / textureView " + textureView.getWidth() + " x " + textureView.getHeight());
        startProgressUpdates();
    }

    public void setVolume(boolean isSoundPlay) {
        if (mediaPlayer == null) {
            return;
        }
        float volume = isSoundPlay ? 1.0f : 0.0f;
        mediaPlayer.setVolume(volume, volume);
    }

    public void pauseVideo() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            pauseByLifeCycle = true;
        }
    }

    public boolean isPaused() {
        return pauseByLifeCycle;
    }

    public void resumeVideo() {
        if (pauseByLifeCycle && mediaPlayer != null) {
            mediaPlayer.start();
            pauseByLifeCycle = false;
        }
    }

    public void stopVideo() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
    }

    public void performAdClick() {
        if (vastClient == null) {
            return;
        }
        if (pUrl.isEmpty()) {
            Utils.getBrowserPackageName(mContext, vastClient.getClickThrough(), mediationAdListener);
            vastClient.clickedVideo();
        } else {
            Utils.getBrowserPackageName(mContext, pUrl, mediationAdListener);
        }
    }

    public int getMediaDuration() {
        return mediaPlayer != null ? mediaPlayer.getDuration() : 0;
    }

    private void startProgressUpdates() {
        MainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    if (vastClient != null) {
                        vastClient.updateProgress(mediaPlayer.getCurrentPosition() / 1000);
                    }
                    MainThreadHandler.postDelayed(this, PROGRESS_INTERVAL_MS);
                }
            }
        });
    }
    // endregion

    // region Aspect ratio
    private void adjustAspectFitRatio(int videoWidth, int videoHeight) {
        if (textureView == null || videoWidth == 0) {
            return;
        }

        // 아직 레이아웃 전이면 크기를 알 수 없으므로 측정이 끝난 뒤에 보정합니다.
        if (textureView.getWidth() == 0 || textureView.getHeight() == 0) {
            textureView.post(() -> applyAspectFitRatio(videoWidth, videoHeight));
            return;
        }

        applyAspectFitRatio(videoWidth, videoHeight);
    }

    private void applyAspectFitRatio(int videoWidth, int videoHeight) {
        if (textureView == null || videoWidth == 0) {
            return;
        }

        int viewWidth = textureView.getWidth();
        int viewHeight = textureView.getHeight();
        if (viewWidth == 0 || viewHeight == 0) {
            return;
        }

        double aspectRatio = (double) videoHeight / videoWidth;

        int newWidth, newHeight;
        if (viewHeight > (int) (viewWidth * aspectRatio)) {
            newWidth = viewWidth;
            newHeight = (int) (viewWidth * aspectRatio);
        } else {
            newWidth = (int) (viewHeight / aspectRatio);
            newHeight = viewHeight;
        }

        int xOff = (viewWidth - newWidth) / 2;
        int yOff = (viewHeight - newHeight) / 2;

        Matrix transform = new Matrix();
        textureView.getTransform(transform);
        transform.setScale((float) newWidth / viewWidth, (float) newHeight / viewHeight);
        transform.postTranslate(xOff, yOff);
        textureView.setTransform(transform);
    }
    // endregion

    // region Banner type / thumbnail
    public String getBannerType() {
        try {
            boolean hasVastSize = vastClient != null
                    && vastClient.getWidth().intValue() != 0
                    && vastClient.getHeight().intValue() != 0;

            int width, height;
            if (hasVastSize) {
                width = vastClient.getWidth().intValue();
                height = vastClient.getHeight().intValue();
            } else if (mediaPlayer != null) {
                width = mediaPlayer.getVideoWidth();
                height = mediaPlayer.getVideoHeight();
            } else {
                return BannerType.VERTICAL;
            }

            return height < width ? BannerType.HORIZONTAL : BannerType.VERTICAL;
        } catch (Exception e) {
            e.printStackTrace();
            return BannerType.VERTICAL;
        }
    }

    public Bitmap getThubnailBitmap() {
        return thumbnailBitmap;
    }

    public void getThumbnail(ThumbnailCallback callback) {
        backgroundExecutor.execute(() -> {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            Bitmap bitmap = null;
            try {
                // Prefer the already-downloaded local file; fall back to the remote URL.
                if (cachedVideoFile != null && cachedVideoFile.exists()) {
                    retriever.setDataSource(cachedVideoFile.getPath());
                } else {
                    retriever.setDataSource(mediaUrl, new HashMap<>());
                }
                bitmap = retriever.getFrameAtTime(THUMBNAIL_FRAME_US, MediaMetadataRetriever.OPTION_CLOSEST);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    retriever.release();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            final Bitmap result = bitmap;
            MainThreadHandler.post(() -> callback.onThumbnailReady(result));
        });
    }
    // endregion

    // region Helpers
    private boolean isMediaPlayable(String url) {
        return url != null && !url.isEmpty();
    }
    // endregion
}