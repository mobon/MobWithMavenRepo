package com.mobwith.adapters;

import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mobwith.imgmodule.ImageModule;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.R;
import com.mobwith.sdk.api.MWRequestCustomURL;
import com.mobwith.sdk.api.MWRequestFrameAd;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataFrameModel;
import com.mobwith.sdk.models.AdDataFrameSubModel;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class SmartFrameAdapter extends AdapterObject {
    private MediationAdListener mediationAdListener;
    private final String mUnitId;
    private final String mZoneId;
    private final String mExid;
    private AdDataFrameModel dataModel;
    private final Context mContext;
    private final FrameLayout containerLayout;
    private final MobwithAdCategoryModel mobwithAdCategoryModel;

    public SmartFrameAdapter(Context context, String name, String unitId, String zoneId, String AdType, MobwithAdCategoryModel mobwithAdCategoryModel, MMAdData adData, boolean isTestMode) {
        super(name, unitId, AdType, adData, isTestMode);
        this.mContext = context;
        this.mUnitId = unitId;
        this.mZoneId = zoneId;
        this.mExid = name;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;

        LogPrint.d("mZoneId : " + mZoneId);

        containerLayout = new FrameLayout(context);
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    @Override
    public void load(String AdType) {
        super.load(AdType);

        MWRequestFrameAd.requestWith(mContext, mExid, mZoneId, mUnitId, mobwithAdCategoryModel, new MobWithApiResponseCallback<AdDataResponseModel>() {
            @Override
            public void onSuccess(AdDataResponseModel response) {
                try {
                    if (response.isSuccess()) {
                        JSONObject result = new JSONObject(response.getJsonString());
                        JSONObject data = result.optJSONObject("data");
                        JSONArray subData = data.optJSONArray("subData");
                        ArrayList<AdDataFrameSubModel> subDataList = new ArrayList<>();
                        if (subData != null && subData.length() > 0) {
                            for (int i = 0; i < subData.length(); i++) {
                                subDataList.add(new AdDataFrameSubModel(
                                        subData.optJSONObject(i).optString("subImg"),
                                        subData.optJSONObject(i).optString("subTitle"),
                                        subData.optJSONObject(i).optString("subSubTitle"),
                                        subData.optJSONObject(i).optString("subDesc1"),
                                        subData.optJSONObject(i).optString("subDesc2"),
                                        subData.optJSONObject(i).optString("subLandingUrl"),
                                        subData.optJSONObject(i).optString("subLandingMUrl")
                                ));
                            }
                        }

                        dataModel = new AdDataFrameModel(
                                data.optString("frameId"),
                                data.optString("frameDesc"),
                                data.optString("impsUrl"),
                                data.optString("logoImg"),
                                data.optString("logoLandingUrl"),
                                data.optString("logoLandingMUrl"),
                                data.optString("delibNo"),
                                data.optString("mainImg"),
                                data.optString("mainTitle"),
                                data.optString("mainSubTitle"),
                                data.optString("mainDesc1"),
                                data.optString("mainDesc2"),
                                data.optString("mainLandingUrl"),
                                data.optString("mainLandingMUrl"),
                                subDataList
                        );
                        updateUI(dataModel);
                    } else {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdFailedToLoad("NO AD");
                        }
                    }
                } catch (Exception e) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("Frame Ad Load Fail - " + e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Exception e) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("Frame Ad Load Fail - " + e.getMessage());
                }
            }
        });
    }

    @Override
    public boolean isLoaded() {
        return dataModel != null;
    }

    public Object getAdView() {
        return containerLayout;
    }

    private void updateUI(AdDataFrameModel dataModel) {
        MainThreadHandler.post(() -> {
            View inflatedView = setFrameUI(dataModel);
            if (inflatedView == null) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("NO FILL");
                }
                return;
            }
            containerLayout.removeAllViews();
            containerLayout.addView(inflatedView);
            if (mediationAdListener != null) {
                mediationAdListener.onAdLoaded();
            }
        });
    }

    private View setFrameUI(AdDataFrameModel dataModel) {
        try {
            View inflatedView = null;
            ImageView logoImg;
            ImageView mainImg;
            TextView mainTitle;
            TextView mainSubTitle;
            TextView mainDesc1;
            TextView mainDesc2;
            LinearLayout mainLayout;
            LinearLayout subLayout1;
            LinearLayout subLayout2;
            LinearLayout subLayout3;
            ImageView subImg1;
            ImageView subImg2;
            ImageView subImg3;
            TextView subTitle1;
            TextView subTitle2;
            TextView subTitle3;
            TextView subMainTitle1;
            TextView subSubTitle1;
            TextView subDesc1;
            TextView subDesc2;
            TextView delibNo;

            switch (dataModel.getFrameId()) {
                case "FB_FRB_001":
                    inflatedView = View.inflate(mContext, R.layout.whowho_type_1, null);
                    break;
                case "FB_FRB_002":
                    inflatedView = View.inflate(mContext, R.layout.whowho_type_2, null);
                    break;
                case "FB_FRB_003":
                    inflatedView = View.inflate(mContext, R.layout.whowho_type_3, null);
                    break;
                case "FB_FRB_004":
                    inflatedView = View.inflate(mContext, R.layout.whowho_type_4, null);
                    break;
                default:
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("NO FRAME");
                    }
                    break;
            }

            if (inflatedView == null) {
                return null;
            }

            logoImg = inflatedView.findViewById(R.id.logoImg);
            mainImg = inflatedView.findViewById(R.id.mainImg);
            subImg1 = inflatedView.findViewById(R.id.subImg1);
            subImg2 = inflatedView.findViewById(R.id.subImg2);
            subImg3 = inflatedView.findViewById(R.id.subImg3);
            mainTitle = inflatedView.findViewById(R.id.mainTitle);
            mainSubTitle = inflatedView.findViewById(R.id.mainSubTitle);
            mainDesc1 = inflatedView.findViewById(R.id.mainDesc1);
            mainDesc2 = inflatedView.findViewById(R.id.mainDesc2);
            mainLayout = inflatedView.findViewById(R.id.mainLayout);
            subLayout1 = inflatedView.findViewById(R.id.subLayout1);
            subLayout2 = inflatedView.findViewById(R.id.subLayout2);
            subLayout3 = inflatedView.findViewById(R.id.subLayout3);
            subTitle1 = inflatedView.findViewById(R.id.subTitle1);
            subTitle2 = inflatedView.findViewById(R.id.subTitle2);
            subTitle3 = inflatedView.findViewById(R.id.subTitle3);
            subMainTitle1 = inflatedView.findViewById(R.id.subMainTitle1);
            subSubTitle1 = inflatedView.findViewById(R.id.subSubTitle1);
            subDesc1 = inflatedView.findViewById(R.id.subDesc1);
            subDesc2 = inflatedView.findViewById(R.id.subDesc2);
            delibNo = inflatedView.findViewById(R.id.delibNo);

            if (logoImg != null) {
                ImageModule.with(mContext).load(dataModel.getLogoImg()).fitCenter().into(logoImg);
                logoImg.setOnClickListener(v -> {
                    LogPrint.d("logoImg clicked");
                    Utils.getBrowserPackageName(mContext, dataModel.getLogoLandingMUrl(), null);
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                });
            }
            if (mainLayout != null) {
                mainLayout.setOnClickListener(v -> {
                    LogPrint.d("mainLayout clicked");
                    Utils.getBrowserPackageName(mContext, dataModel.getMainLandingMUrl(), null);
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                });
            }
            if (mainImg != null) {
                ImageModule.with(mContext).load(dataModel.getMainImg()).centerInside().into(mainImg);
                mainImg.setOnClickListener(v -> {
                    LogPrint.d("mainImg clicked");
                    Utils.getBrowserPackageName(mContext, dataModel.getMainLandingMUrl(), null);
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                });
            }
            if (mainTitle != null) {
                if (dataModel.getMainTitle().isEmpty()) {
                    mainTitle.setVisibility(View.INVISIBLE);
                } else {
                    Utils.setEllipsizedText(mainTitle, dataModel.getMainTitle());
                }
            }
            if (mainSubTitle != null) {
                if (dataModel.getMainSubTitle().isEmpty()) {
                    mainSubTitle.setVisibility(View.INVISIBLE);
                } else {
                    mainSubTitle.setText(dataModel.getMainSubTitle());
                }
            }
            if (mainDesc1 != null) {
                if (dataModel.getMainDesc1().isEmpty()) {
                    mainDesc1.setVisibility(View.INVISIBLE);
                } else {
                    mainDesc1.setText(dataModel.getMainDesc1());
                }
            }
            if (mainDesc2 != null) {
                if (dataModel.getMainDesc2().isEmpty()) {
                    mainDesc2.setVisibility(View.INVISIBLE);
                } else {
                    mainDesc2.setText(dataModel.getMainDesc2());
                }
            }

            if (delibNo != null) {
                if (dataModel.getDelibNo().isEmpty()) {
                    delibNo.setVisibility(View.INVISIBLE);
                } else {
                    delibNo.setText(dataModel.getDelibNo());
                }
            }

            //SubUI
            int subItemCount = dataModel.getSubData().size();
            switch (subItemCount) {
                case 0: {
                    if (subLayout1 != null) {
                        subLayout1.setVisibility(View.GONE);
                    }
                    if (subLayout2 != null) {
                        subLayout2.setVisibility(View.GONE);
                    }
                    if (subLayout3 != null) {
                        subLayout3.setVisibility(View.GONE);
                    }
                    break;
                }
                case 1: {
                    if (subLayout2 != null) {
                        subLayout2.setVisibility(View.INVISIBLE);
                    }
                    if (subLayout3 != null) {
                        subLayout3.setVisibility(View.INVISIBLE);
                    }
                    if (subLayout1 != null) {
                        subLayout1.setOnClickListener(v -> {
                            LogPrint.d("subLayout1 clicked");
                            if (subLayout1.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(0).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subImg1 != null) {
                        ImageModule.with(mContext).load(dataModel.getSubData().get(0).getSubImg()).centerCrop().into(subImg1);
                        subImg1.setOnClickListener(v -> {
                            LogPrint.d("subImg1 clicked");
                            if (subImg1.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(0).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }

                    if (subTitle1 != null) {
                        String subTitle = dataModel.getSubData().get(0).getSubSubTitle();
                        if (subTitle.isEmpty()) {
                            subTitle1.setVisibility(View.INVISIBLE);
                        } else {
                            subTitle1.setText(subTitle);
                        }
                    }

                    if (subMainTitle1 != null) {
                        String subMainTitle = dataModel.getSubData().get(0).getSubTitle();
                        if (subMainTitle.isEmpty()) {
                            subMainTitle1.setVisibility(View.INVISIBLE);
                        } else {
                            Utils.setEllipsizedText(subMainTitle1, subMainTitle);
                        }
                    }

                    if (subSubTitle1 != null) {
                        String subSubTitle = dataModel.getSubData().get(0).getSubSubTitle();
                        if (subSubTitle.isEmpty()) {
                            subSubTitle1.setVisibility(View.INVISIBLE);
                        } else {
                            subSubTitle1.setText(subSubTitle);
                        }
                    }

                    if (subDesc1 != null) {
                        String subDesc = dataModel.getSubData().get(0).getSubDesc1();
                        if (subDesc.isEmpty()) {
                            subDesc1.setVisibility(View.INVISIBLE);
                        } else {
                            subDesc1.setText(subDesc);
                        }
                    }

                    if (subDesc2 != null) {
                        String subDesc = dataModel.getSubData().get(0).getSubDesc2();
                        if (subDesc.isEmpty()) {
                            subDesc2.setVisibility(View.INVISIBLE);
                        } else {
                            subDesc2.setText(subDesc);
                        }
                    }
                    break;
                }
                case 2: {
                    if (subLayout3 != null) {
                        subLayout3.setVisibility(View.INVISIBLE);
                    }
                    if (subLayout1 != null) {
                        subLayout1.setOnClickListener(v -> {
                            LogPrint.d("subLayout1 clicked");
                            if (subLayout1.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(0).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subLayout2 != null) {
                        subLayout2.setOnClickListener(v -> {
                            LogPrint.d("subLayout2 clicked");
                            if (subLayout2.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(1).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subImg1 != null) {
                        ImageModule.with(mContext).load(dataModel.getSubData().get(0).getSubImg()).centerCrop().into(subImg1);
                        subImg1.setOnClickListener(v -> {
                            LogPrint.d("subImg1 clicked");
                            if (subImg1.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(0).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subImg2 != null) {
                        ImageModule.with(mContext).load(dataModel.getSubData().get(1).getSubImg()).centerCrop().into(subImg2);
                        subImg2.setOnClickListener(v -> {
                            LogPrint.d("subImg2 clicked");
                            if (subImg2.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(1).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subTitle1 != null) {
                        String subTitle = dataModel.getSubData().get(0).getSubSubTitle();
                        if (subTitle.isEmpty()) {
                            subTitle1.setVisibility(View.INVISIBLE);
                        } else {
                            subTitle1.setText(subTitle);
                        }
                    }
                    if (subTitle2 != null) {
                        String subTitle = dataModel.getSubData().get(1).getSubSubTitle();
                        if (subTitle.isEmpty()) {
                            subTitle2.setVisibility(View.INVISIBLE);
                        } else {
                            subTitle2.setText(subTitle);
                        }
                    }
                    break;
                }
                case 3: {
                    if (subLayout1 != null) {
                        subLayout1.setOnClickListener(v -> {
                            LogPrint.d("subLayout1 clicked");
                            if (subLayout1.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(0).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subLayout2 != null) {
                        subLayout2.setOnClickListener(v -> {
                            LogPrint.d("subLayout2 clicked");
                            if (subLayout2.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(1).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subLayout3 != null) {
                        subLayout3.setOnClickListener(v -> {
                            LogPrint.d("subLayout3 clicked");
                            if (subLayout3.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(2).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subImg1 != null) {
                        ImageModule.with(mContext).load(dataModel.getSubData().get(0).getSubImg()).centerCrop().into(subImg1);
                        subImg1.setOnClickListener(v -> {
                            LogPrint.d("subImg1 clicked");
                            if (subImg1.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(0).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subImg2 != null) {
                        ImageModule.with(mContext).load(dataModel.getSubData().get(1).getSubImg()).centerCrop().into(subImg2);
                        subImg2.setOnClickListener(v -> {
                            LogPrint.d("subImg2 clicked");
                            if (subImg2.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(1).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subImg3 != null) {
                        ImageModule.with(mContext).load(dataModel.getSubData().get(2).getSubImg()).centerCrop().into(subImg3);
                        subImg3.setOnClickListener(v -> {
                            LogPrint.d("subImg3 clicked");
                            if (subImg3.getVisibility() != View.VISIBLE) {
                                return;
                            }
                            Utils.getBrowserPackageName(mContext, dataModel.getSubData().get(2).getSubLandingMUrl(), null);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        });
                    }
                    if (subTitle1 != null) {
                        String subTitle = dataModel.getSubData().get(0).getSubSubTitle();
                        if (subTitle.isEmpty()) {
                            subTitle1.setVisibility(View.INVISIBLE);
                        } else {
                            subTitle1.setText(subTitle);
                        }
                    }
                    if (subTitle2 != null) {
                        String subTitle = dataModel.getSubData().get(1).getSubSubTitle();
                        if (subTitle.isEmpty()) {
                            subTitle2.setVisibility(View.INVISIBLE);
                        } else {
                            subTitle2.setText(subTitle);
                        }
                    }
                    if (subTitle3 != null) {
                        String subTitle = dataModel.getSubData().get(2).getSubSubTitle();
                        if (subTitle.isEmpty()) {
                            subTitle3.setVisibility(View.INVISIBLE);
                        } else {
                            subTitle3.setText(subTitle);
                        }
                    }
                    break;
                }
            }

            if (dataModel.getImpsUrl() != null && !dataModel.getImpsUrl().isEmpty() && !dataModel.getImpsUrl().equals("null")) {
                MWRequestCustomURL.requestWith(mContext, dataModel.getImpsUrl(), "Frame Impression");
            }

            return inflatedView;
        } catch (Exception e) {
            mediationAdListener.onAdFailedToLoad("Frame error - " + e.getMessage());
            return null;
        }
    }
}
