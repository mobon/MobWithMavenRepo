package com.mobwith.imgmodule;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mobwith.imgmodule.manager.RequestManagerRetriever;
import com.mobwith.imgmodule.module.AppImageModule;

import java.util.Set;

/**
 * Allows {@link AppImageModule}s to exclude {@link com.mobwith.imgmodule.annotation.ImageModule}s to
 * ease the migration from {@link com.mobwith.imgmodule.ImageModule.annotation.ImageModule}s to ImageModule annotation
 * processing system and optionally provides a {@link
 * com.mobwith.imgmodule.manager.RequestManagerRetriever.RequestManagerFactory} impl.
 */
abstract class GeneratedAppImageModule extends AppImageModule {
  /** This method can be removed when manifest parsing is no longer supported. */
  @NonNull
  abstract Set<Class<?>> getExcludedModuleClasses();

  @Nullable
  RequestManagerRetriever.RequestManagerFactory getRequestManagerFactory() {
    return null;
  }
}
