package com.mobwith.sdk;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.mobwith.MobwithSDK;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.SpManager;
import com.mobwith.sdk.api.MWRequestGetCurrentTime;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.callback.iMultiPointBannerCallback;
import com.mobwith.sdk.models.MWCurrentTimeResponseModel;
import com.mobwith.sdk.utils.MainThreadHandler;



/**
 * 여러 개의 포인트 배너를 ViewPager2를 사용하여 표시하고 관리하는 커스텀 뷰입니다.
 * 이 뷰는 다음과 같은 주요 기능을 수행합니다:
 * - 여러 개의 배너 유닛 ID를 설정받아 각각의 {@link MobwithPointBannerView}를 내부적으로 생성하고 관리합니다.
 * - {@link ViewPager2}를 사용하여 좌우로 스와이프 가능한 배너 인터페이스를 제공합니다.
 * - 현재 표시된 배너를 나타내는 점(dot) 인디케이터를 하단에 표시합니다.
 * - 각 배너의 광고 로드, 클릭 이벤트, 리워드 지급 가능 상태 등을 관리합니다.
 * - 주기적으로 서버 시간을 확인하여 포인트 관련 정보를 갱신할 수 있는 로직을 포함합니다.
 * - {@link iMultiPointBannerCallback}을 통해 광고 로드 상태 및 클릭 이벤트를 외부로 전달합니다.
 */
public class MobwithMultiPointBannerView extends RelativeLayout {

    private final Context mContext;
    private iMultiPointBannerCallback mCallback = null;

    private String[] mScriptNos;
    private MobwithPointBannerView[] mPointBanners;
    private boolean[] mRewardEnables;

    private LinearLayout dotLayout;
    private ImageView[] dots;
    private int pageCount = 5;


    private ViewPager2 viewPager;
    private ViewPagerAdapter viewPagerAdapter;


    private boolean isSendedCallback;

    /**
     * MobwithMultiPointBannerView 생성자
     * @param context 뷰를 생성하는 데 사용되는 컨텍스트
     */
    public MobwithMultiPointBannerView(Context context) {
        super(context);
        this.mContext = context;
        initUI();
    }

    /**
     * 표시할 배너들의 유닛 ID 배열을 설정합니다. 최대 5개까지의 유닛 ID가 사용됩니다.
     * 이 메소드가 호출된 후, 내부적으로 배너 뷰들이 생성되고 UI가 구성됩니다.
     * @param unitId 배너 유닛 ID들이 담긴 문자열 배열. null이 아니어야 합니다.
     * @throws NullPointerException unitId가 null인 경우 발생합니다.
     */
    public void setBannerUnitIds(@NonNull String[] unitId) throws NullPointerException {

        int maxCount = Math.min(unitId.length, 5);
        mScriptNos = new String[maxCount];

        for (int i = 0; i < maxCount; i++) {
            mScriptNos[i] = unitId[i];
        }

        initUIDatas();
    }


    /**
     * 특정 인덱스의 배너에 대해 포인트가 지급되었음을 SDK에 알립니다.
     * 이 메소드가 호출되면 해당 배너의 리워드 가능 상태가 false로 변경되고,
     * 이 상태는 SharedPreferences에 저장됩니다.
     * @param index 포인트를 제공한 광고의 인덱스. 광고 클릭 시 전달된 인덱스 값을 사용합니다.
     */
    public void setRewarded(int index) {
        if (index > mPointBanners.length) {
            return;
        }

        mPointBanners[index].setPointEnable(false);
        mRewardEnables[index] = false;

        SpManager.setPointBannerStatus(mContext, mRewardEnables);
    }
    /**
     * 멀티 포인트 배너의 광고 관련 이벤트(로드 완료, 클릭 등)를 수신할 리스너를 설정합니다.
     * @param callback 광고 이벤트를 처리할 {@link iMultiPointBannerCallback} 구현 객체
     */
    public void setAdListener(iMultiPointBannerCallback callback) {
        mCallback = callback;
    }

    /**
     * 모든 배너 광고의 로드를 시작합니다.
     * 먼저 각 배너의 정보를 초기화하고, 서버로부터 현재 시간을 가져와 포인트 정보의 갱신이 필요한지 확인합니다.
     * 이후 각 배너를 순차적으로 새로고침합니다.
     */
    public void loadAd() {
        for (int i = 0; i < mPointBanners.length; i++) {
            mPointBanners[i].resetInfo();
        }
        mPointBanners[0].setPointEnable(mRewardEnables[0]);


        MWRequestGetCurrentTime.request(mContext, new MobWithApiResponseCallback<MWCurrentTimeResponseModel>() {
            @Override
            public void onSuccess(MWCurrentTimeResponseModel response) {
                try {
                    long oldUpdatedTime = SpManager.getPointBannerRefreshedTime(mContext);
                    long currentTime = response.timeModel.getDateTimeMillis();
                    long intervalTime = response.timeModel.getPointCheckTime() * 60 * 1000;

                    if (oldUpdatedTime + intervalTime <= currentTime) {
                        MainThreadHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                resetPointInfo();
                                SpManager.setPointBannerRefreshedTime(mContext, currentTime);
                            }
                        });
                    }
                }
                catch (Exception e) {
                    LogPrint.e("onSuccess: " + e.getMessage());
                }

                MainThreadHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshBanners();
                    }
                });
            }

            @Override
            public void onFailure(Exception e) {
                MainThreadHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        refreshBanners();
                    }
                });
            }
        });

    }

    /**
     * 모든 배너의 포인트 관련 정보를 초기화합니다.
     * 각 배너의 리워드 가능 상태를 true로 설정하고, 이 상태를 SharedPreferences에 저장합니다.
     * 주로 포인트 갱신 주기가 도래했을 때 호출됩니다.
     */
    private void resetPointInfo() {
        for (int i = 0; i < mPointBanners.length; i++) {
            mPointBanners[i].setPointEnable(true);
            mRewardEnables[i] = true;
        }

        SpManager.setPointBannerStatus(mContext, mRewardEnables);
    }

    /**
     * 모든 배너를 새로고침합니다.
     * 광고 로드 완료 콜백 전송 플래그를 초기화하고, 첫 번째 배너부터 광고를 로드합니다.
     * ViewPager를 첫 번째 페이지로 설정합니다.
     */
    private void refreshBanners() {
        isSendedCallback = false;

        if(mPointBanners.length > 0) {
            mPointBanners[0].loadAd();
        }

        viewPager.setCurrentItem(0, false);
    }

    /**
     * 모든 {@link MobwithPointBannerView} 인스턴스의 광고 활동을 다시 시작합니다.
     * 예를 들어, Activity가 onResume 상태가 될 때 호출될 수 있습니다.
     */
    public void restart() {
        if (mPointBanners != null) {
            for (MobwithPointBannerView mBannerView : mPointBanners) {
                mBannerView.restart();
            }
        }
    }

    /**
     * 모든 {@link MobwithPointBannerView} 인스턴스의 광고 활동을 중지합니다.
     * 예를 들어, Activity가 onPause 상태가 될 때 호출될 수 있습니다.
     */
    public void stop() {
        if (mPointBanners != null) {
            for (MobwithPointBannerView mBannerView : mPointBanners) {
                mBannerView.stop();
            }
        }
    }
    /**
     * 모든 {@link MobwithPointBannerView} 인스턴스에서 사용된 리소스를 해제합니다.
     * 예를 들어, Activity가 onDestroy 상태가 될 때 호출하여 메모리 누수를 방지합니다.
     */
    public void destroyAd() {
        if (mPointBanners != null) {
            for (MobwithPointBannerView mBannerView : mPointBanners) {
                mBannerView.destroyAd();
            }
        }
    }

    /**
     * 뷰의 기본적인 UI 구성요소를 초기화합니다.
     * XML 레이아웃을 인플레이트하고, {@link ViewPager2}와 점 인디케이터 레이아웃을 참조합니다.
     * Mobwith SDK를 초기화합니다.
     */
    private void initUI() {
        inflate(mContext, R.layout.banner_mulit_point_layout, this);

        setGravity(Gravity.CENTER);
        MobwithSDK.initSDK(mContext);

        viewPager = findViewById(R.id.viewPager);
        dotLayout = findViewById(R.id.dotLayout);
    }

    /**
     * {@link #setBannerUnitIds(String[])}에서 설정된 유닛 ID를 기반으로
     * 개별 {@link MobwithPointBannerView} 인스턴스들을 생성하고 설정합니다.
     * {@link ViewPager2} 어댑터를 설정하고, 점 인디케이터를 생성하며, 페이지 변경 리스너를 등록합니다.
     */
    private void initUIDatas() {
        mPointBanners = new MobwithPointBannerView[mScriptNos.length];
        mRewardEnables = SpManager.getPointBannerStatus(mContext, mScriptNos.length);

        for (int i = 0; i < mScriptNos.length; i++) {
            mPointBanners[i] = new MobwithPointBannerView(mContext);
            mPointBanners[i].setBannerUnitId(mScriptNos[i]);
            mPointBanners[i].setPointEnable(mRewardEnables[i]);
            mPointBanners[i].setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            int finalI = i;
            mPointBanners[i].setAdListener(new iBannerCallback() {

                @Override
                public void onLoadedAdInfo(boolean result, String errorStr) {
                    if(!isSendedCallback && mCallback != null) {
                        LogPrint.d("onLoadedAdInfo[" + finalI+ "] : "+ result + ", " + errorStr);
                        mCallback.onLoadedAdInfo(result, errorStr);
                        isSendedCallback = true;
                    }
                }

                @Override
                public void onAdClicked() {
                    if(mCallback != null) {
                        mCallback.onAdClicked(finalI, mPointBanners[finalI].isRewarded());

                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                mPointBanners[finalI].loadAd();
                            }
                        }, 500);
                    }
                }
            });
        }

        viewPagerAdapter = new ViewPagerAdapter(mPointBanners);
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setOffscreenPageLimit(1);


        // Dot 생성
        createDots(mPointBanners.length);

        // ViewPager2 페이지 변경 리스너 설정
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);

                LogPrint.d("onPageSelected: " + position);
                updateDots(position);

                if(position + 1 < mPointBanners.length) {
                    mPointBanners[position + 1].setPointEnable(mRewardEnables[position + 1]);
                    mPointBanners[position + 1].loadAdIfNeed();
                }
            }
        });
    }

    /**
     * 배너의 개수만큼 하단에 점(dot) 인디케이터를 동적으로 생성합니다.
     * 생성된 점들은 {@link #dotLayout}에 추가됩니다.
     * @param count 생성할 점의 개수 (배너의 총 개수)
     */
    private void createDots(int count) {
        dotLayout.removeAllViews();

        dots = new ImageView[count];
        for (int i = 0; i < count; i++) {
            dots[i] = new ImageView(mContext);
            // 기본 dot은 비활성화 상태로 설정
            dots[i].setImageResource(R.drawable.dot_inactive);

            // LinearLayout에 추가
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(8, 0, 8, 0);
            dotLayout.addView(dots[i], params);
        }

        // 첫 번째 dot은 활성화 상태로 설정
        dots[0].setImageResource(R.drawable.dot_active);
    }

    /**
     * {@link ViewPager2}의 현재 페이지에 맞게 점 인디케이터의 상태(활성/비활성 이미지)를 업데이트합니다.
     * @param position 현재 활성화된 페이지의 인덱스
     */
    private void updateDots(int position) {
        for (int i = 0; i < dots.length; i++) {
            if (i == position) {
                dots[i].setImageResource(R.drawable.dot_active);  // 활성화된 dot
            } else {
                dots[i].setImageResource(R.drawable.dot_inactive);  // 비활성화된 dot
            }
        }
    }


    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        LogPrint.d("hasWindowFocus = " + hasWindowFocus);
        super.onWindowFocusChanged(hasWindowFocus);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }




    /**
     * {@link ViewPager2}에 {@link MobwithPointBannerView}들을 제공하기 위한 {@link RecyclerView.Adapter}의 구현체입니다.
     * 이 어댑터는 미리 생성된 {@link MobwithPointBannerView} 배열을 사용하여 각 페이지를 구성합니다.
     */
    static class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.ViewHolder> {

        private final MobwithPointBannerView[] pointBanners;


        public ViewPagerAdapter(MobwithPointBannerView[] views) {
            this.pointBanners = views;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // 이미 생성된 View를 사용하여 ViewHolder를 반환
            MobwithPointBannerView view = pointBanners[viewType];
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            // 현재는 미리 생성된 뷰이므로 특별한 바인딩은 필요하지 않음
        }

        @Override
        public int getItemViewType(int position) {
            // 배열 내에서 해당하는 position을 반환
            return position;
        }

        @Override
        public int getItemCount() {
            return pointBanners.length;
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(@NonNull MobwithPointBannerView itemView) {
                super(itemView);
            }
        }
    }

}

