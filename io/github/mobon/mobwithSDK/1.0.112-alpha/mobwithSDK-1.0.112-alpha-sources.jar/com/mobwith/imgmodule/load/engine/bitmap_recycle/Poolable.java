package com.mobwith.imgmodule.load.engine.bitmap_recycle;

interface Poolable {
  void offer();
}
