package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentResultListener;
import androidx.lifecycle.Lifecycle;

import com.kakao.adfit.ads.AdListener;
import com.kakao.adfit.ads.ba.BannerAdView;
import com.kakao.adfit.ads.na.AdFitAdInfoIconPosition;
import com.kakao.adfit.ads.na.AdFitBizBoardAdTemplateLayout;
import com.kakao.adfit.ads.na.AdFitMediaView;
import com.kakao.adfit.ads.na.AdFitNativeAdBinder;
import com.kakao.adfit.ads.na.AdFitNativeAdLayout;
import com.kakao.adfit.ads.na.AdFitNativeAdLoader;
import com.kakao.adfit.ads.na.AdFitNativeAdRequest;
import com.kakao.adfit.ads.na.AdFitNativeAdView;
import com.kakao.adfit.ads.na.AdFitVideoAutoPlayPolicy;
import com.kakao.adfit.ads.popup.AdFitPopupAd;
import com.kakao.adfit.ads.popup.AdFitPopupAdDialogFragment;
import com.kakao.adfit.ads.popup.AdFitPopupAdLoader;
import com.kakao.adfit.ads.popup.AdFitPopupAdRequest;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.R;
import com.mobwith.sdk.utils.MainThreadHandler;

/**
 * AdfitAdapter
 * AdfitAdapter는 Kakao Adfit 광고를 모바일 애플리케이션에 통합하기 위한 외부 SDK 어댑터 입니다.
 * 이 어댑터는 다양한 광고 형식을 지원하며, 광고 요청, 로드, 표시에 필요한 메서드를 제공합니다.
 */
public class AdfitAdapter extends AdapterObject {


    //bizBoardAd
    private AdFitBizBoardAdTemplateLayout bizBoardAdTemplateLayout;
    private AdFitNativeAdLoader bizBoardAdLoader;
    private AdFitNativeAdBinder bizBoardAdBinder;
    //NativeView
    private AdFitNativeAdLayout nativeAdLayout;
    private AdFitNativeAdLoader nativeAdLoader;
    private AdFitNativeAdBinder nativeAdBinder;
    private MediationAdListener mediationAdListener;
    //엔딩
    private AdFitPopupAdDialogFragment endingAdView;
    //전환
    private AdFitPopupAdLoader transitionAdLoader;
    private AdFitPopupAd mAdFitTransitionAd;
    private String mUnitId;
    private Context mContext;
    private AppCompatActivity activity;
    private boolean isTest;
    private Object adView;
    private BannerAdView mBannerAdView;
    private String mScriptNo;
    private String target;

    private String mBannerType = "";

    /**
     * 광고 유형, 단위 ID, 테스트 모드 등 광고 요청에 필요한 매개변수를 초기화합니다.
     */
    public AdfitAdapter(final Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);
        try {
            mUnitId = unitId;
            mContext = context;
            isTest = isTestMode;
            mScriptNo = siteNo;
            mBannerType = AdType;
            if (mContext instanceof AppCompatActivity){
                activity = (AppCompatActivity) mContext;
            }
            switch (AdType) {
                case BannerType.BANNER_BIZ_BOARD:

                    MainThreadHandler.post(() -> {
                        try {
                            mAdType = MediationAdSize.BANNER_BIZ_BOARD;
                            bizBoardAdLoader = AdFitNativeAdLoader.create(mContext, mUnitId);

                            int heightDp = 50;
                            if (TextUtils.equals(AdType, BannerType.BANNER_300x250)) {
                                heightDp = 250;
                            } else if (TextUtils.equals(AdType, BannerType.BANNER_320x100)) {
                                heightDp = 100;
                            }
                            int heightPx = Utils.convertDpToPx(mContext, heightDp);

                            bizBoardAdTemplateLayout = new AdFitBizBoardAdTemplateLayout(mContext); //기존 xml 파싱해서 붙이던 부분은 동작을 하지 않아서 제거.
                            bizBoardAdTemplateLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
//                        bizBoardAdTemplateLayout.setContentMaxHeight(heightPx);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                bizBoardAdTemplateLayout.setBackgroundColor(mContext.getColor(R.color.mobwith_sdk_kakaobiz_bg));        //corner 라운드 처리 제거
                            } else {
                                bizBoardAdTemplateLayout.setBackgroundColor(mContext.getResources().getColor(R.color.mobwith_sdk_kakaobiz_bg));
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });

                    break;
                case BannerType.INTERSTITIAL:
                case BannerType.ENDING:
                case BannerType.TRANSITION:
                    mAdType = MediationAdSize.INTERSTITIAL;
                    break;
                case BannerType.BANNER_ADFIT:
                    mAdType = MediationAdSize.BANNER_ADFIT;
                    break;
            }

            LogPrint.d("mAdType : " + mAdType);
            target = mAdType == MediationAdSize.BANNER_ADFIT ? "KAKAO_ADFIT" : "KAKAO_BIZ";
        } catch (Exception e){
            if (mediationAdListener != null){
                mediationAdListener.onAdFailedToLoad(e.getLocalizedMessage());
            }
        }
    }

    //광고 로드 성공, 실패, 클릭 등 광고 수명 주기 이벤트를 수신할 리스너를 설정합니다.
    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    /*
     * 네이티브 광고보기를 사용할 수 있는지 여부를 반환합니다.
     * 이 어댑터에서는 true를 반환합니다.
     * */
    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    /*
     * 지정된 유형의 광고를 로드합니다.
     * 광고 유형에 따라 BizBoard 광고, 전면 광고 또는 배너 광고를 로드합니다.
     * */
    public void load(String type) {
        super.load(type);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {

                if (mAdType == MediationAdSize.BANNER_BIZ_BOARD) {
                    if (bizBoardAdLoader == null) {
                        if (mediationAdListener != null)
                            mediationAdListener.onAdFailedToLoad("bizBoardAdLoader null");
                        return;
                    }
                    if (TextUtils.isEmpty(mUnitId)) {
                        if (mediationAdListener != null)
                            mediationAdListener.onAdFailedToLoad("bizBoardAd unitID null");
                        return;
                    }

                    AdFitNativeAdRequest request = new AdFitNativeAdRequest.Builder().setAdInfoIconPosition(AdFitAdInfoIconPosition.RIGHT_TOP).build();

                    bizBoardAdLoader.loadAd(request, new AdFitNativeAdLoader.AdLoadListener() {
                        @Override
                        public void onAdLoaded(@NonNull AdFitNativeAdBinder adFitNativeAdBinder) {
                            bizBoardAdBinder = adFitNativeAdBinder;
                            bizBoardAdBinder.setOnAdClickListener(new AdFitNativeAdBinder.OnAdClickListener() {
                                @Override
                                public void onAdClicked(View view) {
                                    if (mediationAdListener != null)
                                        mediationAdListener.onAdClicked();
                                }
                            });

                            bizBoardAdBinder.bind(bizBoardAdTemplateLayout);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdLoaded();
                            }
                            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                        }

                        @Override
                        public void onAdLoadError(int i) {
                            if (bizBoardAdLoader == null) {
                                return;
                            }

                            if (mContext instanceof AppCompatActivity)
                                if (((AppCompatActivity) mContext).getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED) {
                                    return;
                                }

                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad("bizBoardAd onAdLoadError : " + i);
                            }
                        }
                    });

                } else if (TextUtils.equals(type, BannerType.ENDING)) {
                    loadEndingAd();
                } else if (TextUtils.equals(type, BannerType.TRANSITION)) {
                    loadTransitionAd();
                } else if (mAdType == MediationAdSize.INTERSTITIAL || mAdType == MediationAdSize.INTERSTITIAL_POPUP) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("현재 지원하지 않는 유형입니다.");
                    }
                } else if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
                    loadNativeAd();
                } else {  //mAdType == MediationAdSize.BANNER_ADFIT
                    mBannerAdView = new BannerAdView(mContext);
                    mBannerAdView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    mBannerAdView.setClientId(mUnitId);
                    adView = mBannerAdView;

                    LogPrint.d("Load ad with AdFit from unit id is " + mUnitId);
                    mBannerAdView.setAdListener(new AdListener() {
                        @Override
                        public void onAdFailed(int errorCode) {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad("adfit errorCode : " + errorCode);
                            }
                        }

                        @Override
                        public void onAdLoaded() {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdLoaded();
                            }
                            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                        }

                        @Override
                        public void onAdClicked() {
                            if (mediationAdListener != null)
                                mediationAdListener.onAdClicked();
                        }
                    });

                    mBannerAdView.loadAd();
                }
            }
        }, 100);

//        sendImpression();
    }

    @Override
    public boolean show(@NonNull Activity mActivity) {
        if (!(mActivity instanceof AppCompatActivity)){
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToOpen("Need AppCompatActivity Context", getName());
            }
            return false;
        }
        return showAd((AppCompatActivity) mActivity);
    }

    @Override
    public boolean show() {
        try {
            if (activity == null) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen("Need AppCompatActivity Context", getName());
                }
                return false;
            }
            return showAd(activity);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean showAd(AppCompatActivity mActivity){
        if (mBannerType.equals(BannerType.ENDING) && endingAdView != null) {
            mActivity.getSupportFragmentManager().setFragmentResultListener(
                    AdFitPopupAdDialogFragment.REQUEST_KEY_POPUP_AD, // 이벤트를 식별하기 위한 고유 키
                    mActivity,
                    new FragmentResultListener() {
                        @Override
                        public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                            switch (result.getString(AdFitPopupAdDialogFragment.BUNDLE_KEY_EVENT_TYPE)) {
                                case AdFitPopupAdDialogFragment.EVENT_AD_CLICKED: {
                                    // TODO: 광고를 클릭한 경우에 대한 처리
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAdClicked();
                                    }
                                    endingAdView.dismiss();
                                    break;
                                }

                                case AdFitPopupAdDialogFragment.EVENT_POPUP_CANCELED: {
                                    // TODO: "취소"를 선택하거나 팝업을 취소한 경우에 대한 처리
                                    LogPrint.d("취소버튼 클릭");
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAdClosed();
                                    }
                                    break;
                                }

                                case AdFitPopupAdDialogFragment.EVENT_EXIT_CONFIRMED: {
                                    LogPrint.d("종료버튼 클릭");
                                    // TODO: "앱 종료"를 선택한 경우에 대한 처리
                                    // FIXME: 실제 앱 종료를 위한 처리
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAppFinish();
                                    }
                                    break;
                                }
                            }
                        }
                    }
            );
            endingAdView.show(mActivity.getSupportFragmentManager(), AdFitPopupAdDialogFragment.TAG);
            endingAdView = null;
            return true;
        } else if (mBannerType.equals(BannerType.TRANSITION) && mAdFitTransitionAd != null) {
            mActivity.getSupportFragmentManager().setFragmentResultListener(
                    AdFitPopupAdDialogFragment.REQUEST_KEY_POPUP_AD, // 이벤트를 식별하기 위한 고유 키
                    mActivity,
                    new FragmentResultListener() {
                        @Override
                        public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                            switch (result.getString(AdFitPopupAdDialogFragment.BUNDLE_KEY_EVENT_TYPE)) {
                                case AdFitPopupAdDialogFragment.EVENT_AD_CLICKED: {
                                    // TODO: 광고를 클릭한 경우에 대한 처리
                                    LogPrint.d("광고 클릭");
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAdClicked();
                                    }
                                    break;
                                }

                                case AdFitPopupAdDialogFragment.EVENT_POPUP_CANCELED: {
                                    // TODO: "취소"를 선택하거나 팝업을 취소한 경우에 대한 처리
                                    LogPrint.d("취소버튼 클릭");
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAdClosed();
                                    }
                                    break;
                                }

                                case AdFitPopupAdDialogFragment.EVENT_POPUP_DISMISSED: {
                                    LogPrint.d("닫기버튼 클릭");
                                    // TODO: "앱 종료"를 선택한 경우에 대한 처리
                                    // FIXME: 실제 앱 종료를 위한 처리
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAdClosed();
                                    }
                                    break;
                                }
                                case AdFitPopupAdDialogFragment.EVENT_TODAY_DISMISSED: {
                                    LogPrint.d("오늘 안보기 클릭");
                                    if (mediationAdListener != null) {
                                        mediationAdListener.onAdSkip();
                                    }
                                    break;
                                }
                            }
                        }
                    }
            );
            new AdFitPopupAdDialogFragment(mAdFitTransitionAd).show(mActivity.getSupportFragmentManager(), AdFitPopupAdDialogFragment.TAG);
            mAdFitTransitionAd = null;
            return true;
        } else {
            return false;
        }
    }

    /*
     * 광고와 관련된 리소스를 해제합니다.
     * 배너 광고 보기와 BizBoard 광고 바인더를 정리합니다.
     * */
    @Override
    public void destroy() {
        super.destroy();

        try {
            if (mBannerAdView != null) {
                mBannerAdView.destroy();
            }
        } catch (Exception e) {
            LogPrint.d("[AdfitAdapter] " + e.getLocalizedMessage());
        }

        try {
            if (bizBoardAdBinder != null) {
                bizBoardAdBinder.unbind(); // 노출 중인 광고가 있으면 해제
                bizBoardAdBinder = null;
            }
        } catch (Exception e) {
            LogPrint.d("[AdfitAdapter] " + e.getLocalizedMessage());
        }

        bizBoardAdLoader = null;
    }

    /*
     * 로드된 광고에 대한 보기 객체를 반환합니다.
     * BizBoard 광고 또는 일반 배너 광고일 수 있습니다.
     * */
    public Object getAdView() {
        if (mAdType == MediationAdSize.BANNER_BIZ_BOARD)
            return bizBoardAdTemplateLayout;
        else
            return adView;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mBannerAdView != null) {
            mBannerAdView.resume();
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        try {
            if (mBannerAdView != null) {
                mBannerAdView.pause();
            }
        } catch (Exception e) {
            LogPrint.d("[AdfitAdapter] " + e.getLocalizedMessage());
        }
    }

    public void loadEndingAd() {
        AdFitPopupAdLoader adFitPopupAdLoader = AdFitPopupAdLoader.create(mContext, mUnitId);
        adFitPopupAdLoader.loadAd(new AdFitPopupAdRequest.Builder(AdFitPopupAd.Type.Exit).build(), new AdFitPopupAdLoader.OnAdLoadListener() {
            @Override
            public void onAdLoaded(AdFitPopupAd adFitPopupAd) {
                endingAdView = new AdFitPopupAdDialogFragment(adFitPopupAd);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
            }

            @Override
            public void onAdLoadError(int i) {
                endingAdView = null;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("errorCode - " + i);
                }
            }
        });
    }

    public void loadTransitionAd() {
        transitionAdLoader = AdFitPopupAdLoader.create(mContext, mUnitId);

//        transitionAdLoader.clearRequestPoliciesForTest();

        transitionAdLoader.loadAd(new AdFitPopupAdRequest.Builder(AdFitPopupAd.Type.Transition).build(),
                new AdFitPopupAdLoader.OnAdLoadListener() {
                    @Override
                    public void onAdLoaded(AdFitPopupAd adFitPopupAd) {
                        mAdFitTransitionAd = adFitPopupAd;

                        if (mediationAdListener != null) {
                            mediationAdListener.onAdLoaded();
                        }
                    }

                    @Override
                    public void onAdLoadError(int i) {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdFailedToLoad("errorCode - " + i);
                        }
                    }
                }
        );
    }

    @Override
    public boolean isLoaded() {
        if (mBannerType.equals(BannerType.ENDING)) {
            return mAdType == MediationAdSize.INTERSTITIAL && endingAdView != null;
        } else if (mBannerType.equals(BannerType.TRANSITION)) {
            return mAdType == MediationAdSize.INTERSTITIAL && mAdFitTransitionAd != null;
        } else {
            return false;
        }
    }

    /*
     * 네이티브 광고를 로드합니다.
     * 광고 요청을 만들고 광고가 로드되면 광고 구성 요소(제목, 설명, 미디어 등)를 지정된 레이아웃에 바인딩합니다.
     * */
    @Override
    public void loadNativeAd() {
        if (mAdViewItem == null) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다.");
            }
            return;
        }

        nativeAdLoader = AdFitNativeAdLoader.create(mContext, mUnitId);
        AdFitNativeAdRequest request = new AdFitNativeAdRequest.Builder()
                .setAdInfoIconPosition(AdFitAdInfoIconPosition.RIGHT_TOP)
                .setVideoAutoPlayPolicy(AdFitVideoAutoPlayPolicy.WIFI_ONLY)
                .build();

        nativeAdLoader.loadAd(request, new AdFitNativeAdLoader.AdLoadListener() {
            @Override
            public void onAdLoaded(@NonNull AdFitNativeAdBinder binder) {
                try {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }

                    View inflatedView = LayoutInflater.from(mContext).inflate(mAdViewItem.mViewLayoutID, null);

                    ImageView logo = inflatedView.findViewById(mAdViewItem.mADLogoImageViewID);
                    TextView title = inflatedView.findViewById(mAdViewItem.mTitleViewID);
                    TextView desc = inflatedView.findViewById(mAdViewItem.mDescViewID);
                    FrameLayout mediaView = inflatedView.findViewById(mAdViewItem.mMediaViewContainerID);
                    View callToAction = inflatedView.findViewById(mAdViewItem.mGotoSiteViewID);

                    AdFitMediaView adFitMediaView = new AdFitMediaView(mContext);
                    mediaView.addView(adFitMediaView);

                    AdFitNativeAdLayout.Builder nativeAdBuilder = new AdFitNativeAdLayout.Builder(new AdFitNativeAdView(mContext))
                            .setTitleView(title) // 광고 제목 (필수)
                            .setMediaView(adFitMediaView); // 광고 미디어 소재 (이미지, 비디오) (필수)

                    if (desc != null) {
                        nativeAdBuilder.setBodyView(desc); // 광고 홍보문구
                    }

                    if (logo != null) {
                        nativeAdBuilder.setProfileIconView(logo); // 광고주 아이콘 (브랜드 로고)
                    }

                    if (callToAction != null) {
                        nativeAdBuilder.setCallToActionButton((Button) callToAction); // 행동유도버튼 (알아보기, 바로가기 등)
                    }

                    nativeAdLayout = nativeAdBuilder.build();

                    if (nativeAdBinder != null) {
                        // 이전에 노출 중인 광고가 있으면 해제
                        nativeAdBinder.unbind();
                    }

                    // 광고 노출
                    nativeAdBinder = binder;

                    binder.setOnAdClickListener((view -> {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClicked();
                        }
                    }));

                    binder.bind(nativeAdLayout);

                    mAdViewItem.mContainerView.removeAllViews();

                    AdFitNativeAdView adFitNativeAdView = nativeAdLayout.getContainerView();
                    adFitNativeAdView.addView(inflatedView);
                    mAdViewItem.mContainerView.addView(adFitNativeAdView);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }

                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());

                } catch (Exception e) {
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다. - " + e.getMessage());
                }
            }

            @Override
            public void onAdLoadError(int i) {
                LogPrint.d("[AdfitAdapter] onAdLoadError : " + i);
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다. - " + i);
                }
            }
        });
    }
}
