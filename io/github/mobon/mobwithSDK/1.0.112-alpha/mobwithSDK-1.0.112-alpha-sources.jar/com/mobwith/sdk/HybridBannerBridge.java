package com.mobwith.sdk;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mobwith.manager.LogPrint;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.api.MWRequestCustomURL;
import com.mobwith.sdk.api.MWRequestSendDspImpression;
import com.mobwith.sdk.api.MWRequestSendPassbackImpression;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.callback.InAppLandingCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

public class HybridBannerBridge {

    public interface OnAdListener extends InAppLandingCallback {
        void onAdLoaded();

        void onAdLoadedFail(String msg);

        @MainThread
        void onAdClicked(@NonNull String url);
    }

    private static final String TAG = "MobwithHybridBanner";
    private static final String JS_BRIDGE_NAME = "MobwithHybridBannerBridge";
    private static final Pattern PLACEMENT_ID_PATTERN = Pattern.compile("^[A-Za-z0-9_-]+$");

    private final Context mContext;
    private final WebView webView;
    private List<String> categories;
    private List<String> campaignCodes;
    private String userKey = "";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    private OnAdListener listener;

    private HybridBannerBridge(Context context, @NonNull WebView webView) {
        this.mContext = context.getApplicationContext(); // Context 누수 방지
        this.webView = webView;
    }

    @MainThread
    @NonNull
    public static HybridBannerBridge attach(@Nonnull Context context, @NonNull WebView webView) {
        HybridBannerBridge bridge = new HybridBannerBridge(context, webView);
        bridge.configureWebView();
        return bridge;
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadWithOverviewMode(true);
        webView.addJavascriptInterface(new AdBridge(), JS_BRIDGE_NAME);
    }

    public HybridBannerBridge setOnAdListener(@Nullable OnAdListener listener) {
        this.listener = listener;
        return this;
    }

    public HybridBannerBridge setCategory(List<String> categories) {
        this.categories = categories;
        return this;
    }

    public HybridBannerBridge setCampaignCodes(List<String> campaignCodes) {
        this.campaignCodes = campaignCodes;
        return this;
    }

    /**
     * 광고 HTML을 지정 placement 컨테이너에 주입한다.
     *
     * @param shouldRequestAd 페이지 로딩이 완료되면 즉시 광고 로딩을 시작하려면 true를, 광고를 수동으로 요청하려면 false를 파라미터로 전달합니다.
     *                        페이지 로드 완료(onPageFinished) 이후에 호출해야 한다.
     */
    @MainThread
    public void webViewFinishLoad(boolean shouldRequestAd) {
        injectRefreshScript();
        injectRelayScript();
        if (shouldRequestAd) {
            discoverSlots();
        }
    }

    public void destroy() {
        try {
            if (webView != null) {
                webView.removeJavascriptInterface(JS_BRIDGE_NAME);
//                // 아래는 payboc에서 직접 destroy()를 호출하여 재귀 호출로 인한 문제가 발생한 원인이 됨.
//                // 따라서 굳이 필요 없는 부분이며, webview의 final을 제거하고 null로 바꾸거나, 지금 주석친것처럼 아무것도 하지 않도록 하면 됨.
//                webView.destroy();
            }
            mainHandler.removeCallbacksAndMessages(null);
            listener = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    // ------------------------------------------------------------------
    // 내부 구현
    // ------------------------------------------------------------------

    /**
     * assets/mobwith_render.js를 읽어 플레이스홀더를 치환한 최종 JS를 반환한다.
     * 백그라운드 스레드에서 호출해야 한다.
     */
    @Nullable
    private String buildScript(String placementId, String html) {
        LogPrint.d("placementId : " + placementId);
        LogPrint.d("html : " + html);
        try (InputStream is = mContext.getAssets().open("mobwith_render.js");
             BufferedReader reader = new BufferedReader(
                     new InputStreamReader(is, StandardCharsets.UTF_8))) {

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

            return sb.toString()
                    .replace("__PLACEMENT_ID__", escapeJS(placementId))
                    .replace("__BRIDGE_NAME__", escapeJS(JS_BRIDGE_NAME))
                    .replace("__OS__", escapeJS("ANDROID"))
                    .replace("__HTML__", escapeJS(html));

        } catch (Exception e) {
            Log.e(TAG, "JS 로드 실패", e);
            return null;
        }
    }

    /**
     * JS 문자열 인젝션 방지용 이스케이프.
     */
    private String escapeJS(@Nullable String value) {
        if (value == null) return "";
        return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\"", "\\\"")
                .replace("`", "\\`")
                .replace("$", "\\$")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private void injectRefreshScript() {
        String script = "(function() {\n" +
                "    if (window.MobwithBridge) {" +
                "        return;" +
                "    }" +
                "    window.MobwithBridge = {" +
                "        refresh: function() {" +
                "            if (window." + JS_BRIDGE_NAME + " && window." + JS_BRIDGE_NAME + ".postMessage) {" +
                "                window." + JS_BRIDGE_NAME + ".postMessage(" +
                "                    JSON.stringify({" +
                "                        type: \"refresh\"" +
                "                    })" +
                "                );" +
                "            }" +
                "        }" +
                "    };" +
                "})();";
        webView.evaluateJavascript(script, null);
    }

    private void injectRelayScript() {
        String script =
                "(function() {" +
                        "  if (window.__mobwithRelayRegistered) return;" +
                        "  window.__mobwithRelayRegistered = true;" +
                        "  window.addEventListener('message', function(event) {" +
                        "    try {" +
                        "      var bridge = window." + JS_BRIDGE_NAME + ";" +
                        "      if (bridge && typeof bridge.postMessage === 'function') {" +
                        "        bridge.postMessage(JSON.stringify(event.data));" +
                        "      }" +
                        "    } catch(e) {" +
                        "      console.warn('[Mobwith Relay Error]', e);" +
                        "    }" +
                        "  });" +
                        "})();";

        webView.evaluateJavascript(script, null);
    }

    private void discoverSlots() {
        String js = "(function() {" +
                "            return JSON.stringify(" +
                "                Array.from(" +
                "                    document.querySelectorAll(" +
                "                        '.mobwith-banner'" +
                "                    )" +
                "                ).map(function(el) {" +
                "                    return {" +
                "                        placementId: el.getAttribute(\"data-placement-id-android\")," +
                "                        zoneType: el.getAttribute(\"data-zone-type\")," +
                "                        mediaId: el.getAttribute(\"data-media-id\")," +
                "                        serviceId: el.getAttribute(\"data-service-id\")" +
                "                    };" +
                "                })" +
                "            );" +
                "        })();";

        if (webView == null) {
            return;
        }

        webView.evaluateJavascript(js, value -> {
            if (value == null || "null".equals(value)) {
                return;
            }

            String json;
            try {
                json = new JSONObject("{\"v\":" + value + "}").getString("v");
            } catch (Exception e) {
                notifyFail(e.getLocalizedMessage());
                return;
            }

            try {
                LogPrint.d("json : " + json);
                List<HybridBridgeDTO> dto = new ArrayList<>();
                JSONArray array = new JSONArray(json);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    dto.add(new HybridBridgeDTO(
                            obj.optString("placementId", ""),
                            obj.optString("zoneType", ""),
                            obj.optString("mediaId", "mobwith"),
                            obj.optString("serviceId", "sdk")));
                }

                for (HybridBridgeDTO slot : dto) {
                    String placementId = slot.getPlacementId();
                    if (placementId == null) {
                        continue;
                    }

                    if (!PLACEMENT_ID_PATTERN.matcher(slot.getPlacementId()).matches()) {
                        LogPrint.d("잘못된 placementId: " + slot);
                    } else {
                        requestAd(slot);
                    }
                }
            } catch (Exception e) {
                notifyFail(e.getLocalizedMessage());
            }
        });
    }

    private void refreshAd() {
        try {
            String script = "(function() {" +
                    "                document.querySelectorAll('.mobwith-banner').forEach(function(el) {" +
                    "                   // ✅ iframe 내부의 teardown() 함수 호출 (NAM 광고 정리)\n" +
                    "                    try {\n" +
                    "                        if (typeof el.__mobwithCleanup === 'function') {\n" +
                    "                            console.log('[Teardown] Calling __mobwithCleanup for mobwith ad');\n" +
                    "                            el.__mobwithCleanup();\n" +
                    "                        }\n" +
                    "                    } catch (e) {\n" +
                    "                        console.log('[Teardown] __mobwithCleanup error:', e);\n" +
                    "                    }\n" +
                    "                    \n" +
                    "                    // ✅ 2. iframe 내부의 teardown() 함수 호출 (NAM 광고)\n" +
                    "                    try {\n" +
                    "                        const iframe = el.querySelector('iframe');\n" +
                    "                        if (iframe && iframe.contentWindow) {\n" +
                    "                            // teardown 함수가 있으면 호출\n" +
                    "                            if (typeof iframe.contentWindow.teardown === 'function') {\n" +
                    "                                console.log('[Teardown] Calling teardown for NAM ad');\n" +
                    "                                iframe.contentWindow.teardown();\n" +
                    "                            }\n" +
                    "                            // MutationObserver가 window에 저장되어 있으면 disconnect\n" +
                    "                            if (iframe.contentWindow.__namObserver) {\n" +
                    "                                console.log('[Teardown] Disconnecting NAM observer');\n" +
                    "                                iframe.contentWindow.__namObserver.disconnect();\n" +
                    "                                iframe.contentWindow.__namObserver = null;\n" +
                    "                            }\n" +
                    "                        }\n" +
                    "                    } catch (e) {\n" +
                    "                        console.log('[Teardown] Error during iframe cleanup:', e);\n" +
                    "                    }\n" +
                    "                    \n" +
                    "                    // ✅ 3. DOM 제거\n" +
                    "                    el.replaceChildren();" +
                    "                });" +
                    "            })();";
            mainHandler.post(() -> {
                webView.evaluateJavascript(script, new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        LogPrint.d("onReceiveValue value : ");
                        discoverSlots();
                    }
                });
            });
        } catch (Exception e) {
            LogPrint.d("refreshAd error : " + e.getLocalizedMessage());
        }
    }

    private void requestAd(HybridBridgeDTO slot) {
        try {
            StringBuilder campaignCode = new StringBuilder();
            StringBuilder demoDeviceCodes = new StringBuilder();

            if (campaignCodes != null) {
                for (int i = 0; i < campaignCodes.size(); i++) {
                    if (i == campaignCodes.size() - 1) {
                        campaignCode.append(campaignCodes.get(i));
                    } else {
                        campaignCode.append(campaignCodes.get(i)).append(",");
                    }
                }
            }

            if (categories != null) {
                for (int i = 0; i < categories.size(); i++) {
                    if (i == categories.size() - 1) {
                        demoDeviceCodes.append(categories.get(i));
                    } else {
                        demoDeviceCodes.append(categories.get(i)).append(",");
                    }
                }
            }

            Uri uri = Uri.parse(String.format(Url.REQUEST_BRIDGE_AD, Uri.encode(slot.getMediaId()), Uri.encode(slot.getServiceId())))
                    .buildUpon()
                    .appendQueryParameter("zone", slot.getPlacementId())
                    .appendQueryParameter("zone_type", slot.getZoneType())
                    .appendQueryParameter("userKey", userKey)
                    .appendQueryParameter("adid", SpManager.getString(mContext, Key.ADID))
                    .appendQueryParameter("os_type", "android")
                    .appendQueryParameter("demoDeviceCodes", demoDeviceCodes.toString())
                    .appendQueryParameter("campaignCodes", campaignCode.toString())
                    .build();

            MWRequestCustomURL.requestWith(mContext, uri.toString(), "HybridWeb", new MobWithApiCallback() {
                @Override
                public void onSuccess(String html) throws IOException {
                    LogPrint.d("response : ");
                    try {

                        String js = buildScript(slot.getPlacementId(), html);
                        mainHandler.post(() -> {
                            if (js == null) {
                                notifyFail("js is null");
                                return;
                            }
                            webView.evaluateJavascript(js, result -> {
                                LogPrint.d("inject result: " + result);
                                notifyLoaded();
                            });
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                        mainHandler.post(() -> notifyFail(e.getLocalizedMessage()));
                    }
                }

                @Override
                public void onFailure(IOException e) {
                    LogPrint.d("request failed: " + e.getLocalizedMessage());
                    mainHandler.post(() -> notifyFail(e.getLocalizedMessage()));
                }
            });
        } catch (Exception e) {
            mainHandler.post(() -> notifyFail(e.getLocalizedMessage()));
        }
    }

    private void notifyLoaded() {
        if (listener != null) listener.onAdLoaded();
    }

    private void notifyFail(String msg) {
        if (listener != null) listener.onAdLoadedFail(msg);
    }

    // ------------------------------------------------------------------
    // JS → Java 브릿지
    // ------------------------------------------------------------------

    private final class AdBridge {

        @JavascriptInterface
        public void postMessage(String message) {
            try {
                LogPrint.d("bridge message: " + message);
                JSONObject json = new JSONObject(message);
                String type = json.optString("type");

                switch (type) {
                    case "click":
                        handleClick(json);
                        break;
                    case "noad":
                        handleNOAD(json);
                        break;
                    case "refresh":
                        refreshAd();
                        break;
                    case "adLoaded":
                        LogPrint.d("adLoaded");
                        handleImpression(json);
                        break;
                }
            } catch (Exception e) {
                Log.e(TAG, "bridge parse error", e);
                mainHandler.post(() -> notifyFail(e.getLocalizedMessage()));
            }
        }

        private void handleClick(JSONObject json) {
            try {
                JSONObject detail = json.optJSONObject("detail");
                if (detail == null) {
                    String detailStr = json.optString("detail");
                    if (detailStr.isEmpty()) return;
                    detail = new JSONObject(detailStr);
                }

                String landingUrl = detail.optString("landingURL");
                if (landingUrl.isEmpty()) return;

                Utils.getBrowserPackageName(mContext, landingUrl, listener);

                final String finalUrl = landingUrl;
                mainHandler.post(() -> {
                    if (listener != null) listener.onAdClicked(finalUrl);
                });

            } catch (Exception e) {
                Log.e(TAG, "click handling error", e);
            }
        }

        private void handleNOAD(JSONObject json) {
            try {
                LogPrint.d("handleNoAd : " + json);
                JSONObject detail = json.optJSONObject("detail");
                if (detail == null) {
                    String detailStr = json.optString("detail");
                    if (detailStr.isEmpty()) return;
                    detail = new JSONObject(detailStr);
                }

                String zoneType = detail.optString("zone_type");
                String zone = detail.optString("zone");
                String source = detail.optString("source");

                clearAdWith(zone);

                if (source.startsWith("nam_fallback")) {
                    try {
                        mainHandler.post(() -> {
                            if (listener != null)
                                listener.onAdLoadedFail("zone : " + zone + " zoneType : " + zoneType);
                        });

                        JSONArray exlItlInfo = detail.optJSONArray("exlItlInfo");
                        if (exlItlInfo == null) {
                            return;
                        }

                        ArrayList<ExlItlInfoDTO> list = new ArrayList<>();
                        for (int i = 0; i < exlItlInfo.length(); i++) {
                            list.add(new ExlItlInfoDTO(
                                    exlItlInfo.optJSONObject(i).optString("sortlist"),
                                    exlItlInfo.optJSONObject(i).optString("unitId"),
                                    exlItlInfo.optJSONObject(i).optString("exlItlMemo"),
                                    exlItlInfo.optJSONObject(i).optString("exlItlSeq")
                            ));
                        }

                        NoAdDTO noAdDTO = new NoAdDTO(
                                detail.optString("zone"),
                                detail.optString("zone_type"),
                                detail.optString("width"),
                                detail.optString("height"),
                                detail.optString("advrtsPrdtCode"),
                                detail.optString("sessionId"),
                                list);
                        if (!noAdDTO.exlItlInfo.isEmpty()) {
                            sendPassBackImpression(mContext, noAdDTO.sessionId, noAdDTO.zone, noAdDTO.advrtsPrdtCode,
                                    noAdDTO.exlItlInfo.get(0).sortlist, noAdDTO.exlItlInfo.get(0).unitId, noAdDTO.exlItlInfo.get(0).exlItlSeq);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    JSONArray exlItlInfo = detail.optJSONArray("exlItlInfo");
                    if (exlItlInfo == null) {
                        return;
                    }

                    ArrayList<ExlItlInfoDTO> list = new ArrayList<>();
                    for (int i = 0; i < exlItlInfo.length(); i++) {
                        list.add(new ExlItlInfoDTO(
                                exlItlInfo.optJSONObject(i).optString("sortlist"),
                                exlItlInfo.optJSONObject(i).optString("unitId"),
                                exlItlInfo.optJSONObject(i).optString("exlItlMemo"),
                                exlItlInfo.optJSONObject(i).optString("exlItlSeq")
                        ));
                    }
                    NoAdDTO noAdDTO = new NoAdDTO(
                            detail.optString("zone"),
                            detail.optString("zone_type"),
                            detail.optString("width"),
                            detail.optString("height"),
                            detail.optString("advrtsPrdtCode"),
                            detail.optString("sessionId"),
                            list);

                    if (!noAdDTO.exlItlInfo.isEmpty()) {
                        String namAppKey = "";
                        String placementId = "";
                        if (!noAdDTO.exlItlInfo.get(0).unitId.isEmpty()) {
                            String[] tmp = noAdDTO.exlItlInfo.get(0).unitId.split("_");
                            if (tmp.length > 0) {
                                namAppKey = tmp[0];
                                placementId = tmp[1];
                            }
                        }
                        loadNamAds(namAppKey, placementId, noAdDTO);
                        sendDspImpression(mContext, noAdDTO.sessionId, noAdDTO.zone, noAdDTO.advrtsPrdtCode,
                                noAdDTO.exlItlInfo.get(0).sortlist, noAdDTO.exlItlInfo.get(0).unitId, noAdDTO.exlItlInfo.get(0).exlItlSeq);
                    } else {
                        mainHandler.post(() -> {
                            if (listener != null)
                                listener.onAdLoadedFail("zone : " + zone + " zoneType : " + zoneType);
                        });
                    }
                }


            } catch (Exception e) {
                Log.e(TAG, "click handling error", e);
            }
        }

        private void handleImpression(JSONObject json) {
            try {
                LogPrint.d("handleImpression : " + json);
                JSONObject detail = json.optJSONObject("detail");
                if (detail == null) {
                    String detailStr = json.optString("detail");
                    if (detailStr.isEmpty()) return;
                    detail = new JSONObject(detailStr);
                }

                String zone = detail.optString("zone");

                JSONArray exiItlInfo = detail.optJSONArray("exlItlInfo");
                if (exiItlInfo != null && exiItlInfo.length() > 0) {
                    String sortlist = exiItlInfo.optJSONObject(0).optString("sortlist");
                    String unitId = exiItlInfo.optJSONObject(0).getString("unitId");
                    String exlItlSeq = exiItlInfo.optJSONObject(0).optString("exlItlSeq");
                    sendAdSDKImpression(mContext, zone, sortlist, unitId, exlItlSeq);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void clearAdWith(String unitId) {
            String script = "";

            try (InputStream is = mContext.getAssets().open("remove_ad.js");
                 BufferedReader reader = new BufferedReader(
                         new InputStreamReader(is, StandardCharsets.UTF_8))) {

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }

                script = sb.toString().replace("__PLACEMENT_ID__", escapeJS(unitId));

            } catch (Exception e) {
                Log.e(TAG, "JS 로드 실패", e);
            }

            Log.e(TAG, "Clear AD =======================================================");
            Log.e(TAG, script);
            Log.e(TAG, "================================================================");

            try {
                String finalScript = script;
                mainHandler.post(() -> {
                    webView.evaluateJavascript(finalScript, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            LogPrint.d("[Clear AD] onReceiveValue value : ");
                        }
                    });
                });
            } catch (Exception e) {
                LogPrint.d("clear ad error : " + e.getLocalizedMessage());
            }
        }

        //        private void loadNamAds(final String zoneId, final String zoneType, String namAppKey,
//                                String placementId, String namPlacementId,
//                                String width, String height)
        private void loadNamAds(String namAppKey, String placementId, NoAdDTO noAdDTO) {

            String namAdHTML = readAssetToString("nam_ad.html");
            if (namAdHTML == null) {
                LogPrint.d("nam_ad.html 파일을 찾을 수 없습니다.");
                clearAdWith(noAdDTO.getZone());
                mainHandler.post(() -> notifyFail("not found html file"));
                return;
            }

            namAdHTML = namAdHTML
                    .replace("{{NAM_APP_KEY}}", namAppKey)
                    .replace("{{PLACEMENT_ID}}", placementId)
                    .replace("{{NAM_PLACEMENT_ID}}", noAdDTO.getExlItlInfo().get(0).getExlItlMemo())
                    .replace("{{ZONE_ID}}", noAdDTO.getZone())
                    .replace("{{ZONE_TYPE}}", noAdDTO.getZone_type())
                    .replace("{{BRIDGE_NAME}}", JS_BRIDGE_NAME)
                    .replace("{{PLATFORM}}", "Android")
                    .replace("{{IDFA}}", SpManager.getString(mContext, Key.ADID))
                    .replace("{{AD_WIDTH}}", noAdDTO.getWidth())
                    .replace("{{AD_HEIGHT}}", noAdDTO.getHeight())
                    .replace("{{SESSION_ID}}", noAdDTO.getSessionId())
                    .replace("{{ADVRTS_PRDT_CODE}}", noAdDTO.getAdvrtsPrdtCode())
                    .replace("{{SORTLIST}}", noAdDTO.getExlItlInfo().get(0).getSortlist())
                    .replace("{{UNIT_ID}}", noAdDTO.getExlItlInfo().get(0).getUnitId());

            LogPrint.d("Escaped HTML preview: "
                    + namAdHTML.substring(0, Math.min(500, namAdHTML.length())));

            // Base64 인코딩 (NO_WRAP 필수: 개행이 들어가면 JS 문자열이 깨집니다)
            String base64HTML = Base64.encodeToString(
                    namAdHTML.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);

            // 셀렉터에 들어갈 zoneId 이스케이프
            String safeZoneId = noAdDTO.getZone().replace("\\", "\\\\").replace("\"", "\\\"");

            final String js = " \n" +
                    "(function() {\n" +
                    "            const container = document.querySelector('.mobwith-banner[data-placement-id-android=\"" + safeZoneId + "\"]');\n" +
                    "            if (!container) {\n" +
                    "                console.log('[NAM] Container not found');\n" +
                    "                return;\n" +
                    "            }\n" +
                    "            \n" +
                    "            console.log('[NAM] Container found');\n" +
                    "            container.innerHTML = '';\n" +
                    "            \n" +
                    "            const iframe = document.createElement('iframe');\n" +
                    "            iframe.style.width = '100%';\n" +
                    "            iframe.style.border = 'none';\n" +
                    "            iframe.style.overflow = 'hidden';\n" +
                    "            iframe.style.display = 'block';\n" +
                    "            iframe.style.background = 'transparent';\n" +
                    "            iframe.style.height = '0';  // ✅ 초기 높이 0\n" +
                    "            \n\n" +
                    "            try {\n\n" +
                    "                const decoded = atob('" + base64HTML + "');\n\n" +
                    "                iframe.srcdoc = decoded;\n\n" +
                    "                container.appendChild(iframe);\n\n" +
                    "                \n\n" +
                    "                // ✅ iframe 로드 완료 후 높이 조절\n\n" +
                    "                iframe.addEventListener('load', function() {\n\n" +
                    "                    let lastHeight = 0;\n\n" +
                    "                    let stableCount = 0;\n\n" +
                    "                    let observer = null;\n\n" +
                    "                    \n\n" +
                    "                    function adjustHeight() {\n\n" +
                    "                        try {\n\n" +
                    "                            const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;\n\n" +
                    "                            \n\n" +
                    "                            // ✅ 내부 광고 iframe 찾기\n\n" +
                    "                            const adContainer = iframeDoc?.querySelector('#nam-ad-container');\n\n" +
                    "                            const innerIframe = adContainer?.querySelector('iframe');\n\n" +
                    "                            \n\n" +
                    "                            let height = 0;\n\n" +
                    "                            \n\n" +
                    "                            if (innerIframe && innerIframe.offsetHeight > 0) {\n\n" +
                    "                                // 실제 광고 iframe 높이 사용\n\n" +
                    "                                height = innerIframe.offsetHeight;\n\n" +
                    "                                console.log('[NAM] Using inner iframe height:', height);\n\n" +
                    "                            } else if (adContainer) {\n\n" +
                    "                                // 컨테이너 높이 사용\n\n" +
                    "                                height = adContainer.scrollHeight;\n\n" +
                    "                                console.log('[NAM] Using container height:', height);\n\n" +
                    "                            } else {\n\n" +
                    "                                // body 높이 사용 (fallback)\n\n" +
                    "                                const body = iframeDoc?.body;\n\n" +
                    "                                height = body?.scrollHeight || 0;\n\n" +
                    "                                console.log('[NAM] Using body height:', height);\n\n" +
                    "                            }\n\n" +
                    "                            \n\n" +
                    "                            if (height > 0 && height !== lastHeight) {\n\n" +
                    "                                iframe.style.height = height + 'px';\n\n" +
                    "                                container.style.height = height + 'px';\n\n" +
                    "                                console.log('[NAM] Iframe height adjusted to:', height);\n\n" +
                    "                                lastHeight = height;\n\n" +
                    "                                stableCount = 0;\n\n" +
                    "                            } else if (height === lastHeight && height > 0) {\n\n" +
                    "                                stableCount++;\n\n" +
                    "                                \n\n" +
                    "                                // ✅ 10회 안정화 후 observer 정리\n\n" +
                    "                                if (stableCount >= 10 && observer) {\n\n" +
                    "                                    console.log('[NAM] Height stabilized at', height, '- disconnecting observer');\n\n" +
                    "                                    observer.disconnect();\n\n" +
                    "                                    observer = null;" +
                    "                                }\n" +
                    "                            }\n" +
                    "                        } catch (e) {\n" +
                    "                           console.log('[NAM] Height adjustment error:', e);\n" +
                    "                        }\n" +
                    "                    }\n" +
                    "                    \n" +
                    "                    // 즉시 실행\n" +
                    "                    adjustHeight();\n" +
                    "                    \n" +
                    "                    // 0.5초, 1초, 2초 후에도 다시 체크 (광고 로딩 대기)\n" +
                    "                    setTimeout(adjustHeight, 500);\n" +
                    "                    setTimeout(adjustHeight, 1000);\n" +
                    "                    setTimeout(adjustHeight, 2000);\n" +
                    "                    \n" +
                    "                    // ✅ MutationObserver로 지속적 감시 (안정화 후 자동 정리)\n" +
                    "                    try {\n" +
                    "                        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;\n" +
                    "                        if (iframeDoc?.body) {\n" +
                    "                            observer = new MutationObserver(adjustHeight);\n" +
                    "                            observer.observe(iframeDoc.body, {\n" +
                    "                                childList: true,\n" +
                    "                                subtree: true,\n" +
                    "                                attributes: true\n" +
                    "                            });\n" +
                    "                            \n" +
                    "                            // ✅ 최대 5초 후 강제 정리\n" +
                    "                            setTimeout(function() {\n" +
                    "                                if (observer) {\n" +
                    "                                    console.log('[NAM] Force disconnecting observer after 5s');\n" +
                    "                                    observer.disconnect();\n" +
                    "                                    observer = null;\n" +
                    "                                }\n" +
                    "                            }, 5000);\n" +
                    "                        }\n" +
                    "                    } catch (e) {\n" +
                    "                        console.log('[NAM] MutationObserver setup failed:', e);\n" +
                    "                    }\n" +
                    "                });\n" +
                    "                \n" +
                    "                console.log('[NAM] Iframe with srcdoc added');\n" +
                    "            } catch (e) {\n" +
                    "                console.log('[NAM] Base64 decode error:', e);\n" +
                    "            }\n" +
                    "        })();";

            webView.post(new Runnable() {
                @Override
                public void run() {
                    webView.evaluateJavascript(js, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            LogPrint.d("NAM Ad JS Success: " + value);
                        }
                    });
                }
            });
        }

        private String readAssetToString(String fileName) {
            try (InputStream is = mContext.getAssets().open(fileName);
                 ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) != -1) {
                    bos.write(buf, 0, len);
                }
                return new String(bos.toByteArray(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                LogPrint.d("asset read error: " + e.getMessage());
                return null;
            }
        }

        private void sendPassBackImpression(Context context, String sessionId, String scriptNo, String advrtsPrdtCode, String exId, String unitId, String exlItlSeq) {
            MWRequestSendPassbackImpression.requestWith(context, scriptNo, exId, advrtsPrdtCode, sessionId, unitId, exlItlSeq);
        }

        private void sendDspImpression(Context context, String sessionId, String scriptNo, String advrtsPrdtCode, String exId, String unitId, String exlItlSeq) {
            LogPrint.d("!!!!!!!!!!!!!!!!!!!!!!  sendDspImpression " + exId);
            // 하이브리드(웹) 경로의 exlItlInfo 에 exlItlSeq 가 없으면 빈 값으로 전송된다.
            MWRequestSendDspImpression.requestWith(context, scriptNo, exId, advrtsPrdtCode, sessionId, unitId, exlItlSeq);
        }
    }

    public static class HybridBridgeDTO {
        private String placementId = "";
        private String zoneType = "";
        private String mediaId = "";
        private String serviceId = "";

        public HybridBridgeDTO(String placementId, String zoneType, String mediaId, String serviceId) {
            this.zoneType = zoneType;
            this.placementId = placementId;
            this.serviceId = serviceId;
            this.mediaId = mediaId;
        }

        public String getPlacementId() {
            return placementId;
        }

        public String getZoneType() {
            return zoneType;
        }

        public String getMediaId() {
            return mediaId;
        }

        public String getServiceId() {
            return serviceId;
        }
    }

    public static class NoAdDTO {
        private String zone = "";
        private String zone_type = "";
        private String width = "";
        private String height = "";
        private String sessionId = "";
        private String advrtsPrdtCode = "";
        private List<ExlItlInfoDTO> exlItlInfo = null;

        public NoAdDTO(String zone, String zone_type, String width, String height, String sessionId, String advrtsPrdtCode, List<ExlItlInfoDTO> exlItlInfo) {
            this.zone = zone;
            this.zone_type = zone_type;
            this.width = width;
            this.height = height;
            this.sessionId = sessionId;
            this.advrtsPrdtCode = advrtsPrdtCode;
            this.exlItlInfo = exlItlInfo;
        }

        public String getZone() {
            return zone;
        }

        public String getZone_type() {
            return zone_type;
        }

        public String getWidth() {
            return width;
        }

        public String getHeight() {
            return height;
        }

        public String getSessionId() {
            return sessionId;
        }

        public String getAdvrtsPrdtCode() {
            return advrtsPrdtCode;
        }

        public List<ExlItlInfoDTO> getExlItlInfo() {
            return exlItlInfo;
        }
    }

    public static class ExlItlInfoDTO {
        private String sortlist = "";
        private String unitId = "";
        private String exlItlMemo = "";
        private String exlItlSeq = "";

        public ExlItlInfoDTO(String sortlist, String unitId, String exlItlMemo) {
            this(sortlist, unitId, exlItlMemo, "");
        }

        public ExlItlInfoDTO(String sortlist, String unitId, String exlItlMemo, String exlItlSeq) {
            this.sortlist = sortlist;
            this.unitId = unitId;
            this.exlItlMemo = exlItlMemo;
            this.exlItlSeq = exlItlSeq;
        }

        public String getSortlist() {
            return sortlist;
        }

        public String getUnitId() {
            return unitId;
        }

        public String getExlItlMemo() {
            return exlItlMemo;
        }

        public String getExlItlSeq() {
            return exlItlSeq;
        }
    }
}