package com.mobwith.VastParser.adsplay;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;


import com.mobwith.VastParser.adsplay.util.HttpGetUtil;
import com.mobwith.VastParser.adsplay.util.VastTimeUtils;
import com.mobwith.VastParser.adsplay.util.XmlTools;
import com.mobwith.VastParser.adsplay.vast.model.TRACKING_EVENTS_TYPE;
import com.mobwith.VastParser.adsplay.vast.model.Tracking;
import com.mobwith.VastParser.adsplay.vast.model.VASTMediaFile;
import com.mobwith.VastParser.adsplay.vast.model.VASTModel;
import com.mobwith.VastParser.adsplay.vast.model.VideoClicks;
import com.mobwith.manager.LogPrint;

import org.w3c.dom.Document;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VastClient {


    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Handler mainThreadHandler = new Handler(Looper.getMainLooper());


    public interface VASTLoadListener {
        void onVASTLoaded();

        void onError(Exception e);
    }


    public long duration;
    public long skipOffset;
    public VideoClicks videoClicks;

    public ArrayList<Tracking> trackingList = new ArrayList<>();
    public List<VASTMediaFile> mediaFiles = new ArrayList<>();
    public List<String> impressions = new ArrayList<>();
    public List<String> errorUrls = new ArrayList<>();

    private boolean isSendedImpressions = false;


    public void parse(String vastURL, @NonNull final VASTLoadListener listener) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // Http 요청 실행
                    String xml = HttpGetUtil.get(vastURL);
                    parseXml(xml, listener);
                } catch (Exception e) {
                    mainThreadHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onError(e);
                        }
                    });
                }
            }
        });
    }

    public void parseXml(String vastXml, @NonNull final VASTLoadListener listener) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!vastXml.isEmpty()) {
                        // 문자열에서 Document 객체 생성
                        Document doc = XmlTools.stringToDocument(vastXml);

                        // VAST 모델 생성
                        final VASTModel vast = new VASTModel(doc);

                        duration = VastTimeUtils.convertTimeStrToIntValue(vast.getDuration());
                        skipOffset = VastTimeUtils.convertTimeStrToIntValue(vast.getSkipOffset());
                        videoClicks = vast.getVideoClicks();

                        trackingList = vast.getTrackingUrls();
                        mediaFiles = vast.getMediaFiles();
                        impressions = vast.getImpressions();
                        errorUrls = vast.getErrorUrl();

                        mainThreadHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onVASTLoaded();
                            }
                        });
                    } else {
                        mainThreadHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onError(new Exception("VAST XML is empty"));
                            }
                        });
                    }
                } catch (Exception e) {
                    mainThreadHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.onError(e);
                        }
                    });

                }
            }
        });
    }


    public void sendRequests(String url) {
        LogPrint.d("Vast Tracking : " + url);
        if (url == null || url.isEmpty()) {
            return;
        }
        executor.execute(new Runnable() {
            @Override
            public void run() {
                HttpGetUtil.sendRequest(url);
            }
        });
    }

    public String getMediaFileUrl() {
        if (mediaFiles != null && !mediaFiles.isEmpty()) {
            return mediaFiles.get(0).getValue();
        }

        return "";
    }

    public BigInteger getHeight() {
        if (mediaFiles != null && !mediaFiles.isEmpty()) {
            return mediaFiles.get(0).getHeight();
        }
        return BigInteger.valueOf(1920);
    }

    public BigInteger getWidth() {
        if (mediaFiles != null && !mediaFiles.isEmpty()) {
            return mediaFiles.get(0).getWidth();
        }

        return BigInteger.valueOf(1080);
    }


    public void sendImpression() {
        if (isSendedImpressions) {
            return;
        }
        isSendedImpressions = true;

        Log.d("VAST", "sendImpression Start : " + impressions.size());
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
            impressions.forEach(this::sendRequests);
        } else {
            for (int i = 0; i < impressions.size(); i++) {
                sendRequests(impressions.get(i));
            }
        }
        Log.d("VAST", "sendImpression End");
    }

    public void clickedVideo() {
        LogPrint.d("MixerVideo Clicked");
        // ClickThrough 값을 이용해서 랜딩 처리하므로, 해당 값은 별도로 request를 전송하지 않는다.
//        String clickThrough = videoClicks.getClickThrough();
//        sendRequests(clickThrough);

        List<String> clickTracking = videoClicks.getClickTracking();
        List<String> customClicks = videoClicks.getCustomClick();

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
            clickTracking.forEach(this::sendRequests);
            customClicks.forEach(this::sendRequests);
        } else {
            for (int i = 0; i < clickTracking.size(); i++) {
                sendRequests(clickTracking.get(i));
            }
            for (int i = 0; i < customClicks.size(); i++) {
                sendRequests(customClicks.get(i));
            }
        }
    }

    public String getClickThrough() {
        return videoClicks.getClickThrough();
    }

    public void sendError() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
            errorUrls.forEach(this::sendRequests);
        } else {
            for (int i = 0; i < errorUrls.size(); i++) {
                sendRequests(errorUrls.get(i));
            }
        }
    }


    public void skipAd() {
        for (Tracking tracking : trackingList) {
            if (tracking.isTracked) {
                continue;
            }

            if (Objects.requireNonNull(tracking.getEvent()) == TRACKING_EVENTS_TYPE.skip) {
                tracking.isTracked = true;
                sendRequests(tracking.getValue());
            }
        }
    }

    public void closeAd() {
        for (Tracking tracking : trackingList) {
            if (tracking.isTracked) {
                continue;
            }

            if (Objects.requireNonNull(tracking.getEvent()) == TRACKING_EVENTS_TYPE.close) {
                tracking.isTracked = true;
                sendRequests(tracking.getValue());
            }
        }
    }


    public void completeAd() {
        LogPrint.d("completeAd");
        for (Tracking tracking : trackingList) {
            if (tracking.isTracked) {
                continue;
            }

            if (Objects.requireNonNull(tracking.getEvent()) == TRACKING_EVENTS_TYPE.complete) {
                tracking.isTracked = true;
                sendRequests(tracking.getValue());
            }
        }
    }

    public void resetTracking() {
        for (Tracking tracking : trackingList) {
            tracking.isTracked = false;
        }
    }

    public void updateProgress(int progress) {

        for (Tracking tracking : trackingList) {
            if (tracking.isTracked) {
                continue;
            }

            switch (tracking.getEvent()) {
                case progress:
                    if (tracking.getOffset() <= progress) {
                        tracking.isTracked = true;
                        sendRequests(tracking.getValue());
                    }
                    break;
                case start:
                    tracking.isTracked = true;
                    sendRequests(tracking.getValue());
                    break;
                case midpoint:
                    if ((duration / 2) <= progress) {
                        tracking.isTracked = true;
                        sendRequests(tracking.getValue());
                    }
                    break;
                case firstQuartile:
                    if ((duration / 4) <= progress) {
                        tracking.isTracked = true;
                        sendRequests(tracking.getValue());
                    }
                    break;

                case thirdQuartile:
                    if ((duration / 4) * 3 <= progress) {
                        tracking.isTracked = true;
                        sendRequests(tracking.getValue());
                    }
                    break;

                default:
                    break;
            }
        }

    }

}
