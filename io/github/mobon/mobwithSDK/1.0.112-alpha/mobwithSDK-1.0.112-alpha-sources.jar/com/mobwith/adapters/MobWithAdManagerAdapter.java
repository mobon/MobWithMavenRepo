package com.mobwith.adapters;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.admanager.AdManagerAdView;
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd;
import com.google.android.gms.ads.admanager.AdManagerInterstitialAdLoadCallback;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.manager.nativeadview.NativeAdViewItem;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.CommonUtils;

import java.util.Map;

public class MobWithAdManagerAdapter extends AdapterObject {

    // 항상 테스트 광고를 내려주는 ID (Banner)  : ca-app-pub-3940256099942544/6300978111
    // 항상 테스트 광고를 내려주는 ID (전면광고) : ca-app-pub-3940256099942544/1033173712

    private boolean isInitialized = false;

    private final Context mContext;
    private final String mUnitId;
    private final String mScriptNo;

    private MediationAdListener mediationAdListener;
    public NativeAdViewItem mAdViewItem;
    private NativeAd mNativeAd;
    private NativeAdView mNativeAdView;
    private volatile boolean isDestroyed = false;

    private AdManagerAdView mAdView;
    private AdManagerInterstitialAd mInterstitial = null;
    private RewardedAd mRewardedAd;

    private boolean needLoadAd = false;
    private String loadAdType = "";

    public MobWithAdManagerAdapter(final Context context, String name, String unitId,
                                   String adType, boolean isTestMode,
                                   String siteNo) {
        super(name, unitId, adType, null, isTestMode);

        mContext = context;
        mUnitId = unitId;
        mScriptNo = siteNo;
        mAdType = mapAdType(adType);

        if (!isInitialized) {
            MobileAds.initialize(mContext, initializationStatus -> {
                isInitialized = true;
                logAdapterStatus(initializationStatus);
                loadPendingAd();
            });
        } else {
            loadPendingAd();
        }
    }

    private int mapAdType(String adType) {
        switch (adType) {
            case BannerType.INTERSTITIAL:
                return MediationAdSize.INTERSTITIAL;
            case BannerType.REWARD_VIDEO:
                return MediationAdSize.REWARD_VIDEO;
            case BannerType.BANNER_320x50:
            case BannerType.BANNER_320x100:
                return MediationAdSize.BANNER_320_50;
            case BannerType.BANNER_300x250:
                return MediationAdSize.BANNER_300_250;
            default:
                return mAdType;
        }
    }

    private void loadPendingAd() {
        if (needLoadAd) {
            load(loadAdType);
        }
    }

    public void logAdapterStatus(InitializationStatus initializationStatus) {
        // Check each adapter's initialization status.
        Map<String, AdapterStatus> statusMap = initializationStatus.getAdapterStatusMap();
        for (Map.Entry<String, AdapterStatus> entry : statusMap.entrySet()) {
            AdapterStatus status = entry.getValue();
            LogPrint.d("Adapter name: " + entry.getKey() + " , Description: " + status.getDescription() + ", Latency: " + status.getLatency());
        }
    }

    private void checkLoadedAdapter() {
        if (mRewardedAd == null) {
            return;
        }
        ResponseInfo responseInfo = mRewardedAd.getResponseInfo();
        String adapterClassName = responseInfo.getMediationAdapterClassName();
        LogPrint.e("adapterClassName : " + adapterClassName);
    }

    public void setAdListener(final MediationAdListener listener) {
        mediationAdListener = listener;
    }

    public void load(String type) {
        super.load(type);

        loadAdType = type;
        if (!isInitialized) {
            needLoadAd = true;
            return;
        }

        if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
            loadNativeAd();
        } else if (TextUtils.equals(type, BannerType.INTERSTITIAL)
                || TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP)) {
            loadInterstitialAd();
        } else if (TextUtils.equals(type, BannerType.ENDING)) {
            notifyFailed("해당 DSP에서는 지원하지 않는 기능 입니다.");
        } else if (TextUtils.equals(type, BannerType.REWARD_VIDEO)) {
            loadRewardAd();
        } else {
            loadBannerAd(type);
        }

    }

    private void loadInterstitialAd() {
        AdManagerInterstitialAd.load(mContext, mUnitId, new AdManagerAdRequest.Builder().build(),
                new AdManagerInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AdManagerInterstitialAd interstitialAd) {
                        mInterstitial = interstitialAd;
                        mInterstitial.setFullScreenContentCallback(fullScreenCallback);
                        notifyLoaded();
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mInterstitial = null;
                        notifyFailed(loadAdError.getMessage());
                    }
                });
    }

    private void loadBannerAd(String type) {
        mAdView = new AdManagerAdView(mContext);
        mAdView.setAdUnitId(mUnitId);
        mAdView.setAdSize(resolveBannerSize(type));
        mAdView.setAdListener(bannerAdListener);
        mAdView.loadAd(new AdManagerAdRequest.Builder().build());
    }

    private AdSize resolveBannerSize(String type) {
        if (TextUtils.equals(type, BannerType.BANNER_320x100)) {
            return AdSize.LARGE_BANNER;
        } else if (TextUtils.equals(type, BannerType.BANNER_300x250)) {
            return AdSize.MEDIUM_RECTANGLE;
        }
        return AdSize.BANNER;
    }

    private final AdListener bannerAdListener = new AdListener() {
        @Override
        public void onAdClicked() {
            if (mediationAdListener != null) {
                mediationAdListener.onAdClicked();
            }
        }

        @Override
        public void onAdClosed() {
            // 사용자가 광고를 탭한 뒤 앱으로 돌아올 때 호출.
            if (mediationAdListener != null) {
                mediationAdListener.onAdClosed();
            }
        }

        @Override
        public void onAdFailedToLoad(LoadAdError adError) {
            notifyFailed(adError.getMessage());
        }

        @Override
        public void onAdImpression() {
            // 노출이 기록될 때 호출.
            if (mediationAdListener != null) {
                mediationAdListener.onAdImpression();
            }
        }

        @Override
        public void onAdLoaded() {
            notifyLoaded();
        }

        @Override
        public void onAdOpened() {
            // 광고가 화면을 덮는 오버레이를 열 때 호출.
            if (mediationAdListener != null) {
                mediationAdListener.onAdDisplayed();
            }
        }
    };

    @Override
    public boolean show(@NonNull Activity activity) {
        if (mInterstitial != null) {
            mInterstitial.show(activity);
            return true;
        }

        if (mRewardedAd != null) {
            mRewardedAd.show(activity, rewardItem -> {
                if (mediationAdListener != null && rewardItem.getAmount() > 0) {
                    mediationAdListener.onAdComplete();
                }
            });
            return true;
        }

        return false;
    }

    @Override
    public boolean show() {
        if (!(mContext instanceof Activity)) {
            return false;
        }

        if (mInterstitial != null) {
            mInterstitial.show((Activity) mContext);
            return true;
        }

        if (mRewardedAd != null) {
            mRewardedAd.show((Activity) mContext, rewardItem -> {
                if (mediationAdListener != null && rewardItem.getAmount() > 0) {
                    mediationAdListener.onAdComplete();
                }
            });
            return true;
        }

        return false;
    }

    @Override
    public boolean isLoaded() {
        return mInterstitial != null || mRewardedAd != null;
    }

    @Override
    public void destroy() {
        super.destroy();
        isDestroyed = true;

        try {
            if (mAdView != null) {
                mAdView.destroy();
            }
        } catch (Exception e) {
            LogPrint.d("[MobWithAdmobAdapter] " + e.getLocalizedMessage());
        }
        mAdView = null;
        mInterstitial = null;
        mRewardedAd = null;

        destroyNativeAd();
        mAdViewItem = null;   // 컨테이너 View → Activity 참조 해제
    }

    private void destroyNativeAd() {
        try {
            if (mNativeAd != null) {
                MediaContent mc = mNativeAd.getMediaContent();
                if (mc != null && mc.hasVideoContent()) {
                    mc.getVideoController().setVideoLifecycleCallbacks(null);
                }
                mNativeAd.destroy();
            }
            if (mNativeAdView != null) {
                mNativeAdView.destroy();
            }
        } catch (Exception e) {
            LogPrint.d("[MobWithAdmobAdapter] destroyNativeAd : " + e.getLocalizedMessage());
        }
        mNativeAd = null;
        mNativeAdView = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        LogPrint.d("onResume");
        if (mAdView != null) {
            mAdView.resume();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            if (mAdView != null) {
                mAdView.pause();
            }
        } catch (Exception e) {
            LogPrint.d("[MobWithAdmobAdapter] " + e.getLocalizedMessage());
        }
    }

    public Object getAdView() {
        return mAdView;
    }

    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    @Override
    public void loadNativeAd() {
        new Thread(() -> {
            AdLoader adLoader = new AdLoader.Builder(mContext, mUnitId)
                    .forNativeAd(this::onNativeAdLoaded)
                    .withAdListener(new AdListener() {
                        @Override
                        public void onAdClicked() {
                            super.onAdClicked();
                            if (mediationAdListener != null){
                                mediationAdListener.onAdClicked();
                            }
                        }

                        @Override
                        public void onAdLoaded() {
                            super.onAdLoaded();
                            notifyLoaded();
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                            notifyFailed("광고를 불러오는데 실패하였습니다 - " + adError.getMessage());
                        }
                    })
                    .withNativeAdOptions(buildNativeAdOptions())
                    .build();

            adLoader.loadAd(new AdManagerAdRequest.Builder().build());
        }).start();
    }

    private NativeAdOptions buildNativeAdOptions() {
        return new NativeAdOptions.Builder()
                .setVideoOptions(new VideoOptions.Builder()
                        .setCustomControlsRequested(true)
                        .setClickToExpandRequested(false)
                        .setStartMuted(true)
                        .build())
                .build();
    }

    private void onNativeAdLoaded(@NonNull NativeAd nativeAd) {

        if (isDestroyed) {
            nativeAd.destroy();
            return;
        }

        if (mAdViewItem == null) {
            nativeAd.destroy();
            notifyFailed("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다.");
            return;
        }

        // 같은 어댑터로 재로드된 경우 이전 광고 정리
        destroyNativeAd();

        try {
            View inflatedView = LayoutInflater.from(mContext).inflate(mAdViewItem.mViewLayoutID, null);

            ImageView logo = inflatedView.findViewById(mAdViewItem.mADLogoImageViewID);
            TextView title = inflatedView.findViewById(mAdViewItem.mTitleViewID);
            TextView desc = inflatedView.findViewById(mAdViewItem.mDescViewID);
            FrameLayout mediaContainer = inflatedView.findViewById(mAdViewItem.mMediaViewContainerID);
            ImageView icon = inflatedView.findViewById(mAdViewItem.mADImageViewID);
            View callToAction = inflatedView.findViewById(mAdViewItem.mGotoSiteViewID);

            // 1) 텍스트/이미지 세팅
            bindNativeAssets(nativeAd, title, desc, logo, callToAction);

            // 2) MediaView 생성 + 컨테이너에 부착 (사이즈를 aspect ratio로 결정)
            MediaView admobMediaView = new MediaView(mContext);
            setupMediaView(nativeAd, admobMediaView, mediaContainer, icon);

            // 3) NativeAdView 구성: addView → 자식 등록 → setNativeAd 순서가 매우 중요
            NativeAdView nativeAdView = new NativeAdView(mContext);
            nativeAdView.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            // 3-1) inflatedView 를 먼저 NativeAdView 의 자식으로 부착
            nativeAdView.addView(inflatedView);

            // 3-2) 각 asset view 를 NativeAdView 에 등록 (MediaView 포함)
            nativeAdView.setMediaView(admobMediaView);
            if (title != null) nativeAdView.setHeadlineView(title);
            if (desc != null) nativeAdView.setBodyView(desc);
            if (logo != null) nativeAdView.setIconView(logo);
            if (callToAction != null) nativeAdView.setCallToActionView(callToAction);

            // 4) 컨테이너에 부착
            mAdViewItem.mContainerView.removeAllViews();
            mAdViewItem.mContainerView.addView(nativeAdView);

            // 3-3) 마지막에 NativeAd 바인딩 — 이 시점에 view tree 가 완성되어 있어야 함
            nativeAdView.setNativeAd(nativeAd);

            mNativeAd = nativeAd;
            mNativeAdView = nativeAdView;
        } catch (Exception e) {
            nativeAd.destroy();
            notifyFailed("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다. - " + e.getMessage());
        }
    }

    private void bindNativeAssets(NativeAd nativeAd, TextView title, TextView desc,
                                  ImageView logo, View callToAction) {
        if (title != null && nativeAd.getHeadline() != null) {
            title.setText(nativeAd.getHeadline());
        }
        if (desc != null && nativeAd.getBody() != null) {
            desc.setText(nativeAd.getBody());
        }
        if (logo != null && nativeAd.getIcon() != null) {
            if (nativeAd.getIcon().getDrawable() != null) {
                ImageModule.with(mContext).load(nativeAd.getIcon().getDrawable()).centerCrop().into(logo);
            } else if (nativeAd.getIcon().getUri() != null) {
                ImageModule.with(mContext).load(nativeAd.getIcon().getUri()).centerCrop().into(logo);
            }
        }
        if (callToAction != null && nativeAd.getCallToAction() != null) {
            if (callToAction instanceof Button) {
                ((Button) callToAction).setText(nativeAd.getCallToAction());
            } else if (callToAction instanceof TextView) {
                ((TextView) callToAction).setText(nativeAd.getCallToAction());
            }
        }
    }

    private void setupMediaView(NativeAd nativeAd, MediaView admobMediaView,
                                FrameLayout mediaContainer, ImageView icon) {
        final MediaContent mediaContent = nativeAd.getMediaContent();

        if (mediaContainer != null && mediaContent != null) {
            admobMediaView.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            mediaContainer.removeAllViews();
            mediaContainer.addView(admobMediaView);

            // 비디오 라이프사이클 콜백 (영상일 때만)
            if (mediaContent.hasVideoContent()) {
                VideoController videoController = mediaContent.getVideoController();
                videoController.setVideoLifecycleCallbacks(videoLifecycleCallbacks);
                // 직접 play() 호출하지 않음 — SDK 가 autoplay 정책에 따라 알아서 재생
            }
        } else if (icon != null && mediaContent != null && mediaContent.getMainImage() != null) {
            ImageModule.with(mContext).load(mediaContent.getMainImage()).centerCrop().into(icon);
        }
    }

    private final VideoController.VideoLifecycleCallbacks videoLifecycleCallbacks =
            new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoStart() {
                    LogPrint.d("Video started.");
                }

                @Override
                public void onVideoPlay() {
                    LogPrint.d("Video played.");
                }

                @Override
                public void onVideoPause() {
                    LogPrint.d("Video paused.");
                }

                @Override
                public void onVideoEnd() {
                    LogPrint.d("Video ended.");
                }

                @Override
                public void onVideoMute(boolean muted) {
                    LogPrint.d("Video isMuted: " + muted);
                }
            };

    private final FullScreenContentCallback fullScreenCallback = new FullScreenContentCallback() {
        @Override
        public void onAdClicked() {
            if (mediationAdListener != null) {
                mediationAdListener.onAdClicked();
            }
        }

        @Override
        public void onAdDismissedFullScreenContent() {
            mInterstitial = null;
            if (mediationAdListener != null) {
                mediationAdListener.onAdClosed();
            }
        }

        @Override
        public void onAdFailedToShowFullScreenContent(AdError adError) {
            mInterstitial = null;
            notifyFailed(adError.getMessage());
        }

        @Override
        public void onAdImpression() {
            if (mediationAdListener != null) {
                mediationAdListener.onAdImpression();
            }
        }

        @Override
        public void onAdShowedFullScreenContent() {
            if (mediationAdListener != null) {
                mediationAdListener.onAdDisplayed();
            }
        }
    };

    private void loadRewardAd() {
        RewardedAd.load(mContext, mUnitId, new AdManagerAdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        checkLoadedAdapter();
                        notifyLoaded();
                        mRewardedAd.setFullScreenContentCallback(fullScreenCallback);
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mRewardedAd = null;
                        notifyFailed(loadAdError.getMessage());
                    }
                });
    }

    private void notifyLoaded() {
        if (mediationAdListener != null) {
            mediationAdListener.onAdLoaded();
        }

        CommonUtils.sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
    }

    private void notifyFailed(String message) {
        if (mediationAdListener != null) {
            mediationAdListener.onAdFailedToLoad(message);
        }
    }
}