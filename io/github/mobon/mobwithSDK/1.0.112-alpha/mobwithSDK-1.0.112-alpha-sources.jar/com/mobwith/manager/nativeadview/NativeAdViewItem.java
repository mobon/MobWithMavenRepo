package com.mobwith.manager.nativeadview;

import android.content.Context;
import android.widget.FrameLayout;

import com.mobwith.manager.LogPrint;

public class NativeAdViewItem {

    public Context mContext = null;

    public FrameLayout mContainerView;

    public int mViewLayoutID;
    public int mMediaViewContainerID;
    public int mADImageViewID;
    public int mADLogoImageViewID;
    public int mTitleViewID;
    public int mDescViewID;
    public int mGotoSiteViewID;
    public int mInfoLogoImageViewContainerID;
    public int mInfoLogoImageViewID;


    public NativeAdViewItem(Context context,
                            FrameLayout containerView,
                            int viewLayoutID,
                            int mediaViewContainerID,
                            int adImageViewID,
                            int adLogoImageViewID,
                            int titleViewID,
                            int descriptionViewID,
                            int gotoSiteButtonID,
                            int infoLogoImageViewContainerID,
                            int infoLogoImageViewID) {
        mContext = context;
        mContainerView = containerView;
        mViewLayoutID = viewLayoutID;
        mMediaViewContainerID = mediaViewContainerID;
        mADImageViewID = adImageViewID;
        mADLogoImageViewID = adLogoImageViewID;
        mTitleViewID = titleViewID;
        mDescViewID = descriptionViewID;
        mGotoSiteViewID = gotoSiteButtonID;
        mInfoLogoImageViewContainerID = infoLogoImageViewContainerID;
        mInfoLogoImageViewID = infoLogoImageViewID;
    }


    public void print() {
        LogPrint.d("[NativeAdViewItem] mViewLayoutID : " + mViewLayoutID);
        LogPrint.d("[NativeAdViewItem] mMediaViewContainerID : " + mMediaViewContainerID);
        LogPrint.d("[NativeAdViewItem] mADImageViewID : " + mADImageViewID);
        LogPrint.d("[NativeAdViewItem] mADLogoImageViewID : " + mADLogoImageViewID);
        LogPrint.d("[NativeAdViewItem] mTitleViewID : " + mTitleViewID);
        LogPrint.d("[NativeAdViewItem] mDescViewID : " + mDescViewID);
        LogPrint.d("[NativeAdViewItem] mGotoSiteViewID : " + mGotoSiteViewID);
        LogPrint.d("[NativeAdViewItem] mInfoLogoImageViewContainerID : " + mInfoLogoImageViewContainerID);
        LogPrint.d("[NativeAdViewItem] mInfoLogoImageViewID : " + mInfoLogoImageViewID);
    }

}
