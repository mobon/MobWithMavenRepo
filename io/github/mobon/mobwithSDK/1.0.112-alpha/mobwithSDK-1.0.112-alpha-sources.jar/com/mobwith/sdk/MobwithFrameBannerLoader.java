//package com.mobwith.sdk;
//
//import android.content.Context;
//import android.os.Handler;
//import android.os.Looper;
//import android.text.TextUtils;
//import android.widget.FrameLayout;
//
//import com.mobwith.MobwithSDK;
//import com.mobwith.adapters.AdapterObject;
//import com.mobwith.manager.LogPrint;
//import com.mobwith.manager.MediationManager;
//import com.mobwith.manager.Utils;
//import com.mobwith.manager.iMobonMediationCallback;
//import com.mobwith.manager.nativeadview.NativeAdViewItemModel;
//import com.mobwith.sdk.api.MWRequestSortList;
//import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
//import com.mobwith.sdk.api.common.MWCommonRequestInterface;
//import com.mobwith.sdk.callback.iBannerCallback;
//import com.mobwith.sdk.models.MobwithAdCategoryModel;
//
//import org.json.JSONObject;
//
//import java.io.IOException;
//
//public class MobwithFrameBannerLoader implements MWCommonRequestInterface {
//
//    private static volatile MobwithFrameBannerLoader instance;
//
//    // Application Context 로 보관해 Activity 누수 방지
//    private final Context mContext;
//    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
//
//    // 기존에 static 이던 상태값들을 인스턴스 필드로 변경 (누수/인스턴스 간 오염 방지)
//    private boolean isInit = false;
//    private boolean isLoaded = false;
//
//    private String mSessionId = "";
//    private String mUnitId;
//    private iBannerCallback mIBannerAdCallback;
//    private AdapterObject mAdapter;
//    private MobwithAdCategoryModel mobwithAdCategoryModel;
//    private MediationManager mediationManager;
//
//    private MobwithFrameBannerLoader(Context context) {
//        // Activity Context 가 전달돼도 누수되지 않도록 Application Context 사용
//        mContext = context.getApplicationContext();
//    }
//
//    public static void init(Context context) {
//        getInstance(context);
//        MobwithSDK.initSDK(context);
//        instance.isInit = true;
//    }
//
//    /** 권장: Context 를 받는 진입점 */
//    public static MobwithFrameBannerLoader getInstance(Context context) {
//        if (instance == null) {
//            synchronized (MobwithFrameBannerLoader.class) {
//                if (instance == null) {
//                    instance = new MobwithFrameBannerLoader(context);
//                }
//            }
//        }
//        return instance;
//    }
//
//    /** 기존 호출부 호환용 (init/getInstance(context) 이후에만 유효) */
//    public static MobwithFrameBannerLoader getInstance() {
//        return instance;
//    }
//
//    public boolean isInitialized() {
//        return isInit;
//    }
//
//    public boolean isLoaded() {
//        return isLoaded;
//    }
//
//    public void setCategory(MobwithAdCategoryModel model) {
//        this.mobwithAdCategoryModel = model;
//    }
//
//    public void setUnitId(String unitId) {
//        this.mUnitId = unitId;
//    }
//
//    public void setListener(iBannerCallback iBannerAdCallback) {
//        this.mIBannerAdCallback = iBannerAdCallback;
//    }
//
//    public void loadAd() {
//        mSessionId = "";
//        isLoaded = false;
//
//        // 새 요청 전에 이전 미디에이션 리소스 해제
//        releaseMediation();
//
//        if (!Utils.isConnectNetwork(mContext)) {
//            LogPrint.d("banner loadAd noConnectNetwork");
//            notifyLoaded(false, "noConnectNetwork");
//            return;
//        }
//
//        if (TextUtils.isEmpty(mUnitId)) {
//            notifyLoaded(false, "No UnitId");
//            return;
//        }
//
//        MWRequestSortList mwRequestSortList = new MWRequestSortList(mContext, mUnitId);
//        mwRequestSortList.execute(new MobWithApiCallback() {
//            @Override
//            public void onSuccess(String response) throws IOException {
//                LogPrint.d("onResponse : " + response);
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//
//                    if (!TextUtils.equals(jsonObject.optString("code"), "01")) {
//                        notifyLoaded(false, jsonObject.optString("message"));
//                        return;
//                    }
//
//                    mSessionId = jsonObject.optString("sessionId");
//
//                    final JSONObject dataObject = jsonObject.getJSONObject("data");
//                    final String advrtsPrdtCode = dataObject.optString("advrtsPrdtCode");
//
//                    sendSortListImpression(mContext, mUnitId, advrtsPrdtCode, mSessionId);
//
//                    mediationManager = new MediationManager(
//                            mContext, dataObject, BannerType.NATIVE_AD,
//                            mobwithAdCategoryModel, null, true);
//
//                    mediationManager.LoadMediation(new iMobonMediationCallback() {
//                        @Override
//                        public void onLoadedAdData(String data, AdapterObject adapter) {
//                            LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
//                        }
//
//                        @Override
//                        public void onAdAdapter(AdapterObject adapter) {
//                            if (adapter != null) {
//                                mAdapter = adapter;
//                                isLoaded = true;
//                                notifyLoaded(true, "");
//                            } else {
//                                isLoaded = false;
//                                notifyLoaded(false, Key.NOFILL);
//                            }
//                        }
//
//                        @Override
//                        public void onAdRequest(String adapterName) {
//                            sendDspImpression(mContext, mSessionId, mUnitId, advrtsPrdtCode, adapterName);
//                        }
//
//                        @Override
//                        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
//                            isLoaded = false;
//                            if (adapter != null) {
//                                LogPrint.d("onAdFailedToLoad : " + adapter.getName());
//                            } else {
//                                LogPrint.d("onAdFailedToLoad : [Null Adapter] " + errorMsg);
//                            }
//                            notifyLoaded(false, Key.NOFILL);
//                        }
//
//                        @Override
//                        public void onAdFailedAdapterName(String adapterName) {
//                            sendPassBackImpression(mContext, mSessionId, mUnitId, advrtsPrdtCode, adapterName);
//                        }
//
//                        @Override
//                        public void onAdClicked() {
//                            LogPrint.d("onAdClicked");
//                            if (mIBannerAdCallback != null) {
//                                mIBannerAdCallback.onAdClicked();
//                            }
//                        }
//
//                        @Override public void onAdImpression() { }
//                        @Override public void onAppFinish() { }
//                        @Override public void onAdDisplayed() { }
//                        @Override public void onAdComplete() { }
//                        @Override public void onAdSkip() { }
//                        @Override public void onAdClosed() { }
//                        @Override public void onAdCancel() { }
//                        @Override public void onAdFailedToOpen() { }
//                    });
//
//                } catch (Exception e) {
//                    isLoaded = false;
//                    notifyLoaded(false, e.getLocalizedMessage());
//                }
//            }
//
//            @Override
//            public void onFailure(IOException e) {
//                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());
//                isLoaded = false;
//                notifyLoaded(false, e.getLocalizedMessage());
//            }
//        });
//    }
//
//    public void getNativeAdView(Context context,
//                                FrameLayout containerView,
//                                int viewLayoutID,
//                                int mediaViewContainerID,
//                                int adImageViewID,
//                                int adLogoImageViewID,
//                                int titleViewID,
//                                int descriptionViewID,
//                                int gotoSiteButtonID,
//                                int infoLogoViewContainerID,
//                                int infoLogoImageViewID) {
//        if (mAdapter == null) {
//            isLoaded = false;
//            notifyLoaded(false, "adapter is null");
//            return;
//        }
//        try {
//            MobwithFrameBannerView bannerView = new MobwithFrameBannerView(
//                    context, mUnitId, containerView,
//                    viewLayoutID, mediaViewContainerID, adImageViewID, adLogoImageViewID,
//                    titleViewID, descriptionViewID, gotoSiteButtonID,
//                    infoLogoViewContainerID, infoLogoImageViewID);
//            bannerView.preLoadAd(mAdapter);
//        } catch (Exception e) {
//            LogPrint.d("getNativeAdView Exception : " + e.getMessage());
//            notifyLoaded(false, "NO AD View - " + e.getMessage());
//        }
//    }
//
//    public void getNativeAdView(Context context,
//                                FrameLayout containerView,
//                                NativeAdViewItemModel directAdViewItemModel,
//                                NativeAdViewItemModel nativeAdViewItemModel) {
//        if (mAdapter == null) {
//            isLoaded = false;
//            notifyLoaded(false, "adapter is null");
//            return;
//        }
//        try {
//            MobwithFrameBannerView bannerView = new MobwithFrameBannerView(
//                    context, mUnitId, containerView,
//                    directAdViewItemModel, nativeAdViewItemModel);
//            bannerView.setAdListener(mIBannerAdCallback);
//            bannerView.preLoadAd(mAdapter);
//        } catch (Exception e) {
//            isLoaded = false;
//            LogPrint.d("getNativeAdView Exception : " + e.getMessage());
//            notifyLoaded(false, "NO AD View - " + e.getMessage());
//        }
//    }
//
//    // ---------------------------------------------------------------------
//    // 리소스 정리
//    // ---------------------------------------------------------------------
//
//    /**
//     * 진행 중인 미디에이션/어댑터 리소스만 해제한다.
//     * (재로딩 시 또는 화면 전환 시 호출)
//     */
//    public void releaseMediation() {
//        if (mediationManager != null) {
//            try {
//                mediationManager.release();
//            } catch (Throwable t) {
//                LogPrint.d("releaseMediation error : " + t.getMessage());
//            }
//            mediationManager = null;
//        }
//        if (mAdapter != null) {
//            try {
//                mAdapter.destroy();
//            } catch (Throwable t) {
//                LogPrint.d("adapter destroy error : " + t.getMessage());
//            }
//            mAdapter = null;
//        }
//        isLoaded = false;
//    }
//
//    /**
//     * 모든 리소스를 해제하고 콜백/상태 참조를 끊는다.
//     * Activity/Fragment 의 onDestroy() 에서 호출 권장.
//     */
//    public void destroy() {
//        releaseMediation();
//        mMainHandler.removeCallbacksAndMessages(null);
//        mIBannerAdCallback = null;
//        mobwithAdCategoryModel = null;
//        mSessionId = "";
//        mUnitId = null;
//    }
//
//    /**
//     * 싱글톤 인스턴스 자체까지 폐기한다.
//     * SDK 종료 시점에만 사용.
//     */
//    public static void clearInstance() {
//        synchronized (MobwithFrameBannerLoader.class) {
//            if (instance != null) {
//                instance.destroy();
//                instance.isInit = false;
//                instance = null;
//            }
//        }
//    }
//
//    // ---------------------------------------------------------------------
//    // 공통 콜백 헬퍼 (항상 메인 스레드에서 전달, null 가드 일원화)
//    // ---------------------------------------------------------------------
//    private void notifyLoaded(final boolean success, final String message) {
//        final iBannerCallback callback = mIBannerAdCallback;
//        if (callback == null) return;
//        mMainHandler.post(() -> callback.onLoadedAdInfo(success, message));
//    }
//}