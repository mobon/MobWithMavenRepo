package com.mobwith.sdk;

import static android.content.Context.POWER_SERVICE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.ScriptAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestReloadInterval;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.custom.rewarded.AffordanceStyle;
import com.mobwith.sdk.custom.rewarded.AffordanceView;
import com.mobwith.sdk.custom.rewarded.AffordanceViewManager;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.MobwithConfigModel;
import com.mobwith.sdk.models.MobwithConfigResponseModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.models.reward.MWRewardBannerModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

/**
 * 다양한 형식의 배너 광고를 표시하기 위한 커스텀 View 입니다.
 * Mobwith SDK의 일부로, 광고 요청, 로드, 수명 주기 관리, 그리고 사용자 상호작용 처리를 담당합니다.
 * 이 클래스는 여러 광고 네트워크와의 미디에이션을 지원하며,
 * 광고 로드 성공, 실패, 클릭 등의 이벤트를 처리하기 위한 콜백 인터페이스를 제공합니다.
 */
public class MobwithBannerView extends RelativeLayout implements MWCommonRequestInterface {

    // region Constants
    private static final int MIN_INTERVAL = 60;
    private static final int SERVER_INTERVAL_UNSET = -999;
    private static final int MAX_WAIT_COUNT = 100;
    private static final String COUPANG_HOUSE_LINK = "https://link.coupang.com/a/coFZKR";

    private static final String SIZE_300_250 = "300px*250px";
    private static final String SIZE_320_100 = "320px*100px";
    private static final String SIZE_320_50 = "320px*500px";

    private static final int[] HOUSE_IMAGES_300_250 = {
            R.drawable.mobwith_house_300_250_1,
            R.drawable.mobwith_house_300_250_2,
            R.drawable.mobwith_house_300_250_3,
            R.drawable.mobwith_house_300_250_4,
            R.drawable.mobwith_house_300_250_5
    };
    private static final int[] HOUSE_IMAGES_320_100 = {
            R.drawable.mobwith_house_320_100_1,
            R.drawable.mobwith_house_320_100_2,
            R.drawable.mobwith_house_320_100_3,
            R.drawable.mobwith_house_320_100_4,
            R.drawable.mobwith_house_320_100_5
    };
    private static final int[] HOUSE_IMAGES_320_50 = {
            R.drawable.mobwith_house_320_50_1,
            R.drawable.mobwith_house_320_50_2,
            R.drawable.mobwith_house_320_50_3,
            R.drawable.mobwith_house_320_50_4,
            R.drawable.mobwith_house_320_50_5
    };
    // endregion

    public interface OnCloseListener {
        void onAdClosed();
    }

    // region Fields
    private final Context mContext;

    private iBannerCallback mIBannerAdCallback = null;
    private OnCloseListener mOnCloseListener;

    private MediationManager mediationManager;
    private AdapterObject mBannerAdapter;
    private AdapterObject oldAdapter = null;
    private MobwithAdCategoryModel mobwithAdCategoryModel;

    private boolean sendSuccessCallback;
    private boolean sendFailCallback;
    private String mSessionId;
    private String mScriptNo;

    //리워드 배너
    private String advrtsPrdtCode = "";
    private MWRewardBannerModel rewardBannerModel;
    private boolean isRewardBanner = false;

    private String userKey = "";
    private String mediaId = "";
    private String serviceId = "";

    private int mInterval = 0;
    private int mServerInterval = SERVER_INTERVAL_UNSET;
    private long prev_scheduleTime;
    private int waitCount;
    private boolean isPaused = false;
    private Handler mScheduleHandler;
    private boolean viewVisible;
    private boolean isInLoading;
    private List<String> categorys;
    public boolean isPointBanner;

    private ImageView mHouseBannerView;
    private ImageView mCloseImage;
    private FrameLayout mCloseLayout;
    private boolean useHouseBanner = false;
    private boolean isShowCloseBtn = false;

    private int containerDp = -1;
    private float adScale = 1.0f;
    // endregion

    // region Constructors

    /**
     * 코드에서 MobwithBannerView를 동적으로 생성할 때 사용되는 생성자입니다.
     */
    public MobwithBannerView(Context context) {
        super(context);
        this.mContext = context;
        this.isInLoading = false;
        setGravity(Gravity.CENTER);
        onInit();
    }

    /**
     * XML 레이아웃 파일에서 MobwithBannerView를 사용할 때 호출되는 생성자입니다.
     */
    public MobwithBannerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        this.isInLoading = false;
    }

    /**
     * XML 레이아웃 파일에서 MobwithBannerView를 사용하며, 기본 스타일을 적용할 때 호출되는 생성자입니다.
     */
    public MobwithBannerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        this.isInLoading = false;
    }

    public MobwithBannerView(Context context, String _adType) {
        super(context);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }
    // endregion

    // region Public configuration (chainable)

    /**
     * 배너 광고의 Unit ID(광고 단위 ID)를 설정합니다.
     */
    public MobwithBannerView setBannerUnitId(String unitId) {
        mScriptNo = unitId;
        return this;
    }

    /**
     * 첫 광고 로딩 중 또는 광고가 없는 경우 하우스 배너를 표시할지를 결정합니다.
     * false로 설정하면 표시 중인 하우스 배너도 제거됩니다.
     */
    public MobwithBannerView setUseHouseBanner(boolean isUse) {
        this.useHouseBanner = isUse;

        if (mHouseBannerView != null && mHouseBannerView.getParent() != null) {
            mHouseBannerView.setVisibility(View.GONE);
            removeView(mHouseBannerView);
            mHouseBannerView = null;
        }
        return this;
    }

    public MobwithBannerView setCloseBtn(OnCloseListener onCloseListener) {
        isShowCloseBtn = true;
        this.mOnCloseListener = onCloseListener;
        return this;
    }

    /**
     * 광고 새로고침 간격(interval)을 설정합니다.
     * 설정된 간격이 MIN_INTERVAL보다 작으면 MIN_INTERVAL로 강제 설정됩니다. (0은 예외)
     */
    public MobwithBannerView setInterval(int interval) {
        if (interval != 0 && interval < MIN_INTERVAL) {
            mInterval = MIN_INTERVAL;
        } else {
            mInterval = interval;
        }
        return this;
    }

    /**
     * 광고 카테고리 모델을 설정합니다.
     */
    public MobwithBannerView setMobwithAdCategoryModel(MobwithAdCategoryModel mobwithAdCategoryModel) {
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        return this;
    }

    /**
     * 배너 광고 리스너(콜백)를 설정합니다.
     */
    public MobwithBannerView setAdListener(iBannerCallback pMobonAdCallback) {
        mIBannerAdCallback = pMobonAdCallback;
        return this;
    }

    /**
     * 스크립트 광고의 사이즈를 조절합니다.
     *
     * @param containerDp 설정한 ContainerView의 Height dp값
     */
    public MobwithBannerView setAdScale(int containerDp) {
        this.containerDp = containerDp;
        return this;
    }


    public MobwithBannerView setUserKey(String userKey) {
        this.userKey = userKey;
        return this;
    }

    public MobwithBannerView setServiceId(String serviceId) {
        this.serviceId = serviceId;
        return this;
    }

    public MobwithBannerView setMediaId(String mediaId) {
        this.mediaId = mediaId;
        return this;
    }

    /**
     * 리워드 배너의 적립 어포던스 배지 노출 설정(위치 / 크기 / 텍스트 / 배경색)을 지정합니다.
     *
     * <p>설정은 <b>이 배너뷰에만</b> 적용되며, 네이티브 광고 등 다른 광고뷰에는 영향을 주지 않습니다.
     * 광고 로드 전에 호출해도 되고, 로드 후 호출하면 즉시 반영됩니다.</p>
     *
     * @param style 적용할 스타일. null 이면 SDK 기본값으로 되돌립니다
     */
    public MobwithBannerView setAffordanceStyle(AffordanceStyle style) {
        AffordanceViewManager.getInstance().setStyle(this, style);
        return this;
    }
    // endregion

    // region View lifecycle overrides
    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        LogPrint.d("onWindowVisibilityChanged = " + visibility);

        if (mBannerAdapter != null) {
            if (visibility == View.GONE) {
                viewVisible = false;
                mBannerAdapter.onPause();
            } else if (visibility == View.VISIBLE) {
                viewVisible = true;
                mBannerAdapter.onResume();
            }
        }
        super.onWindowVisibilityChanged(visibility);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        LogPrint.d("hasWindowFocus = " + hasWindowFocus);
        super.onWindowFocusChanged(hasWindowFocus);
    }

    private void onInit() {
        MobwithSDK.initSDK(mContext);
        advrtsPrdtCode = "";
        rewardBannerModel = null;
    }
    // endregion

    // region Refresh scheduling

    /**
     * 실제 적용될 광고 새로고침 간격(초)을 반환합니다.
     * 서버 간격이 유효하면 우선하고, 아니면 사용자 설정 간격을 사용합니다.
     */
    private int getRealInterval() {
        int realInterval;
        if (mServerInterval >= 0) {
            realInterval = (mServerInterval != 0 && mServerInterval < MIN_INTERVAL)
                    ? MIN_INTERVAL : mServerInterval;
        } else {
            realInterval = mInterval;
        }
        LogPrint.d("getRealInterval : " + realInterval);
        return realInterval;
    }

    private void bannerSchedule() {
        if (mScheduleHandler == null) {
            LogPrint.d("RefreshHnadler - Create New Scheduler");
            mScheduleHandler = new Handler(Looper.getMainLooper());
        } else {
            LogPrint.d("RefreshHnadler - Remove Old Schedule");
            stopScheduler();
        }

        int interval = getRealInterval();
        LogPrint.d("RefreshHnadler - New Schedule Add : " + interval);
        mScheduleHandler.postDelayed(runnableCode, interval * 1000L);
    }

    private void stopScheduler() {
        if (mScheduleHandler != null) {
            mScheduleHandler.removeCallbacks(runnableCode);
        }
    }

    /**
     * 광고 자동 새로고침을 수행하는 Runnable 입니다.
     * 화면이 켜져 있고, 성공/실패 콜백이 전송되었으며, 인터벌이 경과했을 때 광고를 새로고침합니다.
     */
    private final Runnable runnableCode = new Runnable() {
        @SuppressLint("InvalidWakeLockTag")
        @Override
        public void run() {
            LogPrint.d("RefreshHnadler - Runnable start");

            if (mScheduleHandler == null) {
                rescheduleOrStop();
                return;
            }

            PowerManager powerManager = (PowerManager) mContext.getSystemService(POWER_SERVICE);
            LogPrint.d("RefreshHnadler - Refresh Start");

            boolean readyToRefresh = powerManager.isScreenOn()
                    && ((sendSuccessCallback && viewVisible) || sendFailCallback);

            if (!readyToRefresh) {
                rescheduleOrStop();
                return;
            }

            waitCount = 0;
            if (System.currentTimeMillis() - prev_scheduleTime >= getRealInterval() * 1000L) {
                prev_scheduleTime = System.currentTimeMillis();
                LogPrint.d("RefreshHnadler - Refresh");
                loadAd();
            } else {
                LogPrint.d("RefreshHnadler - Retry");
                bannerSchedule();
            }
        }
    };

    /**
     * 새로고침 조건이 아직 충족되지 않았을 때, 최대 대기 횟수 내에서 재예약합니다.
     */
    private void rescheduleOrStop() {
        if (++waitCount > MAX_WAIT_COUNT) {
            LogPrint.d("RefreshHnadler - Stop Refresh, Count is " + waitCount);
            return;
        }
        LogPrint.d("RefreshHnadler - Not Refresh, Count is " + waitCount);
        bannerSchedule();
    }

    public void stop() {
        if (mScheduleHandler != null) {
            LogPrint.d("RefreshHnadler - Pause");
            isPaused = true;
            mScheduleHandler.removeCallbacks(runnableCode);
        }
        if (mBannerAdapter != null) {
            mBannerAdapter.onPause();
        }
    }

    public void restart() {
        if (getRealInterval() > 0 && isPaused) {
            LogPrint.d("RefreshHnadler - Restart");
            isPaused = false;
            bannerSchedule();
        }
        if (mBannerAdapter != null) {
            mBannerAdapter.onResume();
        }
    }
    // endregion

    // region Load flow

    /**
     * 광고 로드를 시작합니다. 이미 로딩 중이면 중복 실행을 방지합니다.
     */
    public void loadAd() {
        if (isInLoading) {
            return;
        }
        isInLoading = true;
        stopScheduler();
        executeLoadAd();
    }

    /**
     * 서버 설정(새로고침 간격)을 먼저 가져온 뒤 realLoadAd()를 호출합니다.
     * 성공/실패와 무관하게 다음 단계로 진행합니다.
     */
    private void executeLoadAd() {
        LogPrint.d("mServerInterval : " + mServerInterval + " mInterval : " + mInterval);

        boolean needServerInterval =
                mServerInterval == SERVER_INTERVAL_UNSET || (mInterval > 0 && mServerInterval < 0);

        if (!needServerInterval) {
            realLoadAd();
            return;
        }

        MWRequestReloadInterval.requestWith(mContext, mScriptNo,
                new MobWithApiResponseCallback<MobwithConfigResponseModel>() {
                    @Override
                    public void onSuccess(MobwithConfigResponseModel response) {
                        MainThreadHandler.post(() -> {
                            MobwithConfigModel configModel = response.getConfigModel(mScriptNo);
                            if (configModel != null) {
                                mServerInterval = configModel.refreshInterval;
                            }
                            realLoadAd();
                        });
                    }

                    @Override
                    public void onFailure(Exception e) {
                        MainThreadHandler.post(MobwithBannerView.this::realLoadAd);
                    }
                });
    }

    /**
     * 광고 목록을 요청하고 미디에이션을 통해 광고를 로드/표시합니다.
     */
    private void realLoadAd() {
        // 이 배너뷰의 배지만 정리한다. 다른 광고뷰(네이티브 등)의 배지에는 영향을 주지 않는다.
        AffordanceViewManager.getInstance().detach(this);
        mSessionId = "";
        isRewardBanner = false;
        sendSuccessCallback = false;
        sendFailCallback = false;

        if (getRealInterval() > 0) {
            bannerSchedule();
        }

        if (mContext == null) {
            return;
        }

        if (!Utils.isConnectNetwork(mContext)) {
            LogPrint.d("noConnectNetwork");
            handleNoNetwork();
            return;
        }

        new MWRequestSortList(mContext, mScriptNo).execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) {
                handleSortListResponse(response);
            }

            @Override
            public void onFailure(IOException e) {
                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());
                responseFailMessage(e.getLocalizedMessage());
            }
        });
    }

    private void handleNoNetwork() {
        MainThreadHandler.post(() -> {
            try {
                if (mIBannerAdCallback != null) {
                    if (!sendFailCallback) {
                        sendFailCallback = true;
                        sendSuccessCallback = true;
                        mIBannerAdCallback.onLoadedAdInfo(false, "noConnectNetwork");
                    }
                    stopScheduler();
                }
            } catch (Exception e) {
                LogPrint.d("error : " + e.getLocalizedMessage());
            }
        });
        isInLoading = false;
    }

    private void handleSortListResponse(String response) {
        try {
            SortListResponse sortList = new SortListResponse(new JSONObject(response));

            if (!sortList.isSuccess()) {
                responseFailMessage(Key.NOFILL);
                return;
            }

            mSessionId = sortList.sessionId;

            advrtsPrdtCode = sortList.advrtsPrdtCode;
            JSONObject rewardBanner = sortList.rewardBanner;

            if (!advrtsPrdtCode.isEmpty() && advrtsPrdtCode.equals("14")) {
                if (rewardBanner != null) {
                    isRewardBanner = true;
                    rewardBannerModel = new MWRewardBannerModel(rewardBanner);
                    rewardBannerModel.setMediaId(mediaId);
                    rewardBannerModel.setServiceId(serviceId);
                    rewardBannerModel.setUserKey(userKey);
                }
            }

            sendSortListImpression(mContext, mScriptNo, advrtsPrdtCode, mSessionId);

            addHouseBanner(sortList.data);

            mediationManager = new MediationManager(mContext, sortList.data, isPointBanner, mobwithAdCategoryModel, rewardBannerModel);
            mediationManager.LoadMediation(new BannerMediationCallback(sortList));
        } catch (Exception e) {
            responseFailMessage(e.getLocalizedMessage());
        }
    }

    /**
     * 미디에이션 결과를 처리하는 콜백. 어댑터가 준비되면 광고 View를 부착합니다.
     */
    private final class BannerMediationCallback implements iMobonMediationCallback {
        private final SortListResponse sortList;
        private final String mediaScriptSize;

        BannerMediationCallback(SortListResponse sortList) {
            this.sortList = sortList;
            this.mediaScriptSize = sortList.mediaScriptSize;
        }

        @Override
        public void onLoadedAdData(String data, final AdapterObject adapter) {
            LogPrint.d("onLoadedAdData : "
                    + (adapter != null ? adapter.getName() : "NoAdapter") + " : " + data);
            isInLoading = false;
        }

        @Override
        public void onAdAdapter(AdapterObject adapter) {
            if (adapter == null) {
                responseFailMessage(Key.NOFILL);
                return;
            }

            LogPrint.d("onAdAdapter : " + adapter.getName() + " adapter : "
                    + adapter.getClass() + " containerDp : " + containerDp);

            if (mBannerAdapter != null) {
                oldAdapter = mBannerAdapter;
            }

            MainThreadHandler.post(() -> attachAdView(adapter, mediaScriptSize));
            isInLoading = false;
        }

        @Override
        public void onAdRequest(AdapterObject adapter) {
            LogPrint.d("unitId : " + adapter.getUnitId());
            sendDspImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
            if (adapter != null) {
                LogPrint.d("onAdFailedToLoad : " + adapter.getName());
            }
            responseFailMessage(Key.NOFILL);
        }

        @Override
        public void onAdFailedAdapterName(AdapterObject adapter) {
            sendPassBackImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdClicked() {
            if (mIBannerAdCallback != null) {
                mIBannerAdCallback.onAdClicked();
            }
            if (isRewardBanner) {
                AffordanceView affordanceView = AffordanceViewManager.getInstance().getAffordanceView(MobwithBannerView.this);
                if (affordanceView != null && affordanceView.isRewarded()) {
                    AffordanceViewManager.getInstance().setRewarded(mContext, mScriptNo, MobwithBannerView.this, false);
                    if (mIBannerAdCallback != null) {
                        mIBannerAdCallback.onRewarded();
                    }
                }
            }
        }

        @Override
        public void onAdImpression() {
        }

        @Override
        public void onAppFinish() {
        }

        @Override
        public void onAdDisplayed() {
        }

        @Override
        public void onAdComplete() {
        }

        @Override
        public void onAdSkip() {
        }

        @Override
        public void onAdClosed() {
        }

        @Override
        public void onAdCancel() {
        }

        @Override
        public void onAdFailedToOpen() {
        }
    }

    /**
     * 어댑터의 광고 View를 현재 View에 부착하고 성공 콜백을 전송합니다. (메인 스레드에서 호출)
     */
    private void attachAdView(AdapterObject adapter, String mediaScriptSize) {
        LogPrint.d("attachAdView");
        mBannerAdapter = adapter;
        removeAllViews();

        try {
            View adView = (View) mBannerAdapter.getAdView();
            if (adView == null) {
                responseFailMessage(Key.NOFILL);
                return;
            }

            if (adapter.getClass().toString().contains("ScriptAdapter") && containerDp != -1) {
                setLayoutSize(mediaScriptSize);
                adView.setScaleX(adScale);
                adView.setScaleY(adScale);
            }

            addView(adView, buildAdLayoutParams(adView));

            if (isShowCloseBtn) {
                if (adapter instanceof JsonAdapter || adapter instanceof ScriptAdapter) {
                    if (adView.getId() == View.NO_ID) {
                        adView.setId(View.generateViewId());
                    }
                    addCloseButton(adView.getId());
                    mCloseLayout.bringToFront();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        mCloseLayout.setElevation(20f * getResources().getDisplayMetrics().density);
                    }
                }
            }

            if (isRewardBanner) {
                if (adapter instanceof JsonAdapter || adapter instanceof ScriptAdapter) {
                    if (TextUtils.equals(mediaScriptSize, SIZE_320_50) || TextUtils.equals(mediaScriptSize, SIZE_320_100)) {
                        AffordanceViewManager.getInstance().show(this, adView, rewardBannerModel, Gravity.BOTTOM | Gravity.END, 8);
                    } else {
                        AffordanceViewManager.getInstance().show(this, adView, rewardBannerModel, Gravity.TOP | Gravity.END, 8);
                    }
                } else {
                    AffordanceViewManager.getInstance().hide(this);
                }
            } else {
                // 리필/새로고침으로 일반 광고가 들어온 경우 이전 뱃지가 남지 않도록
                AffordanceViewManager.getInstance().hide(this);
            }

            responseSuccessMessage();
            releaseOldAdapter();
        } catch (Exception e) {
            e.printStackTrace();
            responseFailMessage(Key.NOFILL);
        }
    }

    private RelativeLayout.LayoutParams buildAdLayoutParams(View adView) {
        RelativeLayout.LayoutParams adParams;
        ViewGroup.LayoutParams existing = adView.getLayoutParams();
        if (existing != null) {
            adParams = new RelativeLayout.LayoutParams(existing.width, existing.height);
        } else {
            adParams = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
        }
        adParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        return adParams;
    }

    private void releaseOldAdapter() {
        try {
            if (oldAdapter != null) {
                oldAdapter.onPause();
                oldAdapter.destroy();
                oldAdapter = null;
            }
        } catch (Exception e) {
            LogPrint.d("[MobWithBannerView]" + e.getLocalizedMessage());
        }
    }
    // endregion

    // region Callback dispatch

    /**
     * 광고 로드 실패 콜백을 전달합니다.
     *
     * @param message 실패 원인 코드
     */
    private void responseFailMessage(String message) {
        MainThreadHandler.post(() -> {
            if (mIBannerAdCallback != null && !sendFailCallback) {
                sendFailCallback = true;
                sendSuccessCallback = true;
                mIBannerAdCallback.onLoadedAdInfo(false, message);
            }
            stopScheduler();
            isInLoading = false;
        });
    }

    /**
     * 광고 로드 성공 콜백을 전달합니다.
     */
    private void responseSuccessMessage() {
        MainThreadHandler.post(() -> {
            if (!sendSuccessCallback) {
                sendFailCallback = true;
                sendSuccessCallback = true;
                if (mIBannerAdCallback != null) {
                    mIBannerAdCallback.onLoadedAdInfo(true, "");
                }
            }
            isInLoading = false;
        });
    }
    // endregion

    // region Public actions

    /**
     * SortList의 다음 광고를 보여줍니다.
     */
    public void showNextAd() {
        if (mediationManager != null) {
            mediationManager.next();
        }
    }

    /**
     * 현재 표시 중인 광고를 제거하고 리소스를 정리합니다.
     */
    public void destroyAd() {
        stopScheduler();
        MainThreadHandler.post(() -> {
            try {
                if (mBannerAdapter != null) {
                    mBannerAdapter.onPause();
                    mBannerAdapter.destroy();
                    mBannerAdapter = null;
                }
                removeAllViews();
                AffordanceViewManager.getInstance().detach(this);
            } catch (Exception e) {
                LogPrint.d("DestroyAd() Error : " + e.getLocalizedMessage());
            }
        });
    }
    // endregion

    // region Layout sizing
    public void setLayoutSize(String mediaScriptSize) {
        LogPrint.d("mediaScriptSize! : " + mediaScriptSize);
        if (getParent() == null) {
            return;
        }

        int bannerDp;
        int height;
        if (TextUtils.equals(mediaScriptSize, SIZE_300_250)) {
            height = (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_250);
            bannerDp = 250;
        } else if (TextUtils.equals(mediaScriptSize, SIZE_320_100)) {
            height = (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_100);
            bannerDp = 100;
        } else {
            height = (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_50);
            bannerDp = 50;
        }

        try {
            String parentName = getParent().getClass().getName();
            if (parentName.contains("LinearLayout")) {
                setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));
            } else if (parentName.contains("RelativeLayout")) {
                setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));
            } else if (parentName.contains("FrameLayout")) {
                setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));
            } else if (parentName.contains("ConstraintLayout")) {
                setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));
            }

            adScale = (containerDp >= bannerDp) ? 1.0f : (float) containerDp / (float) bannerDp;
        } catch (Exception e) {
            LogPrint.d(e.getLocalizedMessage());
        }
    }
    // endregion

    // region House banner

    /**
     * 하우스 배너를 추가합니다. useHouseBanner가 true이고 기존 하우스 배너가 없을 때만 생성합니다.
     *
     * @param adData 광고 데이터 객체
     */
    private void addHouseBanner(JSONObject adData) {
        if (!useHouseBanner || mHouseBannerView != null) {
            return;
        }

        String mediaScriptSize = adData.optString("mediaScriptSize");
        final LayoutParams params;
        final int[] imageIds;

        if (TextUtils.equals(mediaScriptSize, SIZE_300_250)) {
            params = new LayoutParams(
                    (int) mContext.getResources().getDimension(R.dimen.mobwith_sdk_banner_width_300),
                    (int) mContext.getResources().getDimension(R.dimen.mobwith_sdk_banner_height_250));
            imageIds = HOUSE_IMAGES_300_250;
        } else if (TextUtils.equals(mediaScriptSize, SIZE_320_100)) {
            params = houseBannerParams(R.dimen.mobwith_sdk_banner_width_320, R.dimen.mobwith_sdk_banner_height_100);
            imageIds = HOUSE_IMAGES_320_100;
        } else {
            // 300px*50px
            params = houseBannerParams(R.dimen.mobwith_sdk_banner_width_320, R.dimen.mobwith_sdk_banner_height_50);
            imageIds = HOUSE_IMAGES_320_50;
        }

        final int imageResId = imageIds[(int) (System.currentTimeMillis() % imageIds.length)];

        MainThreadHandler.post(() -> {
            mHouseBannerView = new ImageView(mContext);
            mHouseBannerView.setLayoutParams(params);
            mHouseBannerView.setBackgroundColor(0xffffffff);
            mHouseBannerView.setScaleType(MobwithSDK.isFullScreenMode
                    ? ImageView.ScaleType.FIT_XY : ImageView.ScaleType.FIT_CENTER);
            mHouseBannerView.setImageResource(imageResId);

            addView(mHouseBannerView);

            mHouseBannerView.setOnClickListener(v -> {
                Utils.getBrowserPackageName(mContext, COUPANG_HOUSE_LINK, mIBannerAdCallback);
                if (mIBannerAdCallback != null) {
                    mIBannerAdCallback.onAdClicked();
                }
            });
        });
    }

    /**
     * 전체화면 모드면 MATCH_PARENT, 아니면 지정된 dimen 크기의 LayoutParams를 반환합니다.
     */
    private LayoutParams houseBannerParams(int widthDimenRes, int heightDimenRes) {
        if (MobwithSDK.isFullScreenMode) {
            return new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        return new LayoutParams(
                (int) mContext.getResources().getDimension(widthDimenRes),
                (int) mContext.getResources().getDimension(heightDimenRes));
    }
    // endregion

    // region Close button
    private void addCloseButton(int anchorId) {
        final float density = getResources().getDisplayMetrics().density;
        final int sizePx = (int) (14 * density);   // 배경 크기  14
        final int sizeXPx = (int) (6 * density);    // X 버튼 크기  6
        final int marginPx = (int) (4 * density);

        mCloseLayout = new FrameLayout(getContext());
        mCloseLayout.setBackgroundResource(R.drawable.stroke);

        mCloseImage = new ImageView(getContext());
        mCloseImage.setImageResource(R.drawable.iconclose);
        mCloseImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mCloseImage.setPadding(0, 0, 0, 0);

        FrameLayout.LayoutParams imageParams = new FrameLayout.LayoutParams(sizeXPx, sizeXPx);
        imageParams.gravity = Gravity.CENTER;
        mCloseImage.setLayoutParams(imageParams);
        mCloseImage.setClickable(true);
        mCloseImage.setFocusable(true);
        mCloseImage.setOnClickListener(v -> closeBanner());
        mCloseLayout.addView(mCloseImage);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(sizePx, sizePx);
        layoutParams.addRule(RelativeLayout.ALIGN_TOP, anchorId);
        layoutParams.addRule(RelativeLayout.ALIGN_LEFT, anchorId);
        layoutParams.addRule(RelativeLayout.ALIGN_START, anchorId);
        layoutParams.setMargins(marginPx, marginPx, 0, 0);

        addView(mCloseLayout, layoutParams);
    }

    private void closeBanner() {
        try {
            if (mBannerAdapter != null) {
                mBannerAdapter.onPause();
                mBannerAdapter.destroy();
                mBannerAdapter = null;
            }
            AffordanceViewManager.getInstance().detach(this);
        } catch (Exception e) {
            LogPrint.d("[MobWithBannerView] close error : " + e.getLocalizedMessage());
        }
        removeAllViews();

        if (mOnCloseListener != null) {
            mOnCloseListener.onAdClosed();
        }
    }
    // endregion
}