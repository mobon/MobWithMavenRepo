/*
 * Copyright (C) 2013 Square, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.mobwith.httpmodule.internal.cache;

import java.io.IOException;

import com.mobwith.httpmodule.Cache;
import com.mobwith.httpmodule.MobonRequest;
import com.mobwith.httpmodule.MobonResponse;

/**
 * OkHttp's internal cache interface. Applications shouldn't implement this: instead use {@link
 * Cache}.
 */
public interface InternalCache {
  MobonResponse get(MobonRequest mobonRequest) throws IOException;

  CacheRequest put(MobonResponse mobonResponse) throws IOException;

  /**
   * Remove any cache entries for the supplied {@code mobonRequest}. This is invoked when the client
   * invalidates the cache, such as when making POST requests.
   */
  void remove(MobonRequest mobonRequest) throws IOException;

  /**
   * Handles a conditional mobonRequest hit by updating the stored cache response with the headers from
   * {@code network}. The cached response body is not updated. If the stored response has changed
   * since {@code cached} was returned, this does nothing.
   */
  void update(MobonResponse cached, MobonResponse network);

  /** Track an conditional GET that was satisfied by this cache. */
  void trackConditionalCacheHit();

  /** Track an HTTP response being satisfied with {@code cacheStrategy}. */
  void trackResponse(CacheStrategy cacheStrategy);
}
