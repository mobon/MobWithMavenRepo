package com.mobwith.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.widget.FrameLayout;

import com.fsn.cauly.CaulyAdBannerView;
import com.fsn.cauly.CaulyAdBannerViewListener;
import com.fsn.cauly.CaulyAdInfo;
import com.fsn.cauly.CaulyAdInfoBuilder;
import com.fsn.cauly.CaulyInterstitialAd;
import com.fsn.cauly.CaulyNativeAdInfoBuilder;
import com.fsn.cauly.CaulyNativeAdView;
import com.fsn.cauly.CaulyNativeAdViewListener;
import com.fsn.cauly.Logger;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.api.MWRequestImpression;
import com.mobwith.sdk.utils.MainThreadHandler;


public class CaulyAdapter extends AdapterObject {
    private final String mUnitId;
    private final Context mContext;
    private final String mScriptNo;
    private MediationAdListener mediationAdListener;

    private CaulyAdBannerView mCaulyAdView;
    private CaulyInterstitialAd interstitialAd;
    private CaulyNativeAdView nativeAdView;

    private boolean isLoaded = false;
    private boolean isShowed = false;


    public CaulyAdapter(final Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);
        mUnitId = unitId;
        mContext = context;
        mScriptNo = siteNo;

        if (LogPrint.isLogPrint()) {
            Logger.setLogLevel(Logger.LogLevel.Info);
        }

        switch (AdType) {
            case BannerType.INTERSTITIAL:
                mAdType = MediationAdSize.INTERSTITIAL;
                break;
            case BannerType.BANNER_320x50:
                mAdType = MediationAdSize.BANNER_320_50;
                break;
            case BannerType.BANNER_320x100:
                mAdType = MediationAdSize.BANNER_320_100;
                break;
            case BannerType.BANNER_300x250:
                mAdType = MediationAdSize.BANNER_300_250;
                break;
        }
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }


    public void load(String type) {
        super.load(type);

        MainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
//                    loadNativeAd();
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
                    }
                } else if (TextUtils.equals(type, BannerType.INTERSTITIAL) || TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP)) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
                    }
//                    CaulyAdInfo adInfo = new CaulyAdInfoBuilder(mUnitId).build();
//                    interstitialAd = new CaulyInterstitialAd();
//                    interstitialAd.setAdInfo(adInfo);
//                    interstitialAd.setInterstialAdListener(new CaulyInterstitialAdListener() {
//                        @Override
//                        public void onReceiveInterstitialAd(CaulyInterstitialAd caulyInterstitialAd, boolean b) {
//                            if (mediationAdListener != null) {
//                                mediationAdListener.onAdLoaded();
//                            }
//                            isLoaded = true;
//                        }
//
//                        @Override
//                        public void onFailedToReceiveInterstitialAd(CaulyInterstitialAd caulyInterstitialAd, int i, String s) {
//                            if (mediationAdListener != null) {
//                                mediationAdListener.onAdFailedToLoad(s);
//                            }
//                            isLoaded = false;
//                        }
//
//                        @Override
//                        public void onClosedInterstitialAd(CaulyInterstitialAd caulyInterstitialAd) {
//                            if (mediationAdListener != null) {
//                                mediationAdListener.onAdClosed();
//                            }
//                            isShowed = false;
//                        }
//
//                        @Override
//                        public void onLeaveInterstitialAd(CaulyInterstitialAd caulyInterstitialAd) {
//                        }
//
//                        @Override
//                        public void onClickInterstitialAd(CaulyInterstitialAd caulyInterstitialAd) {
//                            if (mediationAdListener != null) {
//                                mediationAdListener.onAdClicked();
//                            }
//                        }
//                    });
//
//                    isShowed = false;
//                    isLoaded = false;
//                    interstitialAd.disableBackKey();
//                    interstitialAd.requestInterstitialAd((Activity) mContext);
                } else if (TextUtils.equals(type, BannerType.ENDING)) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
                    }
                } else {
                    int bannerHeight = 50;
                    int bannerWidth = 320;
                    if (TextUtils.equals(type, BannerType.BANNER_320x100)) {
                        bannerHeight = 100;
                    } else if (TextUtils.equals(type, BannerType.BANNER_300x250)) {
                        bannerHeight = 250;
                        bannerWidth = 300;
                    }

                    CaulyAdInfo adInfo = new CaulyAdInfoBuilder(mUnitId)
                            .effect(CaulyAdInfo.Effect.None.toString())
                            .bannerHeight((bannerHeight < 250 ? CaulyAdInfoBuilder.FIXED : CaulyAdInfoBuilder.ADAPTIVE))
                            .setBannerSize(bannerWidth, bannerHeight)
                            .build();

                    mCaulyAdView = new CaulyAdBannerView(mContext);
                    mCaulyAdView.setAdInfo(adInfo);
                    mCaulyAdView.setAdViewListener(new CaulyAdBannerViewListener() {
                        @Override
                        public void onReceiveAd(CaulyAdBannerView caulyAdBannerView, boolean b) {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdLoaded();
                            }
                            LogPrint.d("[CaulyAdapter] onReceiveAd");
                            CommonUtils.sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                        }

                        @Override
                        public void onFailedToReceiveAd(CaulyAdBannerView caulyAdBannerView, int i, String s) {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad(s);
                            }
                            LogPrint.d("[CaulyAdapter] onFailedToReceiveAd : " + s);
                        }

                        @Override
                        public void onShowLandingScreen(CaulyAdBannerView caulyAdBannerView) {
                            // 광고 배너를 클릭하여 WebView를 통해 랜딩 페이지가 열린 경우 호출됨.
                        }

                        @Override
                        public void onCloseLandingScreen(CaulyAdBannerView caulyAdBannerView) {
                            // 광고 배너를 클릭하여 WebView를 통해 열린 랜딩 페이지가 닫힌 경우 호출됨.
                        }

                        @Override
                        public void onTimeout(CaulyAdBannerView caulyAdBannerView, String s) {

                        }

                        @Override
                        public void onClickAd(CaulyAdBannerView caulyAdBannerView) {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                            LogPrint.d("[CaulyAdapter] onClickAd");
                        }
                    });

                    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
                    FrameLayout frameLayout = new FrameLayout(mContext);
                    frameLayout.setLayoutParams(params);

                    mCaulyAdView.load(mContext, frameLayout);
                }
            }
        });
    }

    public boolean show() {
        if (interstitialAd != null && isLoaded && !isShowed) {
            interstitialAd.show();
            isShowed = true;
            return true;
        }

        return false;
    }

    public boolean isLoaded() {
        return (interstitialAd != null && isLoaded && !isShowed);
    }

    @Override
    public void destroy() {
        super.destroy();

        try {
            if (mCaulyAdView != null) {
                mCaulyAdView.destroy();
            }

            if (nativeAdView != null) {
                nativeAdView.destroy();
            }
        } catch (Exception e) {
            LogPrint.d("[CaulyAdapter] destroy : " + e.getMessage());
        }

    }


    public Object getAdView() {
        return mCaulyAdView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public boolean canUseNativeAdView() {
        return false;
    }

    @Override
    public void loadNativeAd() {
        if (nativeAdView != null) {
            nativeAdView.destroy();
        }

        if (mAdViewItem == null) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다.");
            }
            return;
        }

        CaulyAdInfo adInfo = new CaulyNativeAdInfoBuilder(mUnitId)
                .layoutID(mAdViewItem.mViewLayoutID)
                .mainImageID(mAdViewItem.mADImageViewID)
                .titleID(mAdViewItem.mTitleViewID)
                .textID(mAdViewItem.mDescViewID)
                .iconImageID(mAdViewItem.mADLogoImageViewID)
                .build();

        nativeAdView = new CaulyNativeAdView(mContext);
        nativeAdView.setAdInfo(adInfo);
        nativeAdView.setAdViewListener(new CaulyNativeAdViewListener() {

            @Override
            public void onReceiveNativeAd(CaulyNativeAdView caulyNativeAdView, boolean b) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                LogPrint.d("[CaulyAdapter] onReceiveNativeAd");

                if (mAdViewItem != null && mAdViewItem.mContainerView != null && nativeAdView != null) {
                    mAdViewItem.mContainerView.removeAllViews();
                    nativeAdView.attachToView(mAdViewItem.mContainerView);
                }
                CommonUtils.sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }

            @Override
            public void onFailedToReceiveNativeAd(CaulyNativeAdView caulyNativeAdView, int i, String s) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(s);
                }
                LogPrint.d("[CaulyAdapter] onFailedToReceiveNativeAd : " + s);
            }

            @Override
            public void onClickNativeAd(CaulyNativeAdView caulyNativeAdView) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
                LogPrint.d("[CaulyAdapter] onClickNativeAd");
            }
        });

        nativeAdView.request();
    }

}
