package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.advg.loader.AdViewBannerManager;
import com.advg.loader.AdViewInstlManager;
import com.advg.loader.AdViewVideoManager;
import com.advg.loader.loaderInterface.AdViewBannerListener;
import com.advg.loader.loaderInterface.AdViewInstlListener;
import com.advg.loader.loaderInterface.AdViewVideoListener;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.loader.MMAdData;

public class AdViewAdapter extends AdapterObject {

    private String mUnitId;
    private Context mContext;
    private String mScriptNo;
    private Boolean isInterstitialAdLoaded = false;
    private Boolean isRewardedVideoAdLoaded = false;
    private AdViewBannerManager adViewBIDView = null;   //배너광고
    private AdViewInstlManager adInstlBIDView = null;   //전면광고
    private AdViewVideoManager videoManager = null;     //리워드광고
    private LinearLayout adViewContainer;
    public static String adViewAppId = "";
    private MediationAdListener mediationAdListener;

    public AdViewAdapter(Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);
        mContext = context;
        mUnitId = unitId;
        mScriptNo = siteNo;

        if (AdType.equals(BannerType.INTERSTITIAL)) {
            mAdType = MediationAdSize.INTERSTITIAL;
        } else if (AdType.equals(BannerType.BANNER_320x50)) {
            mAdType = MediationAdSize.BANNER_320_50;
        } else if (AdType.equals(BannerType.BANNER_320x100)) {
            mAdType = MediationAdSize.BANNER_320_100;
        } else if (AdType.equals(BannerType.BANNER_300x250)) {
            mAdType = MediationAdSize.BANNER_300_250;
        } else if (AdType.equals(BannerType.REWARD_VIDEO)) {
            mAdType = MediationAdSize.REWARD_VIDEO;
        }

    }

    public static void initSDK(String appId) {
        adViewAppId = appId;
    }

    @Override
    public void setAdListener(MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    @Override
    public void load(String AdType) {
        super.load(AdType);

        if (adViewAppId.isEmpty()) {
            //SDK 초기화 실패 (AppId 누락)
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("AdView SDK 초기화 실패(AppId 누락)");
            }
            return;
        }

        if (TextUtils.equals(AdType, BannerType.NATIVE_AD)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("현재 지원하지 않는 유형입니다.");
            }
        } else if (TextUtils.equals(AdType, BannerType.INTERSTITIAL) || TextUtils.equals(AdType, BannerType.INTERSTITIAL_POPUP)) {
            loadAdInterstitial();
        } else if (TextUtils.equals(AdType, BannerType.REWARD_VIDEO)) {
            loadAdRewardedVideo();
        } else {
            loadAdBanner();
        }

//        sendImpression();
    }

    @Override
    public boolean isLoaded() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            return isInterstitialAdLoaded;
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            return isRewardedVideoAdLoaded;
        } else {
            return false;
        }
    }

    @Override
    public boolean show() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (adInstlBIDView != null) {
                adInstlBIDView.showInstl(mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (videoManager != null) {
                videoManager.showVideo(mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public Object getAdView() {
        return adViewContainer;
    }

    private void loadAdBanner() {
        try {
            int adSize = AdViewBannerManager.BANNER_AUTO_FILL;

            if (mAdType == MediationAdSize.BANNER_300_250) {
                adSize = AdViewBannerManager.BANNER_MREC;
            }

            adViewBIDView = new AdViewBannerManager(
                    mContext,
                    adViewAppId,
                    mUnitId,
                    adSize,
                    false);

            adViewContainer = new LinearLayout(mContext);

            adViewBIDView.setOnAdViewListener(new AdViewBannerListener() {
                @Override
                public void onAdClicked() {
                    LogPrint.d("onAdClicked");
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }

                @Override
                public void onAdDisplayed() {
                    LogPrint.d("onAdDisplayed");
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onAdReceived() {
                    LogPrint.d("onAdReceived");
                }

                @Override
                public void onAdFailedReceived(String s) {
                    LogPrint.d("onAdFailedReceived : " + s);
                    adViewBIDView = null;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(s);
                    }
                }

                @Override
                public void onAdClosed() {
                    LogPrint.d("onAdClosed");
                }

                @Override
                public void onAdReady() {
                    LogPrint.d("onAdReady");
                    if (adViewContainer != null) {
                        adViewContainer.setLayoutParams(
                                new ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.WRAP_CONTENT
                                )
                        );
                        adViewContainer.setGravity(Gravity.CENTER);
                        adViewContainer.addView(adViewBIDView.getAdViewLayout());
                    } else {
                        LogPrint.d("adViewContainer is null");
                    }

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                }
            });
        } catch (Exception e) {
            adViewContainer = null;
            e.printStackTrace();
        }
    }

    private void loadAdInterstitial() {
        try {
            adInstlBIDView = new AdViewInstlManager(
                    mContext,
                    adViewAppId,
                    mUnitId,
                    true);
            adInstlBIDView.enableFullScreen(true);
            adInstlBIDView.setOnAdViewListener(new AdViewInstlListener() {
                @Override
                public void onAdClicked() {
                    LogPrint.d("onAdClicked");
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }

                @Override
                public void onAdDisplayed() {
                    LogPrint.d("onAdDisplayed");
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onAdReceived() {
                    LogPrint.d("onAdReceived");
                }

                @Override
                public void onAdFailedReceived(String s) {
                    LogPrint.d("onAdFailedReceived : " + s);
                    isInterstitialAdLoaded = false;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("onAdFailedReceived : " + s);
                    }
                    adInstlBIDView = null;
                }

                @Override
                public void onAdClosed() {
                    LogPrint.d("onAdClosed");
                    isInterstitialAdLoaded = false;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClosed();
                    }
                    adInstlBIDView = null;
                }

                @Override
                public void onAdReady() {
                    LogPrint.d("onAdReady");
                    isInterstitialAdLoaded = true;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                }
            });
        } catch (Exception e){
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("onAdFailedToLoad" + e.getLocalizedMessage());
            }
        }
    }

    private void loadAdRewardedVideo() {
        try {
            videoManager = new AdViewVideoManager(mContext,
                    adViewAppId,
                    mUnitId,
                    new AdViewVideoListener() {
                        @Override
                        public void onReceivedVideo(String s) {
                            LogPrint.d("onReceivedVideo");
                        }

                        @Override
                        public void onFailedReceivedVideo(String s) {
                            isRewardedVideoAdLoaded = false;
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad("onAdFailedReceived : " + s);
                            }
                            videoManager = null;
                        }

                        @Override
                        public void onVideoReady() {
                            LogPrint.d("onVideoReady");
                            isRewardedVideoAdLoaded = true;
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdLoaded();
                            }
                        }

                        @Override
                        public void onVideoStartPlayed() {
                            LogPrint.d("onVideoStartPlayed");
                        }

                        @Override
                        public void onVideoFinished() {
                            LogPrint.d("onVideoFinished");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdComplete();
                            }
                        }

                        @Override
                        public void onVideoClosed() {
                            isRewardedVideoAdLoaded = false;
                            LogPrint.d("onVideoClosed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClosed();
                            }
                            videoManager = null;
                        }

                        @Override
                        public void onPlayedError(String s) {
                            isRewardedVideoAdLoaded = false;
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad("onPlayedError : " + s);
                            }
                            videoManager = null;
                        }

                        @Override
                        public void onVideoClicked(int i, int i1) {
                            LogPrint.d("onVideoClicked");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        }
                    });

            videoManager.setVideoOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } catch (Exception e){
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("onAdFailedToLoad : " + e.getLocalizedMessage());
            }
        }
    }

}
