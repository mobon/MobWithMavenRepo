//
//  Tracking.java
//
//  Copyright (c) 2014 Nexage. All rights reserved.
//

package com.mobwith.VastParser.adsplay.vast.model;


import com.mobwith.VastParser.adsplay.util.VastTimeUtils;

public class Tracking {

	private String value;
	private TRACKING_EVENTS_TYPE event;
	private long offset;

	public boolean isTracked = false;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public TRACKING_EVENTS_TYPE getEvent() {
		return event;
	}

	public void setEvent(TRACKING_EVENTS_TYPE event) {
		this.event = event;
	}

	public long getOffset() {
		return offset;
	}


	public void setOffset(String offset) {
		this.offset = VastTimeUtils.convertTimeStrToIntValue(offset);
	}

	@Override
	public String toString() {
		return "Tracking [event=" + event + ", value=" + value + ", offset=" + offset + "]";
	}

}
