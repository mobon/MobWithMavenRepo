package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.fyber.inneractive.sdk.external.InneractiveAdManager;
import com.fyber.inneractive.sdk.external.InneractiveAdRequest;
import com.fyber.inneractive.sdk.external.InneractiveAdSpot;
import com.fyber.inneractive.sdk.external.InneractiveAdSpotManager;
import com.fyber.inneractive.sdk.external.InneractiveAdViewEventsListener;
import com.fyber.inneractive.sdk.external.InneractiveAdViewUnitController;
import com.fyber.inneractive.sdk.external.InneractiveErrorCode;
import com.fyber.inneractive.sdk.external.InneractiveFullScreenAdRewardedListener;
import com.fyber.inneractive.sdk.external.InneractiveFullscreenAdEventsListener;
import com.fyber.inneractive.sdk.external.InneractiveFullscreenUnitController;
import com.fyber.inneractive.sdk.external.InneractiveFullscreenVideoContentController;
import com.fyber.inneractive.sdk.external.InneractiveUnitController;
import com.fyber.inneractive.sdk.external.OnFyberMarketplaceInitializedListener;
import com.fyber.inneractive.sdk.external.VideoContentListener;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.loader.MMAdData;

import java.lang.reflect.Method;

public class DTExchangeAdapter extends AdapterObject {

    private static String appKey = "";
    private Context mContext;
    private String mUnitId;
    private String mScriptNo;
    private InneractiveAdSpot mSpot;
    private LinearLayout bannerView;
    private InneractiveFullscreenUnitController interstitialController;
    private InneractiveFullscreenUnitController rewardController;
    private static boolean isInitialized = false;
    private boolean isInterstitialAdLoaded = false;
    private boolean isInterstitialAdProgressed = false;
    private boolean isRewardedVideoAdLoaded = false;
    private boolean isRewardedAdProgressed = false;
    private MediationAdListener mediationAdListener;

    public DTExchangeAdapter(Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mContext = context;
        mUnitId = unitId;
        mScriptNo = siteNo;

        switch (AdType) {
            case BannerType.INTERSTITIAL:
                mAdType = MediationAdSize.INTERSTITIAL;
                break;
            case BannerType.BANNER_320x50:
            case BannerType.BANNER_320x100:
                mAdType = MediationAdSize.BANNER_320_50;
                break;
            case BannerType.BANNER_300x250:
                mAdType = MediationAdSize.BANNER_300_250;
                break;
            case BannerType.REWARD_VIDEO:
                mAdType = MediationAdSize.REWARD_VIDEO;
                break;
        }

        initialize();
    }

    public static void initSDK(String appKey) {
        DTExchangeAdapter.appKey = appKey;
    }

    private void initialize() {

        if (isInitialized) {
            return;
        }

        InneractiveAdManager.initialize(mContext, appKey, new OnFyberMarketplaceInitializedListener() {
            @Override
            public void onFyberMarketplaceInitialized(FyberInitStatus status) {
                switch (status) {
                    case SUCCESSFULLY: {
                        try {
                            LogPrint.d("DT Exchange Init SUCCESSFULLY");
                            isInitialized = true;
                            String userId = "";
                            InneractiveAdManager.setUserId(userId);
                            Class<?> FyberInneractiveAdManagerClass = Class.forName("com.fyber.inneractive.sdk.external.InneractiveAdManager");
                            Method setUserIdStaticMethod = FyberInneractiveAdManagerClass.getDeclaredMethod("setUserId", String.class);
                            setUserIdStaticMethod.invoke(null, userId);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                    case FAILED: {
                    }
                    case INVALID_APP_ID: {
                    }
                    case FAILED_NO_KITS_DETECTED: {
                        LogPrint.d("initSDK - DTExChange SDK init fail - " + status.name());
                        isInitialized = false;
                        break;
                    }
                }
            }
        });
    }

    @Override
    public void setAdListener(MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    @Override
    public void load(String AdType) {
        super.load(AdType);

        if (appKey.isEmpty()) {
            //SDK 초기화 실패 (AppId 누락)
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("DTExChange SDK 초기화 실패(AppId 누락)");
            }
            return;
        }

        if (!isInitialized) {
            initialize();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    load(AdType);
                }
            }, 500);

            return;
        }

        if (TextUtils.equals(AdType, BannerType.NATIVE_AD)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else if (TextUtils.equals(AdType, BannerType.INTERSTITIAL) || TextUtils.equals(AdType, BannerType.INTERSTITIAL_POPUP)) {
            loadAdInterstitial();
        } else if (TextUtils.equals(AdType, BannerType.REWARD_VIDEO)) {
            loadAdRewardedVideo();
        } else {
            loadAdBanner();
        }

//        sendImpression();
    }

    @Override
    public boolean isLoaded() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            return isInterstitialAdLoaded;
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            return isRewardedVideoAdLoaded;
        } else {
            return false;
        }
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (interstitialController != null) {
                interstitialController.show(activity);
                sendAdSDKImpression(activity, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (rewardController != null) {
                rewardController.show(activity);
                sendAdSDKImpression(activity, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean show() {
        if (!(mContext instanceof Activity)){
            return false;
        }

        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (interstitialController != null) {
                interstitialController.show((Activity) mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            // Show the ad using the Activity's context
            if (rewardController != null) {
                rewardController.show((Activity) mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public Object getAdView() {
        return bannerView;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void destroy() {
        try {
            if (mSpot != null) {
                mSpot.destroy();
                mSpot = null;
            }
            if (bannerView != null && bannerView.getParent() != null) {
                ((ViewGroup) bannerView.getParent()).removeView(bannerView);
            }
            bannerView = null;
            interstitialController = null;
            rewardController = null;
            mediationAdListener = null;
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
    }

    private void loadAdBanner() {
        if (mSpot != null) {
            mSpot.destroy();
        }

        mSpot = InneractiveAdSpotManager.get().createSpot();
        // Adding the adview controller
        InneractiveAdViewUnitController controller = new InneractiveAdViewUnitController();
        InneractiveAdSpot.RequestListener mSpotListener = new InneractiveAdSpot.RequestListener() {
            @Override
            // When the ad request sends successfully.
            public void onInneractiveSuccessfulAdRequest(InneractiveAdSpot inneractiveAdSpot) {
                if (mSpot.isReady()) {
                    LogPrint.d("onInneractiveSuccessfulAdRequest");
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }

                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());

                    InneractiveAdViewUnitController controller = (InneractiveAdViewUnitController) mSpot.getSelectedUnitController();

                    controller.setEventsListener(new InneractiveAdViewEventsListener() {
                        @Override
                        public void onAdImpression(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdImpression");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdImpression();
                                mediationAdListener.onAdDisplayed();
                            }
                        }

                        @Override
                        public void onAdClicked(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdClicked");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        }

                        @Override
                        public void onAdWillCloseInternalBrowser(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdWillCloseInternalBrowser");
                        }

                        @Override
                        public void onAdWillOpenExternalApp(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdWillOpenExternalApp");
                        }

                        @Override
                        public void onAdEnteredErrorState(InneractiveAdSpot inneractiveAdSpot, InneractiveUnitController.AdDisplayError adDisplayError) {
                            LogPrint.d("onAdEnteredErrorState");
                            bannerView = null;
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad("DT Exchange 배너 광고 로드 실패");
                            }
                        }

                        @Override
                        public void onAdExpanded(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdExpanded");
                        }

                        @Override
                        public void onAdResized(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdResized");
                        }

                        @Override
                        public void onAdCollapsed(InneractiveAdSpot inneractiveAdSpot) {
                            LogPrint.d("onAdCollapsed");
                        }
                    });

                    ViewGroup layout = bannerView;
                    controller.bindView(layout);
                } else {
                    bannerView = null;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("DT Exchange 배너 광고 로드 실패 : is not ready");
                    }
                }
            }

            @Override
            // When the ad request fails to send.
            public void onInneractiveFailedAdRequest(InneractiveAdSpot inneractiveAdSpot, InneractiveErrorCode inneractiveErrorCode) {
                bannerView = null;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("DT Exchange 배너 광고 로드 실패 : " + inneractiveErrorCode.name());
                }
            }
        };

        bannerView = new LinearLayout(mContext);
        mSpot.addUnitController(controller);
        mSpot.setRequestListener(mSpotListener);
        InneractiveAdRequest adRequest = new InneractiveAdRequest(mUnitId);
        mSpot.requestAd(adRequest);
    }

    private void loadAdInterstitial() {
        isInterstitialAdProgressed = false;

        if (mSpot != null) {
            mSpot.destroy();
        }

        mSpot = InneractiveAdSpotManager.get().createSpot();

        // Adding the fullscreen controller
        InneractiveFullscreenUnitController controller = getInneractiveFullscreenUnitController();

        // Adding the video fullscreen controller
        InneractiveFullscreenVideoContentController videoContentController = new InneractiveFullscreenVideoContentController();

        videoContentController.setEventsListener(new VideoContentListener() {
            @Override
            public void onProgress(int totalDurationInMsec, int positionInMsec) {
                LogPrint.d("onProgress");
                if (!isInterstitialAdProgressed) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }
                isInterstitialAdProgressed = true;
            }

            @Override
            public void onCompleted() {
                LogPrint.d("onCompleted");
            }

            @Override
            public void onPlayerError() {
                LogPrint.d("onPlayerError");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen("onPlayerError", "DTExchangeAdapter");
                }
            }
        });

        InneractiveAdSpot.RequestListener mSpotListener = new InneractiveAdSpot.RequestListener() {
            @Override
            // When the ad request sends successfully
            public void onInneractiveSuccessfulAdRequest(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onInneractiveSuccessfulAdRequest");
                if (mSpot.isReady()) {
                    isInterstitialAdLoaded = true;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                    // Getting the spot's controller
                    interstitialController = (InneractiveFullscreenUnitController) mSpot.getSelectedUnitController();
                } else {
                    isInterstitialAdLoaded = false;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("DT Exchange 전면 광고 로드 실패 : Not Ready");
                    }
                }
            }

            @Override
            // When the ad request fails to send
            public void onInneractiveFailedAdRequest(InneractiveAdSpot inneractiveAdSpot, InneractiveErrorCode inneractiveErrorCode) {
                LogPrint.d("onInneractiveFailedAdRequest");
                if (mediationAdListener != null) {
                    isInterstitialAdLoaded = false;
                    mediationAdListener.onAdFailedToLoad("DT Exchange 전면 광고 로드 실패 : " + inneractiveErrorCode.toString());
                }
            }
        };

        // Adding the video fullscreen controller to the adview controller
        controller.addContentController(videoContentController);

        mSpot.addUnitController(controller);
        mSpot.setRequestListener(mSpotListener);

        InneractiveAdRequest adRequest = new InneractiveAdRequest(mUnitId);

        // To perform the ad request
        mSpot.requestAd(adRequest);
    }

    private void loadAdRewardedVideo() {
        LogPrint.d("loadAdRewardedVideo");
        isRewardedAdProgressed = false;

        if (mSpot != null) {
            mSpot.destroy();
        }

        mSpot = InneractiveAdSpotManager.get().createSpot();

        InneractiveFullscreenUnitController controller = new InneractiveFullscreenUnitController();

        controller.setEventsListener(new InneractiveFullscreenAdEventsListener() {
            @Override
            public void onAdImpression(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdImpression");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdImpression();
                }
            }

            @Override
            public void onAdClicked(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdClicked");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onAdWillOpenExternalApp(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdWillOpenExternalApp");
            }

            @Override
            public void onAdEnteredErrorState(InneractiveAdSpot inneractiveAdSpot, InneractiveUnitController.AdDisplayError adDisplayError) {
                LogPrint.d("onAdEnteredErrorState");
            }

            @Override
            public void onAdWillCloseInternalBrowser(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdWillCloseInternalBrowser");
            }

            @Override
            public void onAdDismissed(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdDismissed");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClosed();
                }
            }
        });

        controller.setRewardedListener(new InneractiveFullScreenAdRewardedListener() {
            @Override
            public void onAdRewarded(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdRewarded");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdComplete();
                }
            }
        });

        // Adding the Video adview controller
        InneractiveFullscreenVideoContentController videoContentController = new InneractiveFullscreenVideoContentController();

        videoContentController.setEventsListener(new VideoContentListener() {
            @Override
            public void onProgress(int totalDurationInMsec, int positionInMsec) {
                if (!isRewardedAdProgressed) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }
                isRewardedAdProgressed = true;
            }

            @Override
            public void onCompleted() {
                LogPrint.d("onCompleted");
            }

            @Override
            public void onPlayerError() {
                LogPrint.d("onPlayerError");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen("onPlayerError", "DTExchangeAdapter");
                }
            }
        });

        InneractiveAdRequest adRequest = new InneractiveAdRequest(mUnitId);

        InneractiveAdSpot.RequestListener mSpotListener = new InneractiveAdSpot.RequestListener() {
            @Override
            //when the ad request sends successfully.
            public void onInneractiveSuccessfulAdRequest(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onInneractiveSuccessfulAdRequest");
                // Check if we have ad content
                if (mSpot.isReady()) {
                    isRewardedVideoAdLoaded = true;
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                    // Get the spot's controller
                    rewardController = (InneractiveFullscreenUnitController) mSpot.getSelectedUnitController();
                } else {
                    if (mediationAdListener != null) {
                        isRewardedVideoAdLoaded = false;
                        mediationAdListener.onAdFailedToLoad("DT Exchange Reward 광고 로드 실패 : Not Ready");
                    }
                }
            }

            @Override
            public void onInneractiveFailedAdRequest(InneractiveAdSpot inneractiveAdSpot, InneractiveErrorCode inneractiveErrorCode) {
                LogPrint.d("onInneractiveFailedAdRequest");
                if (mediationAdListener != null) {
                    isRewardedVideoAdLoaded = false;
                    mediationAdListener.onAdFailedToLoad("DT Exchange Reward 광고 로드 실패 : " + inneractiveErrorCode.toString());
                }
            }
        };

        controller.addContentController(videoContentController);

        mSpot.addUnitController(controller);

        mSpot.setRequestListener(mSpotListener);


        // When ready to perform the ad request
        mSpot.requestAd(adRequest);
    }

    @NonNull
    private InneractiveFullscreenUnitController getInneractiveFullscreenUnitController() {
        InneractiveFullscreenUnitController controller = new InneractiveFullscreenUnitController();

        controller.setEventsListener(new InneractiveFullscreenAdEventsListener() {
            @Override
            public void onAdImpression(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdImpression");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdImpression();
                }
            }

            @Override
            public void onAdClicked(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdClicked");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onAdWillOpenExternalApp(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdWillOpenExternalApp");
            }

            @Override
            public void onAdEnteredErrorState(InneractiveAdSpot inneractiveAdSpot, InneractiveUnitController.AdDisplayError adDisplayError) {
                LogPrint.d("onAdEnteredErrorState");
            }

            @Override
            public void onAdWillCloseInternalBrowser(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdWillCloseInternalBrowser");
            }

            @Override
            public void onAdDismissed(InneractiveAdSpot inneractiveAdSpot) {
                LogPrint.d("onAdDismissed");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClosed();
                }
            }
        });
        return controller;
    }
}
