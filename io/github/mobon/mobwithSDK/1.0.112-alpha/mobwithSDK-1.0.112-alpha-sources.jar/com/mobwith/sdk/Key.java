package com.mobwith.sdk;

public class Key {
    protected static final String URL = "Key.MOBON_URL";
    public static final String ENDING_POPPUP_DIM_ALPHA = "Key.ENDING_POPPUP_DIM_ALPHA";
    public static final String BROWSER_ORDER_DATA = "Key.BROWSER_ORDER_DATA";
    public static final String DATE_COMPARE_FORMAT_TIME = "yyyy.MM.dd kk:mm";
    public static final String DATE_COMPARE_FORMAT_DAY = "yyyy.MM.dd";
    public static final String MOBON_MEDIA_CROSS_BROWSER_VALUE = "Key.MOBON_MEDIA_CROSS_BROWSER_VALUE";
    protected static final String INTERSTITIAL_POPUP_TYPE = "Key.INTERSTITIAL_POPUP_TYPE";
    public enum BANNER_TYPE {BANNER_320_50, BANNER_320_100, BANNER_300_250, BIZ_BOARD}
    public enum INTERSTITIAL_TYPE {MODAL, FULL, RANDOM}
    public enum INTERSTITIAL_KEYCODE {ADCLICK, CLOSE_AD, CLOSE_APP, SKIP_AD }
    //banner init BroadCast
    public static final String AUID = "Key.AUID";
    public static final String ADID = "Key.ADID";
    public static final String USER_AGENT = "Key.USER_AGENT";
    protected static final String INTERSTITIAL_CACHE_DATA = "Key.INTERSTITIAL_CACHE_DATA";
    protected static final String REWARDAD_CACHE_DATA = "Key.REWARDAD_CACHE_DATA";
    public static final String NOFILL = "No fill";
    public static final String CHROME_BROWSER_RUN = "Key.CHROME_BROWSER_RUN";
    public static final String NAVER_BROWSER_RUN = "Key.NAVER_BROWSER_RUN";
    public static final String SAMSUNG_BROWSER_RUN = "Key.SAMSUNG_BROWSER_RUN";
    public static final String DAUM_BROWSER_RUN = "Key.DAUM_BROWSER_RUN";
    public static final String FREE_PASS_VIEW_CLICKED_TIME = "Key.FREE_PASS_VIEW_CLICKED_TIME";
    public static final String MULTI_POINT_BANNER_REFRESHED_TIME = "Key.MULTI_POINT_BANNER_REFRESHED_TIME";
    public static final String MULTI_POINT_BANNER_INTERVAL_TIME = "Key.MULTI_POINT_BANNER_INTERVAL_TIME";
    public static final String MULTI_POINT_BANNER_STATUS = "Key.MULTI_POINT_BANNER_STATUS";
    public static final String POINT_BRIDGE_IN_BACKGROUND_TIME = "Key.POINT_BRIDGE_IN_BACKGROUND_TIME";
    public static final String POINT_BRIDGE_UUIDS = "Key.POINT_BRIDGE_UUIDS";
    public static final String POINT_BRIDGE_UUID_UPDATED_TIME = "Key.POINT_BRIDGE_UUID_UPDATED_TIME";
    public static final String POINT_BRIDGE_UUID_UPDATED_DATE = "Key.POINT_BRIDGE_UUID_UPDATED_DATE";

    public static final String EX_ID_PREFIX_MOBWADS = "MOBWADS";
    public static final String EX_ID_PREFIX_MOBWITHAD = "MOBWITHAD";
}
