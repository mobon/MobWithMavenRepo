package com.mobwith.sdk;

import static com.mobwith.manager.Utils.setEdgeToEdgeLayout;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.ScriptAdapter;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.imgmodule.RequestManager;
import com.mobwith.imgmodule.load.resource.drawable.DrawableTransitionOptions;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iInterstitialCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataImageModel;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortListResponse;

import org.json.JSONObject;

import java.io.IOException;

/**
 * 앱 종료 시점에 표시되는 전면 광고 다이얼로그 클래스입니다.
 * Mobwith SDK의 전면 광고 기능을 구현하며, 자체 광고 및 미디에이션을 통한 외부 광고 네트워크의 광고를 표시할 수 있습니다.
 * 사용자는 광고 단위 ID를 설정하고, 광고 로드 및 표시에 대한 콜백을 받을 수 있습니다.
 */
public class EndingDialog extends Dialog implements View.OnClickListener, MWCommonRequestInterface {

    private final Context mContext;

    private iInterstitialCallback mInterstitialAdCallback = null;
    private String mAdType;
    private boolean isFull;
    private AdapterObject mInterstitialAdapter;

    private MediationManager mediationManager;
    private boolean isFail = false;

    private boolean sendSuccessCallback;
    private boolean sendFailCallback;
    private String mSessionId;
    private String mScriptNo = "";

    private boolean isBackNotCancel = false;

    private RequestManager mRequestManager = null;

    private MobwithAdCategoryModel mobwithAdCategoryModel;
    /**
     * 전면 광고 콜백을 받는 EndingDialog 생성자입니다.
     * @param context 애플리케이션 컨텍스트
     * @param _callback 전면 광고 콜백 인터페이스
     */
    public EndingDialog(Context context, iInterstitialCallback _callback) {
        super(context, R.style.ThemeDim);

        mInterstitialAdCallback = _callback;
        mContext = context;
        requestWindowFeature(Window.FEATURE_NO_TITLE);



        mAdType = Key.INTERSTITIAL_TYPE.MODAL.toString();

        setDialogSize(mAdType.equals(Key.INTERSTITIAL_TYPE.MODAL.toString()));
    }
    /**
     * 기본 EndingDialog 생성자입니다. (콜백 없이 생성)
     * @param context 애플리케이션 컨텍스트
     */
    public EndingDialog(Context context) {
        super(context, R.style.ThemeDim);

        mContext = context;
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setEdgeToEdgeLayout(getWindow());

        mAdType = Key.INTERSTITIAL_TYPE.MODAL.toString();

        setDialogSize(mAdType.equals(Key.INTERSTITIAL_TYPE.MODAL.toString()));
    }
    /**
     * 광고 단위 ID를 설정합니다. (Builder 패턴)
     * @param unitId 설정할 광고 단위 ID
     * @return EndingDialog 인스턴스
     */
    public EndingDialog setUnitId(String unitId) {
        mScriptNo = unitId;
        return this;
    }
    /**
     * EndingDialog를 빌드하고 초기화합니다. (Builder 패턴)
     * @return EndingDialog 인스턴스
     */
    public EndingDialog build() {
        init();
        return this;
    }
    /**
     * 뒤로가기 버튼으로 다이얼로그를 닫을 수 있는지 여부를 설정합니다. (Builder 패턴)
     * @param _is true이면 뒤로가기 버튼으로 닫을 수 있음, false이면 닫을 수 없음
     * @return EndingDialog 인스턴스
     */
    public EndingDialog setBackCancel(boolean _is) {
        isBackNotCancel = _is;
        return this;
    }
    /**
     * Mobwith 광고 카테고리 모델을 설정합니다.
     * @param mobwithAdCategoryModel 설정할 광고 카테고리 모델
     */
    public EndingDialog setMobwithAdCategoryModel(MobwithAdCategoryModel mobwithAdCategoryModel) {
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        return this;
    }
    /**
     * 다이얼로그를 초기화합니다. Mobwith SDK를 초기화하고 캐시된 전면 광고 데이터를 지웁니다.
     */
    private void init() {
        MobwithSDK.initSDK(mContext);

        SpManager.setString(mContext, Key.INTERSTITIAL_CACHE_DATA, "");
        setDialogSize(isFull);
    }
    /**
     * 다이얼로그를 초기화합니다. (전체 화면 여부 파라미터 포함 - 현재 코드에서는 명시적으로 사용되지 않음)
     * 광고 ID(ADID) 및 User-Agent 정보를 확인하고 설정합니다.
     * @param _isFull 전체 화면 여부
     */
    private void init(boolean _isFull) {
        String adid = SpManager.getString(mContext, Key.ADID);
        if (TextUtils.isEmpty(adid)) {
            CommonUtils.getAdId(mContext);
        }

        setDialogSize(_isFull);
    }

    /**
     * 다이얼로그의 크기를 설정합니다.
     * 화면 너비의 80%, 화면 높이의 80%로 설정하며, 최소 크기를 보장합니다.
     * 배경의 어두운 정도(dim)도 설정합니다.
     * @param isFull 전체 화면 여부 (true이면 전체 화면 플래그 추가, false이면 dim 비하인드 플래그 추가)
     */
    private void setDialogSize(boolean isFull) {
        final DisplayMetrics dm = mContext.getResources().getDisplayMetrics();

        if (getWindow() != null) {
            WindowManager.LayoutParams params = getWindow().getAttributes();

            params.width = (int) (dm.widthPixels * 0.8f);
            params.height = (int) (dm.heightPixels * 0.8f);

            if (params.width < Utils.convertDpToPx(mContext, 320)) {
                params.width = Utils.convertDpToPx(mContext, 320);
            }

            if (params.height < Utils.convertDpToPx(mContext, 560)) {
                params.height = Utils.convertDpToPx(mContext, 560);
            }

            float _alpha = SpManager.getFloat(mContext);
            if (_alpha < 0)
                _alpha = 0.6f;
            params.dimAmount = _alpha;

            getWindow().addFlags(isFull ? WindowManager.LayoutParams.FLAG_FULLSCREEN : WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            getWindow().setAttributes(params);
            getWindow().setGravity(Gravity.CENTER);
        }
    }

    /**
     * 다이얼로그를 닫습니다. (Dialog 클래스의 dismiss 오버라이드)
     */
    @Override
    public void dismiss() {
        super.dismiss();
    }

    /**
     * 다이얼로그가 현재 표시 중이면 닫습니다.
     */
    public void close() {
        if (isShowing()) {
            dismiss();
        }
    }
    /**
     * 전면 광고를 표시합니다.
     * 로드된 광고 어댑터가 있으면 해당 어댑터를 통해 광고를 표시하거나,
     * Mobwith 자체 광고 데이터를 사용하여 UI를 구성하고 표시합니다.
     * 광고 표시에 성공하면 onOpened 콜백, 실패하면 onFailOpened 콜백을 호출합니다.
     */
    public void show(){
        showAd(null);
    }

    public void show(Activity activity) {
        showAd(activity);
    }

    private void showAd(Activity activity){
        LogPrint.d("Ending show");
        if (mInterstitialAdapter != null) {
            MMAdData adData = mInterstitialAdapter.getAdData();
            boolean isShowed;
            if (activity == null){
                isShowed = mInterstitialAdapter.show();
            } else {
                isShowed = mInterstitialAdapter.show(activity);
            }

            if (isShowed) {
                if (mInterstitialAdCallback != null) {
                    mInterstitialAdCallback.onOpened();
                }
            } else if (adData != null && !TextUtils.isEmpty(adData.jsonData)) {
                if (CommonUtils.isActivityVisible(mContext)) {
                    if (!isShowing()) {
                        updateUIWith(adData.jsonData, adData.needShowInfoLogo());

                        EndingDialog.super.show();

                        if (mInterstitialAdCallback != null) {
                            mInterstitialAdCallback.onOpened();
                        }
                    }
                    else {
                        if (mInterstitialAdCallback != null) {
                            mInterstitialAdCallback.onFailOpened();
                        }
                    }
                }
                else {
                    if (mInterstitialAdCallback != null) {
                        mInterstitialAdCallback.onFailOpened();
                    }
                }
            } else if ((mInterstitialAdapter instanceof ScriptAdapter)) {

                setContentView(R.layout.ending_normal_layout);

                findViewById(R.id.closeBtn).setOnClickListener(this);
                findViewById(R.id.buttonExit).setOnClickListener(this);
                findViewById(R.id.buttonClose).setOnClickListener(this);

                View adView =((View)mInterstitialAdapter.getAdView());
                if (adView == null) {
                    showNextMediation();
                    return ;
                }

                ViewParent parentView = adView.getParent();
                if(parentView instanceof ViewGroup) {
                    ((ViewGroup) parentView).removeView(adView);
                }

                ((FrameLayout)findViewById(R.id.layout_root)).addView(adView);

                final ImageView infoLogoImageView = findViewById(R.id.infoBtn);
                final TextView textViewTitle = findViewById(R.id.textview_title);
                final TextView textViewDesc = findViewById(R.id.textview_desc);
                final TextView textViewPrice = findViewById(R.id.textview_price);

                textViewTitle.setText("");
                textViewDesc.setText("");
                textViewPrice.setText("");

                infoLogoImageView.setVisibility(View.GONE);

                if (CommonUtils.isActivityVisible(mContext)) {
                    if (!isShowing()) {
                        EndingDialog.super.show();

                        if (mInterstitialAdCallback != null) {
                            mInterstitialAdCallback.onOpened();
                        }
                    }
                    else {
                        if (mInterstitialAdCallback != null) {
                            mInterstitialAdCallback.onFailOpened();
                        }
                    }
                }
                else {
                    if (mInterstitialAdCallback != null) {
                        mInterstitialAdCallback.onFailOpened();
                    }
                }
            } else {
                showNextMediation();
            }
        } else {
            if (mInterstitialAdCallback != null) {
                mInterstitialAdCallback.onFailOpened();
            }
        }
    }


    private void showNextMediation() {
//        boolean nextMediation = false;
//
//        if (mediationManager != null) {
//            nextMediation = mediationManager.next();
//        }
//
//        if (!nextMediation) {
//            if (mInterstitialAdCallback != null && !isFail) {
//                setFail(true);
//                mInterstitialAdCallback.onLoadedAdInfo(false, Key.NOFILL);
//            }
//        }
        if (mInterstitialAdCallback != null) {
            mInterstitialAdCallback.onFailOpened();
        }
    }
    /**
     * 다이얼로그 내의 뷰 클릭 이벤트를 처리합니다.
     * 닫기 버튼, 앱 종료 버튼, 광고 닫기 버튼에 대한 동작을 정의합니다.
     * @param v 클릭된 뷰
     */
    @Override
    public void onClick(View v) {

        final int viewId = v.getId();
        if (viewId == R.id.closeBtn) {
            if (mInterstitialAdCallback != null) {
                mInterstitialAdCallback.onClosed();
            }
            dismiss();
        }
        else if(viewId == R.id.buttonExit) {
            if (mInterstitialAdCallback != null) {
                mInterstitialAdCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.CLOSE_APP);
            }
            dismiss();
        }
        else if(viewId == R.id.buttonClose) {
            if (mInterstitialAdCallback != null) {
                mInterstitialAdCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.CLOSE_AD);
            }
            dismiss();
        }
    }
    /**
     * 뒤로가기 버튼 눌렀을 때의 동작을 처리합니다.
     * isBackNotCancel이 true이면 다이얼로그를 닫고 onClosed 콜백을 호출합니다.
     */
    @Override
    public void onBackPressed() {
        try {
            if (isBackNotCancel) {
                if (isShowing()) {
                    dismiss();
                }

                if (mInterstitialAdCallback != null) {
                    mInterstitialAdCallback.onClosed();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 다이얼로그가 윈도우에 첨부될 때 호출됩니다. (Dialog 클래스 메소드 오버라이드)
     */
    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
    }
    /**
     * 다이얼로그가 윈도우에서 분리될 때 호출됩니다. (Dialog 클래스 메소드 오버라이드)
     */
    @Override
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    /**
     * 전면 광고 리스너(콜백)를 설정합니다.
     * @param pMobonAdCallback 설정할 전면 광고 콜백 인터페이스
     */
    public void setAdListener(iInterstitialCallback pMobonAdCallback) {
        mInterstitialAdCallback = pMobonAdCallback;
    }
    /**
     * 광고가 로드되었는지 확인합니다.
     * @return 광고 어댑터가 존재하고 로드된 상태이면 true, 그렇지 않으면 false
     */
    public boolean isLoaded() {
        return (mInterstitialAdapter != null && mInterstitialAdapter.isLoaded());
    }

    /**
     * 광고 로드 실패 상태를 설정하고, 실패 시 다이얼로그를 닫습니다.
     * @param is 실패 여부
     */
    private void setFail(boolean is) {
        isFail = is;
        if (is) {
            close();
        }
    }

    /**
     * 광고를 로드합니다.
     * 네트워크 연결 상태를 확인하고, 연결되지 않았으면 실패 콜백을 호출합니다.
     * Mobon 서버에 광고 정렬 목록(미디에이션 순서)을 요청하고,
     * 응답을 바탕으로 MediationManager를 통해 미디에이션 광고 로드를 시작합니다.
     */
    public void load() {
        if (!Utils.isConnectNetwork(mContext)) {
            if (mInterstitialAdCallback != null && !isFail) {
                LogPrint.d("Interstitial loadAd noConnectNetwork");
                mInterstitialAdCallback.onLoadedAdInfo(false, "noConnectNetwork");
                setFail(true);
            }
        }

        mSessionId = "";
        sendSuccessCallback = false;
        sendFailCallback = false;

        if (!Utils.isConnectNetwork(mContext)) {
            if (mInterstitialAdCallback != null) {
                LogPrint.d("banner loadAd noConnectNetwork");
                if (!sendFailCallback) {
                    sendFailCallback = true;
                    mInterstitialAdCallback.onLoadedAdInfo(false, "noConnectNetwork");
                }
            }
        }

        MWRequestSortList requestSortList = new MWRequestSortList(mContext, mScriptNo);
        requestSortList.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));

                    if (!sortList.isSuccess()) {
                        if (mInterstitialAdCallback != null && !sendFailCallback) {
                            sendFailCallback = true;
                            mInterstitialAdCallback.onLoadedAdInfo(false, sortList.message);
                        }
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    sendSortListImpression(mContext, mScriptNo, sortList.advrtsPrdtCode, mSessionId);

                    mediationManager = new MediationManager(mContext, sortList.data, BannerType.ENDING, mobwithAdCategoryModel);
                    mediationManager.LoadMediation(new iMobonMediationCallback() {
                        @Override
                        public void onLoadedAdData(String data, final AdapterObject adapter) {
                            if (adapter != null) {
                                LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
                            }
                            else {
                                LogPrint.d("onLoadedAdData : NoAdapter : " + data);
                            }
                        }

                        @Override
                        public void onAdAdapter(AdapterObject adapter) {
                            if (adapter == null) {
                                if (mInterstitialAdCallback != null) {
                                    if (!sendFailCallback) {
                                        sendFailCallback = true;
                                        mInterstitialAdCallback.onLoadedAdInfo(false, Key.NOFILL);
                                    }
                                }
                                return;
                            }

                            LogPrint.d("onAdAdapter : " + adapter.getName() );
                            mInterstitialAdapter = adapter;
                            if (mInterstitialAdCallback != null) {
                                new Handler(Looper.getMainLooper()).post(() -> {
                                    if (!sendSuccessCallback) {
                                        sendSuccessCallback = true;
                                        mInterstitialAdCallback.onLoadedAdInfo(true, "");
                                    }
                                });
                            }
                        }

                        @Override
                        public void onAdRequest(AdapterObject adapter) {
                            sendDspImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
                            if (adapter != null) {
                                LogPrint.d("onAdFailedToLoad : " + adapter.getName() );
                                adapter.destroy();
                            }

                            if (mInterstitialAdCallback != null) {
                                if (!sendFailCallback) {
                                    sendFailCallback = true;
                                    mInterstitialAdCallback.onLoadedAdInfo(false, Key.NOFILL);
                                }
                            }
                        }

                        @Override
                        public void onAdFailedAdapterName(AdapterObject adapter) {
                            sendPassBackImpression(mContext,  mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdClicked() {
                            if (mInterstitialAdCallback != null) {
                                mInterstitialAdCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.ADCLICK);
                            }
                        }

                        @Override
                        public void onAdFailedToOpen() {
                            if (mInterstitialAdCallback != null) {
                                mInterstitialAdCallback.onFailOpened();
                            }
                        }

                        @Override
                        public void onAdClosed() {
                            if (mInterstitialAdCallback != null) {
                                mInterstitialAdCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.CLOSE_AD);
                            }
                        }

                        @Override public void onAdImpression() {}
                        @Override public void onAppFinish() {
                            if (mInterstitialAdCallback != null) {
                                mInterstitialAdCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.CLOSE_APP);
                            }
                        }
                        @Override public void onAdDisplayed() {}
                        @Override public void onAdComplete() {}
                        @Override public void onAdSkip() {}
                        @Override public void onAdCancel() {}

                    });


                } catch (Exception e) {
                    if (mInterstitialAdCallback != null && !sendFailCallback) {
                        sendFailCallback = true;
                        mInterstitialAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
                    }
                }
            }

            @Override
            public void onFailure(IOException e) {
                if (mInterstitialAdCallback != null && !sendFailCallback) {
                    sendFailCallback = true;
                    mInterstitialAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
                }
            }
        });

    }


    /**
     * 광고 데이터를 사용하여 전면 광고 UI를 업데이트하고 표시합니다.
     * 이 메소드는 Mobwith 자체 광고를 표시할 때 호출됩니다.
     * 광고 데이터에는 이미지 URL, 텍스트, 클릭 URL 등이 포함될 수 있습니다.
     *
     * @param jsonString UI를 구성하는 데 사용될 광고 데이터가 포함된 JSON 문자열입니다.
     * @param isShowInfoLogo 정보 로고 (예: 광고 출처 표시 아이콘)를 표시할지 여부를 나타내는 부울 값입니다.
     */
    public void updateUIWith(String jsonString, boolean isShowInfoLogo) {

        if (mRequestManager == null) {
            mRequestManager = ImageModule.with(mContext.getApplicationContext());
        }

        setContentView(R.layout.ending_normal_layout);

        findViewById(R.id.closeBtn).setOnClickListener(this);
        findViewById(R.id.buttonExit).setOnClickListener(this);
        findViewById(R.id.buttonClose).setOnClickListener(this);

        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);

//                final String logoIcon = "https:" + jsonObject.getJSONObject("data").optString("logoDefault", "");
//                final String logoUrl = "https:" + jsonObject.getJSONObject("data").optString("logoUrl");
                final String logoIcon = jsonObject.getJSONObject("data").optString("logoDefault", "");
                final String logoUrl = jsonObject.getJSONObject("data").optString("logoUrl", "");
                final String impUrl = jsonObject.getJSONObject("data").optString("impUrl", "");
                final String pUrl = adData.optString("pUrl");

                AdDataModel adDataModel = new AdDataModel(adData);
                final AdDataImageModel imageModel = adDataModel.getAdImageModel();

                final String adImage = imageModel == null ? adDataModel.getpImg() : imageModel.getInterstitialImage();
                final String fullImage = adDataModel.getFullSizeImageForInterstitial();
                final String logoDefault = adDataModel.getaLogoDefault();
                final String logoSub = adDataModel.getaLogoSub();
                final String pNm = adDataModel.getpNm();
                final String desc3 = adDataModel.getaDesc3();
                final String price = adDataModel.getpPrice();

                final ImageView fullSizeImageView = findViewById(R.id.imageViewFullSize);

                final ImageView infoLogoImageView = findViewById(R.id.infoBtn);
                final ImageView adImageView = findViewById(R.id.imageview_thumbnail);
                final ImageView adLogoImageView = findViewById(R.id.imageview_sitelogo);
                final TextView textViewTitle = findViewById(R.id.textview_title);
                final TextView textViewDesc = findViewById(R.id.textview_desc);
                final TextView textViewPrice = findViewById(R.id.textview_price);

                if (fullImage != null && !fullImage.isEmpty()) {
                    adImageView.setVisibility(View.INVISIBLE);
                    adLogoImageView.setVisibility(View.INVISIBLE);
                    textViewTitle.setVisibility(View.INVISIBLE);
                    textViewDesc.setVisibility(View.INVISIBLE);
                    textViewPrice.setVisibility(View.INVISIBLE);
                    fullSizeImageView.setVisibility(View.VISIBLE);

                    mRequestManager.load(fullImage).transition(DrawableTransitionOptions.withCrossFade()).placeholder(new ColorDrawable(Color.WHITE)).centerCrop().into(fullSizeImageView);
                }
                else {
                    fullSizeImageView.setVisibility(View.INVISIBLE);
                    adImageView.setVisibility(View.VISIBLE);
                    adLogoImageView.setVisibility(View.VISIBLE);
                    textViewTitle.setVisibility(View.VISIBLE);
                    textViewDesc.setVisibility(View.VISIBLE);
                    textViewPrice.setVisibility(View.VISIBLE);

                    if (adImageView != null) {
                        if (!adImage.isEmpty()) {
                            mRequestManager.load(adImage).transition(DrawableTransitionOptions.withCrossFade()).placeholder(new ColorDrawable(Color.WHITE)).centerCrop().into(adImageView);
                        }
                        else {
                            adImageView.setImageBitmap(null);
                        }
                    }

                    if (!logoSub.isEmpty()) {
//                            mRequestManager.load("https:" + logoSub).fitCenter().into(adLogoImageView);
                        mRequestManager.load(logoSub).fitCenter().into(adLogoImageView);
                    } else if (!logoDefault.isEmpty()) {
//                            mRequestManager.load("https:" + logoDefault).fitCenter().into(adLogoImageView);
                        mRequestManager.load(logoDefault).fitCenter().into(adLogoImageView);
                    } else {
                        adLogoImageView.setImageBitmap(null);
                    }

                    if (textViewTitle != null) {
                        String title = pNm;
                        textViewTitle.setText( title.isEmpty() || title.equals("null") ? "" : title);
                    }

                    if (textViewDesc != null) {
                        String desc = desc3;
                        textViewDesc.setText( desc.isEmpty() || desc.equals("null") ? "" : desc);
                    }

                    if (textViewPrice != null) {
                        String convertedPrice = adDataModel.getPrice();
                        textViewPrice.setText( convertedPrice.isEmpty() || convertedPrice.equals("null") ? "" : convertedPrice);
                    }


                    if (infoLogoImageView != null) {
                        if (!logoIcon.isEmpty()) {
                            mRequestManager.load(logoIcon).fitCenter().into(infoLogoImageView);
                        }
                        else {
                            infoLogoImageView.setImageBitmap(null);
                        }

                        infoLogoImageView.setOnClickListener( v ->  {
                            if (logoUrl != null && !logoUrl.isEmpty()) {
                                Utils.getBrowserPackageName(mContext, logoUrl, mInterstitialAdCallback);
                            }
                        });
                    }

                    if (isShowInfoLogo) {
                        infoLogoImageView.setVisibility(View.VISIBLE);
                    }
                    else {
                        infoLogoImageView.setVisibility(View.GONE);
                    }
                }

                findViewById(R.id.layout_root).setOnClickListener( v -> {
                    if (mInterstitialAdCallback != null) {
                        mInterstitialAdCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.ADCLICK);
                    }

                    Utils.getBrowserPackageName(mContext, pUrl, mInterstitialAdCallback);
                    CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
                });

                sendImpressionWith(mContext, adDataModel.getCustom08(), impUrl);
                CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

}
