package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.inmobi.ads.AdMetaInfo;
import com.inmobi.ads.InMobiAdRequestStatus;
import com.inmobi.ads.InMobiBanner;
import com.inmobi.ads.InMobiInterstitial;
import com.inmobi.ads.InMobiNative;
import com.inmobi.ads.listeners.BannerAdEventListener;
import com.inmobi.ads.listeners.InterstitialAdEventListener;
import com.inmobi.ads.listeners.NativeAdEventListener;
import com.inmobi.sdk.InMobiSdk;
import com.inmobi.sdk.SdkInitializationListener;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.loader.MMAdData;

import java.util.Map;

public class InMobiAdapter extends AdapterObject {

    private static String appKey = "";
    private Context mContext;
    private String mUnitId;
    private String mScriptNo;
    private boolean isInitialized = false;
    private boolean isInterstitialAdLoaded = false;
    private boolean isRewardedVideoAdLoaded = false;
    private MediationAdListener mediationAdListener;
    private RelativeLayout inMobiBannerView;
    private InMobiBanner bannerAd;
    private InMobiInterstitial interstitialAd;
    private InMobiInterstitial rewardAd;
    private InMobiNative nativeAd;
    private int bannerWidth = 0;
    private int bannerHeight = 0;

    //Native 광고 로딩 이슈
    private boolean isActive = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable checkLoadAd = new Runnable() {
        @Override
        public void run() {
            if (isActive) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("AD 요청 시간 초과");
                }
                nativeAd.destroy();
            }
        }
    };

    public InMobiAdapter(Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mContext = context;
        mUnitId = unitId;
        mScriptNo = siteNo;

        //TODO: 배너 사이즈
        if (AdType.equals(BannerType.INTERSTITIAL)) {
            mAdType = MediationAdSize.INTERSTITIAL;
        } else if (AdType.equals(BannerType.BANNER_320x50)) {
            mAdType = MediationAdSize.BANNER_320_50;
            bannerWidth = 320;
            bannerHeight = 50;
        } else if (AdType.equals(BannerType.BANNER_320x100)) {
            mAdType = MediationAdSize.BANNER_320_50;
            bannerWidth = 320;
            bannerHeight = 50;
        } else if (AdType.equals(BannerType.BANNER_300x250)) {
            mAdType = MediationAdSize.BANNER_300_250;
            bannerWidth = 320;
            bannerHeight = 250;
        } else if (AdType.equals(BannerType.REWARD_VIDEO)) {
            mAdType = MediationAdSize.REWARD_VIDEO;
        }

        initialize();
    }

    public static void initSDK(String appKey) {
        InMobiAdapter.appKey = appKey;
    }

    private void initialize() {

        if (isInitialized) {
            return;
        }

        InMobiSdk.setLogLevel(InMobiSdk.LogLevel.DEBUG);
        InMobiSdk.init(mContext, appKey, null, new SdkInitializationListener() {
            @Override
            public void onInitializationComplete(@Nullable Error error) {
                if (null != error) {
                    LogPrint.d("InMobi Init failed -" + error.getMessage());
                    isInitialized = false;
                } else {
                    LogPrint.d("InMobi Init Successful");
                    isInitialized = true;
                }
            }
        });
    }

    @Override
    public void setAdListener(MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    @Override
    public void load(String AdType) {
        super.load(AdType);

        if (appKey.isEmpty()) {
            //SDK 초기화 실패 (AppId 누락)
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("InMobi SDK 초기화 실패(AppId 누락)");
            }
            return;
        }

        if (!isInitialized) {
            initialize();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    load(AdType);
                }
            }, 500);

            return;
        }

        LogPrint.d("AdType : " + AdType);

        if (TextUtils.equals(AdType, BannerType.NATIVE_AD)) {
            loadNativeAd();
        } else if (TextUtils.equals(AdType, BannerType.INTERSTITIAL) || TextUtils.equals(AdType, BannerType.INTERSTITIAL_POPUP)) {
            loadAdInterstitial();
        } else if (TextUtils.equals(AdType, BannerType.REWARD_VIDEO)) {
            loadAdReward();
        } else {
            loadAdBanner();
        }

//        sendImpression();
    }

    @Override
    public boolean isLoaded() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            return isInterstitialAdLoaded;
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            return isRewardedVideoAdLoaded;
        } else {
            return false;
        }
    }

    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        return showAd();
    }

    @Override
    public boolean show() {
        return showAd();
    }

    private boolean showAd(){
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (interstitialAd == null) {
                return false;
            } else {
                if (interstitialAd.isReady()) {
                    interstitialAd.setListener(new InterstitialAdEventListener() {
                        @Override
                        public void onAdFetchFailed(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                            super.onAdFetchFailed(inMobiInterstitial, inMobiAdRequestStatus);
                            LogPrint.d("onAdFetchFailed");
                        }

                        @Override
                        public void onAdWillDisplay(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onAdWillDisplay(inMobiInterstitial);
                            LogPrint.d("onAdWillDisplay");
                        }

                        @Override
                        public void onAdDisplayed(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull AdMetaInfo adMetaInfo) {
                            super.onAdDisplayed(inMobiInterstitial, adMetaInfo);
                            LogPrint.d("onAdDisplayed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdDisplayed();
                            }
                        }

                        @Override
                        public void onAdDisplayFailed(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onAdDisplayFailed(inMobiInterstitial);
                            LogPrint.d("onAdDisplayFailed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToOpen("InMobi Ad Display Failed", "InMobiAdapter");
                            }
                        }

                        @Override
                        public void onAdDismissed(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onAdDismissed(inMobiInterstitial);
                            LogPrint.d("onAdDismissed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClosed();
                            }
                        }

                        @Override
                        public void onUserLeftApplication(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onUserLeftApplication(inMobiInterstitial);
                            LogPrint.d("onUserLeftApplication");
                        }
                    });

                    interstitialAd.show();
                    return true;
                } else {
                    return false;
                }
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (rewardAd == null) {
                return false;
            } else {
                if (rewardAd.isReady()) {
                    rewardAd.setListener(new InterstitialAdEventListener() {
                        @Override
                        public void onAdFetchFailed(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                            super.onAdFetchFailed(inMobiInterstitial, inMobiAdRequestStatus);
                            LogPrint.d("onAdFetchFailed");
                        }

                        @Override
                        public void onAdWillDisplay(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onAdWillDisplay(inMobiInterstitial);
                            LogPrint.d("onAdWillDisplay");
                        }

                        @Override
                        public void onAdDisplayed(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull AdMetaInfo adMetaInfo) {
                            super.onAdDisplayed(inMobiInterstitial, adMetaInfo);
                            LogPrint.d("onAdDisplayed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdDisplayed();
                            }
                        }

                        @Override
                        public void onAdDisplayFailed(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onAdDisplayFailed(inMobiInterstitial);
                            LogPrint.d("onAdDisplayFailed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToOpen("InMobi Ad Display Failed", "InMobiAdapter");
                            }
                        }

                        @Override
                        public void onAdDismissed(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onAdDismissed(inMobiInterstitial);
                            LogPrint.d("onAdDismissed");
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClosed();
                            }
                        }

                        @Override
                        public void onUserLeftApplication(@NonNull InMobiInterstitial inMobiInterstitial) {
                            super.onUserLeftApplication(inMobiInterstitial);
                            LogPrint.d("onUserLeftApplication");
                        }

                        @Override
                        public void onRewardsUnlocked(@NonNull InMobiInterstitial inMobiInterstitial, Map<Object, Object> map) {
                            super.onRewardsUnlocked(inMobiInterstitial, map);
                            LogPrint.d("onRewardsUnlocked : " + map);
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdComplete();
                            }
                        }
                    });

                    rewardAd.show();
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    private void loadAdBanner() {
        LogPrint.d("loadAdBanner");
        bannerAd = new InMobiBanner(mContext, Long.parseLong(mUnitId));
        inMobiBannerView = new RelativeLayout(mContext);

        bannerAd.setListener(new BannerAdEventListener() {
            @Override
            public void onAdFetchSuccessful(@NonNull InMobiBanner inMobiBanner, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdFetchSuccessful(inMobiBanner, adMetaInfo);
                LogPrint.d("onAdFetchSuccessful");
            }

            @Override
            public void onAdLoadSucceeded(@NonNull InMobiBanner inMobiBanner, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdLoadSucceeded(inMobiBanner, adMetaInfo);
                LogPrint.d("onAdLoadSucceeded");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }

            @Override
            public void onAdLoadFailed(@NonNull InMobiBanner inMobiBanner, @NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onAdLoadFailed(inMobiBanner, inMobiAdRequestStatus);
                LogPrint.d("onAdLoadFailed : " + inMobiAdRequestStatus.getMessage() + "(" + inMobiAdRequestStatus.getStatusCode() + ")");
                bannerAd.destroy();
                inMobiBannerView = null;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("InMobi 배너 광고 로드 실패");
                }
            }

            @Override
            public void onAdClicked(@NonNull InMobiBanner inMobiBanner, Map<Object, Object> map) {
                super.onAdClicked(inMobiBanner, map);
                LogPrint.d("onAdClicked");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onRequestPayloadCreated(byte[] bytes) {
                super.onRequestPayloadCreated(bytes);
                LogPrint.d("onRequestPayloadCreated");
            }

            @Override
            public void onRequestPayloadCreationFailed(@NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onRequestPayloadCreationFailed(inMobiAdRequestStatus);
                LogPrint.d("onRequestPayloadCreationFailed");
            }

            @Override
            public void onAdImpression(@NonNull InMobiBanner inMobiBanner) {
                super.onAdImpression(inMobiBanner);
                LogPrint.d("onAdImpression");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdImpression();
                }
            }
        });

        ViewGroup.LayoutParams bannerLp = new ViewGroup.LayoutParams(toPixelUnits(bannerWidth), toPixelUnits(bannerHeight));
        inMobiBannerView.addView(bannerAd, bannerLp);
        bannerAd.load();
    }


    private void loadAdInterstitial() {
        interstitialAd = new InMobiInterstitial(mContext, Long.parseLong(mUnitId), new InterstitialAdEventListener() {
            @Override
            public void onAdFetchSuccessful(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdFetchSuccessful(inMobiInterstitial, adMetaInfo);
                LogPrint.d("onAdFetchSuccessful");
            }

            @Override
            public void onAdLoadSucceeded(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdLoadSucceeded(inMobiInterstitial, adMetaInfo);
                LogPrint.d("onAdLoadSucceeded");
                isInterstitialAdLoaded = true;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }

            @Override
            public void onAdLoadFailed(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onAdLoadFailed(inMobiInterstitial, inMobiAdRequestStatus);
                LogPrint.d("onAdLoadFailed : " + inMobiAdRequestStatus.getMessage() + "(" + inMobiAdRequestStatus.getStatusCode() + ")");
                interstitialAd = null;
                isInterstitialAdLoaded = false;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("InMobi 전면 광고 로드 실패 : " + inMobiAdRequestStatus.getMessage() + "(" + inMobiAdRequestStatus.getStatusCode());
                }
            }

            @Override
            public void onAdClicked(@NonNull InMobiInterstitial inMobiInterstitial, Map<Object, Object> map) {
                super.onAdClicked(inMobiInterstitial, map);
                LogPrint.d("onAdClicked");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onRequestPayloadCreated(byte[] bytes) {
                super.onRequestPayloadCreated(bytes);
                LogPrint.d("onRequestPayloadCreated");
            }

            @Override
            public void onRequestPayloadCreationFailed(@NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onRequestPayloadCreationFailed(inMobiAdRequestStatus);
                LogPrint.d("onRequestPayloadCreationFailed");
            }

            @Override
            public void onAdImpression(@NonNull InMobiInterstitial inMobiInterstitial) {
                super.onAdImpression(inMobiInterstitial);
                LogPrint.d("onAdImpression");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdImpression();
                }
            }
        });
        interstitialAd.load();
    }

    private void loadAdReward() {
        rewardAd = new InMobiInterstitial(mContext, Long.parseLong(mUnitId), new InterstitialAdEventListener() {
            @Override
            public void onAdFetchSuccessful(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdFetchSuccessful(inMobiInterstitial, adMetaInfo);
                LogPrint.d("onAdFetchSuccessful");
            }

            @Override
            public void onAdLoadSucceeded(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdLoadSucceeded(inMobiInterstitial, adMetaInfo);
                LogPrint.d("onAdLoadSucceeded");
                isRewardedVideoAdLoaded = true;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }

            @Override
            public void onAdLoadFailed(@NonNull InMobiInterstitial inMobiInterstitial, @NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onAdLoadFailed(inMobiInterstitial, inMobiAdRequestStatus);
                LogPrint.d("onAdLoadFailed : " + inMobiAdRequestStatus.getMessage() + "(" + inMobiAdRequestStatus.getStatusCode() + ")");
                rewardAd = null;
                isRewardedVideoAdLoaded = false;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("InMobi 리워드 광고 로드 실패 : " + inMobiAdRequestStatus.getMessage() + "(" + inMobiAdRequestStatus.getStatusCode());
                }
            }

            @Override
            public void onAdClicked(@NonNull InMobiInterstitial inMobiInterstitial, Map<Object, Object> map) {
                super.onAdClicked(inMobiInterstitial, map);
                LogPrint.d("onAdClicked");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onRequestPayloadCreated(byte[] bytes) {
                super.onRequestPayloadCreated(bytes);
                LogPrint.d("onRequestPayloadCreated");
            }

            @Override
            public void onRequestPayloadCreationFailed(@NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onRequestPayloadCreationFailed(inMobiAdRequestStatus);
                LogPrint.d("onRequestPayloadCreationFailed");
            }

            @Override
            public void onAdImpression(@NonNull InMobiInterstitial inMobiInterstitial) {
                super.onAdImpression(inMobiInterstitial);
                LogPrint.d("onAdImpression");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdImpression();
                }
            }
        });

        rewardAd.load();
    }

    @Override
    public void loadNativeAd() {
        //TODO: Display 시점 확인 필요
        LogPrint.d("loadNativeAd");

        if (isActive) {
            return;
        }

        isActive = true;

        handler.postDelayed(checkLoadAd, 3000);

        nativeAd = new InMobiNative(mContext, Long.parseLong(mUnitId), new NativeAdEventListener() {
            @Override
            public void onAdFetchSuccessful(@NonNull InMobiNative inMobiNative, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdFetchSuccessful(inMobiNative, adMetaInfo);
                LogPrint.d("onAdFetchSuccessful");
            }

            @Override
            public void onAdLoadSucceeded(@NonNull InMobiNative inMobiNative, @NonNull AdMetaInfo adMetaInfo) {
                super.onAdLoadSucceeded(inMobiNative, adMetaInfo);
                LogPrint.d("onAdLoadSucceeded");
                isActive = false;
                if (mAdViewItem == null) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다.");
                    }
                    return;
                }

                try {
                    View inflatedView = LayoutInflater.from(mContext).inflate(mAdViewItem.mViewLayoutID, null);

                    ImageView logo = inflatedView.findViewById(mAdViewItem.mADLogoImageViewID);

                    TextView title = inflatedView.findViewById(mAdViewItem.mTitleViewID);
                    TextView desc = inflatedView.findViewById(mAdViewItem.mDescViewID);
                    FrameLayout mediaView = inflatedView.findViewById(mAdViewItem.mMediaViewContainerID);
                    View callToAction = inflatedView.findViewById(mAdViewItem.mGotoSiteViewID);

                    if (title != null && inMobiNative.getAdTitle() != null) {
                        title.setText(inMobiNative.getAdTitle());
                    }

                    if (desc != null && inMobiNative.getAdDescription() != null) {
                        desc.setText(inMobiNative.getAdDescription());
                    }

                    if (logo != null && inMobiNative.getAdIconUrl() != null) {
                        ImageModule.with(mContext).load(inMobiNative.getAdIconUrl()).centerCrop().into(logo);
                    }

                    if (callToAction != null && inMobiNative.getAdCtaText() != null) {
                        if (callToAction instanceof Button) {
                            Button callTextView = (Button) callToAction;
                            callTextView.setText(inMobiNative.getAdCtaText());
                        } else if (callToAction instanceof TextView) {
                            TextView callTextView = (TextView) callToAction;
                            callTextView.setText(inMobiNative.getAdCtaText());
                        }
                    }

                    if (mContext instanceof Activity) {
                        DisplayMetrics displayMetrics = new DisplayMetrics();
                        Activity activity = (Activity) mContext;
                        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                        View primaryViewOfWidth = inMobiNative.getPrimaryViewOfWidth(mContext, mediaView, mAdViewItem.mContainerView, displayMetrics.widthPixels);
                        if (mediaView != null && primaryViewOfWidth != null) {
                            mediaView.addView(primaryViewOfWidth);
                        }
                    }

                    //TODO: inMobiNative.getCustomAdContent() 데이터 확인 필요
                    //TODO: Display 시점 확인 필요
                    mAdViewItem.mContainerView.removeAllViews();
                    mAdViewItem.mContainerView.addView(inflatedView);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                        mediationAdListener.onAdDisplayed();
                    }

                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());

                } catch (Exception e) {
                    isActive = false;
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다. - " + e.getLocalizedMessage());
                }
            }

            @Override
            public void onAdLoadFailed(@NonNull InMobiNative inMobiNative, @NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onAdLoadFailed(inMobiNative, inMobiAdRequestStatus);
                LogPrint.d("onAdLoadFailed : " + inMobiAdRequestStatus.getMessage() + "(" + inMobiAdRequestStatus.getStatusCode() + ")");
                isActive = false;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다.");
                }
            }

            @Override
            public void onAdClicked(@NonNull InMobiNative inMobiNative, Map<Object, Object> map) {
                LogPrint.d("onAdClicked");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onRequestPayloadCreated(byte[] bytes) {
                super.onRequestPayloadCreated(bytes);
                LogPrint.d("onRequestPayloadCreated");
            }

            @Override
            public void onRequestPayloadCreationFailed(@NonNull InMobiAdRequestStatus inMobiAdRequestStatus) {
                super.onRequestPayloadCreationFailed(inMobiAdRequestStatus);
                LogPrint.d("onRequestPayloadCreationFailed");
            }

            @Override
            public void onAdImpression(@NonNull InMobiNative inMobiNative) {
                super.onAdImpression(inMobiNative);
                LogPrint.d("onAdImpression");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdImpression();
                }
            }
        });


        nativeAd.load();
    }

    @Override
    public Object getAdView() {
        return inMobiBannerView;
    }

    @Override
    public void destroy() {
        handler.removeCallbacks(checkLoadAd);
    }


    private int toPixelUnits(int dipUnit) {
        float density = mContext.getResources().getDisplayMetrics().density;
        return Math.round(dipUnit * density);
    }
}
