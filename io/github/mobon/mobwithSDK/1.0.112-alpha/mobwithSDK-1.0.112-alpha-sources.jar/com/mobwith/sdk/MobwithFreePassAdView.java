package com.mobwith.sdk;


import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.CoupangAdapter;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.adapters.ScriptAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.api.freepass.MWRequestFreepassFrameClick;
import com.mobwith.sdk.api.freepass.MWRequestFreepassFrameImp;
import com.mobwith.sdk.callback.iFreePassBannerCallback;
import com.mobwith.sdk.custom.freepass.MobwithFreePassViewModel;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataImageModel;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.AdDataResponseDataModel;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.models.freepass.MWFreePassFrameDataModel;
import com.mobwith.sdk.models.freepass.MWFreePassFrameModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

/**
 * FreePass 광고 (특정 조건 충족 시 혜택을 제공하는 형태의 광고)를 표시하기 위한 커스텀 View 입니다.
 * Mobwith SDK의 일부로, 광고 요청, 미디에이션, 네이티브 광고 데이터 처리,
 * 그리고 FreePass 광고에 특화된 UI(매체사 로고, 정보 텍스트 등) 관리를 담당합니다.
 * 이 클래스는 다양한 광고 프레임 타입을 지원할 수 있는 기반을 가지고 있으며 (현재는 일부 주석 처리됨),
 * 광고 로드 성공, 실패 등의 이벤트를 처리하기 위한 콜백 인터페이스를 제공합니다.
 */
public class MobwithFreePassAdView extends RelativeLayout implements MWCommonRequestInterface {
    private Activity mActivity;
    private final Context mContext;
    private iFreePassBannerCallback mIBannerAdCallback = null;
    private MediationManager mediationManager;
    private AdapterObject mBannerAdapter;
    private boolean isSendedCallback;
    private String mSessionId;
    private String mScriptNo;
    private String exlItlMemo;
    private String isParallel;
    private String adBname;
    private boolean viewVisible;
    private boolean isInLoading = false;
    private AdapterObject mCurrentAdapter;

    private MobwithFreePassViewModel freePassViewModel = new MobwithFreePassViewModel();
    private FrameLayout containerFrameLayout;

    private String mMcName;
    private Drawable mMcLogoImage;


    private MobwithFreePassViewModel.ViewType normalViewType = MobwithFreePassViewModel.ViewType.unknownLayout;
    private MobwithFreePassViewModel.ViewType productViewType = MobwithFreePassViewModel.ViewType.unknownPrductLayout;

    MWFreePassFrameDataModel frameDataModel = null;
    MWFreePassFrameModel normalFrameModel = null;
    MWFreePassFrameModel productFrameModel = null;

    MWFreePassFrameModel showedFrameModel = null;

    MobwithAdCategoryModel mobwithAdCategoryModel;

    //프레임 UI Test
    MobwithFreePassViewModel.ViewType testNormalViewType;
    MobwithFreePassViewModel.ViewType testProductViewType;

    /**
     * 코드에서 MobwithFreePassAdView를 동적으로 생성할 때 사용되는 생성자입니다.
     *
     * @param context 컨텍스트.
     */
    public MobwithFreePassAdView(Context context) {
        super(context);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }

    /**
     * XML 레이아웃 파일에서 MobwithFreePassAdView를 사용할 때 호출되는 생성자입니다.
     *
     * @param context 컨텍스트.
     * @param attrs   XML 레이아웃에서 정의된 속성들.
     */
    public MobwithFreePassAdView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }

    /**
     * XML 레이아웃 파일에서 MobwithFreePassAdView를 사용하며, 기본 스타일을 적용할 때 호출되는 생성자입니다.
     *
     * @param context  컨텍스트.
     * @param attrs    XML 레이아웃에서 정의된 속성들.
     * @param defStyle 기본 스타일 속성 리소스 ID.
     */
    public MobwithFreePassAdView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }

    /**
     * 배너 광고의 Unit ID(광고 단위 ID)를 설정합니다.
     *
     * @param unitId 광고 Unit Id.
     * @return MobwithFreePassAdView 자기 자신을 반환하여 메소드 체이닝을 가능하게 합니다.
     * @throws NullPointerException (현재 코드에서는 명시적 예외 발생 없음)
     */
    public MobwithFreePassAdView setBannerUnitId(String unitId) throws NullPointerException {
        try {
            mScriptNo = unitId;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    /**
     * FreePass 광고에 표시될 매체사 이름을 설정합니다.
     *
     * @param name 매체사 이름.
     */
    public MobwithFreePassAdView setMcName(String name) {
        this.mMcName = name;
        return this;
    }

    /**
     * FreePass 광고에 표시될 매체사 로고 이미지를 설정합니다.
     *
     * @param logoImage 매체사 로고 Drawable 객체.
     */
    public MobwithFreePassAdView setMcLogoImage(Drawable logoImage) {
        this.mMcLogoImage = logoImage;
        return this;
    }

    /**
     * 특정 광고 카테고리 모델을 설정합니다. (예: 특정 서비스 연동 시 사용)
     *
     * @param mobwithAdCategoryModel 광고 카테고리 정보.
     */
    public MobwithFreePassAdView setMobwithAdCategoryModel(MobwithAdCategoryModel mobwithAdCategoryModel) {
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        return this;
    }

    /**
     * View의 윈도우 가시성 변경 시 호출됩니다.
     * (주석: mBannerAdapter가 현재 로직에서 직접적인 광고 객체를 담고 있지 않아 onPause/onResume의 효과가 제한적일 수 있습니다.
     * MediationManager 내부의 AdapterObject에 대한 생명주기 관리가 더 중요할 수 있습니다.)
     *
     * @param visibility View의 새로운 가시성 상태.
     */
    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        LogPrint.d("onWindowVisibilityChanged = " + visibility);

        if (mBannerAdapter != null) {
            if (visibility == View.GONE) {
                viewVisible = false;
                mBannerAdapter.onPause();
            } else if (visibility == View.VISIBLE) {
                viewVisible = true;
                mBannerAdapter.onResume();
            }
        }

        super.onWindowVisibilityChanged(visibility);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        LogPrint.d("hasWindowFocus = " + hasWindowFocus);
        super.onWindowFocusChanged(hasWindowFocus);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    /**
     * `MobwithFreePassAdView`의 초기화 작업을 수행합니다.
     * Mobwith SDK를 초기화하고, 기본 매체사 로고를 설정하며, 광고를 담을 컨테이너 FrameLayout을 준비합니다.
     */
    private void onInit() {
        if (mContext instanceof Activity) {
            mActivity = (Activity) mContext;
        }

        setGravity(Gravity.CENTER);

        MobwithSDK.initSDK(mContext);

        mMcName = mContext.getString(R.string.mobwith_freepass_default_mc_name);
        mMcLogoImage = mContext.getResources().getDrawable(R.drawable.logo_whowho);

        containerFrameLayout = new FrameLayout(mContext);
        containerFrameLayout.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (int) mContext.getResources().getDimension(R.dimen.freepass_banner_height)
        ));

        this.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /**
     * 광고 로드를 시작합니다.
     * 이미 로딩 중이면 중복 실행을 방지합니다.
     * (주석: 현재 프레임 RTB 관련 로직은 주석 처리되어 있고, `realLoadAd()`가 즉시 호출됩니다.
     * 프레임 RTB 활성화 시, 서버에서 프레임 정보를 먼저 가져온 후 `realLoadAd()`를 호출하게 됩니다.)
     */
    public void loadAd() {
        if (isInLoading) {
            return;
        }

        isInLoading = true;

        productViewType = MobwithFreePassViewModel.ViewType.unknownPrductLayout;
        normalViewType = MobwithFreePassViewModel.ViewType.unknownLayout;
        realLoadAd();
    }

    /**
     * 실제 광고 목록을 요청하고, 미디에이션을 통해 네이티브 광고를 로드하여 View에 표시합니다.
     * 네트워크 연결 상태를 확인하고, 연결되지 않았으면 실패 콜백을 호출합니다.
     * 광고 목록 요청 성공 시, 미디에이션 매니저를 통해 각 광고 네트워크 어댑터를 시도합니다.
     * 성공적으로 네이티브 광고 데이터를 받거나, 특정 어댑터(예: CoupangAdapter)가 선택되면 UI를 업데이트합니다.
     */
    private void realLoadAd() {
        mSessionId = "";
        isSendedCallback = false;

        if (!Utils.isConnectNetwork(mContext)) {
            LogPrint.d("banner loadAd noConnectNetwork");
            responseFailMessage("noConnectNetwork");
            isInLoading = false;

            return;
        }

        MWRequestSortList requestSortList = new MWRequestSortList(mContext, mScriptNo);
        requestSortList.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {

                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));

                    if (!sortList.isSuccess()) {
                        responseFailMessage(Key.NOFILL);
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    exlItlMemo = sortList.exlItlMemo;
                    adBname = sortList.adBname;
                    isParallel = sortList.isParallel;
                    sendSortListImpression(mContext, mScriptNo, sortList.advrtsPrdtCode, mSessionId);


                    freePassViewModel.setViewTypes(normalViewType, productViewType);
                    freePassViewModel.setContainerView(containerFrameLayout);

                    mediationManager = new MediationManager(mContext,
                            sortList.data,
                            BannerType.NATIVE_AD,
                            mobwithAdCategoryModel,
                            freePassViewModel.toNativeAdViewItem(mContext, false),
                            freePassViewModel.toNativeAdViewItem(mContext, true));
                    mediationManager.LoadMediation(new iMobonMediationCallback() {
                        @Override
                        public void onLoadedAdData(String data, final AdapterObject adapter) {
                            if (adapter != null) {
                                LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
                            } else {
                                LogPrint.d("onLoadedAdData : NoAdapter : " + data);
                            }
                            isInLoading = false;
                        }

                        @Override
                        public void onAdAdapter(AdapterObject adapter) {
                            MMAdData adData = adapter.getAdData();
                            mCurrentAdapter = adapter;
                            if (adData != null && adData.jsonData != null && !adData.jsonData.isEmpty()) {
                                if (checkJsonAd(adapter, this)) {
                                    MainThreadHandler.post(() -> {
                                        updateUIWith(adData);

                                        removeAllViews();
                                        containerFrameLayout.removeAllViews();
                                        containerFrameLayout.addView(freePassViewModel.getAdView());

                                        addView(containerFrameLayout);

                                        responseSuccessMessage();
                                    });
                                }
                            } else if (adapter instanceof JsonAdapter || adapter instanceof ScriptAdapter) {
                                onAdFailedToLoad(adapter, Key.NOFILL);
                            } else {
                                MainThreadHandler.post(() -> {
                                    responseSuccessMessage();
                                    removeAllViews();

                                    MobwithFreePassViewModel.setMcLogoImage(containerFrameLayout, mMcLogoImage);

                                    if (adapter instanceof CoupangAdapter) {
                                        MobwithFreePassViewModel.setTxtInfoShow(containerFrameLayout, true);
                                    } else {
                                        MobwithFreePassViewModel.setTxtInfoShow(containerFrameLayout, false);
                                    }

                                    MobwithFreePassViewModel.updateMcName(containerFrameLayout, mMcName);

                                    if (adapter instanceof CoupangAdapter) {
                                        showedFrameModel = productFrameModel;
                                    } else {
                                        showedFrameModel = normalFrameModel;
                                    }

                                    if (freePassViewModel != null) {
                                        if (adapter.getName().contains("MOBON")) {
                                            MobwithFreePassViewModel.setInfoMarkShow(containerFrameLayout, true);
                                        } else {
                                            MobwithFreePassViewModel.setInfoMarkShow(containerFrameLayout, false);
                                        }
                                    }

                                    if (frameDataModel != null) {
                                        MWRequestFreepassFrameImp.requestWith(mContext, mScriptNo, showedFrameModel.adFrameCode, frameDataModel.advrtsPrdtCode);
                                    }

                                    addView(containerFrameLayout);
                                });
                            }

                            isInLoading = false;
                        }

                        @Override
                        public void onAdRequest(AdapterObject adapter) {
                            sendDspImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
                            if (adapter != null) {
                                LogPrint.d("onAdFailedToLoad : " + adapter.getName() + " msg : " + errorMsg);
                            }
                            responseFailMessage(Key.NOFILL);
                        }

                        @Override
                        public void onAdFailedAdapterName(AdapterObject adapter) {
                            sendPassBackImpression(mContext, mSessionId, mScriptNo, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdClicked() {
                            sendClickedCallback();
                        }

                        @Override
                        public void onAdImpression() {
                        }

                        @Override
                        public void onAppFinish() {
                        }

                        @Override
                        public void onAdDisplayed() {
                        }

                        @Override
                        public void onAdComplete() {
                        }

                        @Override
                        public void onAdSkip() {
                        }

                        @Override
                        public void onAdClosed() {
                        }

                        @Override
                        public void onAdCancel() {
                        }

                        @Override
                        public void onAdFailedToOpen() {
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    responseFailMessage(e.getLocalizedMessage());
                }
            }

            @Override
            public void onFailure(IOException e) {
                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());
                responseFailMessage(e.getLocalizedMessage());
            }
        });
    }

    /**
     * 광고 로드 실패 시 호출될 메시지(콜백) 처리 함수입니다.
     * 실패 콜백 플래그를 설정하고, mIBannerAdCallback을 통해 실패 이벤트를 전달합니다.
     * 로딩 상태를 해제합니다.
     *
     * @param message 실패 원인 메시지.
     */
    private void responseFailMessage(String message) {
        MainThreadHandler.post(() -> {
            if (mIBannerAdCallback != null && !isSendedCallback) {
                isSendedCallback = true;
                mIBannerAdCallback.onLoadedAdInfo(false, message);
            }
        });
        isInLoading = false;
    }

    /**
     * 광고 로드 성공 시 호출될 메시지(콜백) 처리 함수입니다.
     * 성공 콜백 플래그를 설정하고, mIBannerAdCallback을 통해 성공 이벤트를 전달합니다.
     * 로딩 상태를 해제합니다.
     */
    private void responseSuccessMessage() {
        MainThreadHandler.post(() -> {
            if (!isSendedCallback) {
                isSendedCallback = true;

                if (mIBannerAdCallback != null) {
                    mIBannerAdCallback.onLoadedAdInfo(true, "");
                }
            }
        });

        isInLoading = false;
    }

    public void destroyAd() {

        MainThreadHandler.post(() -> {
            try {
                if (mActivity != null) {
                    mActivity.getApplication().unregisterActivityLifecycleCallbacks(lifecycleCallbacks);
                }

                if (mCurrentAdapter != null) {
                    if (mCurrentAdapter instanceof VideoAdapter) {
                        VideoAdapter adapter = (VideoAdapter) mCurrentAdapter;
                        adapter.close();
                        adapter.reset();
                    }
                    mCurrentAdapter.onPause();
                    mCurrentAdapter.destroy();
                    mCurrentAdapter = null;
                }

                removeAllViews();
            } catch (Exception e) {
                LogPrint.d("DestroyAd() Error : " + e.getLocalizedMessage());
            }
        });
    }

    /**
     * 광고 데이터(MMAdData)를 사용하여 FreePass 광고 UI를 업데이트합니다.
     * ViewModel을 통해 광고 제목, 매체사 정보 등을 설정하고 네이티브 광고 데이터를 등록합니다.
     *
     * @param adData 광고 데이터.
     */
    private void updateUIWith(MMAdData adData) {
        AdDataResponseModel model = null;
        try {
            JSONObject jsonObject = new JSONObject(adData.jsonData);
            model = new AdDataResponseModel(jsonObject);
        } catch (JSONException e) {
            responseFailMessage("NO FILL");
            return;
        }

        AdDataResponseDataModel dataModel = model.getData();

        final String logoUrl = dataModel.getLogoUrl();
        final String logoDefault = dataModel.getLogoDefault();
        final String impUrl = dataModel.getImpUrl();

        AdDataModel adDataModel = dataModel.getFirstAd();
        if (adDataModel == null) {
            responseFailMessage("NO FILL");
            return;
        }


        AdDataImageModel imageModel = adDataModel.getAdImageModel();

        sendImpressionWith(mContext, adDataModel.getCustom08(), impUrl);
        CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);

        String pcode = adDataModel.getpCode();
        String purl = adDataModel.getpUrl();

        String title = "";
        String desc = "";
        String thumbnailUrl = "";
        boolean isProduct = !TextUtils.isEmpty(pcode);

        freePassViewModel.loadView(mContext, isProduct);

        MobwithFreePassViewModel.setTxtInfoShow(freePassViewModel.getAdView(), isProduct);
        MobwithFreePassViewModel.updateMcName(freePassViewModel.getAdView(), mMcName);
        MobwithFreePassViewModel.setMcLogoImage(freePassViewModel.getAdView(), mMcLogoImage);

        if (isProduct) {     //상품
            showedFrameModel = productFrameModel;
            thumbnailUrl = adDataModel.getpImg();
            title = adDataModel.getpNm();
            desc = adDataModel.getPrice();

            freePassViewModel.setTitle(title);
            freePassViewModel.setDesc(desc);
        } else {      //비상품
            showedFrameModel = normalFrameModel;
            ArrayList<String> imgArray = imageModel.getImageArray(BannerType.BANNER_300x250);
            int size = imgArray.size();
            String tempImageUrl = "";

            for (int i = 0; i < size; i++) {
                if (!imgArray.get(i).isEmpty()) {
                    tempImageUrl = imgArray.get(i);
                    break;
                }
            }

            thumbnailUrl = TextUtils.isEmpty(tempImageUrl) ? adDataModel.getaLogoDefault() : tempImageUrl;
        }


        freePassViewModel.setThumbnailImage(mContext, thumbnailUrl, isProduct);

        //info mark
        boolean isLogoAvailable = logoUrl != null && !logoUrl.isEmpty();
        freePassViewModel.setInfoMarkShow(isLogoAvailable);

        LogPrint.d("isLogoAvailable : " + isLogoAvailable);

        if (isLogoAvailable) {
            freePassViewModel.setInfoMarkImage(mContext, logoDefault);
            freePassViewModel.setInfoMarkClickListener(v -> {
                Utils.getBrowserPackageName(mContext, logoUrl, null);
            });
        }

        //광고 클릭 처리
        freePassViewModel.setAdClickListener(v -> {
            if (mCurrentAdapter != null && mCurrentAdapter instanceof VideoAdapter){
                VideoAdapter videoAdapter = (VideoAdapter) mCurrentAdapter;
                videoAdapter.performAdClick();
            } else {
                Utils.getBrowserPackageName(mContext, purl, null);
            }
            sendClickedCallback();
            CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
        });

        if (showedFrameModel != null && frameDataModel != null) {
            MWRequestFreepassFrameImp.requestWith(mContext, mScriptNo, showedFrameModel.adFrameCode, frameDataModel.advrtsPrdtCode);
        }
    }

    /**
     * FreePass 배너 광고의 라이프사이클 이벤트 및 사용자 상호작용에 대한 콜백 리스너를 설정합니다.
     *
     * @param callback iFreePassBannerCallback 구현 객체.
     */
    public void setAdListener(iFreePassBannerCallback callback) {
        mIBannerAdCallback = callback;
    }


    @Override
    public int getDescendantFocusability() {
        return super.getDescendantFocusability();
    }

    /**
     * 광고 클릭 콜백을 전송하고, 프레임 클릭 정보를 서버에 요청합니다.
     * mIBannerAdCallback 리스너가 설정되어 있으면, 현재 시간을 클릭 시간으로 저장하고 onAdClicked 콜백을 호출합니다.
     * 현재 표시된 프레임 정보(showedFrameModel)와 프레임 데이터(frameDataModel)가 유효하면,
     * MWRequestFreepassFrameClick을 통해 서버에 프레임 클릭 정보를 전송합니다.
     */
    public void sendClickedCallback() {
        if (mIBannerAdCallback != null) {
            SpManager.setFreePassViewClickedTime(mContext, System.currentTimeMillis());
            mIBannerAdCallback.onAdClicked(SpManager.getFreePassViewClickedTime(mContext));
        }

        if (showedFrameModel != null && frameDataModel != null) {
            MWRequestFreepassFrameClick.requestWith(mContext, mScriptNo, showedFrameModel.adFrameCode, frameDataModel.advrtsPrdtCode);
        }

    }

    /**
     * FreePass MixerVideo 광고 UI를 설정합니다.
     *
     * @param adapter                 MixerVideoAdapter
     * @param iMobonMediationCallback 광고 콜백
     */
    private void setMixerVideoContainer(AdapterObject adapter, iMobonMediationCallback iMobonMediationCallback) {
        try {
            if (mActivity != null) {
                mActivity.getApplication().registerActivityLifecycleCallbacks(lifecycleCallbacks);
            }

            VideoAdapter videoAdapter = (VideoAdapter) adapter;
            videoAdapter.setLoop(true);
            videoAdapter.setMuteMode(true);

            View videoView = (View) videoAdapter.getAdView();
            videoAdapter.playVideo();

            containerFrameLayout.addView(freePassViewModel.setVideoLayout(mContext, videoView));
            containerFrameLayout.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    videoAdapter.performAdClick();
                    iMobonMediationCallback.onAdClicked();
                }
            });
            addView(containerFrameLayout);

//            if (videoAdapter.isLoaded()) {
//                videoAdapter.playVideo();
//                containerFrameLayout.addView(freePassViewModel.setVideoLayout(mContext, videoView));
//                containerFrameLayout.setOnClickListener(new OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        videoAdapter.performAdClick();
//                        iMobonMediationCallback.onAdClicked();
//                    }
//                });
//                addView(containerFrameLayout);
//            } else {
//                iMobonMediationCallback.onAdFailedToLoad(adapter, "NO LOAD VIDEO");
//            }
        } catch (Exception e) {
            iMobonMediationCallback.onAdFailedToLoad(adapter, e.getMessage());
        }
    }

    /**
     * SharedPreferences에 저장된 마지막 프리패스 광고 클릭 시간을 Date 객체로 반환합니다.
     *
     * @param context 컨텍스트
     * @return 마지막 광고 클릭 시간을 나타내는 Date 객체. 저장된 시간이 없으면 현재 시간을 기준으로 한 Date 객체가 반환될 수 있습니다 (SpManager 구현에 따라 다름).
     */
    public static Date getLastAdClickedTime(Context context) {
        return SpManager.getFreePassViewClickedTime(context);
    }

//    /**
//     * 테스트 목적으로 일반 광고 프레임과 상품 광고 프레임의 뷰 타입을 설정합니다.
//     * 이 함수를 통해 설정된 뷰 타입은 광고 로드 시 실제 프레임 정보를 가져오기 전에 사용될 수 있습니다.
//     *
//     * @param testNormalViewType 테스트용 일반 광고 프레임 뷰 타입
//     * @param testProductViewType 테스트용 상품 광고 프레임 뷰 타입
//     */
//    public void setFrame(MobwithFreePassViewModel.ViewType testNormalViewType, MobwithFreePassViewModel.ViewType testProductViewType) {
//        this.testNormalViewType = testNormalViewType;
//        this.testProductViewType = testProductViewType;
//    }

    /**
     * Activity 생명주기 변경을 감지하는 콜백 리스너입니다.
     * 이 리스너는 현재 리워드 광고 다이얼로그가 연결된 Activity의 상태 변경에 따라
     * 광고(특히 MixerVideo)의 재생/일시정지 및 카운트다운 타이머를 관리합니다.
     * - onActivityResumed: Activity가 다시 활성화될 때,
     * - MixerVideo 광고가 일시정지 상태였다면 재개하고, 아니면 재생 시작.
     * - 다이얼로그가 열려있다면 카운트다운 타이머를 다시 시작.
     * - onActivityPaused: Activity가 일시정지될 때,
     * - MixerVideo 광고를 일시정지하고, 카운트다운 타이머도 취소.
     */
    Application.ActivityLifecycleCallbacks lifecycleCallbacks = new Application.ActivityLifecycleCallbacks() {

        @Override
        public void onActivityResumed(Activity activity) {
            LogPrint.d("[MobwithFreePassAdView] onActivityResumed: " + activity.getLocalClassName());

            if (activity != mActivity) {
                return;
            }

            if (mCurrentAdapter != null && mCurrentAdapter instanceof VideoAdapter) {
                VideoAdapter adapter = (VideoAdapter) mCurrentAdapter;
                if (adapter.isPaused()) {
                    adapter.resumeVideo();
                } else {
                    adapter.playVideo();
                }
            }
        }

        @Override
        public void onActivityPaused(Activity activity) {
            LogPrint.d("[MobwithFreePassAdView] onActivityPaused: " + activity.getLocalClassName());
            if (activity != mActivity) {
                return;
            }

            if (mCurrentAdapter != null && mCurrentAdapter instanceof VideoAdapter) {
                ((VideoAdapter) mCurrentAdapter).pauseVideo();
            }
        }

        @Override
        public void onActivityDestroyed(Activity activity) {
            LogPrint.d("[MobwithFreePassAdView] onActivityDestroyed");
            destroyAd();
        }

        @Override
        public void onActivityStopped(@NonNull Activity activity) {
            LogPrint.d("[MobwithFreePassAdView] onActivityStopped");
        }

        @Override
        public void onActivityCreated(@NonNull Activity activity, Bundle savedInstanceState) {
            LogPrint.d("[MobwithFreePassAdView] onActivityCreated");
        }

        @Override
        public void onActivityStarted(@NonNull Activity activity) {
            LogPrint.d("[MobwithFreePassAdView] onActivityStarted");
        }

        @Override
        public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
            LogPrint.d("[MobwithFreePassAdView] onActivitySaveInstanceState");
        }
    };

    private boolean checkJsonAd(AdapterObject adapter, iMobonMediationCallback listener) {
        try {
            String useParallel = String.valueOf(((JsonAdapter) adapter).useParallel);
            JSONObject jsonData = new JSONObject(adapter.getAdData().jsonData);
            JSONArray adData = jsonData.optJSONObject("data").optJSONArray("data");
            if (adData != null && adData.length() > 0) {
                String videoAd = adData.getJSONObject(0).optString("videoAd");
                String custom10 = adData.getJSONObject(0).optString("custom10");
                if (!videoAd.isEmpty()) {
                    VideoAdapter videoAdapter = new VideoAdapter(
                            mContext,
                            adapter.getName(),
                            adapter.getUnitId(),
                            exlItlMemo,
                            "",
                            adapter.getAdData(),
                            false,
                            mScriptNo,
                            useParallel,
                            adBname
                    );
                    videoAdapter.initVideoAd(videoAd, adData.getJSONObject(0).optString("pUrl"), null);
                    mCurrentAdapter = videoAdapter;
                } else if (!custom10.isEmpty()) {
                    VideoAdapter videoAdapter = new VideoAdapter(
                            mContext,
                            adapter.getName(),
                            adapter.getUnitId(),
                            exlItlMemo,
                            "",
                            adapter.getAdData(),
                            false,
                            mScriptNo,
                            useParallel,
                            adBname
                    );
                    videoAdapter.initVastVideo(custom10, new VideoAdapter.OnVideoListener() {
                        @Override
                        public void onReady(boolean isReady) {
                            if (isReady) {
                                responseSuccessMessage();
                                removeAllViews();
                                setMixerVideoContainer(videoAdapter, listener);
                            }
                        }
                    });
                    mCurrentAdapter = videoAdapter;
                } else {
                    mCurrentAdapter = adapter;
                }
                return true;
            } else {
                mCurrentAdapter = adapter;
                return false;
            }
        } catch (Exception e) {
            mCurrentAdapter = adapter;
            return false;
        }
    }
}
