package com.mobwith.VastParser.adsplay.util;

import android.annotation.SuppressLint;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class VastTimeUtils {

    @SuppressLint("SimpleDateFormat")
    public static int convertTimeStrToIntValue(String timeStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        try {
            Date date = sdf.parse(timeStr);
            Calendar calendar = Calendar.getInstance();
            if (date != null) {
                calendar.setTime(date);

                int hours = calendar.get(Calendar.HOUR_OF_DAY);
                int minutes = calendar.get(Calendar.MINUTE);
                int seconds = calendar.get(Calendar.SECOND);

                return hours * 3600 + minutes * 60 + seconds;
            }
            else {
                return 0;
            }
        } catch (ParseException e) {
            return 0;
        }
    }


    @SuppressLint("DefaultLocale")
    public static String convertIntToTimeStr(int time) {
        int hours = time / 3600;
        int minutes = (time % 3600) / 60;
        int seconds = time % 60;

        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }


}
