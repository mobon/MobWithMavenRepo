package com.mobwith.manager;

public class MediationAdSize
{
	public static final int BANNER_320_50 = 200;
	public static final int BANNER_320_100 = 201;
	public static final int BANNER_300_250 = 202;
	public static final int BANNER_BIZ_BOARD = 203;
	public static final int BANNER_ADFIT = 204;

	public static final int INTERSTITIAL = 300;
	public static final int INTERSTITIAL_POPUP = 301;
	public static final int INTERSTITIAL_POPUP_NATIVE = 302;

	public static final int REWARD_VIDEO = 400;
}
