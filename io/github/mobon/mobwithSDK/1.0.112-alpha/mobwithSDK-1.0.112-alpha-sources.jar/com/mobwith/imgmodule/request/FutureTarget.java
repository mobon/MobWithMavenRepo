package com.mobwith.imgmodule.request;

import com.mobwith.imgmodule.request.target.Target;

import java.util.concurrent.Future;

/**
 * An interface for an object that is both a {@link com.mobwith.imgmodule.request.target.Target} and a
 * {@link Future}. For example:
 *
 *
 * <p>Note - {@link #get()} and {@link #get(long, java.util.concurrent.TimeUnit)} must be called off
 * of the main thread or they will block forever.
 *
 * @param <R> The type of resource this FutureTarget will retrieve.
 */
public interface FutureTarget<R> extends Future<R>, Target<R> {}
