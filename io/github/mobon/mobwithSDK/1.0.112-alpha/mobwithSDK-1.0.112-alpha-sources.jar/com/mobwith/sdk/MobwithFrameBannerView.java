package com.mobwith.sdk;

import static com.mobwith.sdk.CommonUtils.sendClickTrackersEvent;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.manager.nativeadview.NativeAdView;
import com.mobwith.manager.nativeadview.NativeAdViewItem;
import com.mobwith.manager.nativeadview.NativeAdViewItemModel;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortListResponse;

import org.json.JSONObject;

import java.io.IOException;

/**
 * MobwithFrameBannerView는 광고주 측으로부터 제공 받는 주요 에셋들을 배치하여 노출하는 형태의 광고 입니다.
 * 지정된 프레임 형태의 광고로 구성되어 있습니다.
 * 체크사항 - 사용 시 배경색을 흰색으로 지정해주시기 바랍니다.
 * **/
public class MobwithFrameBannerView extends FrameLayout implements MWCommonRequestInterface {

    private Context mContext;
    private NativeAdViewItem nativeAdViewItem;
    private NativeAdView networkAdnativeAdView;
    private NativeAdView nativeAdView;
    private MediationManager mediationManager;
    private iBannerCallback mIBannerAdCallback = null;
    private String mBannerUnitID;
    private String mSessionId;
    private String pUrl;
    private String logoUrl;
    private AdDataModel adDataModel;
    private FrameLayout containerView;
    private MobwithAdCategoryModel mobwithAdCategoryModel;

    public MobwithFrameBannerView(@NonNull Context context,
                                  String unitId,
                                  FrameLayout containerView,
                                  int viewLayoutID,
                                  int mediaViewContainerID,
                                  int adImageViewID,
                                  int adLogoImageViewID,
                                  int titleViewID,
                                  int descriptionViewID,
                                  int gotoSiteButtonID,
                                  int infoLogoViewContainerID,
                                  int infoLogoImageViewID) {
        super(context);
        this.mContext = context;
        this.containerView = containerView;

        setUnitID(unitId);

        nativeAdViewItem = new NativeAdViewItem(
                context,
                containerView,
                viewLayoutID,
                mediaViewContainerID,
                adImageViewID,
                adLogoImageViewID,
                titleViewID,
                descriptionViewID,
                gotoSiteButtonID,
                infoLogoViewContainerID,
                infoLogoImageViewID
        );

        nativeAdView = new NativeAdView(context, nativeAdViewItem);

        nativeAdView.setCtaButtonOnClickListener(v -> {
            performAdClicked();
        });

        nativeAdView.setOnClickListener(v -> {
            performAdClicked();
        });

        nativeAdView.setInfoLogoViewOnClickListener(v -> {
            if (logoUrl != null && !logoUrl.isEmpty()) {
                Utils.getBrowserPackageName(mContext, logoUrl, null);
            }
        });

        MobwithSDK.initSDK(mContext);
    }

    public MobwithFrameBannerView(Context context,
                                  String unitId,
                                  FrameLayout containerView,
                                  NativeAdViewItemModel directAdViewItemModel,
                                  NativeAdViewItemModel nativeAdViewItemModel) {
        super(context);
        mContext = context;
        this.containerView = containerView;

        setUnitID(unitId);

        //직광고 UI
        nativeAdView = new NativeAdView(context, new NativeAdViewItem(
                context,
                containerView,
                directAdViewItemModel.getViewLayoutID(),
                directAdViewItemModel.getMediaViewContainerID(),
                directAdViewItemModel.getAdImageViewID(),
                directAdViewItemModel.getAdLogoImageViewID(),
                directAdViewItemModel.getTitleViewID(),
                directAdViewItemModel.getDescriptionViewID(),
                directAdViewItemModel.getGotoSiteButtonID(),
                directAdViewItemModel.getInfoLogoImageViewContainerID(),
                directAdViewItemModel.getInfoLogoImageViewID()
        ));

        //네트워크 광고 UI
        nativeAdViewItem = new NativeAdViewItem(
                context,
                containerView,
                nativeAdViewItemModel.getViewLayoutID(),
                nativeAdViewItemModel.getMediaViewContainerID(),
                nativeAdViewItemModel.getAdImageViewID(),
                nativeAdViewItemModel.getAdLogoImageViewID(),
                nativeAdViewItemModel.getTitleViewID(),
                nativeAdViewItemModel.getDescriptionViewID(),
                nativeAdViewItemModel.getGotoSiteButtonID(),
                nativeAdViewItemModel.getInfoLogoImageViewContainerID(),
                nativeAdViewItemModel.getInfoLogoImageViewID()
        );

        networkAdnativeAdView = new NativeAdView(context, nativeAdViewItem);

        nativeAdView.setCtaButtonOnClickListener(v -> {
            performAdClicked();
        });

        nativeAdView.setOnClickListener(v -> {
            performAdClicked();
        });

        nativeAdView.setInfoLogoViewOnClickListener(v -> {
            if (logoUrl != null && !logoUrl.isEmpty()) {
                Utils.getBrowserPackageName(mContext, logoUrl, null);
            }
            if (adDataModel != null) {
                CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
            }
        });

        networkAdnativeAdView.setCtaButtonOnClickListener(v -> {
            performAdClicked();
        });

        networkAdnativeAdView.setOnClickListener(v -> {
            performAdClicked();
        });

        networkAdnativeAdView.setInfoLogoViewOnClickListener(v -> {
            if (logoUrl != null && !logoUrl.isEmpty()) {
                Utils.getBrowserPackageName(mContext, logoUrl, null);
            }
            if (adDataModel != null) {
                CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
            }
        });

        MobwithSDK.initSDK(mContext);
    }

    public MobwithFrameBannerView setUnitID(String unitID) {
        this.mBannerUnitID = unitID;
        return this;
    }

    public MobwithFrameBannerView setAdListener(iBannerCallback callback) {
        try {
            mIBannerAdCallback = callback;
        } catch (Exception ignored) {}
        return this;
    }

    public MobwithFrameBannerView setMobwithAdCategoryModel(MobwithAdCategoryModel mobwithAdCategoryModel){
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        return this;
    }

    public void loadAd() {

        mSessionId = "";

        if (!Utils.isConnectNetwork(mContext)) {
            if (mIBannerAdCallback != null) {
                LogPrint.d("banner loadAd noConnectNetwork");
                mIBannerAdCallback.onLoadedAdInfo(false, "noConnectNetwork");
            }
        }

        if (mBannerUnitID == null) {
            if (mIBannerAdCallback != null) {
                mIBannerAdCallback.onLoadedAdInfo(false, "No UnitId");
            }
        }

        MWRequestSortList mwRequestSortList = new MWRequestSortList(mContext, mBannerUnitID);
        mwRequestSortList.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {

                LogPrint.d("onResponse : " + response);
                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));

                    if (!sortList.isSuccess()) {
                        if (mIBannerAdCallback != null) {
                            mIBannerAdCallback.onLoadedAdInfo(false, sortList.message);
                        }
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    sendSortListImpression(mContext, mBannerUnitID, sortList.advrtsPrdtCode, mSessionId);

                    mediationManager = new MediationManager(mContext, sortList.data, BannerType.NATIVE_AD, mobwithAdCategoryModel, nativeAdViewItem, true);
                    mediationManager.LoadMediation(new iMobonMediationCallback() {
                        @Override
                        public void onLoadedAdData(String data, final AdapterObject adapter) {
                            LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
                        }

                        @Override
                        public void onAdAdapter(AdapterObject adapter) {
                            try {
                                MMAdData adData = adapter.getAdData();
                                if (adData != null && adData.jsonData != null && !adData.jsonData.isEmpty()) {
                                    updateUIWith(adData.jsonData, adData.needShowInfoLogo(), adData.exid);

                                    if (mIBannerAdCallback != null) {
                                        mIBannerAdCallback.onLoadedAdInfo(true, "");
                                    }
                                } else if (adapter instanceof JsonAdapter) {
                                    onAdFailedToLoad(adapter, Key.NOFILL);
                                } else {
                                    //adapter는 항상 null이 아니므로, 이 경우는 외부 DSP사의 Native Ad를 수신한 경우이다.
                                    //외부 DSP사의 Native Ad를 수신한 경우. 광고 로딩에 성공한 케이스이므로 바로 성공 메세지를 전달 한다.
                                    LogPrint.d(mBannerUnitID + " : onAdAdapter : " + adapter.getName());
                                    if (adapter.getAdView() == null) {
                                        mIBannerAdCallback.onLoadedAdInfo(false, "NO AD View");
                                    } else {
                                        containerView.removeAllViews();
                                        if (adapter.getAdView() != null) {
                                            containerView.addView((View) adapter.getAdView());
                                            mIBannerAdCallback.onLoadedAdInfo(true, "");
                                        } else {
                                            mIBannerAdCallback.onLoadedAdInfo(false, "NO AD View");
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                LogPrint.d("onAdAdapter Exception : " + e.getMessage());
                                mIBannerAdCallback.onLoadedAdInfo(false, "NO AD View - " + e.getMessage());
                            }
                        }

                        @Override
                        public void onAdRequest(AdapterObject adapter) {
                            sendDspImpression(mContext, mSessionId, mBannerUnitID, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
                            if (adapter != null) {
                                LogPrint.d("onAdFailedToLoad : " + adapter.getName());
                            } else {
                                LogPrint.d("onAdFailedToLoad : [Null Adapter] " + errorMsg);
                            }

                            if (mIBannerAdCallback != null) {
                                mIBannerAdCallback.onLoadedAdInfo(false, Key.NOFILL);
                            }
                        }

                        @Override
                        public void onAdFailedAdapterName(AdapterObject adapter) {
                            sendPassBackImpression(mContext, mSessionId, mBannerUnitID, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdClicked() {
                            if (mIBannerAdCallback != null) {
                                mIBannerAdCallback.onAdClicked();
                            }
                            if (adDataModel != null) {
                                sendClickTrackersEvent(mContext, adDataModel);
                            }
                        }

                        @Override
                        public void onAdImpression() {
                        }

                        @Override
                        public void onAppFinish() {
                        }

                        @Override
                        public void onAdDisplayed() {
                        }

                        @Override
                        public void onAdComplete() {
                        }

                        @Override
                        public void onAdSkip() {
                        }

                        @Override
                        public void onAdClosed() {
                        }

                        @Override
                        public void onAdCancel() {
                        }

                        @Override
                        public void onAdFailedToOpen() {
                        }
                    });


                } catch (Exception e) {
                    if (mIBannerAdCallback != null) {
                        mIBannerAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
                    }
                }

            }

            @Override
            public void onFailure(IOException e) {
                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());

                new Handler(Looper.getMainLooper()).post(() -> {
                    if (mIBannerAdCallback != null) {
                        mIBannerAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
                    }
                });
            }

        });

    }

    protected void preLoadAd(AdapterObject adapter){
        try {
            MMAdData adData = adapter.getAdData();
            if (adData != null && adData.jsonData != null && !adData.jsonData.isEmpty()) {
                updateUIWith(adData.jsonData, adData.needShowInfoLogo(), adData.exid);
            } else if (adapter instanceof JsonAdapter) {
                if (mIBannerAdCallback != null) {
                    mIBannerAdCallback.onLoadedAdInfo(false, Key.NOFILL);
                }
            } else {
                //adapter는 항상 null이 아니므로, 이 경우는 외부 DSP사의 Native Ad를 수신한 경우이다.
                //외부 DSP사의 Native Ad를 수신한 경우. 광고 로딩에 성공한 케이스이므로 바로 성공 메세지를 전달 한다.
                LogPrint.d(mBannerUnitID + " : onAdAdapter : " + adapter.getName());
                if (adapter.getAdView() == null) {
                    mIBannerAdCallback.onLoadedAdInfo(false, "NO AD View");
                } else {
                    containerView.removeAllViews();
                    if (adapter.getAdView() != null) {
                        containerView.addView((View) adapter.getAdView());
                    } else {
                        mIBannerAdCallback.onLoadedAdInfo(false, "NO AD View");
                    }
                }
            }
        } catch (Exception e) {
            LogPrint.d("onAdAdapter Exception : " + e.getMessage());
            mIBannerAdCallback.onLoadedAdInfo(false, "NO AD View - " + e.getMessage());
        }
    }

    public void performAdClicked() {
        if (pUrl != null && !pUrl.isEmpty()) {
            Utils.getBrowserPackageName(mContext, pUrl, null);
            if (mIBannerAdCallback != null) {
                LogPrint.d("onAdClicked");
                mIBannerAdCallback.onAdClicked();
            }
        }
        if (adDataModel != null) {
            CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
        }
    }

    private void updateUIWith(String jsonString, boolean isShowInfoLogo, String exId) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                LogPrint.d("updateUIWith", jsonString);
                LogPrint.d("exId : " + exId);

                JSONObject jsonObject = new JSONObject(jsonString);
                JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);
                adDataModel = new AdDataModel(adData);

                pUrl = adData.optString("pUrl");
                logoUrl = jsonObject.getJSONObject("data").optString("logoUrl");

                if (networkAdnativeAdView != null) {
                    if (exId.startsWith("MOBWADS") || exId.startsWith("MOBWITHAD")) {
                        nativeAdView.updateUIWith(jsonString, isShowInfoLogo, null);
                    } else {
                        networkAdnativeAdView.updateUIWith(jsonString, isShowInfoLogo, null);
                    }
                } else {
                    nativeAdView.updateUIWith(jsonString, isShowInfoLogo, null);
                }
            } catch (Exception e) {
                if (mIBannerAdCallback != null){
                mIBannerAdCallback.onLoadedAdInfo(false, "fail to update ui " + e.getMessage());
                }
            }
        });
    }


}
