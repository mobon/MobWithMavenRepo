package com.mobwith.sdk;

import static com.mobwith.sdk.Key.EX_ID_PREFIX_MOBWADS;
import static com.mobwith.sdk.Key.EX_ID_PREFIX_MOBWITHAD;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.AdfitAdapter;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.manager.nativeadview.NativeAdView;
import com.mobwith.manager.nativeadview.NativeAdViewItem;
import com.mobwith.manager.nativeadview.NativeAdViewItemModel;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.custom.rewarded.AffordanceStyle;
import com.mobwith.sdk.custom.rewarded.AffordanceView;
import com.mobwith.sdk.custom.rewarded.AffordanceViewManager;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.models.reward.MWRewardBannerModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

/**
 * 네이티브 광고를 표시하고 관리하는 커스텀 뷰입니다.
 * - Mobwith SDK를 통해 네이티브 광고를 요청/로드합니다.
 * - 광고 데이터를 파싱하여 개발자가 정의한 네이티브 레이아웃에 UI 요소를 채웁니다.
 * - 미디에이션을 지원하며, 로드 성공/실패/클릭 이벤트를 콜백으로 전달합니다.
 */
public class MobwithNativeAdView extends RelativeLayout implements MWCommonRequestInterface {

    public static final int UNUSED_LAYOUT_RES = -1;
    private static final long LOAD_TIMEOUT_MS = 10_000L;

    // region Fields
    private final Context mContext;
    private MediationManager mediationManager;
    private iBannerCallback mIBannerAdCallback = null;

    private boolean sendSuccessCallback;
    private boolean sendFailCallback;

    private int mLoadToken = 0;          // 메인 스레드에서만 변경
    private boolean isLoading = false;   // 메인 스레드에서만 변경

    private final Runnable loadTimeout = () -> {
        notifyLoadFailed("timeout");
        finishLoading();
    };

    //리워드 배너
    private String advrtsPrdtCode;
    private String exlItlMemo = "";
    private String isParallel = "";
    private String adBname = "";
    private MWRewardBannerModel rewardBannerModel;
    private String userKey = "";
    private String mediaId = "";
    private String serviceId = "";

    private String mSessionId;
    private String mBannerUnitID;
    private String pUrl;
    private String logoUrl;

    private final NativeAdView nativeAdView;
    private NativeAdView networkAdnativeAdView;  // 네트워크 네이티브 뷰
    private final NativeAdViewItem nativeAdViewItem;
    private final NativeAdViewItem directNativeAdViewItem;  //직광고 네이티브 아이템

    private AdDataModel adDataModel;
    private MobwithAdCategoryModel mobwithAdCategoryModel;
    private List<String> categories;
    private List<String> campaignCodes;

    private VideoAdapter videoAdapter;
    private MMAdData mmAdData;
    // endregion

    /**
     * 각 UI 요소의 ID를 직접 전달받아 네이티브 광고 뷰를 생성합니다.
     */
    public MobwithNativeAdView(Context context,
                               String unitId,
                               FrameLayout containerView,
                               int viewLayoutID,
                               int mediaViewContainerID,
                               int adImageViewID,
                               int adLogoImageViewID,
                               int titleViewID,
                               int descriptionViewID,
                               int gotoSiteButtonID,
                               int infoLogoViewContainerID,
                               int infoLogoImageViewID) {
        super(context);
        mContext = context;
        setUnitId(unitId);

        directNativeAdViewItem = null;

        nativeAdViewItem = new NativeAdViewItem(
                context, containerView, viewLayoutID, mediaViewContainerID, adImageViewID,
                adLogoImageViewID, titleViewID, descriptionViewID, gotoSiteButtonID,
                infoLogoViewContainerID, infoLogoImageViewID);

        nativeAdView = new NativeAdView(context, nativeAdViewItem);
        wireAdViewListeners(nativeAdView);

        MobwithSDK.initSDK(mContext);
    }

    /**
     * 직광고용/네트워크용 UI 모델을 각각 전달받아 광고 소스에 따라 다른 레이아웃을 사용할 수 있게 생성합니다.
     */
    public MobwithNativeAdView(Context context,
                               String unitId,
                               FrameLayout containerView,
                               NativeAdViewItemModel directAdViewItemModel,
                               NativeAdViewItemModel nativeAdViewItemModel) {
        super(context);
        mContext = context;
        setUnitId(unitId);

        // 직광고 UI
        directNativeAdViewItem = buildViewItem(containerView, directAdViewItemModel);
        nativeAdView = new NativeAdView(context, directNativeAdViewItem);

        // 네트워크 광고 UI
        nativeAdViewItem = buildViewItem(containerView, nativeAdViewItemModel);
        networkAdnativeAdView = new NativeAdView(context, nativeAdViewItem);

        wireAdViewListeners(nativeAdView);
        wireAdViewListeners(networkAdnativeAdView);

        MobwithSDK.initSDK(mContext);
    }

    // region Construction helpers
    private NativeAdViewItem buildViewItem(FrameLayout containerView, NativeAdViewItemModel model) {
        return new NativeAdViewItem(
                mContext,
                containerView,
                model.getViewLayoutID(),
                model.getMediaViewContainerID(),
                model.getAdImageViewID(),
                model.getAdLogoImageViewID(),
                model.getTitleViewID(),
                model.getDescriptionViewID(),
                model.getGotoSiteButtonID(),
                model.getInfoLogoImageViewContainerID(),
                model.getInfoLogoImageViewID());
    }

    private void wireAdViewListeners(NativeAdView view) {
        view.setCtaButtonOnClickListener(v -> performAdClicked());
        view.setOnClickListener(v -> performAdClicked());
        view.setInfoLogoViewOnClickListener(v -> onInfoLogoClicked());
    }

    private void onInfoLogoClicked() {
        if (logoUrl != null && !logoUrl.isEmpty()) {
            Utils.getBrowserPackageName(mContext, logoUrl, mIBannerAdCallback);
        }
        if (adDataModel != null) {
            CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
        }
    }
    // endregion

    // region Public configuration

    /**
     * 이 네이티브 광고 뷰에 사용할 광고 단위 ID를 설정합니다.
     */
    public MobwithNativeAdView setUnitId(String unitId) {
        mBannerUnitID = unitId;
        return this;
    }

    /**
     * 광고 관련 이벤트를 수신할 콜백 리스너를 설정합니다.
     */
    public MobwithNativeAdView setAdListener(iBannerCallback callback) {
        mIBannerAdCallback = callback;
        return this;
    }

    /**
     * 광고 카테고리 모델을 설정합니다.
     */
    public MobwithNativeAdView setMobwithAdCategoryModel(MobwithAdCategoryModel mobwithAdCategoryModel) {
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        return this;
    }

    public MobwithNativeAdView setCategory(List<String> categories) {
        this.categories = categories;
        return this;
    }

    public MobwithNativeAdView setCampaignCodes(List<String> campaignCodes) {
        this.campaignCodes = campaignCodes;
        return this;
    }

    public MobwithNativeAdView setUserKey(String userKey) {
        this.userKey = userKey;
        return this;
    }

    public MobwithNativeAdView setServiceId(String serviceId) {
        this.serviceId = serviceId;
        return this;
    }

    public MobwithNativeAdView setMediaId(String mediaId) {
        this.mediaId = mediaId;
        return this;
    }

    /**
     * 메인 광고 이미지 스케일 설정 기능 (기본값 : false)
     * true로 설정 시 네이티브 광고의 메인 광고 이미지뷰의 스케일을 직접 설정할 수 있습니다.
     */
    public MobwithNativeAdView useImageViewScaleType(boolean isUse) {
        if (nativeAdView != null) {
            nativeAdView.useScaleType(isUse);
        }
        if (networkAdnativeAdView != null) {
            networkAdnativeAdView.useScaleType(isUse);
        }
        return this;
    }

    /**
     * 리워드 광고의 적립 어포던스 배지 노출 설정(위치 / 크기 / 텍스트 / 배경색)을 지정합니다.
     *
     * <p>설정은 <b>이 네이티브 광고뷰에만</b> 적용되며, 배너 등 다른 광고뷰에는 영향을 주지 않습니다.
     * 광고 로드 전에 호출해도 되고, 로드 후 호출하면 즉시 반영됩니다.</p>
     *
     * @param style 적용할 스타일. null 이면 SDK 기본값으로 되돌립니다
     */
    public MobwithNativeAdView setAffordanceStyle(AffordanceStyle style) {
        AffordanceViewManager manager = AffordanceViewManager.getInstance();
        if (nativeAdViewItem != null && nativeAdViewItem.mContainerView != null) {
            manager.setStyle(nativeAdViewItem.mContainerView, style);
        }
        if (directNativeAdViewItem != null && directNativeAdViewItem.mContainerView != null) {
            manager.setStyle(directNativeAdViewItem.mContainerView, style);
        }
        return this;
    }

    /**
     * 영상 광고 자동 일시정지 설정 기능 (기본값 : true)
     * 광고 뷰가 스크롤 등으로 화면에서 벗어나면 영상을 일시정지하고, 다시 보이면 이어서 재생합니다.
     * false 로 설정 시 노출 여부와 상관없이 계속 재생합니다. (앱이 백그라운드로 가도 일시정지하지 않습니다)
     */
    private void useVideoAutoPause(boolean isUse) {
        if (nativeAdView != null) {
            nativeAdView.useVideoAutoPause(isUse);
        }
        if (networkAdnativeAdView != null) {
            networkAdnativeAdView.useVideoAutoPause(isUse);
        }
    }

    /**
     * 영상 광고의 소리를 켜고 끄는 버튼의 사용 여부를 설정합니다. (기본값 : true)
     * 영상은 항상 소리가 꺼진 상태로 재생되며, 버튼을 누를 때마다 소리가 켜지고 꺼집니다.
     */
    private void useVideoSoundButton(boolean isUse) {
        if (nativeAdView != null) {
            nativeAdView.useSoundButton(isUse);
        }
        if (networkAdnativeAdView != null) {
            networkAdnativeAdView.useSoundButton(isUse);
        }
    }

    /**
     * 영상 광고 사운드 버튼의 위치를 설정합니다. (기본값 : Gravity.BOTTOM | Gravity.START)
     *
     * @param gravity Gravity 조합 값. 예) Gravity.BOTTOM | Gravity.START 이면 좌측 하단
     */
    private void setVideoSoundButtonGravity(int gravity) {
        if (nativeAdView != null) {
            nativeAdView.setSoundButtonGravity(gravity);
        }
        if (networkAdnativeAdView != null) {
            networkAdnativeAdView.setSoundButtonGravity(gravity);
        }
    }

    /**
     * 영상 광고 사운드 버튼의 여백을 설정합니다. (기본값 : 10dp)
     *
     * @param marginDp 여백 (dp)
     */
    private void setVideoSoundButtonMargin(int marginDp) {
        if (nativeAdView != null) {
            nativeAdView.setSoundButtonMargin(marginDp);
        }
        if (networkAdnativeAdView != null) {
            networkAdnativeAdView.setSoundButtonMargin(marginDp);
        }
    }
    // endregion

    /**
     * 광고 클릭 이벤트를 수동으로 트리거합니다.
     * pUrl로 브라우저를 열고, onAdClicked() 콜백을 호출하며 클릭 트래킹 이벤트를 전송합니다.
     */
    public void performAdClicked() {
        if (pUrl != null && !pUrl.isEmpty()) {
            Utils.getBrowserPackageName(mContext, pUrl, mIBannerAdCallback);
            if (mIBannerAdCallback != null) {
                mIBannerAdCallback.onAdClicked();
            }
        }

        if (adDataModel != null) {
            CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
        }

        if (rewardBannerModel != null) {
            try {
                if (mmAdData != null) {
                    boolean isDirectAd = mmAdData.exid.startsWith(EX_ID_PREFIX_MOBWADS) || mmAdData.exid.startsWith(EX_ID_PREFIX_MOBWITHAD);

                    if (directNativeAdViewItem != null && isDirectAd) {
                        AffordanceView affordanceView = AffordanceViewManager.getInstance().getAffordanceView(directNativeAdViewItem.mContainerView);
                        if (affordanceView != null && affordanceView.isRewarded()) {
                            AffordanceViewManager.getInstance().setRewarded(mContext, mBannerUnitID, directNativeAdViewItem.mContainerView, false);
                            if (mIBannerAdCallback != null) {
                                mIBannerAdCallback.onRewarded();
                            }
                        }
                    } else {
                        AffordanceView affordanceView = AffordanceViewManager.getInstance().getAffordanceView(nativeAdViewItem.mContainerView);
                        if (affordanceView != null && affordanceView.isRewarded()) {
                            AffordanceViewManager.getInstance().setRewarded(mContext, mBannerUnitID, nativeAdViewItem.mContainerView, false);
                            if (mIBannerAdCallback != null) {
                                mIBannerAdCallback.onRewarded();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 이 광고뷰가 쓰는 컨테이너의 어포던스 배지만 제거합니다.
     * ({@link #setAffordanceStyle(AffordanceStyle)} 으로 지정한 설정은 유지되어 다음 광고에도 적용됩니다.)
     */
    private void detachAffordance() {
        AffordanceViewManager manager = AffordanceViewManager.getInstance();
        if (nativeAdViewItem != null && nativeAdViewItem.mContainerView != null) {
            manager.detach(nativeAdViewItem.mContainerView);
        }
        if (directNativeAdViewItem != null && directNativeAdViewItem.mContainerView != null) {
            manager.detach(directNativeAdViewItem.mContainerView);
        }
    }

    /**
     * 표시 중인 광고의 리소스를 정리합니다.
     * 영상 재생을 중단하고 영상 뷰/사운드 버튼을 포함한 이전 광고 UI 를 모두 제거합니다.
     */
    private void clearAd() {
        if (videoAdapter != null) {
            videoAdapter.destroy();
            videoAdapter = null;
        }
        if (nativeAdView != null) {
            nativeAdView.clearAdView();
        }
        if (networkAdnativeAdView != null) {
            networkAdnativeAdView.clearAdView();
        }
    }

    // region Callback dispatch
    private void notifyLoadSuccess() {
        finishLoading();
        if (!sendSuccessCallback) {
            sendSuccessCallback = true;
            if (mIBannerAdCallback != null) {
                mIBannerAdCallback.onLoadedAdInfo(true, "");
            }
        }
    }

    private void notifyLoadFailed(String message) {
        finishLoading();
        if (mIBannerAdCallback != null && !sendFailCallback) {
            sendFailCallback = true;
            mIBannerAdCallback.onLoadedAdInfo(false, message);
        }
    }

    private void releaseMediation() {
        if (mediationManager != null) {
            mediationManager.release();
            mediationManager = null;
        }
    }

    private void resetState() {
        mSessionId = "";
        advrtsPrdtCode = "";
        rewardBannerModel = null;
        sendSuccessCallback = false;
        sendFailCallback = false;
    }

    private void finishLoading() {
        isLoading = false;
        MainThreadHandler.removeCallbacks(loadTimeout);
    }
    // endregion

    // region Load flow

    /**
     * 네이티브 광고 로드를 시작합니다.
     */
    public void loadAd() {

        if (isLoading) return;
        isLoading = true;
        final int token = ++mLoadToken;
        MainThreadHandler.postDelayed(loadTimeout, LOAD_TIMEOUT_MS);

        releaseMediation();
        resetState();

        detachAffordance();

        mSessionId = "";
        advrtsPrdtCode = "";
        mmAdData = null;
        rewardBannerModel = null;
        sendSuccessCallback = false;
        sendFailCallback = false;

        // 이전 광고가 남아있지 않도록 정리한 뒤 로드를 시작합니다.
        clearAd();

        if (!Utils.isConnectNetwork(mContext)) {
            LogPrint.d("banner loadAd noConnectNetwork");
            notifyLoadFailed("noConnectNetwork");
            return;
        }

        new MWRequestSortList(mContext, mBannerUnitID).execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) {
                if (token != mLoadToken) return;
                LogPrint.d("onResponse : " + response);
                handleSortListResponse(response);
            }

            @Override
            public void onFailure(IOException e) {
                if (token != mLoadToken) return;
                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());
                MainThreadHandler.post(() -> notifyLoadFailed(e.getLocalizedMessage()));
            }
        });
    }

    private void handleSortListResponse(String response) {
        try {
            SortListResponse sortList = new SortListResponse(new JSONObject(response));

            if (!sortList.isSuccess()) {
                notifyLoadFailed(sortList.message);
                return;
            }

            mSessionId = sortList.sessionId;

            advrtsPrdtCode = sortList.advrtsPrdtCode;
            exlItlMemo = sortList.exlItlMemo;
            adBname = sortList.adBname;
            isParallel = sortList.isParallel;
            JSONObject rewardBanner = sortList.rewardBanner;

            if (!advrtsPrdtCode.isEmpty() && advrtsPrdtCode.equals("14")) {
                if (rewardBanner != null) {
                    rewardBannerModel = new MWRewardBannerModel(rewardBanner);
                    rewardBannerModel.setMediaId(mediaId);
                    rewardBannerModel.setServiceId(serviceId);
                    rewardBannerModel.setUserKey(userKey);
                }
            }

            sendSortListImpression(mContext, mBannerUnitID, advrtsPrdtCode, mSessionId);

            if (mediationManager != null) {
                mediationManager.release();
                mediationManager = null;
            }

            mediationManager = new MediationManager(mContext, sortList.data, BannerType.NATIVE_AD, mobwithAdCategoryModel, nativeAdViewItem, categories, campaignCodes, rewardBannerModel);
            mediationManager.LoadMediation(new NativeMediationCallback(sortList));
        } catch (Exception e) {
            notifyLoadFailed(e.getLocalizedMessage());
        }
    }

    /**
     * 광고 뷰를 떼어내고 리소스를 해제한다. 이후 loadAd() 재호출 가능. 메인 스레드에서 호출.
     */
    public void destroy() {
        mLoadToken++;                    // 진행 중인 모든 비동기 응답 무효화
        finishLoading();                 // 가드, 타임아웃 해제
        releaseMediation();              // 어댑터 destroy (AdMob NativeAd 등)

        nativeAdView.destroyView();
        if (networkAdnativeAdView != null) networkAdnativeAdView.destroyView();

        if (nativeAdViewItem.mContainerView != null) {
            AffordanceViewManager.getInstance().detach(nativeAdViewItem.mContainerView);
            nativeAdViewItem.mContainerView.removeAllViews();
        }

        adDataModel = null;              // 남은 클릭 경로 차단
        pUrl = null;
        logoUrl = null;
        rewardBannerModel = null;
        // mIBannerAdCallback 은 유지 (재사용을 위해)
        try {
            clearAd();
            detachAffordance();
            mmAdData = null;
        } catch (Exception ignore) {
        }
    }

    /**
     * 미디에이션 결과를 처리하는 콜백.
     */
    private final class NativeMediationCallback implements iMobonMediationCallback {
        private final SortListResponse sortList;

        NativeMediationCallback(SortListResponse sortList) {
            this.sortList = sortList;
        }

        @Override
        public void onLoadedAdData(String data, final AdapterObject adapter) {
            LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
        }

        @Override
        public void onAdAdapter(AdapterObject adapter) {
            mmAdData = adapter.getAdData();
            boolean hasJsonData = mmAdData != null && mmAdData.jsonData != null && !mmAdData.jsonData.isEmpty();

            if (hasJsonData) {
                checkJsonAd(adapter);
            } else if (adapter instanceof JsonAdapter) {
                onAdFailedToLoad(adapter, Key.NOFILL);
            } else if (adapter instanceof AdfitAdapter) {
                //biz board
                AdfitAdapter adfitAdapter = (AdfitAdapter) adapter;
                nativeAdView.updateUIBizBoard(adfitAdapter);
                notifyLoadSuccess();
            } else {
                // adapter는 항상 non-null. 외부 DSP사 Native Ad 수신 → 로딩 성공으로 처리.
                LogPrint.d(mBannerUnitID + " : onAdAdapter : " + adapter.getName());
                notifyLoadSuccess();
            }
        }

        @Override
        public void onAdRequest(AdapterObject adapter) {
            sendDspImpression(mContext, mSessionId, mBannerUnitID, sortList.advrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
            if (adapter != null) {
                LogPrint.d("onAdFailedToLoad : " + adapter.getName());
            } else {
                LogPrint.d("onAdFailedToLoad : [Null Adapter] " + errorMsg);
            }
            notifyLoadFailed(Key.NOFILL);
        }

        @Override
        public void onAdFailedAdapterName(AdapterObject adapter) {
            sendPassBackImpression(mContext, mSessionId, mBannerUnitID, advrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdClicked() {
            if (mIBannerAdCallback != null) {
                mIBannerAdCallback.onAdClicked();
            }
        }

        @Override
        public void onAdImpression() {
        }

        @Override
        public void onAppFinish() {
        }

        @Override
        public void onAdDisplayed() {
        }

        @Override
        public void onAdComplete() {
        }

        @Override
        public void onAdSkip() {
        }

        @Override
        public void onAdClosed() {
        }

        @Override
        public void onAdCancel() {
        }

        @Override
        public void onAdFailedToOpen() {
        }
    }
    // endregion

    /**
     * 수신된 JSON 광고 데이터로 네이티브 광고 UI를 업데이트합니다. (메인 스레드에서 실행)
     * exId로 직광고/네트워크 광고를 구분하여 적절한 NativeAdView 를 사용합니다.
     */
    private void updateUIWith(String jsonString, boolean isShowInfoLogo, String exId) {
        MainThreadHandler.post(() -> {
            try {
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONObject dataObject = jsonObject.getJSONObject("data");
                JSONObject adData = dataObject.getJSONArray("data").getJSONObject(0);

                adDataModel = new AdDataModel(adData);
                pUrl = adData.optString("pUrl");
                logoUrl = dataObject.optString("logoUrl");

                boolean isDirectAd = exId.startsWith(EX_ID_PREFIX_MOBWADS) || exId.startsWith(EX_ID_PREFIX_MOBWITHAD);

                NativeAdView targetView = (networkAdnativeAdView != null && !isDirectAd) ? networkAdnativeAdView : nativeAdView;
                targetView.setRewardBannerModel(rewardBannerModel);
                if (videoAdapter != null) {
//                    targetView.updateUIVideo(jsonString, videoAdapter);
                    targetView.updateUIWith(jsonString, isShowInfoLogo, videoAdapter);
                    View videoView = (View) videoAdapter.getAdView();
                    if (videoView != null) {
                        videoView.setOnClickListener(new OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                videoAdapter.performAdClick();
                            }
                        });
                    }
                    //영상 광고 사운드 버튼 (기본값 : 사용함 / 좌측 하단 / 10dp)
                    useVideoSoundButton(true);
                    setVideoSoundButtonGravity(Gravity.BOTTOM | Gravity.START);
                    setVideoSoundButtonMargin(10);
                    //영상 광고 자동 일시정지 (광고 뷰가 화면에서 벗어나면 일시정지, 다시 보이면 재생)
                    useVideoAutoPause(true);
                } else {
                    targetView.updateUIWith(jsonString, isShowInfoLogo, videoAdapter);
                }
                notifyLoadSuccess();
            } catch (Exception e) {
                notifyLoadFailed(e.getLocalizedMessage());
            }
        });
    }

    private void checkJsonAd(AdapterObject adapter) {
        try {
            if (adapter instanceof JsonAdapter) {
                String useParallel = String.valueOf(((JsonAdapter) adapter).useParallel);
                JSONObject jsonData = new JSONObject(adapter.getAdData().jsonData);
                JSONArray adData = jsonData.optJSONObject("data").optJSONArray("data");
                if (adData != null && adData.length() > 0) {
                    String videoAd = adData.getJSONObject(0).optString("videoAd");
                    String custom10 = adData.getJSONObject(0).optString("custom10");

                    if (!videoAd.isEmpty() || !custom10.isEmpty()) {
                        videoAdapter = new VideoAdapter(
                                mContext, adapter.getName(), adapter.getUnitId(),
                                exlItlMemo, BannerType.NATIVE_AD, adapter.getAdData(),
                                false, mBannerUnitID, useParallel, adBname);

                        VideoAdapter.OnVideoListener videoListener = isReady -> {
                            if (isReady) {
                                MMAdData nnAdData = adapter.getAdData();
                                updateUIWith(nnAdData.jsonData, nnAdData.needShowInfoLogo(), nnAdData.exid);
                            } else {
                                // 영상을 재생할 수 없으면 영상 없이 일반 네이티브 광고로 표시합니다.
                                if (videoAdapter != null) {
                                    videoAdapter.destroy();
                                    videoAdapter = null;
                                }
                                MMAdData nnAdData = adapter.getAdData();
                                updateUIWith(nnAdData.jsonData, nnAdData.needShowInfoLogo(), nnAdData.exid);
                            }
                        };

                        if (!videoAd.isEmpty()) {
                            videoAdapter.initVideoAd(videoAd, adData.getJSONObject(0).optString("pUrl"), videoListener);
                        } else {
                            videoAdapter.initVastVideo(custom10, videoListener);
                        }
                    } else {
                        MMAdData nnAdData = adapter.getAdData();
                        updateUIWith(nnAdData.jsonData, nnAdData.needShowInfoLogo(), nnAdData.exid);
                    }
                }
            }
        } catch (Exception e) {
            LogPrint.d("checkJsonAd error : " + e.getLocalizedMessage());
            notifyLoadFailed(e.getLocalizedMessage());
        }
    }
}