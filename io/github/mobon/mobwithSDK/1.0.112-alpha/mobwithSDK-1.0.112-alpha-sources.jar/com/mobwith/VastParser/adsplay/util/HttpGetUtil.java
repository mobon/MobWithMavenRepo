package com.mobwith.VastParser.adsplay.util;

import android.util.Log;

import com.mobwith.httpmodule.MobonOkHttpClient;
import com.mobwith.httpmodule.MobonRequest;
import com.mobwith.httpmodule.MobonResponse;
import com.mobwith.manager.LogPrint;

public class HttpGetUtil {
	static class HttpGet {

		MobonOkHttpClient client = new MobonOkHttpClient();
		String url;

		public HttpGet(String url) {
			this.url = url;
		}

		public String run()  {
			try {

				MobonRequest request = new MobonRequest.Builder().url(url).build();
				MobonResponse response = client.newCall(request).execute();

                return response.body().string();

			} catch (Exception e) {
				LogPrint.e("VAST", "HttpGetUtil run() Exception : " + e.getMessage());
			}

			return "";
		}
	}

	public static String get(String url) {
		return new HttpGet(url).run();
	}



	public static void sendRequest(String url) {
		//TODO: 실 적용 테스트때는 아래 주석 풀어줘야 한다.
		String response = new HttpGet(url).run();

		Log.d("VAST", "Send[Request]---------------------------------\n" + url + "\n----------------------------------\n");
		Log.d("VAST", "Send[Result]----------------------------------\n : " + response + "\n----------------------------------\n");
	}
}
