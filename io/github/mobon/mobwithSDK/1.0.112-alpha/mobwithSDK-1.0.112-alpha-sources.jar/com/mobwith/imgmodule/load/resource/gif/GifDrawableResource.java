package com.mobwith.imgmodule.load.resource.gif;

import androidx.annotation.NonNull;

import com.mobwith.imgmodule.load.engine.Initializable;
import com.mobwith.imgmodule.load.resource.drawable.DrawableResource;

/** A resource wrapping an {@link com.mobwith.imgmodule.load.resource.gif.GifDrawable}. */
public class GifDrawableResource extends DrawableResource<GifDrawable> implements Initializable {
  // Public API.
  @SuppressWarnings("WeakerAccess")
  public GifDrawableResource(GifDrawable drawable) {
    super(drawable);
  }

  @NonNull
  @Override
  public Class<GifDrawable> getResourceClass() {
    return GifDrawable.class;
  }

  @Override
  public int getSize() {
    return drawable.getSize();
  }

  @Override
  public void recycle() {
    drawable.stop();
    drawable.recycle();
  }

  @Override
  public void initialize() {
    drawable.getFirstFrame().prepareToDraw();
  }
}
