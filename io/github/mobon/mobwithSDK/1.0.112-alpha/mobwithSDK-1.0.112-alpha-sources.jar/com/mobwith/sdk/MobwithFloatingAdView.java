package com.mobwith.sdk;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.mobwith.adapters.AdapterObject;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 앱 화면(Activity) 안에서 모든 뷰 위에 떠 있는 플로팅 광고 뷰.
 * <p>
 * SYSTEM_ALERT_WINDOW 권한을 사용하지 않습니다. WindowManager 오버레이 대신
 * 현재 Activity의 DecorView에 직접 addView 하는 방식이라, 다른 앱 위에는 노출되지
 * 않고 "현재 앱 화면 안"에서만 최상단에 표시됩니다. (권한 불필요, 심사 이슈 회피 가능)
 * <p>
 * - Click(탭): 설정된 랜딩 URL로 이동
 * - setPosition()으로 상하좌우 배치 지정 (예: Gravity.TOP, Gravity.LEFT → 상단 왼쪽)
 * - setTopMargin()/setBottomMargin()/setLeftMargin()/setRightMargin()으로 배치 기준 여백(dp) 지정
 * <p>
 * 주의: DecorView에 붙는 방식이므로 Activity가 바뀌면 사라집니다.
 * 앱 전체에서 계속 띄우려면 Activity마다 show()를 다시 호출하세요.
 */
class MobwithFloatingAdView extends FrameLayout implements MWCommonRequestInterface {
    //닫기버튼 정책 : 자정에 리셋, 앱 종료 시는 보여주기
    private final Activity mActivity;
    private final ImageView adImageView;
    private final LayoutParams layoutParams;

    private String landingUrl;

    private String mUnitId;
    private String mSessionId = "";
    private String mAdvrtsPrdtCode = "";
    private String mExlItlMemo = "";
    private String mIsParallel = "";

    private AdapterObject mBannerAdapter;
    private iBannerCallback mBannerCallback;
    private MediationManager mediationManager;
    private List<String> categories;
    private List<String> campaignCodes;

    private final AtomicBoolean isInLoading = new AtomicBoolean(false);
    private boolean sendSuccessCallback;
    private boolean sendFailCallback;

    // ──────────────────────────────────────────────────────────────────────
    // 미디에이션 콜백
    // ──────────────────────────────────────────────────────────────────────

    private final iMobonMediationCallback mediationCallback = new iMobonMediationCallback() {

        @Override
        public void onAdAdapter(AdapterObject adapter) {
            LogPrint.d("FloatingAdView - onAdAdapter");
            if (adapter == null) {
                dispatchFail(Key.NOFILL);
                return;
            }

            boolean hasJsonData = adapter.getAdData() != null && adapter.getAdData().jsonData != null && !adapter.getAdData().jsonData.isEmpty();

            if (hasJsonData) {
                MainThreadHandler.post(() -> {
                    if (mBannerAdapter != null) {
                        mBannerAdapter.destroy();
                    }

                    mBannerAdapter = adapter;

                    try {
                        LogPrint.d("FloatingAdView - onAdAdapter: " + adapter.getAdData().jsonData);
                        JSONObject jsonObject = new JSONObject(adapter.getAdData().jsonData);
                        JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);
                        AdDataModel adDataModel = new AdDataModel(adData);
                        final String adImage = adData.optString("pImg", "");
                        ImageModule.with(mActivity).load(adImage).into(adImageView);
                        dispatchSuccess();
                        show();
                    } catch (Exception e) {
                        dispatchFail(e.getLocalizedMessage());
                    }
                });
            } else {
                dispatchFail(Key.NOFILL);
            }
        }

        @Override
        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
            if (adapter != null) adapter.destroy();
            dispatchFail(errorMsg);
        }

        @Override
        public void onAdFailedAdapterName(AdapterObject adapter) {
            sendPassBackImpression(
                    getContext(), mSessionId, mUnitId, mAdvrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdRequest(AdapterObject adapter) {
            sendDspImpression(
                    getContext(), mSessionId, mUnitId, mAdvrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdClicked() {
            if (mBannerCallback != null) mBannerCallback.onAdClicked();
        }

        @Override
        public void onLoadedAdData(String data, AdapterObject adapter) {
        }

        @Override
        public void onAdClosed() {
        }

        @Override
        public void onAdCancel() {
        }

        @Override
        public void onAdImpression() {
        }

        @Override
        public void onAppFinish() {
        }

        @Override
        public void onAdDisplayed() {
        }

        @Override
        public void onAdComplete() {
        }

        @Override
        public void onAdSkip() {
        }

        @Override
        public void onAdFailedToOpen() {
        }
    };

    public MobwithFloatingAdView(Activity activity) {
        super(activity);
        this.mActivity = activity;

        // 광고 이미지를 담을 ImageView
        adImageView = new ImageView(activity);
        LayoutParams imageParams = new LayoutParams(
                Utils.convertDpToPx(activity, 150),
                Utils.convertDpToPx(activity, 150));
        addView(adImageView, imageParams);

        // 기본 배치: 상단-왼쪽, 여백 없음. setPosition()/setXxxMargin()으로 변경 가능.
        layoutParams = new LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;

        // 탭 시 랜딩 이동 (드래그 이동 기능은 제거됨)
        setOnClickListener(v -> openLanding());
    }

    public MobwithFloatingAdView setUnitId(String unitId) {
        mUnitId = unitId;
        return this;
    }

    /**
     * 광고 이미지를 리소스로 설정합니다.
     */
    public void setAdImageResource(int resId) {
        adImageView.setImageResource(resId);
    }

    /**
     * 광고 이미지를 Drawable로 설정합니다.
     */
    public void setAdImageDrawable(Drawable drawable) {
        adImageView.setImageDrawable(drawable);
    }

    /**
     * 클릭 시 이동할 랜딩 URL을 설정합니다.
     */
    public void setLandingUrl(String url) {
        this.landingUrl = url;
    }

    /**
     * 뷰가 배치될 상하/좌우 위치를 설정합니다.
     * 예: setPosition(Gravity.TOP, Gravity.LEFT) → 화면(부모 뷰) 상단 왼쪽에 배치.
     *
     * @param verticalGravity   Gravity.TOP 또는 Gravity.BOTTOM
     * @param horizontalGravity Gravity.LEFT 또는 Gravity.RIGHT
     */
    public MobwithFloatingAdView setPosition(int verticalGravity, int horizontalGravity) {
        layoutParams.gravity = verticalGravity | horizontalGravity;
        applyLayoutParamsIfAttached();
        return this;
    }

    /**
     * 위쪽 기준 여백을 설정합니다. (dp 단위, 예: setTopMargin(10) → 위치로부터 10dp 여백)
     * setPosition()에서 Gravity.TOP을 사용할 때 적용됩니다.
     */
    public MobwithFloatingAdView setTopMargin(int dp) {
        layoutParams.topMargin = Utils.convertDpToPx(mActivity, dp);
        applyLayoutParamsIfAttached();
        return this;
    }

    /**
     * 아래쪽 기준 여백을 설정합니다. (dp 단위)
     * setPosition()에서 Gravity.BOTTOM을 사용할 때 적용됩니다.
     */
    public MobwithFloatingAdView setBottomMargin(int dp) {
        layoutParams.bottomMargin = Utils.convertDpToPx(mActivity, dp);
        applyLayoutParamsIfAttached();
        return this;
    }

    /**
     * 왼쪽 기준 여백을 설정합니다. (dp 단위)
     * setPosition()에서 Gravity.LEFT를 사용할 때 적용됩니다.
     */
    public MobwithFloatingAdView setLeftMargin(int dp) {
        layoutParams.leftMargin = Utils.convertDpToPx(mActivity, dp);
        applyLayoutParamsIfAttached();
        return this;
    }

    /**
     * 오른쪽 기준 여백을 설정합니다. (dp 단위)
     * setPosition()에서 Gravity.RIGHT를 사용할 때 적용됩니다.
     */
    public MobwithFloatingAdView setRightMargin(int dp) {
        layoutParams.rightMargin = Utils.convertDpToPx(mActivity, dp);
        applyLayoutParamsIfAttached();
        return this;
    }

    private void applyLayoutParamsIfAttached() {
        if (getParent() != null) {
            setLayoutParams(layoutParams);
        }
    }

    /**
     * Activity의 DecorView에 추가하여 현재 화면의 모든 뷰 위에 노출합니다.
     */
    public void show() {
//        if (getParent() == null) {
//            ViewGroup decorView = (ViewGroup) mActivity.getWindow().getDecorView();
//            decorView.addView(this, layoutParams);
//        }
        if (getParent() == null) {
            ViewGroup contentView = mActivity.findViewById(android.R.id.content);
            if (contentView == null) {
                LogPrint.d("FloatingAdView - contentView is null");
                return;
            }
            contentView.addView(this, layoutParams);
        }
    }

    public void renderAdView() {
        try {
            removeAllViews();

            dispatchSuccess();
            show();
        } catch (Exception e) {
            dispatchFail(e.getLocalizedMessage());
        }
    }

    public void loadAd() {
        if (!isInLoading.compareAndSet(false, true)) {
            return;
        }

        if (!Utils.isConnectNetwork(getContext())) {
            dispatchFail("noConnectNetwork");
            return;
        }

        mSessionId = "";
        sendSuccessCallback = false;
        sendFailCallback = false;

        new MWRequestSortList(getContext(), mUnitId).execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));

                    if (!sortList.isSuccess()) {
                        dispatchFail(Key.NOFILL);
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    mAdvrtsPrdtCode = sortList.advrtsPrdtCode;
                    mExlItlMemo = sortList.exlItlMemo;
                    mIsParallel = sortList.isParallel;

                    sendSortListImpression(getContext(), mUnitId, mAdvrtsPrdtCode, mSessionId);
                    mediationManager = new MediationManager(getContext(), sortList.data, BannerType.ENDING, null, campaignCodes, categories);
                    mediationManager.LoadMediation(mediationCallback);

                } catch (Exception e) {
                    dispatchFail(e.getLocalizedMessage());
                }
            }

            @Override
            public void onFailure(IOException e) {
                dispatchFail(e.getLocalizedMessage());
            }
        });
    }

    /**
     * 뷰를 화면에서 제거합니다.
     */
    public void dismiss() {
        ViewGroup parent = (ViewGroup) getParent();
        if (parent != null) {
            parent.removeView(this);
        }
    }

    private void openLanding() {
        if (landingUrl == null || landingUrl.isEmpty()) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(landingUrl));
        mActivity.startActivity(intent);
    }

    // ──────────────────────────────────────────────────────────────────────
    // 콜백 디스패치
    // ──────────────────────────────────────────────────────────────────────

    private void dispatchSuccess() {
        MainThreadHandler.post(() -> {
            isInLoading.set(false);
            if (sendSuccessCallback) return;
            sendSuccessCallback = true;
            if (mBannerCallback != null) {
                mBannerCallback.onLoadedAdInfo(true, "");
            }
        });
    }

    private void dispatchFail(String message) {
        MainThreadHandler.post(() -> {
            isInLoading.set(false);
            if (sendFailCallback) return;
            sendFailCallback = true;
            sendSuccessCallback = true;
            if (mBannerCallback != null) {
                mBannerCallback.onLoadedAdInfo(false, message);
            }
        });
    }
}