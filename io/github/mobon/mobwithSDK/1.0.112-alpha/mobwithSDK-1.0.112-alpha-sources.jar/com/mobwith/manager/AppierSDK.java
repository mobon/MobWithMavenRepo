package com.mobwith.manager;

import android.app.Application;
import android.content.Context;

/**
 * Appier AISTRA SDK(com.appier:aistra-android) 연동부.
 *
 * AISTRA 클래스를 직접 import 해서 호출하면, 연동사 앱에 해당 SDK가 빠져 있을 때
 * (혹은 구버전 argus-android만 들어있을 때) 호출 시점에 NoClassDefFoundError로 앱이 죽는다.
 * 그래서 다른 외부 SDK들과 동일하게 {@link Reflection} 을 통해서만 접근하고,
 * SDK를 찾지 못하면 조용히 비활성 상태로 남는다.
 */
public class AppierSDK {
    private static final String CLASS_AISTRA = "com.appier.aistra.api.Aistra";

    private static boolean isInitArgus = false;
    /** com.appier.aistra.api.Aistra.INSTANCE (Kotlin object 싱글턴) */
    private static Object aistraInstance;

    /** AISTRA SDK가 런타임 클래스패스에 존재하는지 여부. */
    public static boolean isAvailable() {
        return resolveInstance() != null;
    }

    public static void initArgus(Context context) {
        if (isInitArgus) {
            return;
        }

        Object instance = resolveInstance();
        if (instance == null) {
            LogPrint.d("AppierSDK.initArgus - AISTRA SDK not found");
            return;
        }

        if (context == null) {
            LogPrint.d("AppierSDK.initArgus - context is null");
            return;
        }

        Context applicationContext = context.getApplicationContext();
        if (!(applicationContext instanceof Application)) {
            LogPrint.d("AppierSDK.initArgus - applicationContext is not an Application");
            return;
        }

        try {
            new Reflection.MethodBuilder(instance, "initialize")
                    .addParam(Application.class, (Application) applicationContext)
                    .execute();
            isInitArgus = true;
            LogPrint.d("AppierSDK.initArgus - AISTRA SDK init success");
        } catch (Throwable t) {
            LogPrint.d("AppierSDK.initArgus - AISTRA SDK init fail - " + t);
        }
    }

    public static String getData() {
        if (!isInitArgus) {
            return "";
        }

        Object instance = resolveInstance();
        if (instance == null) {
            return "";
        }

        try {
            Object data = new Reflection.MethodBuilder(instance, "getData").execute();
            return (data instanceof String) ? (String) data : "";
        } catch (Throwable t) {
            LogPrint.d("AppierSDK.getData - AISTRA SDK getData fail - " + t);
            return "";
        }
    }

    public static String getVersion() {
        if (!isInitArgus) {
            return "";
        }

        Object instance = resolveInstance();
        if (instance == null) {
            return "";
        }

        try {
            Object data = new Reflection.MethodBuilder(instance, "getVersion").execute();
            return (data instanceof String) ? (String) data : "";
        } catch (Throwable t) {
            LogPrint.d("AppierSDK.getData - AISTRA SDK getVersion fail - " + t);
            return "";
        }
    }

    /**
     * Aistra 싱글턴을 한 번만 찾아서 캐싱한다.
     * 클래스가 없으면 null을 돌려주고, 이후 호출은 모두 no-op 이 된다.
     */
    private static synchronized Object resolveInstance() {
        if (aistraInstance == null) {
            try {
                aistraInstance = Class.forName(CLASS_AISTRA).getField("INSTANCE").get(null);
            } catch (Throwable t) {
                aistraInstance = null;
            }
        }
        return aistraInstance;
    }
}
