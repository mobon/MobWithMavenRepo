package com.mobwith.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;

import com.mobwith.manager.IntegrationHelper;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.Reflection;
import com.mobwith.manager.nativeadview.NativeAdViewItem;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.splash.MWSplashAdResponse;

import org.jetbrains.annotations.NotNull;

/**
 * Created by yikim on 2018-02-09.
 * 광고 어댑터 객체를 나타내는 클래스입니다.
 * 다양한 광고 네트워크의 광고를 통합/관리하며, 공통 인터페이스(로드, 표시, 생명주기 등)를 제공합니다.
 */
public class AdapterObject {

    private String mName;
    private String mAdapterPackageName;
    private String mUnitId;
    private String mExlItlSeq;
    protected int mAdType;
    private MMAdData mAdData; // json ad data
    private MWSplashAdResponse.MWAdvertData mSplashAdData; // json ad data
    public NativeAdViewItem mAdViewItem;
    private Object instance;

    /**
     * 어댑터 이름, 패키지 이름, 어댑터 사용 여부를 받아 생성합니다.
     */
    public AdapterObject(String name, String pkgName) {
        this.mName = name;
        this.mAdapterPackageName = pkgName;
    }

    /**
     * 광고 네트워크 정보, 광고 데이터, 테스트 모드 여부 등을 받아 생성합니다.
     *
     * @param name       광고 네트워크 이름
     * @param unitId     광고 단위 ID
     * @param AdType     광고 타입 (사용되지 않음)
     * @param adData     광고 데이터
     * @param isTestMode 테스트 모드 사용 여부
     */
    public AdapterObject(String name, String unitId, String AdType, MMAdData adData, boolean isTestMode) {
        this.mName = name;
        this.mUnitId = unitId;
        mAdData = adData;
        if (isTestMode) {
            setTestMode(true);
        }
    }

    /**
     * 광고 네트워크 이름에 해당하는 어댑터 패키지 이름을 반환합니다. 매칭되는 항목이 없으면 null.
     */
    private static String resolveAdapterPackageName(String name) {
        if (name.equalsIgnoreCase(IntegrationHelper.ADFIT)
                || name.equalsIgnoreCase(IntegrationHelper.KAKAO_ADFIT)) {
            return IntegrationHelper.PackageNames.ADFIT;
        } else if (name.equalsIgnoreCase(IntegrationHelper.NEW_ADOPSDK)) {
            return IntegrationHelper.PackageNames.NEW_ADOPSDK;
        } else if (name.equalsIgnoreCase(IntegrationHelper.COUPANGSDK)) {
            return IntegrationHelper.PackageNames.COUPANGSDK;
        } else if (name.equalsIgnoreCase(IntegrationHelper.ADMOB)) {
            return IntegrationHelper.PackageNames.ADMOB;
        }
        return null;
    }

    // region Simple accessors
    public String getName() {
        return this.mName;
    }

    void setName(String name) {
        this.mName = name;
    }

    public MMAdData getAdData() {
        return mAdData;
    }

    public void setAdData(MMAdData _data) {
        mAdData = _data;
    }

    public void setSplashData(MWSplashAdResponse.MWAdvertData mSplashAdData) {
        this.mSplashAdData = mSplashAdData;
    }

    public MWSplashAdResponse.MWAdvertData getSplashData() {
        return mSplashAdData;
    }

    public String getAdapterPackageName() {
        return this.mAdapterPackageName;
    }

    /**
     * 광고 단위 ID를 반환합니다. null인 경우 빈 문자열을 반환합니다.
     */
    public String getUnitId() {
        return mUnitId == null ? "" : mUnitId;
    }

    /**
     * SortList 항목의 가중치(exlItlSeq)를 반환합니다. null인 경우 빈 문자열을 반환합니다.
     */
    public String getExlItlSeq() {
        return mExlItlSeq == null ? "" : mExlItlSeq;
    }

    /**
     * SortList 항목의 가중치(exlItlSeq)를 지정합니다. 어댑터 생성 직후 MediationManager 가 설정합니다.
     */
    public void setExlItlSeq(String exlItlSeq) {
        this.mExlItlSeq = exlItlSeq;
    }

    public boolean isCreated() {
        return instance != null;
    }
    // endregion

    // region Reflection helper

    /**
     * 실제 어댑터의 MethodBuilder를 구성하기 위한 콜백.
     */
    private interface MethodConfigurer {
        void configure(Reflection.MethodBuilder builder);
    }

    /**
     * 인스턴스가 존재할 때 리플렉션으로 어댑터의 메소드를 호출합니다.
     * 예외 발생 시 메소드 이름을 포함해 로그를 남깁니다.
     *
     * @param methodName 호출할 메소드 이름
     * @param configurer 파라미터 구성 콜백 (없으면 null)
     */
    private void invokeAdapterMethod(String methodName, MethodConfigurer configurer) {
        if (instance == null) {
            return;
        }
        try {
            Reflection.MethodBuilder builder = new Reflection.MethodBuilder(instance, methodName);
            if (configurer != null) {
                configurer.configure(builder);
            }
            builder.execute();
        } catch (Exception e) {
            System.out.println("AdapterObject " + methodName + "() : " + e.getMessage());
        }
    }
    // endregion

    // region Reflection-backed adapter calls

    /**
     * 어댑터를 초기화합니다. (리플렉션으로 실제 어댑터의 init 호출)
     *
     * @param unit_id 광고 단위 ID
     * @param AdSize  광고 크기
     * @param width   광고 너비 (사용되지 않음)
     * @param height  광고 높이 (사용되지 않음)
     */
    public void init(String unit_id, int AdSize, int width, int height) {
        invokeAdapterMethod("init", builder -> builder
                .addParam(String.class, unit_id)
                .addParam(int.class, AdSize));
    }

    public void setLog(boolean is) {
        invokeAdapterMethod("setLog", builder -> builder.addParam(boolean.class, is));
    }

    public void getVersion() {
        invokeAdapterMethod("getVersion", null);
    }

    public void setTestMode(boolean isTest) {
        invokeAdapterMethod("setTestMode", builder -> builder.addParam(boolean.class, isTest));
    }

    public void close() {
        invokeAdapterMethod("close", null);
    }
    // endregion

    // region Overridable hooks (하위 클래스/리플렉션에서 실제 구현)
    public void onCreate(Context context, String className) {
    }

    public void load(String AdType) {
    }

    public boolean isLoaded() {
        return false;
    }

    public boolean show() {
        return false;
    }

    public boolean show(@NotNull Activity activity) {
        return false;
    }

    public void setAdListener(final MediationAdListener _listener) {
    }

    public Object getAdView() {
        return null;
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public void destroy() {
    }
    // endregion

    // region Native ad hooks
    public boolean canUseNativeAdView() {
        return false;
    }

    public void setUpNativeAdView(NativeAdViewItem adViewItem) {
        mAdViewItem = adViewItem;
    }

    public void loadNativeAd() {
    }

    public void reDrawNativeAd() {
    }

    public ViewGroup getNativeAdView() {
        return null;
    }
    // endregion
}