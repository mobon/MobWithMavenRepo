package com.mobwith.sdk;

import android.content.Context;
import android.text.TextUtils;

import com.mobwith.adapters.AdapterObject;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

public class MobwithNativeAdBridge implements MWCommonRequestInterface {

    private Context mContext;
    private String zoneId;
    private String mSessionId = "";
    private String advrtsPrdtCode = "";
    private String exlItlMemo = "";
    private String adBname = "";
    private OnResultNativeAdBridge onResultNativeAdBridge;

    public interface OnResultNativeAdBridge{
        void onSuccess(AdapterObject adapterObject);
        void onFailed(String errorMsg);
    }

    public MobwithNativeAdBridge(@NotNull Context context, @NotNull String zoneId, @NotNull OnResultNativeAdBridge onResultNativeAdBridge){
        this.mContext = context;
        this.zoneId = zoneId;
        this.onResultNativeAdBridge = onResultNativeAdBridge;
    }

    public void getNativeAdData(){
        try {
            MWRequestSortList mwRequestSortList = new MWRequestSortList(mContext, zoneId);
            mwRequestSortList.execute(new MobWithApiCallback() {
                @Override
                public void onSuccess(String response) throws IOException {
                    try {
                        SortListResponse sortList = new SortListResponse(new JSONObject(response));
                        if (!sortList.isSuccess()) {
                            LogPrint.d("onResponse : " + sortList.message);
                            return;
                        }

                        mSessionId = sortList.sessionId;

                        advrtsPrdtCode = sortList.advrtsPrdtCode;
                        exlItlMemo = sortList.exlItlMemo;
                        adBname = sortList.adBname;

                        sendSortListImpression(mContext, zoneId, sortList.advrtsPrdtCode, mSessionId);

                        MediationManager mediationManager = new MediationManager(mContext, sortList.data,BannerType.NATIVE_AD,null,null, false);
                        mediationManager.LoadMediation(new iMobonMediationCallback() {
                            @Override
                            public void onLoadedAdData(String data, AdapterObject adapter) {
                                LogPrint.e("onLoadedAdData : " + data);
                            }

                            @Override
                            public void onAdAdapter(AdapterObject adapter) {
                                try {
//                                    JSONObject jsonObject = new JSONObject(adapter.getAdData().jsonData);
//                                    JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);
//                                    LogPrint.d("adData : " + adData.toString());
//                                    AdDataModel adDataModel = new AdDataModel(adData);

                                    onResultNativeAdBridge.onSuccess(checkJsonAd(adapter));
                                } catch (Exception e){
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onAdClosed() {

                            }

                            @Override
                            public void onAdCancel() {

                            }

                            @Override
                            public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
                                onResultNativeAdBridge.onFailed("onAdFailedToLoad : " + errorMsg);
                            }

                            @Override
                            public void onAdFailedAdapterName(AdapterObject adapter) {
                                sendPassBackImpression(mContext, mSessionId, zoneId, sortList.advrtsPrdtCode,
                                        adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                            }

                            @Override
                            public void onAdImpression() {
                            }

                            @Override
                            public void onAdClicked() {
                            }

                            @Override
                            public void onAppFinish() {

                            }

                            @Override
                            public void onAdRequest(AdapterObject adapter) {
                                sendDspImpression(mContext, mSessionId, zoneId, sortList.advrtsPrdtCode,
                                        adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                            }

                            @Override
                            public void onAdDisplayed() {

                            }

                            @Override
                            public void onAdComplete() {

                            }

                            @Override
                            public void onAdSkip() {

                            }

                            @Override
                            public void onAdFailedToOpen() {

                            }
                        });
                    } catch (Exception e){
                        onResultNativeAdBridge.onFailed(e.getMessage());
                    }
                }

                @Override
                public void onFailure(IOException e) {
                    onResultNativeAdBridge.onFailed(e.getMessage());
                }
            });

        } catch (Exception e){
            onResultNativeAdBridge.onFailed(e.getMessage());
        }
    }

    private AdapterObject checkJsonAd(AdapterObject adapter) {
        try {
            if (adapter instanceof JsonAdapter) {
                String useParallel = String.valueOf(((JsonAdapter) adapter).useParallel);
                JSONObject jsonData = new JSONObject(adapter.getAdData().jsonData);
                JSONArray adData = jsonData.optJSONObject("data").optJSONArray("data");
                if (adData != null && adData.length() > 0) {
                    String videoAd = adData.getJSONObject(0).optString("videoAd");
                    String custom10 = adData.getJSONObject(0).optString("custom10");
                    if (!videoAd.isEmpty() || !custom10.isEmpty()) {
                        return new VideoAdapter(
                                mContext, adapter.getName(), adapter.getUnitId(),
                                exlItlMemo, BannerType.NATIVE_AD, adapter.getAdData(),
                                false, zoneId, useParallel, adBname);
                    }
                }
            }
        } catch (Exception e) {
            LogPrint.d("checkJsonAd error : " + e.getLocalizedMessage());
        }
        return adapter;
    }
}
