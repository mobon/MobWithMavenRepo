//package com.mobwith.adapters;
//
//import android.app.Activity;
//import android.content.Context;
//import android.text.TextUtils;
//import android.view.ViewGroup;
//import android.widget.FrameLayout;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//
//import com.applovin.mediation.MaxAd;
//import com.applovin.mediation.MaxAdFormat;
//import com.applovin.mediation.MaxAdListener;
//import com.applovin.mediation.MaxAdViewAdListener;
//import com.applovin.mediation.MaxError;
//import com.applovin.mediation.ads.MaxAdView;
//import com.applovin.mediation.ads.MaxInterstitialAd;
//import com.applovin.mediation.nativeAds.MaxNativeAdListener;
//import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
//import com.applovin.mediation.nativeAds.MaxNativeAdView;
//import com.applovin.mediation.nativeAds.MaxNativeAdViewBinder;
//import com.applovin.sdk.AppLovinMediationProvider;
//import com.applovin.sdk.AppLovinSdk;
//import com.applovin.sdk.AppLovinSdkConfiguration;
//import com.applovin.sdk.AppLovinSdkInitializationConfiguration;
//import com.applovin.sdk.AppLovinSdkUtils;
//import com.mobwith.manager.LogPrint;
//import com.mobwith.manager.MediationAdListener;
//import com.mobwith.sdk.BannerType;
//import com.mobwith.sdk.loader.MMAdData;
//import com.mobwith.sdk.models.SortList;
//
//
//public class AppLovinAdapter extends AdapterObject {
//    private MaxInterstitialAd interstitialAd;
//    private MaxAdView adView;
//    private MediationAdListener mediationAdListener;
//    private String mUnitId;
//    private Context mContext;
//
//    private MaxNativeAdView mNativeAdView;
//    private MaxNativeAdLoader nativeAdLoader;
//    private MaxAd loadedNativeAd;
//
//    private boolean isInitialized = false;
//
//    private boolean needLoadAd = false;
//    private String loadAdType = "";
//
//    public AppLovinAdapter(final Context context, String name, String mediaKey, String unitId, String AdType, String adData, boolean isTestMode, boolean isAdapter) {
//        super(name, mediaKey, unitId, AdType, null, isTestMode, isAdapter);
//
//        AppLovinSdkInitializationConfiguration initConfig = AppLovinSdkInitializationConfiguration.builder("cyOmFZkTu_mdxFtH7wD1RVxBwy4Z_NEa6rF5czSgSulvk-DJfrF3-ymxsWhEgUQhDpC1dTwLKR3G8ntO-2uCaT")
//                .setMediationProvider(AppLovinMediationProvider.MAX)
//                .build();
//
//        // Initialize the SDK with the configuration
//        AppLovinSdk.getInstance(context).initialize(initConfig, new AppLovinSdk.SdkInitializationListener() {
//            @Override
//            public void onSdkInitialized(final AppLovinSdkConfiguration sdkConfig) {
//                isInitialized = true;
//            }
//        });
//
//        mUnitId = unitId;
//        mContext = context;
//    }
//
//    public void setAdListner(final MediationAdListener _listner) {
//        mediationAdListener = _listner;
//    }
//
//
//    public void load(String type) {
//        super.load(type);
//
//        loadAdType = type;
//        if (!isInitialized) {
//            needLoadAd = true;
//            return;
//        }
//
//        if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
//            loadNativeAd();
//        } else if (TextUtils.equals(type, BannerType.INTERSTITIAL) || TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP)) {
//            if (interstitialAd != null) {
//                interstitialAd.destroy();
//            }
//
//            if (!(mContext instanceof Activity)) {
//                mediationAdListener.onAdFailedToLoad("잘못된 Context 입니다.");
//                return;
//            }
//
//            interstitialAd = new MaxInterstitialAd(mUnitId);
//
//            interstitialAd.setListener(new MaxAdListener() {
//                @Override
//                public void onAdLoaded(@NonNull MaxAd maxAd) {
//                    mediationAdListener.onAdLoaded();
//                }
//
//                @Override
//                public void onAdDisplayed(@NonNull MaxAd maxAd) {
//                    mediationAdListener.onAdDisplayed();
//                }
//
//                @Override
//                public void onAdHidden(@NonNull MaxAd maxAd) {
//
//                }
//
//                @Override
//                public void onAdClicked(@NonNull MaxAd maxAd) {
//                    mediationAdListener.onAdClicked();
//                }
//
//                @Override
//                public void onAdLoadFailed(@NonNull String s, @NonNull MaxError maxError) {
//                    mediationAdListener.onAdFailedToLoad(maxError.getMessage());
//                }
//
//                @Override
//                public void onAdDisplayFailed(@NonNull MaxAd maxAd, @NonNull MaxError maxError) {
//
//                }
//            });
//
//            interstitialAd.loadAd();
//
//        } else if (TextUtils.equals(type, BannerType.ENDING)) {
//            if (mediationAdListener != null) {
//                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
//            }
//        } else {
//            if (TextUtils.equals(type, BannerType.BANNER_300x250))
//                adView = new MaxAdView(mUnitId, MaxAdFormat.MREC);
//            else
//                adView = new MaxAdView(mUnitId);
//
//            adView.setListener(new MaxAdViewAdListener() {
//                @Override
//                public void onAdExpanded(@NonNull MaxAd ad) {
//                    LogPrint.d("onAdExpanded");
//                }
//
//                @Override
//                public void onAdCollapsed(@NonNull MaxAd ad) {
//                    LogPrint.d("onAdCollapsed");
//                }
//
//                @Override
//                public void onAdLoaded(@NonNull MaxAd maxAd) {
//                    LogPrint.d("onAdLoaded");
//                    adView.stopAutoRefresh();
//                    mediationAdListener.onAdLoaded();
//                }
//
//                @Override
//                public void onAdDisplayed(@NonNull MaxAd maxAd) {
//                    LogPrint.d("onAdDisplayed");
//                    mediationAdListener.onAdDisplayed();
//                }
//
//                @Override
//                public void onAdHidden(@NonNull MaxAd maxAd) {
//                    LogPrint.d("onAdHidden");
//                }
//
//                @Override
//                public void onAdClicked(@NonNull MaxAd maxAd) {
//                    LogPrint.d("onAdClicked");
//                    mediationAdListener.onAdClicked();
//                }
//
//                @Override
//                public void onAdLoadFailed(@NonNull String s, @NonNull MaxError maxError) {
//                    LogPrint.d("onAdLoadFailed");
//                    adView.destroy();
//                    mediationAdListener.onAdFailedToLoad(maxError.getMessage());
//                }
//
//                @Override
//                public void onAdDisplayFailed(@NonNull MaxAd maxAd, @NonNull MaxError maxError) {
//                    LogPrint.d("onAdDisplayFailed");
//                    mediationAdListener.onAdFailedToLoad(maxError.getMessage());
//                }
//            });
//
//            int width = ViewGroup.LayoutParams.MATCH_PARENT;
//
//            // Get the adaptive banner height.
//            // int heightDp = MaxAdFormat.BANNER.getAdaptiveSize((Activity) context).getHeight();
//            int heightDp = 50;
//            if (TextUtils.equals(type, BannerType.BANNER_300x250)) {
//                heightDp = 250;
//            } else if (TextUtils.equals(type, BannerType.BANNER_320x100)) {
//                heightDp = 90;
//            }
//
//            int heightPx = AppLovinSdkUtils.dpToPx(mContext, heightDp);
//
//            adView.setLayoutParams(new FrameLayout.LayoutParams(width, heightPx));
//            adView.setExtraParameter("adaptive_banner", "true");
//            adView.loadAd();
//        }
//
//
//    }
//
//    public boolean show() {
//        if (interstitialAd != null && interstitialAd.isReady()) {
//            interstitialAd.showAd((Activity) mContext);
//            return true;
//        }
//        return false;
//
//    }
//
//    @Override
//    public boolean isLoaded() {
//        return (interstitialAd != null && interstitialAd.isReady());
//    }
//
//    @Override
//    public void destroy() {
//        super.destroy();
//
//        try {
//            if (adView != null)
//                adView.destroy();
//
//            if (interstitialAd != null)
//                interstitialAd.destroy();
//
//            adView = null;
//            interstitialAd = null;
//        } catch (Exception e) {
//            LogPrint.d("Something wrong...");
//        }
//
//
//    }
//
//
//    public Object getAdView() {
//        return adView;
//    }
//
//    @Override
//    public boolean canUseNativeAdView() {
//        return true;
//    }
//
//    @Override
//    public void loadNativeAd() {
//
//        nativeAdLoader = new MaxNativeAdLoader(mUnitId);
//        nativeAdLoader.setNativeAdListener(new NativeAdListener());
//
//        LogPrint.d("Load AppLovin Native AD : Start");
//
//        if (mAdViewItem == null) {
////            mediationAdListener.onAdFailedAdapterName("AppLovin - Not setted native ad views");
//            nativeAdLoader.loadAd();
//        } else {
//            nativeAdLoader.loadAd(createNativeAdView());
//        }
//    }
//
//    private MaxNativeAdView createNativeAdView() {
//        mAdViewItem.print();
//        MaxNativeAdViewBinder binder = new MaxNativeAdViewBinder.Builder(mAdViewItem.mViewLayoutID)
//                .setTitleTextViewId(mAdViewItem.mTitleViewID)
//                .setAdvertiserTextViewId(mAdViewItem.mDescViewID)
//                .setIconImageViewId(mAdViewItem.mADLogoImageViewID)
//                .setMediaContentViewGroupId(mAdViewItem.mMediaViewContainerID)
//                .setCallToActionButtonId(mAdViewItem.mGotoSiteViewID)
//                .setOptionsContentViewGroupId(mAdViewItem.mInfoLogoImageViewContainerID)
//                .build();
//
//        return new MaxNativeAdView(binder, mContext);
//    }
//
//    private class NativeAdListener extends MaxNativeAdListener {
//        @Override
//        public void onNativeAdLoaded(@Nullable MaxNativeAdView maxNativeAdView, @NonNull MaxAd maxAd) {
//            LogPrint.d("Load AppLovin Native AD : Loaded");
//
//            MMAdData adData = new MMAdData();
//            adData.type = SortList.Type.APPLOVIN;
//            adData.adapterObject = AppLovinAdapter.this;
//            setAdData(adData);
//
//            mediationAdListener.onAdLoaded();
//
//            if (loadedNativeAd != null) {
//                nativeAdLoader.destroy(loadedNativeAd);
//            }
//
//            loadedNativeAd = maxAd;
//            mNativeAdView = maxNativeAdView;
//
//
//            if (mAdViewItem != null && mAdViewItem.mContainerView != null) {
//                mAdViewItem.mContainerView.removeAllViews();
//                mAdViewItem.mContainerView.addView(maxNativeAdView);
//            }
//        }
//
//        @Override
//        public void onNativeAdLoadFailed(@NonNull String s, @NonNull MaxError maxError) {
//            LogPrint.d("Load AppLovin Native AD : Fail");
//
//            if (mAdViewItem.mContainerView != null) {
//                mAdViewItem.mContainerView.removeAllViews();
//            }
//
//            if (loadedNativeAd != null) {
//                nativeAdLoader.destroy(loadedNativeAd);
//            }
//            nativeAdLoader.setNativeAdListener(null);
//            nativeAdLoader.destroy();
//            nativeAdLoader = null;
//
//            mediationAdListener.onAdFailedToLoad(maxError.getMessage());
//        }
//
//        @Override
//        public void onNativeAdClicked(@NonNull MaxAd maxAd) {
//            mediationAdListener.onAdClicked();
//        }
//
//        @Override
//        public void onNativeAdExpired(@NonNull MaxAd maxAd) {
//        }
//    }
//
//    @Override
//    public void reDrawNativeAd() {
//        if (nativeAdLoader != null && mNativeAdView != null && loadedNativeAd != null) {
//            nativeAdLoader.render(mNativeAdView, loadedNativeAd);
//        }
//    }
//
//
//    @Override
//    public ViewGroup getNativeAdView() {
//        return mNativeAdView;
//    }
//}
//
//
