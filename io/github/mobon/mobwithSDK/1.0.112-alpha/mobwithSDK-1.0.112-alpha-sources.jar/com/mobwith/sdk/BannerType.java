package com.mobwith.sdk;

public class BannerType {
    public static final String BANNER_320x50 = "BANNER_320x50";
    public static final String BANNER_320x100 = "BANNER_320x100";
    public static final String BANNER_300x250 = "BANNER_300x250";
    public static final String BANNER_BIZ_BOARD = "BANNER_BIZ_BOARD";
    public static final String BANNER_ADFIT = "BANNER_ADFIT";
    public static final String INTERSTITIAL = "INTERSTITIAL";
    public static final String INTERSTITIAL_POPUP = "INTERSTITIAL_POPUP";
    public static final String NATIVE_AD = "NATIVE_AD";
    public static final String ENDING = "ENDING";
    public static final String TRANSITION = "TRANSITION";

    public static final String REWARD_VIDEO = "REWARD_VIDEO";
    public static final String SPLASH_AD = "SPLASH_AD";
    public static final String ENDING_BANNER = "ENDING_BANNER";

    public static final String HORIZONTAL = "HORIZONTAL";
    public static final String VERTICAL = "VERTICAL";
}
