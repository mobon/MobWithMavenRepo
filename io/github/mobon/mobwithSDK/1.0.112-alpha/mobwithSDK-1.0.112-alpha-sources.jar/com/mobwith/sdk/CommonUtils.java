package com.mobwith.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.mobwith.MobwithSDK;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.SpManager;
import com.mobwith.sdk.api.MWRequestCustomURL;
import com.mobwith.sdk.api.MWRequestImpression;
import com.mobwith.sdk.api.MWRequestSendInterstitialData;
import com.mobwith.sdk.models.AdDataModel;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CommonUtils {
    /**
     * Google Advertising ID (GAID)를 비동기적으로 가져와 SharedPreferences에 저장합니다.
     * GAID를 가져올 수 없거나 광고 추적이 제한된 경우, UUID를 생성하여 대신 저장합니다.
     * 이 작업은 네트워크 요청을 포함할 수 있으므로 AsyncTask를 사용하여 백그라운드 스레드에서 실행됩니다.
     *
     * @param context 애플리케이션 컨텍스트. SharedPreferences 접근 및 AdvertisingIdClient 사용에 필요합니다.
     */
    public static void getAdId(final Context context) {
        AsyncTask.execute(() -> {
            AdvertisingIdClient.Info adInfo;
            adInfo = null;
            try {
                if (context != null) {
                    adInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
                    if (!adInfo.isLimitAdTrackingEnabled()) {
                        SpManager.setString(context, Key.ADID, adInfo.getId());
                    } else {
                        String uniqueId = UUID.randomUUID().toString();
                        SpManager.setString(context, Key.ADID, uniqueId);
                    }
                }
            } catch (Exception e) {
                LogPrint.w("Failed to get Advertising ID, using UUID instead: " + e.getMessage());
            } finally {
                if (adInfo == null) {
                    String uniqueId = UUID.randomUUID().toString();
                    SpManager.setString(context, Key.ADID, uniqueId);
                }
            }
        });
    }

    /**
     * WebView의 사용자 에이전트(User-Agent) 문자열을 가져와 SharedPreferences에 저장합니다.
     * 사용자 에이전트는 광고 요청 시 서버에서 클라이언트 환경을 식별하는 데 사용될 수 있습니다.
     *
     * @param context 애플리케이션 컨텍스트. WebView 생성 및 SharedPreferences 접근에 필요합니다.
     */
    public static void setUserAgent(final Context context) {
        SpManager.setString(context, Key.USER_AGENT, new WebView(context).getSettings().getUserAgentString());
    }

    /**
     * 애플리케이션의 버전 이름(versionName)을 가져옵니다.
     * 예: "1.0.0"
     *
     * @param _context 애플리케이션 컨텍스트. PackageManager 접근에 필요합니다.
     * @return 앱의 버전 이름 문자열. 가져오기 실패 시 빈 문자열을 반환합니다.
     */
    public static String getAppVersion(Context _context) {
        try {
            if (_context == null) {
                return "";
            }
            PackageInfo packageInfo = _context.getPackageManager().getPackageInfo(_context.getPackageName(), 0);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    /**
     * SharedPreferences에 저장된 광고 ID (ADID 또는 대체 UUID)를 가져옵니다.
     *
     * @param _context 애플리케이션 컨텍스트. SharedPreferences 접근에 필요합니다.
     * @return 저장된 광고 ID 문자열.
     */
    public static String getAdid(Context _context) {
        try {
            if (_context == null) {
                return "";
            }
            return SpManager.getString(_context, Key.ADID);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 주어진 컨텍스트가 유효한 (활성화되어 있고 종료 중이 아닌) 액티비티와 연결되어 있는지 확인합니다.
     * 광고 표시는 일반적으로 활성 액티비티 위에서 이루어지므로, 광고를 표시하기 전에 이 메소드를 사용하여
     * 액티비티 상태를 확인할 수 있습니다.
     *
     * @param context 확인할 컨텍스트.
     * @return 액티비티가 활성 상태이고 종료 중이 아니면 true, 그렇지 않으면 false.
     * 컨텍스트에서 액티비티를 찾을 수 없는 경우에도 true를 반환 (주의 필요).
     */
    protected static boolean isActivityVisible(Context context) {
        Activity activity = findActivity(context);
        return activity == null || !activity.isFinishing();
    }

    /**
     * 주어진 컨텍스트에서 액티비티(Activity) 인스턴스를 찾습니다.
     * 컨텍스트가 액티비티 자체이거나 액티비티를 포함하는 ContextWrapper인 경우 해당 액티비티를 반환합니다.
     *
     * @param context 검색을 시작할 컨텍스트.NonNull로 지정되어 null이 아님을 보장합니다.
     * @return 찾아낸 액티비티. 찾지 못한 경우 null을 반환합니다.
     */
    @Nullable
    private static Activity findActivity(@NonNull Context context) {
        if (context instanceof Activity) {
            return (Activity) context;
        } else if (context instanceof ContextWrapper) {
            return findActivity(((ContextWrapper) context).getBaseContext());
        } else {
            return null;
        }
    }

    /**
     * 주어진 URL 문자열에서 특정 쿼리 파라미터의 값을 추출합니다.
     * 예: "http://example.com?id=123&name=test" 에서 "id" 파라미터를 추출하면 "123"을 반환합니다.
     *
     * @param url    파라미터를 추출할 전체 URL 문자열.
     * @param _param 추출할 쿼리 파라미터의 이름.
     * @return 해당 파라미터의 값. 파라미터가 없거나 URL 형식이 잘못된 경우 null 또는 빈 문자열을 반환할 수 있습니다.
     * (Uri.getQueryParameter는 파라미터가 없으면 null을 반환)
     */
    public static String getParameter(String url, String _param) {
        Uri uri = Uri.parse(url);
        String paramValue = uri.getQueryParameter(_param);
        return paramValue;
    }

    /**
     * 주어진 URL로부터 HTML 컨텐츠를 동기적으로 가져옵니다.
     * 이 메소드는 네트워크 요청을 수행하므로, 메인 스레드에서 직접 호출하면 ANR(Application Not Responding)을
     * 유발할 수 있습니다. 반드시 백그라운드 스레드에서 실행해야 합니다.
     *
     * @param _url HTML 컨텐츠를 가져올 URL.
     * @return 가져온 HTML 문자열. 오류 발생 시 빈 문자열 또는 부분적인 HTML을 반환할 수 있습니다.
     */
    public static String getHtml(String _url) {
        String Html = "";

        HttpURLConnection con = null;
        InputStreamReader isr = null;
        BufferedReader br = null;

        try {
            URL url = new URL(_url);
            con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);

            isr = new InputStreamReader(con.getInputStream());
            br = new BufferedReader(isr);

            String str = null;
            while ((str = br.readLine()) != null) {
                Html += str + "\n";
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    con.disconnect();
                } catch (Exception e) {
                }
            }

            if (isr != null) {
                try {
                    isr.close();
                } catch (Exception e) {
                }
            }

            if (br != null) {
                try {
                    br.close();
                } catch (Exception e) {
                }
            }
        }
        return Html;
    }

    /**
     * 디바이스의 현재 통신사(네트워크 사업자) 이름을 가져옵니다.
     * 예: "SKTelecom", "KT", "LGU+"
     * READ_PHONE_STATE 권한이 필요할 수 있습니다 (API 레벨에 따라 다름).
     *
     * @param _context 애플리케이션 컨텍스트. TelephonyManager 서비스 접근에 필요합니다.
     * @return 통신사 이름 문자열. 가져오기 실패 또는 권한 없는 경우 빈 문자열을 반환합니다.
     */
    public static String getTelecom(Context _context) {
        try {
            TelephonyManager manager = (TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);
            return manager.getNetworkOperatorName();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 숫자 문자열을 3자리마다 콤마(,)를 추가하고 "원" 단위를 붙여 포맷팅합니다.
     * 예: "10000" -> "10,000원"
     * 입력 문자열이 숫자로 변환될 수 없는 경우 원본 문자열을 그대로 반환합니다.
     *
     * @param str 포맷팅할 숫자 문자열.
     * @return 포맷팅된 금액 문자열. 변환 실패 시 원본 문자열.
     */
    public static String getCommaNumeric(String str) {
        if (str.equals(""))
            return "";

        long value = 0;

        try {
            value = Long.parseLong(str);
        } catch (Exception e) {
            return str;
        }

        DecimalFormat format = new DecimalFormat("###,###");
        return format.format(value) + "원";
    }

    /**
     * ManPlus 광고 네트워크 요청에 필요한 추가 파라미터 문자열을 생성합니다.
     * 이 파라미터에는 광고 ID, OS 정보, 앱 정보 등이 포함됩니다.
     *
     * @param context 애플리케이션 컨텍스트. SharedPreferences 및 앱 정보 접근에 필요합니다.
     * @return 생성된 쿼리 파라미터 문자열 (예: "&adid=xxx&osIndex=3...")
     */
    public static String getManPlusParam(Context context) {
        String params;

        params = "&adid=" + SpManager.getString(context, Key.ADID);
        params += "&osIndex=3";
        params += "&osVer=" + Build.VERSION.RELEASE;
        params += "&appId=" + context.getPackageName();
        params += "&appName=" + getApplicationName(context);
        return params;
    }

    /**
     * 애플리케이션의 표시 이름(label)을 가져옵니다.
     * AndroidManifest.xml의 application 태그에 정의된 android:label 값을 반환합니다.
     *
     * @param context 애플리케이션 컨텍스트. ApplicationInfo 접근에 필요합니다.
     * @return 애플리케이션 이름 문자열.
     */
    public static String getApplicationName(Context context) {
        try {
            ApplicationInfo applicationInfo = context.getApplicationInfo();
            int stringId = applicationInfo.labelRes;
            return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : context.getString(stringId);
        } catch (Exception e){
            return "";
        }
    }

    /**
     * 광고 요청 시 User-Agent Client Hints (UA-CH) 관련 HTTP 헤더를 생성합니다.
     * UA-CH는 기존의 User-Agent 문자열을 대체하거나 보강하여 더 구조화되고 개인 정보 보호적인 방식으로
     * 클라이언트 정보를 서버에 제공하는 메커니즘입니다.
     * 생성되는 헤더에는 Chrome 버전, 플랫폼 정보, 아키텍처, 모델명 등이 포함될 수 있습니다.
     *
     * @param context 애플리케이션 컨텍스트. WebView의 User-Agent 정보 접근에 필요합니다.
     * @return 생성된 UA-CH 관련 헤더들을 담은 Map 객체. 컨텍스트가 null이거나 오류 발생 시 null을 반환합니다.
     */
    public static Map<String, String> setAGHeaders(Context context) {

        try {
            Map<String, String> agHeaders = new HashMap<>();
            String userAgent = WebSettings.getDefaultUserAgent(context);

            String chromeVersion = "0.0.0.0";
            Pattern pattern = Pattern.compile("Chrome/([\\d.]+)");
            Matcher matcher = pattern.matcher(userAgent);
            if (matcher.find()) {
                chromeVersion = matcher.group(1);
            }

            String[] parts = chromeVersion.split("\\.");
            String majorVersion = parts.length > 0 ? parts[0] : "0";

            String bitness = "";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (Build.SUPPORTED_64_BIT_ABIS.length > 0) {
                    bitness = "64";
                } else {
                    bitness = "32";
                }
            }

            agHeaders.put("Sec-CH-UA", "\"Chromium\";v=\"" + majorVersion + "\", \"Android WebView\";v=\"" + majorVersion + "\"");
            agHeaders.put("Sec-CH-UA-Full-Version-List", "\"Chromium\";v=\"" + chromeVersion + "\", \"Android WebView\";v=\"" + chromeVersion + "\"");
            agHeaders.put("Sec-CH-UA-Platform", "Android");
            agHeaders.put("Sec-CH-UA-Platform-Version", Build.VERSION.RELEASE);
            agHeaders.put("Sec-CH-UA-Arch", System.getProperty("os.arch"));
            agHeaders.put("Sec-CH-UA-Bitness", bitness);
            agHeaders.put("Sec-CH-UA-Model", Build.MODEL);
            agHeaders.put("Sec-CH-UA-Mobile", "?1");


            return agHeaders;
        } catch (Exception e) {
            LogPrint.d("setAGHeaders context is null");
            return null;
        }
    }

    public static void sendAdSDKImpression(Context mContext, String mScriptNo, String target, String unitId) {
        sendAdSDKImpression(mContext, mScriptNo, target, unitId, "");
    }

    /**
     * 광고 노출(Impression) 정보를 서버로 전송합니다.
     *
     * @param exlItlSeq SortList 가중치. 알 수 없는 경로에서 호출되는 경우 빈 값을 전달합니다.
     */
    public static void sendAdSDKImpression(Context mContext, String mScriptNo, String target, String unitId, String exlItlSeq) {
        LogPrint.d("sendAdSDKImpression : " + target + " unitId : " + unitId + " exlItlSeq : " + exlItlSeq);
        try {
            MWRequestImpression.requestWith(mContext, mScriptNo, target, unitId, exlItlSeq, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 광고 노출(Impression) 트래킹 URL들을 전송합니다.
     * 광고가 사용자에게 보여졌을 때 호출되며, AdDataModel에 포함된 모든 노출 트래커 URL로 HTTP GET 요청을 보냅니다.
     *
     * @param context     애플리케이션 컨텍스트. MWRequestCustomURL 사용에 필요합니다.
     * @param adDataModel 노출 트래커 URL 목록을 포함하는 광고 데이터 모델.
     */
    public static void sendImpressTrackersEvent(Context context, AdDataModel adDataModel) {
        LogPrint.d("sendImpressTrackersEvent");
        try {
            //광고를 보여 줬을 때 호출
            if (!adDataModel.getImpTrackers().isEmpty()) {
                JSONArray jsonImpTrackers = new JSONArray(adDataModel.getImpTrackers());
                if (jsonImpTrackers.length() > 0) {
                    for (int i = 0; i < jsonImpTrackers.length(); i++) {
                        String impTracer = jsonImpTrackers.optString(i).replace("\\u003d", "=").replace("\\u0026", "&");
                        if (!impTracer.isEmpty()) {
                            MWRequestCustomURL.requestWith(context, impTracer, "Impression Trackers");
                        }
                    }
                    LogPrint.d("Imp Trackers : " + jsonImpTrackers.length());
                } else {
                    LogPrint.d("Imp Trackers is empty");
                }
            }
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
    }

    public static void sendImpressTrackersEvent(Context context, ArrayList<String> impTrackers) {
        LogPrint.d("sendImpressTrackersEvent");
        try {
            //광고를 보여 줬을 때 호출
            if (!impTrackers.isEmpty()) {
                for (int i = 0; i < impTrackers.size(); i++) {
                    String impTracer = impTrackers.get(i).replace("\\u003d", "=").replace("\\u0026", "&");
                    if (!impTracer.isEmpty()) {
                        MWRequestCustomURL.requestWith(context, impTrackers.get(i), "Impression Trackers");
                    }
                }
                LogPrint.d("Imp Trackers : " + impTrackers.size());
            } else {
                LogPrint.d("Imp Trackers is empty");
            }
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
    }

    /**
     * 광고 클릭(Click) 트래킹 URL들을 전송합니다.
     * 사용자가 광고를 클릭했을 때 호출되며, AdDataModel에 포함된 모든 클릭 트래커 URL로 HTTP GET 요청을 보냅니다.
     *
     * @param context     애플리케이션 컨텍스트. MWRequestCustomURL 사용에 필요합니다.
     * @param adDataModel 클릭 트래커 URL 목록을 포함하는 광고 데이터 모델.
     */
    public static void sendClickTrackersEvent(Context context, AdDataModel adDataModel) {
        //광고를 클릭 했을 때 호출
        LogPrint.d("sendClickTrackersEvent");
        try {
            if (!adDataModel.getClickTrackers().isEmpty()) {
                JSONArray jsonClickTrackers = new JSONArray(adDataModel.getClickTrackers());
                if (jsonClickTrackers.length() > 0) {
                    for (int i = 0; i < jsonClickTrackers.length(); i++) {
                        String clickTracer = jsonClickTrackers.optString(i).replace("\\u003d", "=").replace("\\u0026", "&");;
                        if (!clickTracer.isEmpty()) {
                            MWRequestCustomURL.requestWith(context, clickTracer, "Click Trackers");
                        }
                    }
                    LogPrint.d("Click Trackers : " + jsonClickTrackers.length());
                } else {
                    LogPrint.d("Click Trackers is empty");
                }
            }
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
    }

    public static void sendClickTrackersEvent(Context context, ArrayList<String> clickTrackers) {
        //광고를 클릭 했을 때 호출
        LogPrint.d("sendClickTrackersEvent");
        try {
            if (!clickTrackers.isEmpty()) {
                for (int i = 0; i < clickTrackers.size(); i++) {
                    String clickTracer = clickTrackers.get(i).replace("\\u003d", "=").replace("\\u0026", "&");;
                    if (!clickTracer.isEmpty()) {
                        MWRequestCustomURL.requestWith(context, clickTracer, "Click Trackers");
                    }
                }

            }else {
                LogPrint.d("Click Trackers is empty");
            }
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
    }

    public static void sendInterstitialData(Context context, String sessionId, String type, String zone, boolean isFull, String styleCode, String advrtsPrdtCode) {
        LogPrint.d("sendInterstitialData");
        try {
            String formatCode;
            if (isFull){
                formatCode = "03";
            } else {
                formatCode = "02";
            }

            MWRequestSendInterstitialData.requestWith(context, sessionId, type, zone, formatCode, styleCode, advrtsPrdtCode);
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
    }

}
