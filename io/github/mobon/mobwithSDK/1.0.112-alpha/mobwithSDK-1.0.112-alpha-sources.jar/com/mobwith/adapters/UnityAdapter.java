package com.mobwith.adapters;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.api.MWRequestImpression;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

import java.util.concurrent.atomic.AtomicInteger;


public class UnityAdapter extends AdapterObject {

    private final AtomicInteger RetryCount = new AtomicInteger(0);

    private final Context mContext;
    private final String mUnitId;
    private final String mScriptNo;

    private MediationAdListener mediationAdListener;


    private BannerView mAdView = null;

    private boolean interstitialLoaded = false;
    private static boolean isInitialized = false;
    private static boolean isInInitialize = false;

    public static void initSDK(Context context, String gameId) {
        if (UnityAds.isInitialized() && isInitialized) {
            return;
        }

        if (gameId != null && !gameId.isEmpty()) {
            isInInitialize = true;

            UnityAds.initialize(context.getApplicationContext(), gameId, false, new IUnityAdsInitializationListener() {
                @Override
                public void onInitializationComplete() {
                    LogPrint.d("UnityAds initialization complete");
                    isInitialized = true;
                    isInInitialize = false;
                }

                @Override
                public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                    LogPrint.e("UnityAds initialization failed: " + error + ", " + message);
                    isInitialized = false;
                    isInInitialize = false;
                }
            });
        }
    }


    public UnityAdapter(final Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mUnitId = unitId;
        mContext = context;
        mScriptNo = siteNo;

        if (AdType.equals(BannerType.INTERSTITIAL)) {
            mAdType = MediationAdSize.INTERSTITIAL;
        } else if (AdType.equals(BannerType.BANNER_320x50)) {
            mAdType = MediationAdSize.BANNER_320_50;
        } else if (AdType.equals(BannerType.BANNER_320x100)) {
            mAdType = MediationAdSize.BANNER_320_50;
        } else if (AdType.equals(BannerType.BANNER_300x250)) {
            mAdType = MediationAdSize.BANNER_300_250;
        } else if (AdType.equals(BannerType.REWARD_VIDEO)) {
            mAdType = MediationAdSize.REWARD_VIDEO;
        }
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }


    public void load(String type) {
        super.load(type);

        if (RetryCount.incrementAndGet() > 10) {
            LogPrint.d("RetryCount limit");
            RetryCount.set(0);

            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("Unity Ad SDK 초기화 실패");
            }

            return;
        }

        if (isInInitialize) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    load(type);
                }
            }, 100);

            return;
        }

        RetryCount.set(0);


        if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        }
        //유니티AD는 전면배너와 리워드 배너가 리스너 콜백 내려주는 부분에서만 차이가 있는듯함.  실제 적용 부분에서는 아예 차이가 없다고 봐도 무방하다.
        else if (TextUtils.equals(type, BannerType.INTERSTITIAL) ||
                TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP) ||
                TextUtils.equals(type, BannerType.REWARD_VIDEO)) {
            if (UnityAdapter.isInitialized) {
                UnityAds.load(mUnitId, new IUnityAdsLoadListener() {
                    @Override
                    public void onUnityAdsAdLoaded(String placementId) {
                        LogPrint.d("UnityAds interstitial loaded : " + placementId);
                        interstitialLoaded = true;
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdLoaded();
                        }
                    }

                    @Override
                    public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                        LogPrint.d("UnityAds interstitial failed to load : " + message);
                        interstitialLoaded = false;
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdFailedToLoad(message);
                        }
                    }
                });
            } else {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("UnityAds 초기화 실패");
                }
            }
        } else if (TextUtils.equals(type, BannerType.ENDING)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else {
            UnityBannerSize adSize = null;

            if (TextUtils.equals(type, BannerType.BANNER_300x250)) {
                adSize = new UnityBannerSize(300, 250);
            } else if (TextUtils.equals(type, BannerType.BANNER_320x100)) {
                adSize = new UnityBannerSize(320, 100);
            } else {
                adSize = new UnityBannerSize(320, 50);
            }

            mAdView = new BannerView((Activity) mContext, mUnitId, adSize);
            mAdView.setListener(new BannerView.IListener() {
                @Override
                public void onBannerLoaded(BannerView bannerAdView) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                }

                @Override
                public void onBannerShown(BannerView bannerAdView) {
                }

                @Override
                public void onBannerClick(BannerView bannerAdView) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }

                @Override
                public void onBannerFailedToLoad(BannerView bannerAdView, BannerErrorInfo errorInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(errorInfo.errorMessage);
                    }
                }

                @Override
                public void onBannerLeftApplication(BannerView bannerView) {
                }
            });

            mAdView.load();
        }

        CommonUtils.sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        if (interstitialLoaded) {
            UnityAds.show(activity, mUnitId, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                @Override
                public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToOpen(error.toString(), getName());
                    }
                }

                @Override
                public void onUnityAdsShowStart(String placementId) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onUnityAdsShowClick(String placementId) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }

                @Override
                public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                    // 유니티 AD는 광고가 닫힐때 complete, skip 여부를 판단하도록 되어 있다.
                    // 우리 입장에서는 이 시점에 두 콜백과 함께 close 콜백을 같이 내려줘야 할 듯하다..
                    if (mediationAdListener != null) {
                        if (state.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
                            mediationAdListener.onAdComplete();
                        } else {
                            mediationAdListener.onAdSkip();
                        }
                        mediationAdListener.onAdClosed();
                    }
                }
            });
            return true;
        }
        return false;
    }

    @Override
    public boolean show() {
        if (interstitialLoaded && mContext instanceof Activity) {
            UnityAds.show((Activity) mContext, mUnitId, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                @Override
                public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToOpen(error.toString(), getName());
                    }
                }

                @Override
                public void onUnityAdsShowStart(String placementId) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onUnityAdsShowClick(String placementId) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }

                @Override
                public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                    // 유니티 AD는 광고가 닫힐때 complete, skip 여부를 판단하도록 되어 있다.
                    // 우리 입장에서는 이 시점에 두 콜백과 함께 close 콜백을 같이 내려줘야 할 듯하다..
                    if (mediationAdListener != null) {
                        if (state.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
                            mediationAdListener.onAdComplete();
                        } else {
                            mediationAdListener.onAdSkip();
                        }

                        mediationAdListener.onAdClosed();
                    }
                }
            });
            return true;
        }
        return false;
    }

    @Override
    public boolean isLoaded() {
        return interstitialLoaded;
    }

    @Override
    public void destroy() {
        super.destroy();

        try {
            mAdView.destroy();
            mAdView = null;

            interstitialLoaded = false;
        } catch (Exception e) {
            LogPrint.d("[UnityAdapter] " + e.getLocalizedMessage());
        }
    }

    public Object getAdView() {
        return mAdView;
    }

    @Override
    public boolean canUseNativeAdView() {
        return false;
    }

}