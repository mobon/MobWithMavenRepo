package com.mobwith.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.ApiAdapter;
import com.mobwith.adapters.CoupangAdapter;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.ScriptAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iInterstitialCallback;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

public class InterstitialDialog implements MWCommonRequestInterface {

    private static final long LOAD_TIMEOUT_MS = 10_000L;

    private final Context mContext;
    private iInterstitialCallback mCallback;
    private MediationManager mediationManager;
    private MobwithAdCategoryModel mobwithAdCategoryModel;

    private String mScriptNo = "";
    private String mSessionId;
    private String mAdType;
    private String advrtsPrdtCode = "";
    private String exlItlMemo = "";
    private String isParallel = "";
    private String adBname = "";
    private String interstitialFormatCode = "";
    private String closeBtnDisplaySeconds = "";
    private Key.INTERSTITIAL_TYPE screenType = Key.INTERSTITIAL_TYPE.RANDOM;

    private AdapterObject mLoadedAdapter;
    /** show() 로 광고 Activity 에 넘긴 어댑터. 소유권이 Activity 에 있으므로 해제 대상에서 제외한다. */
    private AdapterObject mShownAdapter;
    /** 로드 진행 중 여부. 중복 load() 호출을 막는 가드. */
    private final AtomicBoolean isLoading = new AtomicBoolean(false);
    /** 이전 로드의 지연 응답을 무시하기 위한 토큰. */
    private volatile int mLoadToken = 0;
    private boolean sendSuccessCallback;
    private boolean sendFailCallback;
    private boolean isBackNotCancel = false;

    /** 콜백이 오지 않는 어댑터 때문에 isLoading 이 고정되는 것을 막는다. */
    private final Runnable loadTimeout = () -> failLoad("timeout");

    public InterstitialDialog(Context context) {
        this.mContext = context;
        this.mAdType = SpManager.getString(mContext, Key.INTERSTITIAL_POPUP_TYPE);
    }

    public InterstitialDialog setUnitId(String unitId) {
        this.mScriptNo = unitId;
        return this;
    }

    public InterstitialDialog setBackCancel(boolean is) {
        this.isBackNotCancel = is;
        return this;
    }

    public InterstitialDialog setMobwithAdCategoryModel(MobwithAdCategoryModel model) {
        this.mobwithAdCategoryModel = model;
        return this;
    }

    public InterstitialDialog setAdListener(iInterstitialCallback callback) {
        this.mCallback = callback;
        return this;
    }

    public InterstitialDialog build() {
        MobwithSDK.initSDK(mContext);
        SpManager.setString(mContext, Key.INTERSTITIAL_CACHE_DATA, "");
        return this;
    }

    public boolean isLoaded() {
        return mLoadedAdapter != null && mLoadedAdapter.isLoaded();
    }

    /** 광고 로드 (구 InterstitialDialog#load 와 동일 로직) */
    public void load() {
        // 이전 로드가 끝나기 전에 들어온 호출은 무시한다.
        if (!isLoading.compareAndSet(false, true)) {
            return;
        }

        final int token = ++mLoadToken;
        MainThreadHandler.postDelayed(loadTimeout, LOAD_TIMEOUT_MS);

        // 이전 사이클에서 남은 어댑터들을 정리한다.
        // 단, show() 로 넘겨 노출 중일 수 있는 어댑터는 Activity 가 소유하므로 남겨둔다.
        if (mediationManager != null) {
            mediationManager.releaseExcept(mShownAdapter);
        }
        mLoadedAdapter = null;

        mSessionId = "";
        sendSuccessCallback = false;
        sendFailCallback = false;

        if (!Utils.isConnectNetwork(mContext)) {
            failLoad("noConnectNetwork");
            return;
        }

        new MWRequestSortList(mContext, mScriptNo).execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                if (token != mLoadToken) return;
                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));
                    if (!sortList.isSuccess()) {
                        failLoad(sortList.message);
                        return;
                    }

                    mSessionId = sortList.sessionId;
                    advrtsPrdtCode         = sortList.advrtsPrdtCode;
                    exlItlMemo             = sortList.exlItlMemo;
                    adBname             = sortList.adBname;
                    isParallel             = sortList.isParallel;
                    interstitialFormatCode = sortList.interstitialFormatCode;
                    closeBtnDisplaySeconds = sortList.closeBtnDisplaySeconds;

                    setScreenType(interstitialFormatCode);
                    sendSortListImpression(mContext, mScriptNo, advrtsPrdtCode, mSessionId);

                    mediationManager = new MediationManager(
                            mContext, sortList.data, BannerType.INTERSTITIAL,
                            mobwithAdCategoryModel);

                    mediationManager.LoadMediation(mediationCallback);
                } catch (Exception e) {
                    failLoad(e.getLocalizedMessage());
                }
            }

            @Override public void onFailure(IOException e) {
                if (token != mLoadToken) return;
                failLoad(e.getLocalizedMessage());
            }
        });
    }

    /** 로드된 광고 표시 → InterstitialAdActivity 실행 */
    public void show() {
        LogPrint.d("show");
        if (mLoadedAdapter == null) {
            if (mCallback != null) mCallback.onFailOpened();
            return;
        }
        if (!CommonUtils.isActivityVisible(mContext)) {
            if (mCallback != null) mCallback.onFailOpened();
            return;
        }

        if (mLoadedAdapter instanceof JsonAdapter || mLoadedAdapter instanceof VideoAdapter || mLoadedAdapter instanceof CoupangAdapter) {
            // 정적 홀더로 Activity 에 전달
            InterstitialAdActivity.bind(
                    mLoadedAdapter, mCallback, screenType,
                    mSessionId, mScriptNo, advrtsPrdtCode,
                    closeBtnDisplaySeconds, isBackNotCancel
            );

            Intent intent = new Intent(mContext, InterstitialAdActivity.class);
            if (!(mContext instanceof Activity)) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            mContext.startActivity(intent);
            markShown();
        } else if (mLoadedAdapter instanceof ApiAdapter){
            if (mLoadedAdapter.getAdView() != null) {
                InterstitialAdActivity.bind(
                        mLoadedAdapter, mCallback, screenType,
                        mSessionId, mScriptNo, advrtsPrdtCode,
                        closeBtnDisplaySeconds, isBackNotCancel
                );

                Intent intent = new Intent(mContext, InterstitialAdActivity.class);
                if (!(mContext instanceof Activity)) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                mContext.startActivity(intent);
                markShown();
            } else {
                if (mCallback != null) mCallback.onLoadedAdInfo(false, "Ads are not loaded yet");
            }
        } else {
            if (mLoadedAdapter.show()) {
                markShown();
                if (mCallback != null) mCallback.onOpened();
            }
        }
    }

    public void show(Activity activity) {
        LogPrint.d("show activity");
        if (mLoadedAdapter == null) {
            if (mCallback != null) mCallback.onFailOpened();
            return;
        }
        if (!CommonUtils.isActivityVisible(activity)) {
            if (mCallback != null) mCallback.onFailOpened();
            return;
        }

        if (mLoadedAdapter instanceof JsonAdapter || mLoadedAdapter instanceof VideoAdapter || mLoadedAdapter instanceof CoupangAdapter) {
            // 정적 홀더로 Activity 에 전달
            InterstitialAdActivity.bind(
                    mLoadedAdapter, mCallback, screenType,
                    mSessionId, mScriptNo, advrtsPrdtCode,
                    closeBtnDisplaySeconds, isBackNotCancel
            );

            Intent intent = new Intent(activity, InterstitialAdActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
            markShown();
        } else if (mLoadedAdapter instanceof ApiAdapter){
            if (mLoadedAdapter.getAdView() != null) {
                InterstitialAdActivity.bind(
                        mLoadedAdapter, mCallback, screenType,
                        mSessionId, mScriptNo, advrtsPrdtCode,
                        closeBtnDisplaySeconds, isBackNotCancel
                );

                Intent intent = new Intent(activity, InterstitialAdActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
                markShown();
            } else {
                if (mCallback != null) mCallback.onLoadedAdInfo(false, "Ads are not loaded yet");
            }
        } else {
            if (mLoadedAdapter.show(activity)) {
                markShown();
                if (mCallback != null) mCallback.onOpened();
            }
        }
    }

    /* --------- 내부 --------- */

    /**
     * 광고를 Activity/외부 SDK 로 넘겼음을 기록한다.
     * 소유권이 넘어갔으므로 이 인스턴스는 더 이상 로드된 광고를 들고 있지 않다
     * (Activity 의 onDestroy 가 어댑터를 destroy 한다).
     */
    private void markShown() {
        mShownAdapter = mLoadedAdapter;
        mLoadedAdapter = null;
    }

    private final iMobonMediationCallback mediationCallback = new iMobonMediationCallback() {
        @Override public void onLoadedAdData(String data, AdapterObject adapter) {}

        @Override public void onAdAdapter(AdapterObject adapter) {
            if (adapter == null) { failLoad(Key.NOFILL); return; }
            if (!checkJsonAd(adapter)) {
//                MainThreadHandler.post(() -> {
//                    if (mCallback != null && !sendSuccessCallback) {
//                        sendSuccessCallback = true;
//                        mCallback.onLoadedAdInfo(true, "");
//                    }
//                });
                failLoad(Key.NOFILL);
            }
            // 성공 시 isLoading 해제는 successLoad() 에서 처리한다.
            // (비디오 광고는 준비 완료 콜백까지 기다려야 하므로 여기서 풀지 않는다.)
        }

        @Override public void onAdRequest(AdapterObject adapter) {
            sendDspImpression(mContext, mSessionId, mScriptNo, advrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
            if (adapter != null) adapter.destroy();
            failLoad(Key.NOFILL);
        }

        @Override public void onAdFailedAdapterName(AdapterObject adapter) {
            sendPassBackImpression(mContext, mSessionId, mScriptNo, advrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override public void onAdClicked() {
            if (mCallback != null) mCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.ADCLICK);
        }
        @Override public void onAdFailedToOpen() {
            if (mCallback != null) mCallback.onFailOpened();
        }
        @Override public void onAdClosed() {
            if (mCallback != null) mCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.CLOSE_AD);
        }
        @Override public void onAdImpression()  { }
        @Override public void onAppFinish()     { }
        @Override public void onAdDisplayed()   { }
        @Override public void onAdComplete()    { }
        @Override public void onAdSkip()        { }
        @Override public void onAdCancel()      { }
    };

    private boolean checkJsonAd(AdapterObject adapter) {
        try {
            if (adapter instanceof JsonAdapter) {
                String useParallel = String.valueOf(((JsonAdapter) adapter).useParallel);
                JSONObject jsonData = new JSONObject(adapter.getAdData().jsonData);
                JSONArray adData = jsonData.optJSONObject("data").optJSONArray("data");
                if (adData != null && adData.length() > 0) {
                    String videoAd = adData.getJSONObject(0).optString("videoAd");
                    String custom10 = adData.getJSONObject(0).optString("custom10");
                    if (!videoAd.isEmpty() || !custom10.isEmpty()) {
                        VideoAdapter v = new VideoAdapter(
                                mContext, adapter.getName(), adapter.getUnitId(),
                                exlItlMemo, mAdType, adapter.getAdData(),
                                false, mScriptNo, useParallel, adBname);
                        if (!videoAd.isEmpty()) {
                            v.initVideoAd(videoAd, adData.getJSONObject(0).optString("pUrl"), new VideoAdapter.OnVideoListener() {
                                @Override
                                public void onReady(boolean isReady) {
                                    if (isReady){
                                        successLoad();
                                    } else {
                                        failLoad("no ad");
                                    }
                                }
                            });
                        } else {
                            v.initVastVideo(custom10, new VideoAdapter.OnVideoListener() {
                                @Override
                                public void onReady(boolean isReady) {
                                    if (isReady){
                                        successLoad();
                                    } else {
                                        failLoad("no ad");
                                    }
                                }
                            });
                        }
                        mLoadedAdapter = v;
                    } else {
                        mLoadedAdapter = adapter;
                        successLoad();
                    }
                } else {
                    mLoadedAdapter = adapter;
                    successLoad();
                }
            } else {
                mLoadedAdapter = adapter;
                successLoad();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void setScreenType(String code) {
        switch (code == null ? "" : code) {
            case "02": screenType = Key.INTERSTITIAL_TYPE.MODAL;  break;
            case "03": screenType = Key.INTERSTITIAL_TYPE.FULL;   break;
            case "01":
            default:   screenType = Key.INTERSTITIAL_TYPE.RANDOM; break;
        }
        mAdType = screenType.toString();
    }

    private void successLoad() {
        finishLoading();
        MainThreadHandler.post(() -> {
            if (mCallback != null && !sendSuccessCallback) {
                sendSuccessCallback = true;
                mCallback.onLoadedAdInfo(true, "");
            }
        });
    }

    private void failLoad(String msg) {
        finishLoading();
        if (mCallback != null && !sendFailCallback) {
            sendFailCallback = true;
            mCallback.onLoadedAdInfo(false, msg);
        }
    }

    /** 로드 사이클 종료 - 중복 호출 가드 해제 및 타임아웃 취소. */
    private void finishLoading() {
        isLoading.set(false);
        MainThreadHandler.removeCallbacks(loadTimeout);
    }
}