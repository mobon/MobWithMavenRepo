package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bytedance.sdk.openadsdk.api.banner.PAGBannerAd;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerAdInteractionCallback;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerAdLoadListener;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerRequest;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerSize;
import com.bytedance.sdk.openadsdk.api.init.PAGConfig;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialAd;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialAdLoadCallback;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialRequest;
import com.bytedance.sdk.openadsdk.api.model.PAGErrorModel;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAd;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAdLoadListener;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeRequest;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardItem;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAd;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdLoadListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedRequest;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.loader.MMAdData;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class PangleAdapter extends AdapterObject {

    private final AtomicInteger retryCount = new AtomicInteger(0);
    private final String mUnitId;
    private final Context mContext;
    private final String mScriptNo;
    private PAGConfig pagConfig;

    private RelativeLayout pangleBannerView;

    public static String pangleAppId = "";
    private MediationAdListener mediationAdListener;
    private boolean isInitialized = false;
    private boolean isInterstitialAdLoaded = false;
    private boolean isRewardedVideoAdLoaded = false;
    private PAGBannerSize pagBannerSize;
    private PAGInterstitialAd mPagInterstitialAd;
    private PAGRewardedAd mPagRewardedAd;

    public PangleAdapter(Context context, String name, String unitId, String AdType, MMAdData adData, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mContext = context;
        mUnitId = unitId;
        mScriptNo = siteNo;

        switch (AdType) {
            case BannerType.INTERSTITIAL:
                mAdType = MediationAdSize.INTERSTITIAL;
                break;
            case BannerType.BANNER_320x50:
            case BannerType.BANNER_320x100:
                mAdType = MediationAdSize.BANNER_320_50;
                pagBannerSize = PAGBannerSize.BANNER_W_320_H_50;
                break;
            case BannerType.BANNER_300x250:
                mAdType = MediationAdSize.BANNER_300_250;
                pagBannerSize = PAGBannerSize.BANNER_W_300_H_250;
                break;
            case BannerType.REWARD_VIDEO:
                mAdType = MediationAdSize.REWARD_VIDEO;
                break;
        }

        initialize();
    }

    public static void initSDK(String appId) {
        pangleAppId = appId;
    }

    public void initialize() {
        if (isInitialized) {
            return;
        }

        if (pagConfig == null) {
            pagConfig = new PAGConfig.Builder()
                    .appId(pangleAppId)
                    .debugLog(true)
                    .supportMultiProcess(false)
                    .build();

            PAGSdk.init(mContext, pagConfig, new PAGSdk.PAGInitCallback() {
                @Override
                public void success() {
                    isInitialized = true;
                }

                @Override
                public void fail(int i, String s) {
                    LogPrint.d("pangle SDK 초기화 실패 : " + s);
                    isInitialized = false;
                }
            });
        }
    }

    @Override
    public void load(String AdType) {
        super.load(AdType);

        if (pangleAppId.isEmpty()) {
            //SDK 초기화 실패 (AppId 누락)
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("Pangle SDK 초기화 실패(AppId 누락)");
            }
            return;
        }

        if (retryCount.incrementAndGet() > 10) {
            retryCount.set(0);

            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("Pangle SDK 초기화 실패");
            }

            return;
        }

        if (!isInitialized) {
            initialize();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    load(AdType);
                }
            }, 500);

            return;
        }

        retryCount.set(0);

        if (!isInitialized) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("Pangle SDK 초기화 실패");
            }
            return;
        }

        if (TextUtils.equals(AdType, BannerType.NATIVE_AD)) {
            loadNativeAd();
        } else if (TextUtils.equals(AdType, BannerType.INTERSTITIAL) || TextUtils.equals(AdType, BannerType.INTERSTITIAL_POPUP)) {
            isInterstitialAdLoaded = false;
            mPagInterstitialAd = null;
            loadAdInterstitial();
        } else if (TextUtils.equals(AdType, BannerType.REWARD_VIDEO)) {
            isRewardedVideoAdLoaded = false;
            mPagRewardedAd = null;
            loadAdRewardedVideo();
        } else {
            loadAdBanner();
        }

//        sendImpression();
    }

    @Override
    public boolean isLoaded() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            return isInterstitialAdLoaded;
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            return isRewardedVideoAdLoaded;
        } else {
            return false;
        }
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (mPagInterstitialAd != null) {
                mPagInterstitialAd.show(activity);
                sendAdSDKImpression(activity, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (mPagRewardedAd != null) {
                mPagRewardedAd.show(activity);
                sendAdSDKImpression(activity, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean show() {
        if (!(mContext instanceof Activity)){
            return false;
        }

        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (mPagInterstitialAd != null) {
                mPagInterstitialAd.show((Activity) mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (mPagRewardedAd != null) {
                mPagRewardedAd.show((Activity) mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


    @Override
    public void setAdListener(MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void destroy() {
        super.destroy();
    }

    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    @Override
    public void loadNativeAd() {

        PAGNativeRequest request = new PAGNativeRequest();
        PAGNativeAd.loadAd(mUnitId, request, new PAGNativeAdLoadListener() {
            @Override
            public void onError(int code, String message) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다 - code : " + code + " Message : " + message);
                }
            }

            @Override
            public void onAdLoaded(PAGNativeAd pagNativeAd) {

                if (mAdViewItem == null || pagNativeAd == null || pagNativeAd.getNativeAdData() == null) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다.");
                    }
                    return;
                }

                try {
                    View inflatedView = LayoutInflater.from(mContext).inflate(mAdViewItem.mViewLayoutID, null);

                    FrameLayout infoContainer = inflatedView.findViewById(mAdViewItem.mInfoLogoImageViewContainerID);
                    ImageView logo = inflatedView.findViewById(mAdViewItem.mADLogoImageViewID);

                    TextView title = inflatedView.findViewById(mAdViewItem.mTitleViewID);
                    TextView desc = inflatedView.findViewById(mAdViewItem.mDescViewID);
                    FrameLayout mediaView = inflatedView.findViewById(mAdViewItem.mMediaViewContainerID);
                    View callToAction = inflatedView.findViewById(mAdViewItem.mGotoSiteViewID);

                    if (title != null && pagNativeAd.getNativeAdData().getTitle() != null) {
                        title.setText(pagNativeAd.getNativeAdData().getTitle());
                    }

                    if (desc != null && pagNativeAd.getNativeAdData().getDescription() != null) {
                        desc.setText(pagNativeAd.getNativeAdData().getDescription());
                    }

                    if (logo != null && pagNativeAd.getNativeAdData().getIcon() != null) {
                        ImageModule.with(mContext).load(pagNativeAd.getNativeAdData().getIcon().getImageUrl()).centerCrop().into(logo);
                    }

                    if (callToAction != null && pagNativeAd.getNativeAdData().getButtonText() != null) {
                        if (callToAction instanceof Button) {
                            Button callTextView = (Button) callToAction;
                            callTextView.setText(pagNativeAd.getNativeAdData().getButtonText());
                        } else if (callToAction instanceof TextView) {
                            TextView callTextView = (TextView) callToAction;
                            callTextView.setText(pagNativeAd.getNativeAdData().getButtonText());
                        }
                    }

                    if (mediaView != null && pagNativeAd.getNativeAdData().getMediaView() != null) {
                        mediaView.addView(pagNativeAd.getNativeAdData().getMediaView());
                    }

                    if (infoContainer != null && pagNativeAd.getNativeAdData().getAdLogoView() != null) {
                        infoContainer.addView(pagNativeAd.getNativeAdData().getAdLogoView());
                    }

                    ArrayList<View> viewList = new ArrayList<>();
                    viewList.add(inflatedView);

                    ArrayList<View> viewList2 = new ArrayList<>();
                    viewList.add(callToAction);

                    pagNativeAd.registerViewForInteraction((ViewGroup) inflatedView, viewList, viewList2, null, new PAGNativeAdInteractionListener() {
                        @Override
                        public void onAdShowed() {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdDisplayed();
                            }
                        }

                        @Override
                        public void onAdClicked() {
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdClicked();
                            }
                        }

                        @Override
                        public void onAdDismissed() {

                        }
                    });

                    mAdViewItem.mContainerView.removeAllViews();
                    mAdViewItem.mContainerView.addView(inflatedView);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }

                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                } catch (Exception e) {
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - 광고뷰가 설정되지 않았습니다. - " + e.getMessage());
                }

            }
        });
    }

    @Override
    public Object getAdView() {
        return pangleBannerView;
    }


    private void loadAdBanner() {
        PAGBannerRequest bannerRequest = new PAGBannerRequest(pagBannerSize);

        PAGBannerAd.loadAd(mUnitId, bannerRequest, new PAGBannerAdLoadListener() {
            @Override
            public void onError(int code, String message) {
                pangleBannerView = null;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("Pangle 배너 광고 로드 실패 - Code : " + code + " Message : " + message);
                }
            }

            @Override
            public void onAdLoaded(PAGBannerAd bannerAd) {
                if (bannerAd == null) {
                    return;
                }

                pangleBannerView = new RelativeLayout(mContext);

                bannerAd.setAdInteractionCallback(new PAGBannerAdInteractionCallback() {
                    @Override
                    public void onAdShowed() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdDisplayed();
                        }
                    }

                    @Override
                    public void onAdClicked() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClicked();
                        }
                    }

                    @Override
                    public void onAdDismissed() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClosed();
                        }
                    }

                    @Override
                    public void onAdShowFailed(@NonNull PAGErrorModel pagErrorModel) {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdFailedToLoad("Pangle 배너 광고 로드 실패 - Code : " + pagErrorModel.getErrorCode() + " Message : " + pagErrorModel.getErrorMessage());
                        }
                    }
                });

                pangleBannerView.addView(bannerAd.getBannerView());

                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }
        });
    }

    private void loadAdInterstitial() {
        PAGInterstitialRequest request = new PAGInterstitialRequest();

        PAGInterstitialAd.loadAd(mUnitId, request, new PAGInterstitialAdLoadCallback() {
            @Override
            public void onError(@NonNull PAGErrorModel pagErrorModel) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("Pangle 전면 광고 로드 실패 Code : " + pagErrorModel.getErrorCode() + " Message : " + pagErrorModel.getErrorMessage());
                }
            }

            @Override
            public void onAdLoaded(PAGInterstitialAd pagInterstitialAd) {
                if (pagInterstitialAd == null) {
                    return;
                }
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }

                isInterstitialAdLoaded = true;

                mPagInterstitialAd = pagInterstitialAd;
                mPagInterstitialAd.setAdInteractionListener(new PAGInterstitialAdInteractionListener() {
                    @Override
                    public void onAdShowed() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdDisplayed();
                        }
                    }

                    @Override
                    public void onAdClicked() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClicked();
                        }
                    }

                    @Override
                    public void onAdDismissed() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClosed();
                        }
                    }
                });
            }
        });
    }

    private void loadAdRewardedVideo() {

        PAGRewardedRequest request = new PAGRewardedRequest();

        PAGRewardedAd.loadAd(mUnitId, request, new PAGRewardedAdLoadListener() {
            @Override
            public void onError(int i, String s) {
                mediationAdListener.onAdFailedToLoad("리워드 광고 로드 실패 - Code : " + i + " Message : " + s);
            }

            @Override
            public void onAdLoaded(PAGRewardedAd pagRewardedAd) {
                if (pagRewardedAd == null) {
                    mediationAdListener.onAdFailedToLoad("리워드 광고 로드 실패 : pagRewardedAd is null");
                    return;
                }

                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }

                isRewardedVideoAdLoaded = true;

                mPagRewardedAd = pagRewardedAd;

                mPagRewardedAd.setAdInteractionListener(new PAGRewardedAdInteractionListener() {
                    @Override
                    public void onUserEarnedReward(PAGRewardItem pagRewardItem) {
                        mediationAdListener.onAdComplete();
                    }

                    @Override
                    public void onUserEarnedRewardFail(int i, String s) {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdFailedToLoad("리워드 보상 획득 실패");
                        }
                    }

                    @Override
                    public void onAdShowed() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdDisplayed();
                        }
                    }

                    @Override
                    public void onAdClicked() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClicked();
                        }
                    }

                    @Override
                    public void onAdDismissed() {
                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClosed();
                        }
                    }
                });
            }

        });
    }
}
