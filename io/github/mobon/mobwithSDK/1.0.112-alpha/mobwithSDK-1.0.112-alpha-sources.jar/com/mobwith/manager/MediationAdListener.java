package com.mobwith.manager;

import com.mobwith.sdk.callback.InAppLandingCallback;
import com.mobwith.sdk.loader.MMAdData;

import java.util.Map;

/**
 * Created by yikim on 2018-02-09.
 */

public class MediationAdListener implements InAppLandingCallback {

    public MediationAdListener() {
    }

    public void onAdClosed() {
    }

    public void onAdCancel() {
    }

    public void onAppFinish() {
    }

    public void onAdFailedToLoad(String errorMsg) {
    }
    public void onAdFailedAdapterName(String adapterName) {
    }
    public void onAdRequest() {
    }

    public void onAdLoaded() {
    }

    public void onAdClicked() {
    }

    public void onAdImpression() {
    }

    /**
     * 전면, 리워드 광고에서 화면에 광고가 표시됨
     */
    public void onAdDisplayed() {
    }

    /**
     * 전면, 리워드 광고에서 광고가 완료됨.  리워드 조건을 충족한 경우
     */
    public void onAdComplete() {
    }

    /**
     * 전면, 리워드 광고에서 광고가 스킵됨, 리워드 조건 미충족
     */
    public void onAdSkip() {
    }

    /**
     * 전면, 리워드 광고 여는데 실패한 경우
     */
    public void onAdFailedToOpen(String errMsg, String adapterName) {
    }
}
