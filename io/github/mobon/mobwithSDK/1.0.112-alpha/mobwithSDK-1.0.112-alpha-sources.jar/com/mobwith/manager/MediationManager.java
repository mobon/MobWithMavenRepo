package com.mobwith.manager;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.lifecycle.LifecycleOwner;

import com.mobwith.adapters.AdViewAdapter;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.AdfitAdapter;
import com.mobwith.adapters.AdopBidmadAdapter;
import com.mobwith.adapters.ApiAdapter;
import com.mobwith.adapters.CaulyAdapter;
import com.mobwith.adapters.CoupangAdapter;
import com.mobwith.adapters.DTExchangeAdapter;
import com.mobwith.adapters.InMobiAdapter;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.LevelPlayAdapter;
import com.mobwith.adapters.MobWithAdManagerAdapter;
import com.mobwith.adapters.MobWithAdMobAdapter;
import com.mobwith.adapters.MobWithAdPopcornAdapter;
import com.mobwith.adapters.PangleAdapter;
import com.mobwith.adapters.ScriptAdapter;
import com.mobwith.adapters.SmartFrameAdapter;
import com.mobwith.adapters.UnityAdapter;
import com.mobwith.manager.nativeadview.NativeAdViewItem;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.api.MWRequestCustomURL;
import com.mobwith.sdk.api.MWRequestJsonAd;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.AdDataResponseDataModel;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortList;
import com.mobwith.sdk.models.SortListItemModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.models.reward.MWRewardBannerModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yikim on 2018-02-13.
 */

public class MediationManager {

    private static final long RETRY_INTERVAL_MS = 200L;
    private static final int MAX_RETRY_COUNT = 25; // 최대 5초 대기

    private final Context mContext;
    private final boolean isPointBanner;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    // mAdapterList 와 인덱스가 1:1 로 매핑되는, 각 어댑터가 로드돼야 할 광고 타입.
    // (AD_TYPE 단일 필드를 모든 어댑터에 공유하던 버그를 막기 위해 어댑터별로 보관)
    private final ArrayList<AdapterObject> mAdapterList = new ArrayList<>();
    private final ArrayList<String> mAdapterAdTypes = new ArrayList<>();

    // 생성자에서 한 번 지정되는 "요청된" 광고 타입(네이티브/전면/리워드 등). 항목별 해석의 기준값으로만 사용하고 변경하지 않는다.
    private final String mRequestedAdType;

    // 아무것도 하지 않는 리스너 (null 대신 사용 → 어댑터 NPE 방지)
    private static final MediationAdListener NO_OP_LISTENER = new MediationAdListener() {};

    private volatile AdapterObject mAdapter;
    private volatile int mAdapterIndex = 0;
    private volatile iMobonMediationCallback mCallback;
    private volatile boolean isLoadShow;
    private volatile boolean parallelPostProcessed = false;

    private NativeAdViewItem nativeAdViewItem;
    private NativeAdViewItem nativeAdViewItemForProduct = null;
    private MobwithAdCategoryModel mobwithAdCategoryModel;
    private List<String> campaignCodes;
    private List<String> categories;
    private int dialogHeight = -1;
    private int dialogWidth = -1;
    private boolean isFrameAd = false;

    private MWRewardBannerModel rewardBannerModel = null;
    private String advrtsPrdtCode = "";
    private String mediaScriptNo = "";
    private String isParallel = "false";
    private String sortListParallelYn = "";
    private String adBname = "";

    public MediationManager(Context _context, JSONObject adData, boolean isPointBanner) {
        this.mContext = _context;
        this.mRequestedAdType = null;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = isPointBanner;
        init(adData);
    }

    //배너
    public MediationManager(Context _context, JSONObject adData, boolean isPointBanner, MobwithAdCategoryModel mobwithAdCategoryModel, MWRewardBannerModel rewardBannerModel) {
        this.mContext = _context;
        this.mRequestedAdType = null;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = isPointBanner;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        this.rewardBannerModel = rewardBannerModel;
        init(adData);
    }

    //네이티브 Item 사용 X
    public MediationManager(Context _context, JSONObject adData, String adType, MobwithAdCategoryModel mobwithAdCategoryModel) {
        this.mContext = _context;
        this.mRequestedAdType = adType;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = false;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        init(adData);
    }

    //네이티브 Item 사용 O
    public MediationManager(Context _context, JSONObject adData, String adType, MobwithAdCategoryModel mobwithAdCategoryModel, NativeAdViewItem nativeAdViewItem, boolean isFrameAd) {
        this.mContext = _context;
        this.nativeAdViewItem = nativeAdViewItem;
        this.mRequestedAdType = adType;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = false;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        this.isFrameAd = isFrameAd;
        init(adData);
    }

    //네이티브
    public MediationManager(Context _context, JSONObject adData, String adType, MobwithAdCategoryModel mobwithAdCategoryModel, NativeAdViewItem nativeAdViewItem, List<String> campaignCodes, List<String> categories, MWRewardBannerModel rewardBannerModel) {
        this.mContext = _context;
        this.nativeAdViewItem = nativeAdViewItem;
        this.mRequestedAdType = adType;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = false;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        this.campaignCodes = campaignCodes;
        this.categories = categories;
        this.rewardBannerModel = rewardBannerModel;
        init(adData);
    }

    //프리패스
    public MediationManager(Context _context, JSONObject adData, String adType, MobwithAdCategoryModel mobwithAdCategoryModel, NativeAdViewItem nativeAdViewItem, NativeAdViewItem nativeAdViewItemForProduct) {
        this.mContext = _context;
        this.nativeAdViewItem = nativeAdViewItem;
        this.nativeAdViewItemForProduct = nativeAdViewItemForProduct;
        this.mRequestedAdType = adType;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = false;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        init(adData);
    }

    //페이북 상품
    public MediationManager(Context _context, JSONObject adData, String adType, MobwithAdCategoryModel mobwithAdCategoryModel, List<String> campaignCodes, List<String> categories) {
        this.mContext = _context;
        this.mRequestedAdType = adType;
        IntegrationHelper.validateIntegration();
        this.isPointBanner = false;
        this.mobwithAdCategoryModel = mobwithAdCategoryModel;
        this.campaignCodes = campaignCodes;
        this.categories = categories;
        init(adData);
    }

    /**
     * 다이얼로그(스크립트 광고) 크기 지정. 설정하지 않으면 -1(미지정)로 동작한다.
     */
    public void setDialogSize(int width, int height) {
        this.dialogWidth = width;
        this.dialogHeight = height;
    }

    /**
     * 광고 노출(show) 상태 설정. show 를 트리거하는 외부 코드가 호출해야 close 콜백이 동작한다.
     */
    public void setLoadShow(boolean loadShow) {
        this.isLoadShow = loadShow;
    }

    public synchronized void init(JSONObject obj) {
        init(new SortListResponse(obj));
    }

    /**
     * 파싱이 끝난 SortList 응답으로 어댑터 목록을 구성한다.
     */
    public synchronized void init(SortListResponse sortList) {
        // 인스턴스 재사용 시 이전 어댑터가 누적되지 않도록 매번 초기화한다.
        mAdapterIndex = 0;
        parallelPostProcessed = false;
        mAdapterList.clear();
        mAdapterAdTypes.clear();

        mediaScriptNo = sortList.mediaScriptNo;
        advrtsPrdtCode = sortList.advrtsPrdtCode;
        sortListParallelYn = sortList.sortListParallelYn;
        adBname = sortList.adBname;
        isParallel = sortList.isParallel;

        LogPrint.d("sortlist isParallel : " + isParallel);
        LogPrint.d("obj : " + sortList.data);

        if (sortList.list.isEmpty()) {
            LogPrint.d("init - 'list' 배열이 없습니다. 생성할 어댑터가 없습니다.");
            return;
        }

        // 항목 하나의 생성 실패가 나머지 항목 처리를 막지 않도록 항목 단위로 예외를 격리한다.
        for (int i = 0; i < sortList.list.size(); i++) {
            try {
                buildAdapter(sortList.list.get(i), sortList);
            } catch (Exception e) {
                LogPrint.d("init - " + i + "번째 어댑터 생성 실패 : " + e.getLocalizedMessage());
            }
        }
    }

    private void buildAdapter(SortListItemModel itemModel, SortListResponse sortList) {
        String unitId = itemModel.unitId;
        String exlItlMemo = itemModel.exlItlMemo;

        LogPrint.d("adapterName " + itemModel.getAdapterName() + " : " + unitId
                + " sdk type : " + itemModel.sdkType + " sortListSdkType : " + itemModel.sortListSdkType);

        if (itemModel.sortListSdkType == SortList.SdkType.NONE || TextUtils.isEmpty(unitId)) {
            return;
        }

        // 항목별 광고 타입을 지역 변수로 해석한다. (공유 필드를 덮어쓰지 않음)
        String adtype = resolveAdType(itemModel, sortList.mediaScriptSize);

        LogPrint.d("[SORTLIST] ===> [CHECK] type: " + itemModel.sdkType + ", name: " + itemModel.sortlist
                + ", unitID: " + unitId + " adType : " + adtype);

        // 이번 항목으로 추가된 어댑터에만 SortList 항목 정보를 심어주기 위해 추가 전 크기를 기억한다.
        int adapterCountBefore = mAdapterList.size();

        switch (itemModel.sortListSdkType) {
            case SDK:
                createSdkAdapter(itemModel, adtype, unitId);
                break;
            case Script:
                createScriptAdapter(itemModel, adtype, unitId, sortList);
                break;
            case JSON:
                createJsonAdapter(itemModel, adtype, unitId, exlItlMemo);
                break;
            case FRAME:
                createFrameAdapter(itemModel, adtype, unitId);
                break;
                //TODO:스크립트 전면배너 배포 시 주석 해제
            case API:
                createApiAdapter(itemModel, adtype, unitId, sortList.mediaScriptSize);
                break;
            default:
                LogPrint.d("[SORTLIST] ===> [TYPE] : NONE, [AD SOURCE] : NONE");
                break;
        }

        // 노출/패스백 트래킹에서 쓰도록 어댑터가 어느 SortList 항목에서 나왔는지 기록한다.
        for (int i = adapterCountBefore; i < mAdapterList.size(); i++) {
            mAdapterList.get(i).setExlItlSeq(itemModel.exlItlSeq);
        }

        LogPrint.d("AdapterList add : " + itemModel.getAdapterName() + " : " + unitId);
    }

    /**
     * SortList 항목과 미디어 스크립트 사이즈를 기준으로 광고 타입을 결정한다.
     * mRequestedAdType(요청 타입)은 읽기만 하고 변경하지 않는다.
     */
    private String resolveAdType(SortListItemModel itemModel, String mediaScriptSize) {
        if (BannerType.NATIVE_AD.equals(mRequestedAdType)) {
            if (itemModel.sortListType == SortList.Type.KAKAO_BIZ){
                return BannerType.BANNER_BIZ_BOARD;
            } else {
                return BannerType.NATIVE_AD;
            }
        } else if (BannerType.INTERSTITIAL.equals(mRequestedAdType)) {
            return BannerType.INTERSTITIAL;
        } else if (BannerType.REWARD_VIDEO.equals(mRequestedAdType)) {
            return BannerType.REWARD_VIDEO;
        } else if (BannerType.ENDING.equals(mRequestedAdType)) {
            return BannerType.ENDING;
        } else if (BannerType.TRANSITION.equals(mRequestedAdType)) {
            return BannerType.TRANSITION;
        } else if (BannerType.SPLASH_AD.equals(mRequestedAdType)){
            return BannerType.SPLASH_AD;
        } else if (BannerType.ENDING_BANNER.equals(mRequestedAdType)){
            return BannerType.ENDING_BANNER;
        }
        else if (itemModel.sortListType == SortList.Type.KAKAO_BIZ && advrtsPrdtCode.equals("01")) {
            return BannerType.BANNER_BIZ_BOARD;
        } else if (itemModel.sortListType == SortList.Type.KAKAO_ADFIT
                || itemModel.sortListType == SortList.Type.NEW_KAKAO_ADFIT) {
            return BannerType.BANNER_ADFIT;
        } else if (advrtsPrdtCode.equals("03")) {
            return BannerType.INTERSTITIAL;
        } else if (TextUtils.equals(mediaScriptSize, "300px*250px")) {
            return BannerType.BANNER_300x250;
        } else if (TextUtils.equals(mediaScriptSize, "320px*100px")) {
            return BannerType.BANNER_320x100;
        } else {
            return BannerType.BANNER_320x50;
        }
    }

    private void addAdapter(AdapterObject adapter, String adtype) {
        mAdapterList.add(adapter);
        mAdapterAdTypes.add(adtype);
    }

    private boolean isNativeAd(String adtype) {
        return TextUtils.equals(adtype, BannerType.NATIVE_AD);
    }

    private void createSdkAdapter(SortListItemModel itemModel, String adtype, String unitId) {
        if (!IntegrationHelper.verifiedAdapter(itemModel.getAdapterName())) {
            return;
        }

        SortList.Type type = itemModel.sortListType;

        if (type == SortList.Type.KAKAO_BIZ || type == SortList.Type.KAKAO_ADFIT || type == SortList.Type.NEW_KAKAO_ADFIT) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : SDK, [AD SOURCE] : Kakao Biz");
            AdfitAdapter adfitAdapter = new AdfitAdapter(mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && adfitAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                adfitAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(adfitAdapter, adtype);
        } else if (type == SortList.Type.NEW_ADOPSDK) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : SDK, [AD SOURCE] : ADOP_BidMad");
            AdopBidmadAdapter adopAdapter = new AdopBidmadAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && adopAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                adopAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(adopAdapter, adtype);
        } else if (type == SortList.Type.COUPANGSDK) {
            if (mContext instanceof LifecycleOwner) {
                CoupangAdapter coupangAdapter = new CoupangAdapter(
                        mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);

                boolean nativeOrReward = TextUtils.equals(adtype, BannerType.NATIVE_AD)
                        || TextUtils.equals(adtype, BannerType.REWARD_VIDEO);
                if (nativeOrReward && coupangAdapter.canUseNativeAdView()) {
                    LogPrint.d("Setted Native AD View Item");
                    coupangAdapter.mAdViewItem = (nativeAdViewItemForProduct != null)
                            ? nativeAdViewItemForProduct : nativeAdViewItem;
                }

                addAdapter(coupangAdapter, adtype);
            }
        } else if (type == SortList.Type.ADMOB) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : SDK, [AD SOURCE] : ADMOB");
            MobWithAdMobAdapter admobAdapter = new MobWithAdMobAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && admobAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                admobAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(admobAdapter, adtype);
        } else if (type == SortList.Type.ADMANAGER) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : SDK, [AD SOURCE] : ADMOB");
            MobWithAdManagerAdapter adManagerAdapter = new MobWithAdManagerAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && adManagerAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                adManagerAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(adManagerAdapter, adtype);
        } else if (type == SortList.Type.UNITYADSDK) {
            if (mContext instanceof Activity) {
                addAdapter(new UnityAdapter(mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo), adtype);
            }
        } else if (type == SortList.Type.LEVELPLAYSDK) {
            addAdapter(new LevelPlayAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo), adtype);
        } else if (type == SortList.Type.CAULYSDK) {
            CaulyAdapter caulyAdapter = new CaulyAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && caulyAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                caulyAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(caulyAdapter, adtype);
        } else if (type == SortList.Type.PANGLESDK) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : " + adtype + ", [AD SOURCE] : Pangle");
            PangleAdapter pangleAdapter = new PangleAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, null, false, mediaScriptNo);
            if (isNativeAd(adtype) && pangleAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                pangleAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(pangleAdapter, adtype);
        } else if (type == SortList.Type.DTEXCHANGESDK) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : " + adtype + ", [AD SOURCE] : DT Exchange");
            addAdapter(new DTExchangeAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo), adtype);
        } else if (type == SortList.Type.INMOBISDK) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : " + adtype + ", [AD SOURCE] : InMobi");
            InMobiAdapter inMobiAdapter = new InMobiAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && inMobiAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                inMobiAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(inMobiAdapter, adtype);

        } else if (type == SortList.Type.ADVIEWSDK) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : " + adtype + ", [AD SOURCE] : ADVIEW");
            addAdapter(new AdViewAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo), adtype);
        } else if (type == SortList.Type.ADPOPCORNSDK) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : " + adtype + ", [AD SOURCE] : ADPOPCORN");
            MobWithAdPopcornAdapter adPopcornAdapter = new MobWithAdPopcornAdapter(
                    mContext, itemModel.sortlist, unitId, adtype, false, mediaScriptNo);
            if (isNativeAd(adtype) && adPopcornAdapter.canUseNativeAdView()) {
                LogPrint.d("Setted Native AD View Item");
                adPopcornAdapter.mAdViewItem = nativeAdViewItem;
            }
            addAdapter(adPopcornAdapter, adtype);
        }
    }

    private void createScriptAdapter(SortListItemModel itemModel, String adtype, String unitId, SortListResponse sortList) {
        String adapterName = itemModel.getAdapterName();

        if (adapterName.toUpperCase().contains("MBMIXER")) {
            LogPrint.d("[SORTLIST] ===> [TYPE] : Script, [AD SOURCE] : MobMixer");
            addAdapter(new ScriptAdapter(
                    mContext, itemModel.getAdapterName(), unitId, adtype,
                    "", false, mediaScriptNo, "", dialogWidth, dialogHeight), adtype);
        } else {
            LogPrint.d("adapterName : " + adapterName + " unitId : " + unitId
                    + " adtype : " + adtype + " mediaScriptNo : " + mediaScriptNo);
            addAdapter(new ScriptAdapter(
                    mContext, itemModel.getAdapterName(), unitId, adtype,
                    itemModel.exlItlMemo, false, mediaScriptNo, sortList.siteurl, dialogWidth, dialogHeight), adtype);
        }
    }

    private void createJsonAdapter(SortListItemModel itemModel, String adtype, String unitId, String exlItlMemo) {
        LogPrint.d("[SORTLIST] ===> [TYPE] : JSON, [AD SOURCE] : " + itemModel.sortlist + " isParallel : " + isParallel);

        JsonAdapter jsonAdapter = new JsonAdapter(
                mContext, itemModel.getAdapterName(), unitId, exlItlMemo, adtype,
                mobwithAdCategoryModel, null, false, mediaScriptNo, isParallel, adBname, campaignCodes, categories);
        jsonAdapter.isPointBanner = isPointBanner;
        jsonAdapter.useParallel = itemModel.getUseParallel(sortListParallelYn);
        jsonAdapter.setRewardBannerModel(rewardBannerModel);

        LogPrint.d("jsonAdapter.useParallel : " + jsonAdapter.useParallel);

        if (sortListParallelYn.equalsIgnoreCase("Y") && jsonAdapter.useParallel) {
            prefetchParallelJsonAd(jsonAdapter, exlItlMemo);
        }

        addAdapter(jsonAdapter, adtype);
    }

    /**
     * 병렬(Mixer) 호출 대상 JsonAdapter 의 광고 데이터를 미리 가져온다.
     */
    private void prefetchParallelJsonAd(JsonAdapter jsonAdapter, String exlItlMemo) {
        LogPrint.d("데이터 미리 가져오기 : " + jsonAdapter.getName() + " siteNo : " + mediaScriptNo);
        jsonAdapter.setMixerState(JsonAdapter.MixerState.LOADING);

        String useParallel;
        if (jsonAdapter.useParallel){
            useParallel = "true";
        } else {
            useParallel = "false";
        }

        MWRequestJsonAd.request(mContext, jsonAdapter.getName(), mediaScriptNo, jsonAdapter.getUnitId(),
                exlItlMemo, "true", "Y", mobwithAdCategoryModel, useParallel, adBname, campaignCodes, categories, rewardBannerModel,
                new MobWithApiResponseCallback<AdDataResponseModel>() {
                    @Override
                    public void onSuccess(AdDataResponseModel response) {
                        LogPrint.d("success!!! : " + jsonAdapter.getName() + "  " + response.getJsonString());
                        MMAdData adData = new MMAdData();
                        adData.type = SortList.Type.NONE;
                        adData.jsonData = response.getJsonString();
                        adData.exid = jsonAdapter.getName();
                        jsonAdapter.setAdData(adData);
                        jsonAdapter.setMixerState(JsonAdapter.MixerState.LOADED);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        LogPrint.d("prefetchParallelJsonAd onFailure : " + e.getLocalizedMessage());
                        jsonAdapter.setMixerState(JsonAdapter.MixerState.FAILED);
                    }
                });
    }

    private void createFrameAdapter(SortListItemModel itemModel, String adtype, String unitId) {
        LogPrint.d("[SORTLIST] ===> [TYPE] : FRAME, [AD SOURCE] : " + itemModel.getAdapterName());
        if (isFrameAd) {
            addAdapter(new SmartFrameAdapter(
                    mContext, itemModel.getAdapterName(), unitId, mediaScriptNo, adtype,
                    mobwithAdCategoryModel, null, false), adtype);
        }
    }

    private void createApiAdapter(SortListItemModel itemModel, String adtype, String unitId, String mediaScriptSize) {
        LogPrint.d("[SORTLIST] ===> [TYPE] : API, [AD SOURCE] : " + itemModel.getAdapterName());
        addAdapter(new ApiAdapter(mContext, itemModel.getAdapterName(), unitId, mediaScriptNo, adtype, itemModel, mediaScriptSize), adtype);
    }

    public String getCurMediationName() {
        AdapterObject adapter = mAdapter;
        String name = (adapter != null) ? adapter.getName() : "";
        return TextUtils.isEmpty(name) ? "" : name.toLowerCase();
    }

    public synchronized boolean LoadMediation(final iMobonMediationCallback callback) {
        mCallback = callback;
        LogPrint.d("- LoadMediation : " + mAdapterIndex + " : " + mAdapterList.size()
                + " : Adapter Name is " + (mAdapter != null ? mAdapter.getName() : "null"));

        if (mAdapterIndex < mAdapterList.size()) {
            final AdapterObject adapter = mAdapterList.get(mAdapterIndex);
            final String adtype = mAdapterAdTypes.get(mAdapterIndex);
            mAdapter = adapter;
            mAdapterIndex += 1;

            if (!adapter.isCreated()) {
                adapter.onCreate(mContext, adapter.getAdapterPackageName());
                adapter.setLog(LogPrint.isLogPrint());
            }

            // 비동기 콜백이 공유 필드 mAdapter 가 아니라 "이 어댑터"를 보도록 캡처한다.
            adapter.setAdListener(createMediationListener(callback, adapter));
            callback.onAdRequest(adapter);

            mMainHandler.post(() -> adapter.load(adtype));
            return true;
        }

        LogPrint.d("LoadMediation : Fail to Ad Load : " + mAdapterIndex + " : " + mAdapterList.size());
        callback.onAdFailedToLoad(mAdapter, Key.NOFILL);
        return false;
    }

    private MediationAdListener createMediationListener(final iMobonMediationCallback callback, final AdapterObject adapter) {
        return new MediationAdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                if (isLoadShow) {
                    isLoadShow = false;
                    adapter.close();
                }
                LogPrint.d(adapter.getName() + " onAdClosed");
                callback.onAdClosed();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                LogPrint.d(adapter.getName() + " ADLoaded");
                callback.onAdAdapter(adapter);
                // 병렬 호출 후처리(중복 실행 방지 가드는 메서드 내부에 있음)
                postProcessParallelAdapters();
            }

            @Override
            public void onAdCancel() {
                super.onAdCancel();
                if (isLoadShow) {
                    isLoadShow = false;
                    adapter.close();
                }
                LogPrint.d(adapter.getName() + " onAdCancel");
                callback.onAdCancel();
            }

            @Override
            public void onAdRequest() {
                super.onAdRequest();
                LogPrint.d(adapter.getName() + " onAdRequest");
                callback.onAdRequest(adapter);
            }

            @Override
            public void onAdFailedToLoad(String errorMsg) {
                super.onAdFailedToLoad(errorMsg);
                LogPrint.d(adapter.getName() + "  AD FailLoad: " + errorMsg);
                callback.onAdFailedAdapterName(adapter);

                // 남은 어댑터가 있으면 다음으로 폴백, 없으면 최종 실패 콜백.
                if (mAdapterIndex < mAdapterList.size()) {
                    LogPrint.d(" -- LoadMediation : " + mAdapterIndex + " : " + mAdapterList.size()
                            + " : Adapter Name is " + adapter.getName());
                    LoadMediation(callback);
                } else {
                    callback.onAdFailedToLoad(adapter, errorMsg);
                }
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
                LogPrint.d(adapter.getName() + "  ADClicked");
                callback.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
                LogPrint.d(adapter.getName() + "  onAdImpression");
                callback.onAdImpression();
            }

            @Override
            public void onAppFinish() {
                super.onAppFinish();
                callback.onAppFinish();
            }

            // 리워드형 광고
            @Override
            public void onAdDisplayed() {
                super.onAdDisplayed();
                callback.onAdDisplayed();
            }

            // 리워드형 광고
            @Override
            public void onAdComplete() {
                super.onAdComplete();
                callback.onAdComplete();
            }

            // 리워드형 광고
            @Override
            public void onAdSkip() {
                super.onAdSkip();
                callback.onAdSkip();
            }

            // 리워드형 광고
            @Override
            public void onAdFailedToOpen(String errMsg, String adapterName) {
                super.onAdFailedToOpen(errMsg, adapterName);
                callback.onAdFailedToOpen();
//                MWSendErrorLog.requestWith(mContext, mediaScriptNo, adapterName, advrtsPrdtCode, errMsg);
            }
        };
    }

    /**
     * 병렬 로딩이 켜진 경우, 리스트의 JsonAdapter 들을 메인 스레드에서 한 번만 후처리한다.
     */
    private void postProcessParallelAdapters() {
        if (!sortListParallelYn.equalsIgnoreCase("Y")) {
            return;
        }
        if (parallelPostProcessed) {
            return; // onAdLoaded 가 여러 번 호출돼도 중복 요청이 나가지 않도록 1회만 처리.
        }
        parallelPostProcessed = true;

        for (int i = 0; i < mAdapterList.size(); i++) {
            final int index = i;
            MainThreadHandler.post(() -> {
                if (mCallback == null || index >= mAdapterList.size()) return;

                Object adapter = mAdapterList.get(index);
                if (!(adapter instanceof JsonAdapter)) {
                    return;
                }

                JsonAdapter jsonAdapter = (JsonAdapter) adapter;
                if (!jsonAdapter.useParallel) {
                    return;
                }

                MMAdData d = jsonAdapter.getAdData();
                if (d != null) {
                    LogPrint.d("[DIAG] " + jsonAdapter.getName()
                            + " hash=" + System.identityHashCode(jsonAdapter)
                            + " state=" + jsonAdapter.getMixerState()
                            + " hasData=" + !TextUtils.isEmpty(d.jsonData)
                            + " jsonData=" + d.jsonData);
                }

                waitForLoadedAndHandle(jsonAdapter, 0);
            });
        }
    }

    public boolean next() {
        iMobonMediationCallback callback = mCallback;
        return callback != null && LoadMediation(callback);
    }

    private void waitForLoadedAndHandle(JsonAdapter jsonAdapter, int retryCount) {
        if (jsonAdapter.getMixerState() == JsonAdapter.MixerState.LOADED) {
            handleAdData(jsonAdapter);
            return;
        }

        if (jsonAdapter.getMixerState() == JsonAdapter.MixerState.FAILED) {
            LogPrint.d("Mixer LOAD FAILED");
            return;
        }

        if (retryCount >= MAX_RETRY_COUNT) {
            LogPrint.d("Mixer LOADED 대기 타임아웃 - " + jsonAdapter.getMixerState().name());
            return;
        }

        mMainHandler.postDelayed(() -> waitForLoadedAndHandle(jsonAdapter, retryCount + 1), RETRY_INTERVAL_MS);
    }

    private void handleAdData(JsonAdapter jsonAdapter) {
        try {
            LogPrint.d("handleAdData");

            MMAdData adData = jsonAdapter.getAdData();
            if (adData == null || TextUtils.isEmpty(adData.jsonData)) {
                return;
            }

            JSONObject jsonObject = new JSONObject(adData.jsonData);
            AdDataResponseDataModel dataModel = new AdDataResponseModel(jsonObject).getData();
            if (dataModel == null || dataModel.getFirstAd() == null) {
                return;
            }

            AdDataModel adDataModel = dataModel.getFirstAd();
            String url = jsonAdapter.isMixerLoaded() ? adDataModel.getNurl() : adDataModel.getLurl();
            String tag = jsonAdapter.isMixerLoaded() ? "Mixer Loaded" : "Mixer Not Loaded";

            if (url != null && !url.isEmpty()) {
                MWRequestCustomURL.requestWith(mContext, url, tag);
            }
        } catch (Exception e) {
            LogPrint.d("handleAdData error : " + e.getLocalizedMessage());
        }
    }

    /**
     * 광고 종료 시 참조를 정리해 Context/Activity 누수를 줄인다.
     */
    public synchronized void release() {
        releaseExcept(null);
    }

    /**
     * {@code keep} 을 제외한 나머지 어댑터만 정리한다.
     * 이미 노출 중이거나 노출 예정인 어댑터는 광고 Activity 가 소유하므로,
     * 다음 로드를 시작할 때 그 어댑터만 남기고 나머지를 해제하는 용도.
     */
    public synchronized void releaseExcept(AdapterObject keep) {
        try {
            mMainHandler.removeCallbacksAndMessages(null);

            // clear() 전에 먼저 끊어야 함
            for (AdapterObject adapter : mAdapterList) {
                if (adapter == keep) {
                    continue;
                }
                try {
                    adapter.setAdListener(NO_OP_LISTENER);
                    adapter.destroy();
                } catch (Exception e) {
                    LogPrint.d("release error : " + e.getLocalizedMessage());
                }
            }

            mCallback = null;
            mAdapter = null;
            mAdapterList.clear();
            mAdapterAdTypes.clear();
        } catch (Exception e){
            LogPrint.d("release : " + e.getLocalizedMessage());
        }
    }
}