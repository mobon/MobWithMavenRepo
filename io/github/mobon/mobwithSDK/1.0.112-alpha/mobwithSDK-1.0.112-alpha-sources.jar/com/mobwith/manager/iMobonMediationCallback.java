package com.mobwith.manager;

import com.mobwith.adapters.AdapterObject;

/**
 * - 모비온 미디에이션 콜백
 */
public interface iMobonMediationCallback {


    void onLoadedAdData(final String data, final AdapterObject adapter);

    void onAdAdapter(final AdapterObject adapter);

    void onAdClosed();

    void onAdCancel();

    void onAdFailedToLoad(final AdapterObject adapter,String errorMsg);

    /**
     * 어댑터가 광고를 채우지 못해 다음 어댑터로 넘어가는(패스백) 시점에 호출됩니다.
     * 어댑터 이름/UnitId/SortList 가중치(exlItlSeq)는 모두 {@link AdapterObject} 에서 꺼내 씁니다.
     *
     * @param adapter 광고를 채우지 못한 어댑터
     */
    void onAdFailedAdapterName(final AdapterObject adapter);

    void onAdImpression();

    void onAdClicked();

    void onAppFinish();

    /**
     * 어댑터에 광고를 요청하는 시점에 호출됩니다.
     * 어댑터 이름/UnitId/SortList 가중치(exlItlSeq)는 모두 {@link AdapterObject} 에서 꺼내 씁니다.
     *
     * @param adapter 광고를 요청한 어댑터
     */
    void onAdRequest(final AdapterObject adapter);


    // 보상형 광고를 위해 추가.
    void onAdDisplayed();
    void onAdComplete();
    void onAdSkip();
    void onAdFailedToOpen();

}
