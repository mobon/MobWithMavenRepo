package com.mobwith.manager;

import android.content.Context;

import com.mobwith.MobwithSDK;
import com.mobwith.httpmodule.Buffer;
import com.mobwith.httpmodule.Call;
import com.mobwith.httpmodule.FormBody;
import com.mobwith.httpmodule.HttpUrl;
import com.mobwith.httpmodule.Interceptor;
import com.mobwith.httpmodule.MediaType;
import com.mobwith.httpmodule.MobonOkHttpClient;
import com.mobwith.httpmodule.MobonRequest;
import com.mobwith.httpmodule.MobonResponse;
import com.mobwith.httpmodule.RequestBody;
import com.mobwith.sdk.BuildConfig;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.Key;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;


public final class MobonHttpService {

    private static MobonOkHttpClient client = null;

    private static MobonOkHttpClient getInstance() {
        if (client == null) {
            client = new MobonOkHttpClient.Builder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build();
        }

        return client;
    }

    public static Call get(Context context, String url, Map<String, String> params) {
        return get(context, url, params, null);
    }

    public static Call get(Context context, String url, Map<String, String> params, Map<String, String> headers) {
        MobonOkHttpClient client = getInstance();
        HttpUrl.Builder httpBuider = Objects.requireNonNull(HttpUrl.parse(url)).newBuilder();

        if (params != null) {
            for (Map.Entry<String, String> param : params.entrySet()) {
                httpBuider.addQueryParameter(param.getKey(), param.getValue());
            }
        }

        MobonRequest.Builder builder = new MobonRequest.Builder();
        String userAgent =SpManager.getString(context, Key.USER_AGENT);
        if (!userAgent.isEmpty()) {
            builder = builder.addHeader("User-Agent", userAgent);
        }
        builder = builder.addHeader("Content-Type", "application/json");
        builder = builder.addHeader("Accept", "*/*");
        builder = builder.addHeader("mobwithsdk-version", BuildConfig.MOBWITHSDK_VERSION);
        builder = builder.addHeader("app-version", CommonUtils.getAppVersion(context));
        builder = builder.addHeader("os", "Android");
        if (headers != null) {
            for (Map.Entry<String, String> param : headers.entrySet()) {
                builder = builder.addHeader(param.getKey(), param.getValue());
            }
        }

        MobonRequest mobonRequest = builder.url(httpBuider.build()).build();

        return client.newCall(context, mobonRequest);
//        return makeCall(context, mobonRequest);
    }


    public static Call put(Context context, String url, Map<String, String> params, String sessionId, Map<String, String> headers) {
        return put(context, url, params, sessionId, "", headers);
    }

    public static Call put(Context context, String url, Map<String, String> params, String sessionId, String contentType, Map<String, String> headers) {

        MobonOkHttpClient client = getInstance();
        HttpUrl.Builder httpBuider = HttpUrl.parse(url).newBuilder();

        if (contentType.equals("json")) {
            JSONObject jsonObject = new JSONObject();
            if (params != null) {
                try {
                    for (Map.Entry<String, String> param : params.entrySet()) {
                        try {
                            JSONArray array = new JSONArray(param.getValue());
                            jsonObject.put(param.getKey(), array);
                        } catch (JSONException e) {
                            try {
                                JSONObject item = new JSONObject(param.getValue());
                                jsonObject.put(param.getKey(), item);
                            } catch (JSONException e1) {
                                jsonObject.put(param.getKey(), param.getValue());
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            String json = jsonObject.toString().replace("\\", "");

            RequestBody body = RequestBody.create(JSON, json);

            MobonRequest.Builder builder = new MobonRequest.Builder();
            String userAgent =SpManager.getString(context, Key.USER_AGENT);
            if (!userAgent.isEmpty()) {
                builder = builder.addHeader("User-Agent", userAgent);
            }
            builder = builder.addHeader("Content-Type", "application/json");
            builder = builder.addHeader("session-id", sessionId);
            builder = builder.addHeader("mobwithsdk-version", BuildConfig.MOBWITHSDK_VERSION);
            builder = builder.addHeader("app-version", CommonUtils.getAppVersion(context));
            builder = builder.addHeader("os", "Android");
            builder = builder.addHeader("Accept", "application/json");
            if (headers != null) {
                for (Map.Entry<String, String> param : headers.entrySet()) {
                    builder = builder.addHeader(param.getKey(), param.getValue());
                }
            }

            MobonRequest mobonRequest = builder.url(url).put(body).build();

            assert mobonRequest.body() != null;

            return client.newCall(context, mobonRequest);
//            return makeCall(context, mobonRequest);
        } else {
            FormBody.Builder formbuilder = new FormBody.Builder();

            if (params != null) {
                try {
                    for (Map.Entry<String, String> param : params.entrySet()) {
                        formbuilder.add(param.getKey(), param.getValue());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            MobonRequest.Builder builder = new MobonRequest.Builder();
            String userAgent =SpManager.getString(context, Key.USER_AGENT);
            if (!userAgent.isEmpty()) {
                builder = builder.addHeader("User-Agent", userAgent);
            }
            builder = builder.addHeader("Content-Type", "application/json");
            builder = builder.addHeader("session-id", sessionId);
            builder = builder.addHeader("mobwithsdk-version", BuildConfig.MOBWITHSDK_VERSION);
            builder = builder.addHeader("app-version", CommonUtils.getAppVersion(context));
            builder = builder.addHeader("os", "Android");
            builder = builder.addHeader("Accept", "application/json");
            if (headers != null) {
                for (Map.Entry<String, String> param : headers.entrySet()) {
                    builder = builder.addHeader(param.getKey(), param.getValue());
                }
            }


            MobonRequest mobonRequest = builder.url(httpBuider.build()).put(formbuilder.build()).build();

            return client.newCall(context, mobonRequest);
//            return makeCall(context, mobonRequest);
        }

    }

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    public static Call post(Context context, String url, Map<String, String> params, String content_type, String sessionId, Map<String, String> headers) {

        MobonOkHttpClient client = getInstance();
        MobonRequest mobonRequest;

        if (content_type.equals("json")) {
            JSONObject jsonObject = new JSONObject();
            if (params != null) {
                try {
                    for (Map.Entry<String, String> param : params.entrySet()) {
                        String key = param.getKey();
                        String value = param.getValue();

                        if (key != null && value != null && !key.isEmpty() && !value.isEmpty()) {
                            try {
                                JSONArray array = new JSONArray(value);
                                jsonObject.put(key, array);
                            } catch (JSONException e) {
                                try {
                                    JSONObject item = new JSONObject(value);
                                    jsonObject.put(key, item);
                                } catch (JSONException e1) {
                                    jsonObject.put(key, value);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            String json = jsonObject.toString().replace("\\", "");

            RequestBody body = RequestBody.create(JSON, json);

            MobonRequest.Builder builder = new MobonRequest.Builder();
            String userAgent =SpManager.getString(context, Key.USER_AGENT);
            if (!userAgent.isEmpty()) {
                builder = builder.addHeader("User-Agent", userAgent);
            }
            builder = builder.addHeader("Content-Type", "application/json");
            builder = builder.addHeader("session-id", sessionId);
            builder = builder.addHeader("mobwithsdk-version", BuildConfig.MOBWITHSDK_VERSION);
            builder = builder.addHeader("app-version", CommonUtils.getAppVersion(context));
            builder = builder.addHeader("os", "Android");
            builder = builder.addHeader("Accept", "application/json");
            if (headers != null) {
                for (Map.Entry<String, String> param : headers.entrySet()) {
                    builder = builder.addHeader(param.getKey(), param.getValue());
                }
            }

            mobonRequest = builder.url(url).post(body).build();

        } else {

            FormBody.Builder builder = new FormBody.Builder();

            if (params != null) {
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    builder.add(entry.getKey(), entry.getValue());
                }
            }

            FormBody body = builder.build();

            MobonRequest.Builder reqbuilder = new MobonRequest.Builder();
            String userAgent =SpManager.getString(context, Key.USER_AGENT);
            if (!userAgent.isEmpty()) {
                reqbuilder = reqbuilder.addHeader("User-Agent", SpManager.getString(context, Key.USER_AGENT));
            }
            reqbuilder = reqbuilder.addHeader("Content-Type", "application/x-www-form-urlencoded");
            reqbuilder = reqbuilder.addHeader("session-id", sessionId);
            reqbuilder = reqbuilder.addHeader("mobwithsdk-version", BuildConfig.MOBWITHSDK_VERSION);
            reqbuilder = reqbuilder.addHeader("app-version", CommonUtils.getAppVersion(context));
            reqbuilder = reqbuilder.addHeader("os", "Android");
            reqbuilder = reqbuilder.addHeader("Accept", "application/json");
            if (headers != null) {
                for (Map.Entry<String, String> param : headers.entrySet()) {
                    reqbuilder = reqbuilder.addHeader(param.getKey(), param.getValue());
                }
            }
            mobonRequest = reqbuilder.url(url).post(body).build();
        }

        return client.newCall(mobonRequest);
//        return makeCall(context, mobonRequest);
    }

    public static Call postText(Context context, String url, Map<String, String> params, String rawBody, String sessionId, Map<String, String> headers) {

        MobonOkHttpClient client = getInstance();
        MobonRequest mobonRequest;

        HttpUrl httpUrl = HttpUrl.parse(url);
        HttpUrl.Builder urlBuilder = httpUrl.newBuilder();
        if (params != null) {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                String value = entry.getValue() != null ? entry.getValue() : "";
                urlBuilder.addQueryParameter(entry.getKey(), value);
            }
        }
        HttpUrl finalUrl = urlBuilder.build();

        // body는 params와 무관한 raw 문자열 (암호화된 payload)
        MediaType TEXT_PLAIN = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(TEXT_PLAIN, rawBody != null ? rawBody : "");

        MobonRequest.Builder builder = new MobonRequest.Builder();
        String userAgent =SpManager.getString(context, Key.USER_AGENT);
        if (!userAgent.isEmpty()) {
            builder = builder.addHeader("User-Agent", SpManager.getString(context, Key.USER_AGENT));
        }
        builder = builder.addHeader("Content-Type", "text/plain");
        builder = builder.addHeader("session-id", sessionId);
        builder = builder.addHeader("mobwithsdk-version", BuildConfig.MOBWITHSDK_VERSION);
        builder = builder.addHeader("app-version", CommonUtils.getAppVersion(context));
        builder = builder.addHeader("os", "Android");
        builder = builder.addHeader("Accept", "application/json");
        if (headers != null) {
            for (Map.Entry<String, String> param : headers.entrySet()) {
                builder = builder.addHeader(param.getKey(), param.getValue());
            }
        }

        mobonRequest = builder.url(finalUrl).post(body).build();

        return client.newCall(mobonRequest);
    }

    private static Call makeCall(Context context, MobonRequest request) {
        MobonOkHttpClient client = getInstance();

        if (BuildConfig.DEBUG) {
            // 디버그 모드에서만 타이밍 인터셉터 추가
            client = client.newBuilder()
                    .addNetworkInterceptor(new TimingInterceptor())
                    .build();
        }

        if (context != null) {
            return client.newCall(context, request);
        } else {
            return client.newCall(request);
        }
    }


    static class TimingInterceptor implements Interceptor {

        @Override
        public MobonResponse intercept(Chain chain) throws IOException {
            MobonRequest request = chain.request();

            long startNs = System.nanoTime();
            long startMs = System.currentTimeMillis();

            // 요청 파라미터(body) 추출
            String requestBody = null;
            if (request.body() != null) {
                Buffer buffer = new Buffer();
                request.body().writeTo(buffer);
                requestBody = buffer.readUtf8();
            }

            // 요청 실행
            MobonResponse response = chain.proceed(request);

            long endNs = System.nanoTime();
            long endMs = System.currentTimeMillis();

            double tookMs = (endNs - startNs) / 1_000_000.0;

            // 로그 출력
            String logMessage =
                    "[Reqeust Info] \n" +
                            "URL        : " + request.url() + "\n" +
                            "Method     : " + request.method() + "\n" +
                            "Start Time : " + startMs + " ms" + "\n" +
                            "End Time   : " + endMs + " ms" + "\n" +
                            "Elapsed    : " + tookMs + " ms";

            if (requestBody != null && !requestBody.isEmpty()) {
                logMessage += "\n" + "Parameters : " + requestBody;
            }

            String resultLog = "Result     : " +request.url() + " : " + tookMs + " ms";

            LogPrint.w(resultLog);

            return response;
        }
    }
}