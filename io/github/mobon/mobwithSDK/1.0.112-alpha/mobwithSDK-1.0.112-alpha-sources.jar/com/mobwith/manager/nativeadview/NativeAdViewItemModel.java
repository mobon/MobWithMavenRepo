package com.mobwith.manager.nativeadview;

//직광고와 네트워크 광고를 분기처리 하기 위한 모델
public class NativeAdViewItemModel {

    private int viewLayoutID;
    private int mediaViewContainerID;
    private int adImageViewID;
    private int adLogoImageViewID;
    private int titleViewID;
    private int descriptionViewID;
    private int gotoSiteButtonID;
    private int infoLogoImageViewContainerID;
    private int infoLogoImageViewID;

    public NativeAdViewItemModel(int viewLayoutID, int mediaViewContainerID, int adImageViewID, int adLogoImageViewID, int titleViewID, int descriptionViewID, int gotoSiteButtonID, int infoLogoImageViewContainerID, int infoLogoImageViewID) {
        this.viewLayoutID = viewLayoutID;
        this.mediaViewContainerID = mediaViewContainerID;
        this.adImageViewID = adImageViewID;
        this.adLogoImageViewID = adLogoImageViewID;
        this.titleViewID = titleViewID;
        this.descriptionViewID = descriptionViewID;
        this.gotoSiteButtonID = gotoSiteButtonID;
        this.infoLogoImageViewContainerID = infoLogoImageViewContainerID;
        this.infoLogoImageViewID = infoLogoImageViewID;
    }

    public int getViewLayoutID() {
        return viewLayoutID;
    }

    public int getMediaViewContainerID() {
        return mediaViewContainerID;
    }

    public int getAdImageViewID() {
        return adImageViewID;
    }

    public int getAdLogoImageViewID() {
        return adLogoImageViewID;
    }

    public int getTitleViewID() {
        return titleViewID;
    }

    public int getDescriptionViewID() {
        return descriptionViewID;
    }

    public int getGotoSiteButtonID() {
        return gotoSiteButtonID;
    }

    public int getInfoLogoImageViewContainerID() {
        return infoLogoImageViewContainerID;
    }

    public int getInfoLogoImageViewID() {
        return infoLogoImageViewID;
    }
}
