package com.mobwith.sdk;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mobwith.MobwithSDK;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.custom.RoundedLinearLayout;
import com.mobwith.sdk.utils.MainThreadHandler;
/**
 * 포인트 적립 기능이 있는 배너 광고를 표시하고 관리하는 커스텀 뷰입니다.
 * 이 뷰는 다음과 같은 주요 기능을 수행합니다:
 * - {@link MobwithBannerView}를 내부에 포함하여 실제 배너 광고를 로드하고 표시합니다.
 * - 광고 로드 상태에 따라 프로그레스바를 표시하거나 숨깁니다.
 * - 광고 로드 실패 시 대체 이미지를 표시하고, 클릭 시 기본 URL로 이동하는 기능을 제공합니다.
 * - 포인트 지급 전과 후의 UI를 구분하여 표시할 수 있는 기능을 제공합니다 (예: "포인트 받기" / "적립 완료").
 * - {@link iBannerCallback}을 통해 광고 로드 상태 및 클릭 이벤트를 외부로 전달합니다.
 * - 광고 유닛 ID를 설정하고, 광고를 로드, 재시작, 중지, 파괴하는 기능을 제공합니다.
 */
public class MobwithPointBannerView extends RelativeLayout {

    private String defaultAdUrl = "https://mobwith.co.kr/";
    private final Context mContext;
    private iBannerCallback mIBannerAdCallback = null;
    private boolean isSendedCallback;
    private String mScriptNo;
    private boolean viewVisible;
    private boolean isInLoading = false;
    private MobwithBannerView mBannerView;
    private FrameLayout mBannerContainer;
    private RoundedLinearLayout pointView;
    private RelativeLayout layoutWillPoint;
    private RelativeLayout layoutAfterPoint;
    private TextView willPointTextView;
    private TextView afterPointTextView;
    private ProgressBar progressBar;
    private ImageView imageViewNoAdDefault;

    /**
     * MobwithPointBannerView 생성자 (코드에서 동적 생성 시 사용)
     * @param context 뷰를 생성하는 데 사용되는 컨텍스트
     */
    public MobwithPointBannerView(Context context) {
        super(context);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }
    /**
     * MobwithPointBannerView 생성자 (XML 레이아웃에서 사용 시 호출)
     * @param context 컨텍스트
     * @param attrs XML 레이아웃에서 정의된 속성
     */
    public MobwithPointBannerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }
    /**
     * MobwithPointBannerView 생성자 (XML 레이아웃에서 스타일과 함께 사용 시 호출)
     * @param context 컨텍스트
     * @param attrs XML 레이아웃에서 정의된 속성
     * @param defStyle 적용할 스타일 리소스
     */
    public MobwithPointBannerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        this.isInLoading = false;
        onInit();
    }

    /**
     * 이 포인트 배너 뷰에 사용할 광고 유닛 ID를 설정합니다.
     * 설정된 유닛 ID는 내부 {@link MobwithBannerView}에도 전달됩니다.
     * @param unitId 광고 유닛 ID 문자열
     * @return 설정을 마친 MobwithPointBannerView 자신 (체이닝 방식 지원)
     * @throws NullPointerException unitId가 null인 경우 발생할 수 있음 (내부 로직에 따라)
     */
    public MobwithPointBannerView setBannerUnitId(String unitId) throws NullPointerException {
        mScriptNo = unitId;

        if (mBannerView != null) {
            mBannerView.setBannerUnitId(mScriptNo);
        }

        return this;
    }

    /**
     * 이 배너를 통해 포인트를 지급할 수 있는지 여부를 설정합니다.
     * 이 설정에 따라 포인트 지급 전 UI (layoutWillPoint)와 지급 후 UI (layoutAfterPoint)의 가시성이 변경됩니다.
     * 포인트가 이미 지급된 경우 false로 설정하여 "적립 완료" 등의 UI를 표시할 수 있습니다.
     * UI 변경은 메인 스레드에서 안전하게 수행됩니다.
     *
     * @param isEnable true이면 포인트 지급 가능 UI 표시, false이면 포인트 지급 완료 UI 표시
     */
    public void setPointEnable(boolean isEnable) {

        // 테스트중 아래 부분이 제대로 갱신되지 않는 현상이 확인되어 로직상 UI 갱신에 대한 부분을 보강함.
        MainThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (layoutWillPoint != null && layoutAfterPoint != null) {
                    boolean willPointVisibilityChanged = false;
                    boolean afterPointVisibilityChanged = false;

                    int willPointVisibility = isEnable ? VISIBLE : GONE;
                    if (layoutWillPoint.getVisibility() != willPointVisibility) {
                        layoutWillPoint.setVisibility(willPointVisibility);
                        willPointVisibilityChanged = true;
                    }

                    int afterPointVisibility = isEnable ? GONE : VISIBLE;
                    if (layoutAfterPoint.getVisibility() != afterPointVisibility) {
                        layoutAfterPoint.setVisibility(afterPointVisibility);
                        afterPointVisibilityChanged = true;
                    }


                    if (willPointVisibilityChanged) {
                        layoutWillPoint.requestLayout();
                        layoutWillPoint.invalidate();
                    }
                    if (afterPointVisibilityChanged) {
                        layoutAfterPoint.requestLayout();
                        layoutAfterPoint.invalidate();
                    }
                }
            }
        });
    }


    /**
     * 포인트 표시 영역(pointView)의 배경색을 설정합니다.
     * 현재 버전에서는 private으로 선언되어 외부에서 직접 호출할 수 없습니다.
     *
     * @param color 설정할 배경 색상 값 (예: Color.RED 또는 0xFFFF0000)
     */
    private void setPointViewBackgroundColor(int color) {
        pointView.setBackgroundColor(color);
    }

    /**
     * 포인트 표시 영역의 텍스트 색상을 설정합니다.
     * 배경색에 따라 텍스트가 잘 보이지 않을 경우를 대비한 기능입니다.
     *
     * @param color 설정할 텍스트 색상 값
     */
    private void setPointViewTextColor(int color) {
        willPointTextView.setTextColor(color);
        afterPointTextView.setTextColor(color);
    }
    /**
     * 현재 배너에 대한 리워드(포인트)가 이미 지급되었는지 여부를 반환합니다.
     * 포인트 지급 후 UI (layoutAfterPoint)가 보이는 상태이면 true를 반환합니다.
     *
     * @return 포인트가 지급되었으면 true, 그렇지 않으면 false
     */
    public boolean isRewarded() {
        return (layoutAfterPoint != null && layoutAfterPoint.getVisibility() == VISIBLE); // 포인트를 줄 수 있는 상태인지 여부
    }


    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        LogPrint.d("hasWindowFocus = " + hasWindowFocus);
        super.onWindowFocusChanged(hasWindowFocus);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    /**
     * 뷰의 UI 구성요소를 초기화하고, Mobwith SDK를 초기화합니다.
     * XML 레이아웃 (R.layout.banner_point_layout)을 인플레이트하여 현재 뷰에 추가하고,
     * 내부 UI 요소들(프로그레스바, 이미지뷰, 텍스트뷰 등)을 참조합니다.
     * 광고 로드 실패 시 표시될 기본 이미지뷰에는 클릭 리스너를 설정합니다.
     */
    private void onInit() {
        inflate(mContext, R.layout.banner_point_layout, this);

        setGravity(Gravity.CENTER);
        MobwithSDK.initSDK(mContext);

        mBannerContainer = findViewById(R.id.banner_container);

        pointView = findViewById(R.id.point_container);

        layoutWillPoint = findViewById(R.id.layout_will_point);
        willPointTextView = findViewById(R.id.textViewWillPoint);

        layoutAfterPoint = findViewById(R.id.layout_after_point);
        afterPointTextView = findViewById(R.id.textViewAfterPoint);

        progressBar = findViewById(R.id.progressBarCircular);
        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }

        imageViewNoAdDefault = findViewById(R.id.imageViewNoAd);
        if (imageViewNoAdDefault != null) {
            imageViewNoAdDefault.setVisibility(View.GONE);
            imageViewNoAdDefault.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mIBannerAdCallback != null) {
                        mIBannerAdCallback.onAdClicked();
                    }

                    Utils.getBrowserPackageName(mContext, defaultAdUrl, null);
                }
            });
        }


    }
    /**
     * 배너의 상태 정보를 초기화합니다.
     * 콜백 전송 여부 플래그를 false로 설정하고, 포인트 지급 가능 상태를 true로 (UI를 "지급 전"으로) 되돌립니다.
     * 주로 새로운 광고를 로드하기 전에 호출됩니다.
     */
    public void resetInfo() {
        isSendedCallback = false;
        setPointEnable(true);
    }
    /**
     * 광고를 로드해야 할 필요가 있을 경우에만 광고를 로드합니다.
     * 현재 로딩 중이거나 이미 콜백이 전송된 상태(즉, 광고 로드가 한 번 완료된 상태)가 아니면 {@link #loadAd()}를 호출합니다.
     */
    public void loadAdIfNeed() {
        if (isInLoading || isSendedCallback) {
            return;
        }
        loadAd();
    }

    /**
     * 포인트 배너 광고를 로드합니다.
     * 이미 로딩 중인 경우 중복 실행을 방지합니다.
     * 프로그레스바를 표시하고, 내부 {@link MobwithBannerView}를 생성(필요시)하여 광고 로드를 시작합니다.
     * 내부 배너 뷰의 로드 결과에 따라 UI를 업데이트하고, 설정된 콜백 리스너를 통해 결과를 전달합니다.
     */
    public void loadAd() {
        if (isInLoading) {
            return;
        }

        isSendedCallback = false;
        isInLoading = true;

        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }

        if (mBannerView == null) {
            mBannerView = new MobwithBannerView(mContext);
            mBannerView.setBannerUnitId(mScriptNo);
            mBannerView.isPointBanner = true;

            mBannerView.setAdListener(new iBannerCallback() {
                @Override
                public void onLoadedAdInfo(boolean result, String errorStr) {

                    isInLoading = false;
                    isSendedCallback = true;

                    MainThreadHandler.post(() -> {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }

                        if (result && mBannerView.getParent() == null) {
                            mBannerContainer.addView(mBannerView);
                        } else if (!result) {
                            mBannerContainer.removeView(mBannerView);
                        }

                        if (imageViewNoAdDefault != null && mBannerView.getParent() == null) {
                            if (result) {
                                imageViewNoAdDefault.setVisibility(View.GONE);
                                imageViewNoAdDefault.setClickable(false);
                            } else {
                                imageViewNoAdDefault.setVisibility(View.VISIBLE);
                                imageViewNoAdDefault.setClickable(true);
                            }
                        }

                    });


                    if (mIBannerAdCallback != null) {
                        mIBannerAdCallback.onLoadedAdInfo(result, errorStr);
                    }
                }

                @Override
                public void onAdClicked() {
                    if (mIBannerAdCallback != null) {
                        mIBannerAdCallback.onAdClicked();
                    }
                }
            });
        }

        mBannerView.loadAd();
    }

    /**
     * 이 포인트 배너 뷰의 광고 관련 이벤트(로드 성공/실패, 클릭 등)를 수신할 콜백 리스너를 설정합니다.
     * @param pMobonAdCallback {@link iBannerCallback} 구현 객체
     */
    public void setAdListener(iBannerCallback pMobonAdCallback) {
        mIBannerAdCallback = pMobonAdCallback;
    }
    /**
     * 내부 {@link MobwithBannerView}의 광고 활동을 다시 시작합니다.
     * 예를 들어, Activity가 onResume 상태가 될 때 호출될 수 있습니다.
     */
    public void restart() {
        if (mBannerView != null) {
            mBannerView.restart();
        }
    }
    /**
     * 내부 {@link MobwithBannerView}의 광고 활동을 중지합니다.
     * 예를 들어, Activity가 onPause 상태가 될 때 호출될 수 있습니다.
     */
    public void stop() {
        if (mBannerView != null) {
            mBannerView.stop();
        }
    }
    /**
     * 내부 {@link MobwithBannerView}에서 사용된 리소스를 해제합니다.
     * 예를 들어, Activity가 onDestroy 상태가 되거나 뷰가 더 이상 필요 없을 때 호출하여 메모리 누수를 방지합니다.
     * 내부 배너 뷰를 null로 만들어 다음 loadAd 호출 시 새로 생성하도록 유도할 수도 있습니다.
     */
    public void destroyAd() {
        if (mBannerView != null) {
            mBannerView.destroyAd();
        }
    }

    /**
     * 현재 표시된 광고가 여러 개인 경우, 다음 광고를 표시하도록 내부 {@link MobwithBannerView}에 요청합니다.
     */
    public void showNextAd() {
        if (mBannerView != null) {
            mBannerView.showNextAd();
        }
    }


}
