package com.mobwith.sdk;

import static com.mobwith.manager.Utils.setDialogSize;
import static com.mobwith.manager.Utils.setScreenMode;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.mobwith.adapters.VideoAdapter;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.FrameType;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.Random;

import eightbitlab.com.blurview.BlurTarget;
import eightbitlab.com.blurview.BlurView;

//테스트 지면 10892408
class MobwithPresentationVideoView extends FrameLayout implements MWCommonRequestInterface {
    private final Activity activity;
    private final Context mContext;
    private boolean isFull;
    private boolean isSoundPlay = false;
    private final VideoAdapter adapter;
    private FrameLayout adContainer;
    private View btnClose;
    private final MobwithPresentationView.AdPresentationFormat adPresentationFormat;
    private final Key.INTERSTITIAL_TYPE adPresentationSize;
    private long btnDelay;
    private String styleCode;
    private final String closeBtnDisplaySeconds;
    private AdDataResponseModel adDataResponseModel;

    private final Runnable btnVisibleRunnable = new Runnable() {
        @Override
        public void run() {
            if (btnClose != null) {
                Utils.setFadeAnimation(btnClose, this);
            }
        }
    };

    private final OnPresentationVideoViewListener listener;

    interface OnPresentationVideoViewListener {
        void onOpened();
        void onClose();

        void onAdClicked();

        void onImpression(String type, boolean isFull, String styleCode);
    }

    MobwithPresentationVideoView(@NotNull Activity activity, @NotNull VideoAdapter adapter, Key.INTERSTITIAL_TYPE adPresentationSize, String closeBtnDisplaySeconds, MobwithPresentationView.AdPresentationFormat adPresentationFormat, @NotNull OnPresentationVideoViewListener listener) {
        super(activity);
        this.activity = activity;
        this.mContext = activity;
        this.adapter = adapter;
        this.adPresentationFormat = adPresentationFormat;
        this.adPresentationSize = adPresentationSize;
        this.closeBtnDisplaySeconds = closeBtnDisplaySeconds;
        this.listener = listener;
        init();
    }

    public void init() {
        try {
            this.adDataResponseModel = new AdDataResponseModel(new JSONObject(adapter.getAdData().jsonData));
            setBtnVisibleSecond();
            isFull = setScreenMode(adPresentationSize);
            setUi();
            setDialogSize(mContext, activity.getWindow(), isFull);
        } catch (Exception e) {
            e.printStackTrace();
            listener.onClose();
        }
    }

    private void setUi() {
        if (isFull) {
            activity.setContentView(LayoutInflater.from(mContext).inflate(R.layout.banner_interstitial_layout, this, true));
            adContainer = activity.findViewById(R.id.adContainer);
            BlurTarget target = activity.findViewById(R.id.blurTarget);
            BlurView blurView = activity.findViewById(R.id.blurView);
            ImageView ivBackground = activity.findViewById(R.id.ivBackground);

            if (target != null && blurView != null) {
                blurView.setupWith(target)
                        .setBlurRadius(10f);
            }

            if (adapter.getThubnailBitmap() != null) {
                ivBackground.setImageBitmap(adapter.getThubnailBitmap());
            } else {
                ivBackground.setBackgroundColor(Color.WHITE);
            }


            if (adPresentationFormat == MobwithPresentationView.AdPresentationFormat.INTERSTITIAL) {
                int frameType = new Random().nextInt(3);
                if (adapter.getBannerType().equals(BannerType.HORIZONTAL)) {
                    styleCode = FrameType.NORMAL_FULLSCREEN_VIDEO_HORIZONTAL_TEXT;
                    setContent(R.layout.banner_normal_interstitial_video3_horizontal);
                } else {
                    switch (frameType) {
                        case 0:
                            styleCode = FrameType.NORMAL_FULLSCREEN_VIDEO_VERTICAL_FULL;
                            setContent(R.layout.banner_normal_interstitial_video1);
                            break;
                        case 1:
                            styleCode = FrameType.NORMAL_FULLSCREEN_VIDEO_VERTICAL_NON_TEXT;
                            setContent(R.layout.banner_normal_interstitial_video2);
                            break;
                        case 2:
                            styleCode = FrameType.NORMAL_FULLSCREEN_VIDEO_VERTICAL_TEXT;
                            setContent(R.layout.banner_normal_interstitial_video3_vertical);
                            break;
                    }
                }
            } else if (adPresentationFormat == MobwithPresentationView.AdPresentationFormat.REWARD) {
                if (adapter.getBannerType().equals(BannerType.HORIZONTAL)) {
                    styleCode = FrameType.REWARD_FULLSCREEN_VIDEO_HORIZONTAL_FULL;
                    setContent(R.layout.banner_reward_interstitial_video_horizontal);
                } else {
                    styleCode = FrameType.REWARD_FULLSCREEN_VIDEO_VERTICAL_FULL;
                    setContent(R.layout.banner_reward_interstitial_video_vertical);
                }
            }
        } else {
            int frameType = new Random().nextInt(3);
            activity.setContentView(LayoutInflater.from(mContext).inflate(R.layout.banner_modal_layout_large, this, true));
            adContainer = activity.findViewById(R.id.adContainer);

            if (adPresentationFormat == MobwithPresentationView.AdPresentationFormat.INTERSTITIAL) {
                if (adapter.getBannerType().equals(BannerType.HORIZONTAL)) {
                    styleCode = FrameType.NORMAL_MODAL_VIDEO_HORIZONTAL_TEXT;
                    setContent(R.layout.banner_normal_modal_video3_horizontal);
                } else {
                    switch (frameType) {
                        case 0:
                            styleCode = FrameType.NORMAL_MODAL_VIDEO_VERTICAL_FULL;
                            setContent(R.layout.banner_normal_modal_video1);
                            break;
                        case 1:
                            styleCode = FrameType.NORMAL_MODAL_VIDEO_VERTICAL_NON_TEXT;
                            setContent(R.layout.banner_normal_modal_video2);
                            break;
                        case 2:
                            styleCode = FrameType.NORMAL_MODAL_VIDEO_VERTICAL_TEXT;
                            setContent(R.layout.banner_normal_modal_video3_vertical);
                            break;
                    }
                }
            } else if (adPresentationFormat == MobwithPresentationView.AdPresentationFormat.REWARD) {
                if (adapter.getBannerType().equals(BannerType.HORIZONTAL)) {
                    styleCode = FrameType.REWARD_MODAL_VIDEO_HORIZONTAL_FULL;
                    setContent(R.layout.banner_reward_modal_video_horizontal);
                } else {
                    styleCode = FrameType.REWARD_MODAL_VIDEO_VERTICAL_FULL;
                    setContent(R.layout.banner_reward_modal_video_vertical);
                }
            }
        }
    }

    private void setContent(int layoutRes) {
        View view = LayoutInflater.from(mContext).inflate(layoutRes, adContainer, true);

        FrameLayout videoContainer = view.findViewById(R.id.videoContainer);
        ImageView ivSound = view.findViewById(R.id.ivSound);
        btnClose = findViewById(R.id.btnClose);
        View btnDetail = findViewById(R.id.btnDetail);

        btnClose.postDelayed(btnVisibleRunnable, btnDelay);

        adapter.setLoop(true);
        adapter.setMuteMode(true);

        View videoView = (View) adapter.getAdView();
        if (adapter.isLoaded()) {
            adapter.playVideo();
            videoView.setOnClickListener(v -> adClickEvent());
            view.setOnClickListener(v -> adClickEvent());

//            if (videoView.getParent() != null) {
//                ((ViewGroup) videoView.getParent()).removeView(videoView);
//            }

            videoContainer.addView(videoView);

            view.setOnClickListener(v -> adapter.performAdClick());
        }

        btnClose.setOnClickListener(v -> listener.onClose());

        if (btnDetail != null) {
            btnDetail.setOnClickListener(v -> adClickEvent());
        }

        if (ivSound != null) {
            ivSound.setOnClickListener(v -> {
                if (isSoundPlay) {
                    ivSound.setImageResource(R.drawable.mobwith_sound_off);
                    isSoundPlay = false;
                } else {
                    ivSound.setImageResource(R.drawable.mobwith_sound_on);
                    isSoundPlay = true;
                }
                adapter.setVolume(isSoundPlay);
            });
        }
        listener.onOpened();
        listener.onImpression("imp", isFull, styleCode);

        if (adDataResponseModel != null && adDataResponseModel.getData() != null) {
            sendImpressionWith(mContext, adDataResponseModel.getData().getFirstAd().getCustom08(), adDataResponseModel.getData().getImpUrl());
        }
    }

    private void setBtnVisibleSecond() {
        if (!closeBtnDisplaySeconds.isEmpty()) {
            btnDelay = Long.parseLong(closeBtnDisplaySeconds) * 1000;
        } else {
            if (adPresentationFormat == MobwithPresentationView.AdPresentationFormat.REWARD) {
                btnDelay = 15000L;
            } else {
                btnDelay = 2000L;
            }
        }
    }

    private void adClickEvent(){
        if (adapter != null) {
            adapter.performAdClick();
        }
        if (listener != null) {
            listener.onAdClicked();
            listener.onImpression("click", isFull, styleCode);
        }

        if (btnClose != null) {
            if (btnClose.getVisibility() != View.VISIBLE) {
                Utils.setFadeAnimation(btnClose, btnVisibleRunnable);
            }
        }
    }

}
