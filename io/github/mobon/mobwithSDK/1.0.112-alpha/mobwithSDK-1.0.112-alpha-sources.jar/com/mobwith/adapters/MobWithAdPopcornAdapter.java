package com.mobwith.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.widget.FrameLayout;

import com.igaworks.ssp.AdPopcornSSP;
import com.igaworks.ssp.SSPErrorCode;
import com.igaworks.ssp.part.nativead.AdPopcornSSPNativeAdConfig;
import com.igaworks.ssp.part.nativead.AdPopcornSSPNativeAdView;
import com.igaworks.ssp.part.nativead.binder.MediationViewBinder;
import com.igaworks.ssp.part.nativead.listener.INativeAdEventCallbackListener;
import com.igaworks.ssp.part.video.AdPopcornSSPInterstitialVideoAd;
import com.igaworks.ssp.part.video.AdPopcornSSPRewardVideoAd;
import com.igaworks.ssp.part.video.listener.IInterstitialVideoAdEventCallbackListener;
import com.igaworks.ssp.part.video.listener.IRewardVideoAdEventCallbackListener;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.R;
import com.mobwith.sdk.api.MWRequestImpression;
import com.mobwith.sdk.utils.MainThreadHandler;

public class MobWithAdPopcornAdapter extends AdapterObject {
    private final Context mContext;
    private final String mSiteNo;
    private FrameLayout adViewContainer;
    private AdPopcornSSPNativeAdView bannerAd;
    private AdPopcornSSPInterstitialVideoAd interstitialVideoAd;
    private AdPopcornSSPRewardVideoAd rewardVideoAd;
    private AdPopcornSSPNativeAdView nativeAd;
    private MediationAdListener mediationAdListener;
    private static boolean isInitialized = false;

    public MobWithAdPopcornAdapter(Context context, String name, String unitId, String adType, boolean isTestMode, String siteNo) {
        super(name, unitId, adType, null, isTestMode);
        mContext = context;
        this.mSiteNo = siteNo;

        switch (adType) {
            case BannerType.INTERSTITIAL:
                mAdType = MediationAdSize.INTERSTITIAL;
                break;
            case BannerType.BANNER_320x50:
                mAdType = MediationAdSize.BANNER_320_50;
                break;
            case BannerType.BANNER_320x100:
                mAdType = MediationAdSize.BANNER_320_100;
                break;
            case BannerType.BANNER_300x250:
                mAdType = MediationAdSize.BANNER_300_250;
                break;
            case BannerType.REWARD_VIDEO:
                mAdType = MediationAdSize.REWARD_VIDEO;
                break;
        }

        init();
    }

    private void init() {
        MainThreadHandler.post(() -> {
            if (mContext == null) {
                return;
            }

            if (AdPopcornSSP.isInitialized(mContext)) {
                isInitialized = true;
                return;
            }

            AdPopcornSSP.init(mContext, () -> {
                isInitialized = true;
            });
        });
    }


    @Override
    public void setAdListener(MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    @Override
    public void load(String adType) {
        super.load(adType);

        LogPrint.d("load adType : " + adType);

        if (!AdPopcornSSP.isInitialized(mContext)) {
            AdPopcornSSP.init(mContext, () -> {
                        isInitialized = true;
                        dispatchLoad(adType);
                    }
            );
        } else {
            dispatchLoad(adType);
        }
    }

    private void dispatchLoad(String adType) {
        if (TextUtils.equals(adType, BannerType.NATIVE_AD)) {
            loadNativeAd();
        } else if (TextUtils.equals(adType, BannerType.INTERSTITIAL) || TextUtils.equals(adType, BannerType.INTERSTITIAL_POPUP)) {
//            loadInterstitialAd();
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else if (TextUtils.equals(adType, BannerType.REWARD_VIDEO)) {
//            loadRewardedAd();
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else {
            loadBannerAd();
        }
    }

    @Override
    public void destroy() {
//        AdPopcornSSP.destroy();
    }

    @Override
    public boolean isLoaded() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (interstitialVideoAd != null) {
                return interstitialVideoAd.isReady();
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (rewardVideoAd != null) {
                return rewardVideoAd.isReady();
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean show() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            if (interstitialVideoAd != null && interstitialVideoAd.isReady()) {
                interstitialVideoAd.showAd();
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (rewardVideoAd != null && rewardVideoAd.isReady()) {
                rewardVideoAd.showAd();
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private void loadBannerAd() {
        LogPrint.d("loadBannerAd : " + getUnitId());
        bannerAd = new AdPopcornSSPNativeAdView(mContext);
        bannerAd.setPlacementId(getUnitId());
        MediationViewBinder viewBinder = new MediationViewBinder.Builder(R.layout.adpopcon_banner_layout)
                .mediaContainerViewId(R.id.adContainer)    // 공통
                .build();

        AdPopcornSSPNativeAdConfig config = new AdPopcornSSPNativeAdConfig.Builder()
                // 공통 옵션
                .privacyIconVisibility(true)
                .namActivateObservingOnBackground(true)
                .namEnableMediaBackgroundBlur(true)
                .build();

        bannerAd.setNativeAdConfig(config);
        bannerAd.setMediationViewBinder(viewBinder);
        bannerAd.setNativeAdEventCallbackListener(new INativeAdEventCallbackListener() {
            @Override
            public void onNativeAdLoadSuccess() {
                adViewContainer = new FrameLayout(mContext);
                adViewContainer.addView(bannerAd);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                CommonUtils.sendAdSDKImpression(mContext, mSiteNo, getName(), getUnitId(), getExlItlSeq());
            }

            @Override
            public void onNativeAdLoadFailed(SSPErrorCode sspErrorCode) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(sspErrorCode.getErrorCode() + " - " + sspErrorCode.getErrorMessage());
                }
            }

            @Override
            public void onImpression() {

            }

            @Override
            public void onClicked() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onAdHidden() {
            }
        });

        bannerAd.loadAd();
    }

    private void loadInterstitialAd() {
        interstitialVideoAd = new AdPopcornSSPInterstitialVideoAd(mContext);
        interstitialVideoAd.setPlacementId(getUnitId());
        interstitialVideoAd.setEventCallbackListener(new IInterstitialVideoAdEventCallbackListener() {
            @Override
            public void OnInterstitialVideoAdLoaded() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
            }

            @Override
            public void OnInterstitialVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(sspErrorCode.getErrorCode() + " - " + sspErrorCode.getErrorMessage());
                }
            }

            @Override
            public void OnInterstitialVideoAdOpened() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdDisplayed();
                }
            }

            @Override
            public void OnInterstitialVideoAdOpenFalied() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen("AdPopcorn interstitial open failed", getName());
                }
            }

            @Override
            public void OnInterstitialVideoAdClosed() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClosed();
                }
            }

            @Override
            public void OnInterstitialVideoAdClicked() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }
        });

        interstitialVideoAd.loadAd();
    }

    private void loadRewardedAd() {
        rewardVideoAd = new AdPopcornSSPRewardVideoAd(mContext);
        rewardVideoAd.setPlacementId(getUnitId());
        rewardVideoAd.setRewardVideoAdEventCallbackListener(new IRewardVideoAdEventCallbackListener() {
            @Override
            public void OnRewardVideoAdLoaded() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
            }

            @Override
            public void OnRewardVideoAdLoadFailed(SSPErrorCode sspErrorCode) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(sspErrorCode.getErrorCode() + " - " + sspErrorCode.getErrorMessage());
                }
            }

            @Override
            public void OnRewardVideoAdOpened() {

            }

            @Override
            public void OnRewardVideoAdOpenFalied() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen("AdPopcorn rewardAd open failed", getName());
                }
            }

            @Override
            public void OnRewardVideoAdClosed() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClosed();
                }
            }

            @Override
            public void OnRewardVideoPlayCompleted(int i, boolean b) {

            }

            @Override
            public void OnRewardVideoAdClicked() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void OnRewardPlusCompleted(boolean b, int i, int i1) {

            }
        });

        rewardVideoAd.loadAd();
    }

    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    @Override
    public Object getAdView() {
        return adViewContainer;
    }

    @Override
    public void loadNativeAd() {
        nativeAd = new AdPopcornSSPNativeAdView(mContext);
        nativeAd.setPlacementId(getUnitId());

        MediationViewBinder viewBinder = new MediationViewBinder.Builder(mAdViewItem.mViewLayoutID)
                .titleViewId(mAdViewItem.mTitleViewID)                      // 공통
                .bodyViewId(mAdViewItem.mDescViewID)                        // 공통
                .callToActionViewId(mAdViewItem.mGotoSiteViewID)            // 공통
                .iconViewId(mAdViewItem.mADLogoImageViewID)                 // 공통
                .mediaContainerViewId(mAdViewItem.mMediaViewContainerID)    // 공통
                .build();

        nativeAd.setMediationViewBinder(viewBinder);
        nativeAd.setNativeAdEventCallbackListener(new INativeAdEventCallbackListener() {
            @Override
            public void onNativeAdLoadSuccess() {
                LogPrint.d("onNativeAdLoadSuccess");
                adViewContainer = new FrameLayout(mContext);
                adViewContainer.addView(nativeAd);
                mAdViewItem.mContainerView.removeAllViews();
                mAdViewItem.mContainerView.addView(adViewContainer);
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                CommonUtils.sendAdSDKImpression(mContext, mSiteNo, getName(), getUnitId(), getExlItlSeq());
            }

            @Override
            public void onNativeAdLoadFailed(SSPErrorCode sspErrorCode) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(sspErrorCode.getErrorCode() + " - " + sspErrorCode.getErrorMessage());
                }
            }

            @Override
            public void onImpression() {

            }

            @Override
            public void onClicked() {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onAdHidden() {
            }
        });

        nativeAd.loadAd();
    }

    public void performClickForBannerView() {
        try {
            if (bannerAd != null && bannerAd.isLoaded()) {
                if (bannerAd.getChildCount() > 0) {
                    if (bannerAd.getChildAt(0) != null) {
                        bannerAd.getChildAt(0).performClick();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
