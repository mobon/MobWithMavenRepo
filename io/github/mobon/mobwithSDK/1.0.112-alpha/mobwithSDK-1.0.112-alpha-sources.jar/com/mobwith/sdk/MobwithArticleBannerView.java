package com.mobwith.sdk;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mobwith.MobwithSDK;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.api.MWRequestArticle;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.callback.iArticleBannerCallback;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.MobwithArticleModel;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONObject;

import java.io.IOException;

public class MobwithArticleBannerView extends RelativeLayout {

    private final Context mContext;
    private iArticleBannerCallback articleCallback = null;
    private TextView aritcleTitle;
    private String mArticleUnitID = "";
    private MobwithArticleModel articleModel;
    private AdDataModel adDataModel;
    private boolean isInLoad = false;

    /**
     * 뉴스피드를 표시하는 배너를 생성한다.
     *
     * 기사가 표시될 화면 영역의 높이는 30dp에 맞게 구현되어 있습니다.
     * 따라서, MobwithBannerWithArticleView 표시될 지면의 사이즈를 30dp보다 작게 설정하는 경우 화면에 UI가 제대로 표시되지 않을 수 있습니다.
     */
    public MobwithArticleBannerView(Context context) {
        super(context);
        this.mContext = context;
        isInLoad = false;
        onInit();
    }

    public MobwithArticleBannerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        isInLoad = false;
        onInit();
    }

    public MobwithArticleBannerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        isInLoad = false;
        onInit();
    }

    /**
     * 뉴스피드 unitID 설정
     *
     * @param articleUnitID 발급 받은 뉴스피드 unitID
     */
    public MobwithArticleBannerView setArticleUnitID(String articleUnitID) {
        try {
            mArticleUnitID = articleUnitID;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public MobwithArticleBannerView setAdListener(iArticleBannerCallback callback) {
        articleCallback = callback;
        return this;
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        LogPrint.d("onWindowVisibilityChanged(MobwithBannerWithArticleView) : " + visibility);

        super.onWindowVisibilityChanged(visibility);
    }

    private void onInit() {
        if(mContext == null) {
            return ;
        }

        setGravity(Gravity.CENTER_HORIZONTAL);
        MobwithSDK.initSDK(mContext);

        inflate(mContext, R.layout.banner_article_layout, this);

        aritcleTitle = findViewById(R.id.mobon_sdk_article_title);

        this.setOnClickListener(view -> {
            if (articleCallback != null) {
                articleCallback.onArticleClicked();
            }

            if (articleModel != null) {
                Utils.getBrowserPackageName(mContext, articleModel.linkUrl, null);
            }

            try {
                if (adDataModel != null) {
                    CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
                }
            } catch (Exception e){
                e.printStackTrace();
            }
        });
    }


    public void loadAd() {
        loadArticle();
    }


    void loadArticle() {
        if (isInLoad) {
            return ;
        }
        isInLoad = true;

        MWRequestArticle requestArticle = new MWRequestArticle(mContext, mArticleUnitID);
        requestArticle.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) {
                MainThreadHandler.post(() -> {

                    try {

                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject data = jsonObject.optJSONObject("data");

                        if (data == null) {
                            sendErrorCallbackForArticle("기사 정보를 가져오는데 실패했습니다.");
                            isInLoad = false;
                            return ;
                        }

                        articleModel = new MobwithArticleModel(data);
                        aritcleTitle.setText(articleModel.title);

                        if (articleCallback != null) {
                            try {
                                articleCallback.onLoadedArticles(true, null);
                                JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);
                                adDataModel = new AdDataModel(adData);
                                CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
                            } catch (Exception e){
                                LogPrint.d(e.getMessage());
                            }
                        }
                    }
                    catch(Exception e) {
                        sendErrorCallbackForArticle(e.getLocalizedMessage());
                    }

                    isInLoad = false;
                });
            }

            @Override
            public void onFailure(IOException e) {
                MainThreadHandler.post(() -> {
                    sendErrorCallbackForArticle(e.getLocalizedMessage());
                });

                isInLoad = false;
            }
        });

    }


    private void sendErrorCallbackForArticle(String errMessage) {
        if (articleCallback != null) {
            articleCallback.onLoadedArticles(false, errMessage);
        }
    }


}
