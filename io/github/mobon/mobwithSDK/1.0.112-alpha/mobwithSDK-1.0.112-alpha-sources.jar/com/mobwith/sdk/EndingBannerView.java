package com.mobwith.sdk;

import static com.mobwith.sdk.Key.EX_ID_PREFIX_MOBWADS;
import static com.mobwith.sdk.Key.EX_ID_PREFIX_MOBWITHAD;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.JsonAdapter;
import com.mobwith.adapters.MobWithAdPopcornAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.Utils;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class EndingBannerView extends RelativeLayout implements MWCommonRequestInterface {

    private String mUnitId;
    private String mSessionId = "";
    private String mAdvrtsPrdtCode = "";
    private String mExlItlMemo = "";
    private String mIsParallel = "";
    private String mAdType = "";
    private String mAdBname = "";

    private AdapterObject mBannerAdapter;
    private iBannerCallback mBannerCallback;
    private MediationManager mediationManager;
    private List<String> categories;
    private List<String> campaignCodes;

    private final AtomicBoolean isInLoading = new AtomicBoolean(false);
    private boolean sendSuccessCallback;
    private boolean sendFailCallback;

    public EndingBannerView(Context context) {
        super(context);
        setGravity(Gravity.CENTER);
        MobwithSDK.initSDK(context);
    }

    // ──────────────────────────────────────────────────────────────────────
    // Public API
    // ──────────────────────────────────────────────────────────────────────

    public EndingBannerView setBannerUnitId(String unitId) {
        this.mUnitId = unitId;
        return this;
    }

    public EndingBannerView setCategory(List<String> categories) {
        this.categories = categories;
        return this;
    }

    public EndingBannerView setCampaignCodes(List<String> campaignCodes) {
        this.campaignCodes = campaignCodes;
        return this;
    }

    public EndingBannerView setListener(iBannerCallback listener) {
        this.mBannerCallback = listener;
        return this;
    }

    public void loadAd() {
        if (!isInLoading.compareAndSet(false, true)) {
            return;
        }

        if (!Utils.isConnectNetwork(getContext())) {
            dispatchFail("noConnectNetwork");
            return;
        }

        mSessionId = "";
        sendSuccessCallback = false;
        sendFailCallback = false;

        new MWRequestSortList(getContext(), mUnitId).execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));

                    if (!sortList.isSuccess()) {
                        dispatchFail(Key.NOFILL);
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    mAdvrtsPrdtCode = sortList.advrtsPrdtCode;
                    mExlItlMemo = sortList.exlItlMemo;
                    mAdBname = sortList.adBname;
                    mIsParallel = sortList.isParallel;

                    sendSortListImpression(getContext(), mUnitId, mAdvrtsPrdtCode, mSessionId);
                    mediationManager = new MediationManager(getContext(), sortList.data, BannerType.ENDING_BANNER, null, campaignCodes, categories);
                    mediationManager.LoadMediation(mediationCallback);

                } catch (Exception e) {
                    dispatchFail(e.getLocalizedMessage());
                }
            }

            @Override
            public void onFailure(IOException e) {
                dispatchFail(e.getLocalizedMessage());
            }
        });
    }

    public void destroy() {
        try {
            if (mBannerAdapter != null) {
                mBannerAdapter.destroy();
                mBannerAdapter = null;
            }
            mBannerCallback = null;
            removeAllViews();
        } catch (Exception ignored) {
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // 미디에이션 콜백
    // ──────────────────────────────────────────────────────────────────────

    private final iMobonMediationCallback mediationCallback = new iMobonMediationCallback() {

        @Override
        public void onAdAdapter(AdapterObject adapter) {
            if (adapter == null) {
                dispatchFail(Key.NOFILL);
                return;
            }
            MainThreadHandler.post(() -> {
                if (mBannerAdapter != null) {
                    mBannerAdapter.destroy();
                }
                prepareAd(adapter);
            });
        }

        @Override
        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
            if (adapter != null) adapter.destroy();
            dispatchFail(errorMsg);
        }

        @Override
        public void onAdFailedAdapterName(AdapterObject adapter) {
            sendPassBackImpression(getContext(), mSessionId, mUnitId, mAdvrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdRequest(AdapterObject adapter) {
            sendDspImpression(getContext(), mSessionId, mUnitId, mAdvrtsPrdtCode,
                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
        }

        @Override
        public void onAdClicked() {
            if (mBannerCallback != null) mBannerCallback.onAdClicked();
        }

        @Override
        public void onLoadedAdData(String data, AdapterObject adapter) {
        }

        @Override
        public void onAdClosed() {
        }

        @Override
        public void onAdCancel() {
        }

        @Override
        public void onAdImpression() {
        }

        @Override
        public void onAppFinish() {
        }

        @Override
        public void onAdDisplayed() {
        }

        @Override
        public void onAdComplete() {
        }

        @Override
        public void onAdSkip() {
        }

        @Override
        public void onAdFailedToOpen() {
        }
    };

    // ──────────────────────────────────────────────────────────────────────
    // UI 구성
    // ──────────────────────────────────────────────────────────────────────
    private void prepareAd(AdapterObject adapterObject) {
        if (!checkJsonAd(adapterObject)) {
            LogPrint.d("checkJsonAd false");
            dispatchFail(Key.NOFILL);
            return;
        }

        if (mBannerAdapter instanceof VideoAdapter) {
            VideoAdapter videoAdapter = (VideoAdapter) mBannerAdapter;
            videoAdapter.setOnVideoListener(isReady -> {
                if (!isReady) {
                    dispatchFail(Key.NOFILL);
                    return;
                }
                renderAdView();
            });
        } else if (mBannerAdapter instanceof MobWithAdPopcornAdapter) {
            try {
                removeAllViews();
                MobWithAdPopcornAdapter adPopcornAdapter = (MobWithAdPopcornAdapter) mBannerAdapter;
                if (adPopcornAdapter.getAdView() != null) {
                    View adView = (View) adPopcornAdapter.getAdView();
                    adView.setOnClickListener(v -> {
                        if (mBannerCallback != null) mBannerCallback.onAdClicked();
                    });
                    addView(adView);
                    dispatchSuccess();
                }
            } catch (Exception e) {
                dispatchFail(e.getMessage());
            }
        } else if (mBannerAdapter instanceof JsonAdapter) {
            // JsonAdapter 등 즉시 표시 가능한 경우
            renderAdView();
        } else {
            try {
                removeAllViews();
                View adView = (View) mBannerAdapter.getAdView();
                if (adView == null) {
                    dispatchFail(Key.NOFILL);
                    return;
                }

                addView(adView);
                dispatchSuccess();
            } catch (Exception e) {
                dispatchFail(Key.NOFILL);
            }
        }
    }

    private void renderAdView() {
        try {
            removeAllViews();

            if (mBannerAdapter == null) {
                dispatchFail(Key.NOFILL);
                return;
            }

            try {

                LogPrint.d("data : " + mBannerAdapter.getAdData());

                View view = LayoutInflater.from(getContext()).inflate(R.layout.banner_ending_view, (ViewGroup) getParent(), false);
                FrameLayout mediaContainerView = view.findViewById(R.id.mediaContainerView);
                LinearLayout layoutText = view.findViewById(R.id.layoutText);
                ImageView imgThumbnail = view.findViewById(R.id.imgThumbnail);
                TextView tvTitle = view.findViewById(R.id.tvTitle);
                TextView tvDesc = view.findViewById(R.id.tvDesc);

                if (getParent() != null) {
                    ((ViewGroup) getParent()).removeView(this);
                }

                if (mBannerAdapter instanceof JsonAdapter) {
                    if (mBannerAdapter.getAdData() != null) {
                        AdDataResponseModel model = new AdDataResponseModel(new JSONObject(mBannerAdapter.getAdData().jsonData));

                        ImageModule.with(getContext())
                                .load(model.getData().getFirstAd().getpImg())
                                .fitCenter()
                                .into(imgThumbnail);
                        imgThumbnail.setVisibility(VISIBLE);

                        if (mBannerAdapter.getAdData().exid.startsWith(EX_ID_PREFIX_MOBWADS) || mBannerAdapter.getAdData().exid.startsWith(EX_ID_PREFIX_MOBWITHAD)) {
                            //직광고
                            layoutText.setVisibility(GONE);
                        } else {
                            if (!model.getData().getFirstAd().getpNm().isEmpty()) {
                                tvTitle.setText(model.getData().getFirstAd().getpNm());
                            } else {
                                tvTitle.setText(model.getData().getFirstAd().getaTitle());
                            }

                            if (!model.getData().getFirstAd().getpCode().isEmpty()) {
                                //상품
                                if (!model.getData().getFirstAd().getpDcPrice().isEmpty()) {
                                    tvDesc.setText(model.getData().getFirstAd().getDcPrice());
                                } else {
                                    tvDesc.setText(model.getData().getFirstAd().getPrice());
                                }
                            } else {
                                //비상품
                                if (!model.getData().getFirstAd().getDesc().isEmpty()) {
                                    tvDesc.setText(model.getData().getFirstAd().getDesc());
                                } else if (!model.getData().getFirstAd().getDescWeb().isEmpty()) {
                                    tvDesc.setText(model.getData().getFirstAd().getDescWeb());
                                } else if (!model.getData().getFirstAd().getaDesc1().isEmpty()) {
                                    tvDesc.setText(model.getData().getFirstAd().getaDesc1());
                                }
                            }
                        }

                        view.setOnClickListener(v -> {
                            LogPrint.d("배너 클릭...");
                            Utils.getBrowserPackageName(getContext(), model.getData().getFirstAd().getpUrl(), mBannerCallback);
                            if (mBannerCallback != null) mBannerCallback.onAdClicked();
                            CommonUtils.sendClickTrackersEvent(getContext(), model.getData().getFirstAd());
                        });

                        CommonUtils.sendImpressTrackersEvent(getContext(), model.getData().getFirstAd());
                    } else {
                        dispatchFail(Key.NOFILL);
                        return;
                    }
                } else if (mBannerAdapter instanceof VideoAdapter) {
                    VideoAdapter videoAdapter = (VideoAdapter) mBannerAdapter;
                    View videoView = (View) mBannerAdapter.getAdView();

                    if (mediaContainerView == null || videoView == null) {
                        dispatchFail(Key.NOFILL);
                        return;
                    }
                    videoAdapter.playVideo();
                    mediaContainerView.addView(videoView);
                } else {
                    dispatchFail(Key.NOFILL);
                    return;
                }

                LayoutParams params = new LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT);
                params.addRule(RelativeLayout.CENTER_IN_PARENT);
                addView(view, params);

                if (mBannerAdapter.getAdData() != null && !mBannerAdapter.getAdData().jsonData.isEmpty()) {
                    AdDataResponseModel model = new AdDataResponseModel(new JSONObject(mBannerAdapter.getAdData().jsonData));
                    if (model.getData() != null) {
                        sendImpressionWith(getContext(), model.getData().getFirstAd().getCustom08(), model.getData().getImpUrl());
                    }
                }

                dispatchSuccess();
            } catch (Exception e) {
                dispatchFail(e.getLocalizedMessage());
            }
        } catch (Exception e) {
            dispatchFail(e.getLocalizedMessage());
        }
    }

    public void performAdClick() {
        try {
            if (mBannerAdapter instanceof JsonAdapter) {
                if (mBannerAdapter.getAdData() != null) {
                    AdDataResponseModel model = new AdDataResponseModel(new JSONObject(mBannerAdapter.getAdData().jsonData));

                    Utils.getBrowserPackageName(getContext(), model.getData().getFirstAd().getpUrl(), mBannerCallback);
                    if (mBannerCallback != null) mBannerCallback.onAdClicked();
                    CommonUtils.sendClickTrackersEvent(getContext(), model.getData().getFirstAd());
                } else {
                    LogPrint.d("failed performAdClicked");
                }
            } else if (mBannerAdapter instanceof VideoAdapter) {
                VideoAdapter videoAdapter = (VideoAdapter) mBannerAdapter;
                View videoView = (View) mBannerAdapter.getAdView();

                if (videoView == null) {
                    LogPrint.d("failed performAdClicked");
                    return;
                }

                videoAdapter.performAdClick();
            } else if (mBannerAdapter instanceof MobWithAdPopcornAdapter) {
                try {
                    MobWithAdPopcornAdapter adPopcornAdapter = (MobWithAdPopcornAdapter) mBannerAdapter;
                    if (adPopcornAdapter.getAdView() != null) {
                        adPopcornAdapter.performClickForBannerView();
                    } else {
                        LogPrint.d("failed performAdClicked");
                    }
                } catch (Exception e) {
                    LogPrint.d("failed performAdClicked");
                }
            } else {
                LogPrint.d("failed performAdClicked");
            }
        } catch (Exception e) {
            LogPrint.d("failed performAdClicked");
        }
    }

    private boolean checkJsonAd(AdapterObject adapter) {
        try {
            if (adapter instanceof JsonAdapter) {
                String useParallel = String.valueOf(((JsonAdapter) adapter).useParallel);
                JSONObject jsonData = new JSONObject(adapter.getAdData().jsonData);
                JSONArray adData = jsonData.optJSONObject("data").optJSONArray("data");
                if (adData != null && adData.length() > 0) {
                    String videoAd = adData.getJSONObject(0).optString("videoAd");
                    String custom10 = adData.getJSONObject(0).optString("custom10");
                    if (!videoAd.isEmpty() || !custom10.isEmpty()) {
                        VideoAdapter v = new VideoAdapter(
                                getContext(), adapter.getName(), adapter.getUnitId(),
                                mExlItlMemo, mAdType, adapter.getAdData(),
                                false, mUnitId, useParallel, mAdBname);
                        if (!videoAd.isEmpty()) {
                            v.initVideoAd(videoAd, adData.getJSONObject(0).optString("pUrl"), null);
                        } else {
                            v.initVastVideo(custom10, null);
                        }
                        mBannerAdapter = v;
                    } else {
                        mBannerAdapter = adapter;
                    }
                } else {
                    mBannerAdapter = adapter;
                }
            } else {
                mBannerAdapter = adapter;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // 콜백 디스패치
    // ──────────────────────────────────────────────────────────────────────

    private void dispatchSuccess() {
        MainThreadHandler.post(() -> {
            try {
                isInLoading.set(false);
                if (sendSuccessCallback) return;
                sendSuccessCallback = true;
                if (mBannerCallback != null) {
                    mBannerCallback.onLoadedAdInfo(true, "");
                }
            } catch (Exception e) {
                if (mBannerCallback != null) {
                    mBannerCallback.onLoadedAdInfo(true, e.getMessage());
                }
            }
        });
    }

    private void dispatchFail(String message) {
        MainThreadHandler.post(() -> {
            try {
                isInLoading.set(false);
                if (sendFailCallback) return;
                sendFailCallback = true;
                sendSuccessCallback = true;
                if (mBannerCallback != null) {
                    mBannerCallback.onLoadedAdInfo(false, message);
                }
            } catch (Exception e) {
                if (mBannerCallback != null) {
                    mBannerCallback.onLoadedAdInfo(false, message);
                }
            }
        });
    }
}