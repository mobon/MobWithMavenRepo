package com.mobwith.manager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.mobwith.sdk.Key;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

public class SpManager {
    public static final String KEY_APP_STATE_FLAG = "SpManager.KEY_APP_STATE_FLAG";
    public static final int KEY_APP_STATE_START = 0;
    public static final int KEY_APP_STATE_DESTROY = 1;

    private static final String PREFNAME_FOR_SDK = "mobwith_sdk_preferences";
    private static final String UUID_SEP_VALUE = "##";


    public static String getString(Context context, String key) {
        try {
            SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
            return sp.getString(key, "");

        } catch (Exception e) {
            return "";
        }
    }

    public static int getInteger(Context context, String key) {
        try {
            SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
            return sp.getInt(key, 0);
        } catch (Exception e) {
            return 0;
        }
    }

    public static float getFloat(Context context) {
        try {
            SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
            return sp.getFloat(Key.ENDING_POPPUP_DIM_ALPHA, -1f);
        } catch (Exception e) {
            return -1f;
        }
    }

    public static boolean getBoolean(Context context, String key) {
        try {
            SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
            return sp.getBoolean(key, false);
        } catch (Exception e) {
            return false;
        }

    }


    public static void setLong(Context context, String key, long value) {
        SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putLong(key, value);
        disSetEditor.commit();
    }


    public static void setString(Context context, String key, String value) {
        SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putString(key, value);
        disSetEditor.commit();
    }

    public static void setString(Context context, String packageName, String key, String value) {
        SharedPreferences sp = context.getSharedPreferences(packageName, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putString(key, value);
        disSetEditor.commit();
    }

    public static long getLong(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
        return sp.getLong(key, 0);
    }

    public static void setString(Context context, String key, int value) {
        SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putString(key, String.valueOf(value));
        disSetEditor.commit();
    }

    public static void setString(Context context, String packageName, String key, int value) {
        SharedPreferences sp = context.getSharedPreferences(packageName, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putString(key, String.valueOf(value));
        disSetEditor.commit();
    }

    public static void setInteger(Context context, String key, int value) {
        SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putInt(key, value);
        disSetEditor.commit();
    }

    public static void setInteger(Context context, String packageName, String key, int value) {
        SharedPreferences sp = context.getSharedPreferences(packageName, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putInt(key, value);
        disSetEditor.commit();
    }

    public static void setFloat(Context context, String packageName, float value) {
        SharedPreferences sp = context.getSharedPreferences(packageName, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putFloat(com.mobwith.sdk.Key.ENDING_POPPUP_DIM_ALPHA, value);
        disSetEditor.commit();
    }

    public static void setBoolean(Context context, String key, boolean value) {
        SharedPreferences sp = context.getSharedPreferences(context.getPackageName(), Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putBoolean(key, value);
        disSetEditor.commit();
    }

    public static void setBoolean(Context context, String packageName, String key, boolean value) {
        SharedPreferences sp = context.getSharedPreferences(packageName, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putBoolean(key, value);
        disSetEditor.commit();
    }




    public static void setFreePassViewClickedTime(Context context, long clickTimeMills) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putLong(Key.FREE_PASS_VIEW_CLICKED_TIME, clickTimeMills);
        disSetEditor.commit();
    }


    public static Date getFreePassViewClickedTime(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        long clickTimeMills = sp.getLong(Key.FREE_PASS_VIEW_CLICKED_TIME, 0);

        if (clickTimeMills > 0) {
            return new Date(clickTimeMills);
        }
        else {
            return null;
        }
    }


    public static void setPointBannerRefreshedTime(Context context, long timeMills) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putLong(Key.MULTI_POINT_BANNER_REFRESHED_TIME, timeMills);
        disSetEditor.commit();
    }

    public static long getPointBannerRefreshedTime(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        return sp.getLong(Key.MULTI_POINT_BANNER_REFRESHED_TIME, 0);
    }

    public static void setPointBannerIntervalTime(Context context, long timeMills) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putLong(Key.MULTI_POINT_BANNER_INTERVAL_TIME, timeMills);
        disSetEditor.commit();
    }

    public static long getPointBannerIntervalTime(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        return sp.getLong(Key.MULTI_POINT_BANNER_INTERVAL_TIME, 60 * 60 * 1000);        // 기본값 60분
    }


    public static void setPointBannerStatus(Context context, boolean[] status) {
        long boolToLong = 0L;
        for (int i = 0; i < status.length && i < 64; i++) {
            if (status[i]) {
                boolToLong |= (1L << i);  // true일 경우 해당 비트 위치에 1을 설정
            }
        }

        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putLong(Key.MULTI_POINT_BANNER_STATUS, boolToLong);
        disSetEditor.commit();
    }

    public static boolean[] getPointBannerStatus(Context context, int size) {

        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        long value = sp.getLong(Key.MULTI_POINT_BANNER_STATUS, 0);

        boolean[] boolArray = new boolean[size];
        for (int i = 0; i < size && i < 64; i++) {
            boolArray[i] = (value & (1L << i)) != 0;  // i번째 비트가 1이면 true, 0이면 false
        }

        return boolArray;
    }


    public static void setPointBridgeInBackgroundTime(Context context, long timeMills) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor disSetEditor = sp.edit();
        disSetEditor.putLong(Key.POINT_BRIDGE_IN_BACKGROUND_TIME, timeMills);
        disSetEditor.commit();
    }

    public static long getPointBridgeInBackgroundTime(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        return sp.getLong(Key.POINT_BRIDGE_IN_BACKGROUND_TIME, 0);
    }


    public static String getPointBridgeBannerUUID(Context context, int index) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);

        long timeInterval = getPointBannerIntervalTime(context);

        String currentDate = getCurrentDate();
        long currentRoundedTime = getRoundedTimeToInterval(System.currentTimeMillis(), timeInterval);

        String updatedDate = sp.getString(Key.POINT_BRIDGE_UUID_UPDATED_DATE, "");
        long updatedTime = sp.getLong(Key.POINT_BRIDGE_UUID_UPDATED_TIME, 0);


        Set<String> uuidSet = sp.getStringSet(Key.POINT_BRIDGE_UUIDS, null);

        LogPrint.d("uuid curDate : " + currentDate);
        LogPrint.d("uuid updateDAte : " + updatedDate);
        LogPrint.d("uuid curTime : " + currentRoundedTime);
        LogPrint.d("uuid updateTime : " + updatedTime);
        LogPrint.d("uuidSet : " + uuidSet);



        if ((uuidSet == null) ||
                updatedDate.compareTo(currentDate) != 0 ||
                updatedTime != currentRoundedTime) {
            // UUID 갱신 기준에 부합하므로 새로운 UUID 생성

            Set<String> newSet = new HashSet<>();

            // 최소 5개 이상의 UUID를 생성하도록 한다.  (슬롯 갯수 기본값이 5개이므로)
            int createCount = index < 5 ? 5 : index + 1;

            for (int i = 0; i < createCount; i++) {
                newSet.add(i + UUID_SEP_VALUE + UUID.randomUUID().toString());
            }

            updatePointBridgeBannerUUID(context, newSet);
            uuidSet = newSet;

            updatePointBridgeUUIDUpdatedTime(context, timeInterval);
        }

        LogPrint.d("uuidSet : " + uuidSet);


        if (uuidSet.size() > index) {
            Iterator<String> iterator = uuidSet.iterator();
            while (iterator.hasNext()) {
                String uuid = iterator.next();

                String[] split = uuid.split(UUID_SEP_VALUE);

                if (split.length == 2 && Integer.parseInt(split[0]) == index) {
                    return split[1];
                }
            }

            // 해당 index에 UUID가 없으면 새로운 UUID 생성
            String newUUID = UUID.randomUUID().toString();
            Set<String> mutableSet = new HashSet<>(uuidSet);
            mutableSet.add(index + UUID_SEP_VALUE + newUUID);

            // UUID 값 저장.  시간 갱신은 여기에서는 하지 않는다.
            updatePointBridgeBannerUUID(context, uuidSet);

            return newUUID;
        }





        return "";
    }



    private static long getRoundedTimeToInterval(long currentTimeMillis, long intervalTime) {
        // intervalTime은 millisecond 값.
        // 현재 시간을 interval 단위로 내림하여 기준 값 계산
        return (currentTimeMillis / intervalTime) * intervalTime;
    }

    private static String getCurrentDate() {
        // 현재 날짜를 "yyyy-MM-dd" 형식으로 반환
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(new Date());
    }


    @SuppressLint("SimpleDateFormat")
    public static void updatePointBridgeUUIDUpdatedTime(Context context, long intervalTime) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        // 현재 날짜와 시간을 계산
        String currentDate = getCurrentDate();
        long currentRoundedTime = getRoundedTimeToInterval(System.currentTimeMillis(), intervalTime);

        // 저장
        editor.putString(Key.POINT_BRIDGE_UUID_UPDATED_DATE, currentDate); // 날짜 저장
        editor.putLong(Key.POINT_BRIDGE_UUID_UPDATED_TIME, currentRoundedTime); // 30분 단위 시간 저장
        editor.commit();
    }


    public static void updatePointBridgeBannerUUID(Context context, Set<String> set) {
        SharedPreferences sp = context.getSharedPreferences(PREFNAME_FOR_SDK, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putStringSet(Key.POINT_BRIDGE_UUIDS, set);
        editor.commit();
    }

}
