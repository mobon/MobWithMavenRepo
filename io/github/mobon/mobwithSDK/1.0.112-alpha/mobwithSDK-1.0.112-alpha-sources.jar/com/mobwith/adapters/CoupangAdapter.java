package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleOwner;

import com.coupang.ads.AdsContext;
import com.coupang.ads.AdsException;
import com.coupang.ads.config.AdsCreativeSize;
import com.coupang.ads.config.AdsMode;
import com.coupang.ads.config.AdsViewType;
import com.coupang.ads.custom.AdsNativeView;
import com.coupang.ads.custom.AdsPlacementLayout;
import com.coupang.ads.custom.AdsProductLayout;
import com.coupang.ads.interstitial.AdsInterstitial;
import com.coupang.ads.interstitial.AdsInterstitialListener;
import com.coupang.ads.view.banner.AdsBannerView;
import com.coupang.ads.viewmodels.AdsRequest;
import com.coupang.ads.viewmodels.AdsViewModel;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.R;


public class CoupangAdapter extends AdapterObject {

    private final Context mContext;
    private final String mUnitId;
    private final String mScriptNo;

    private MediationAdListener mediationAdListener;


    private AdsViewModel adsViewModel;
    private AdsBannerView mAdView = null;
    private AdsInterstitial adsInterstitial = null;

    private boolean isRewardAd = false;
    private boolean isRewardAdLoaded = false;


    public CoupangAdapter(final Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mUnitId = unitId;
        mContext = context;
        mScriptNo = siteNo;

        if (AdType.equals(BannerType.INTERSTITIAL)) {
            mAdType = MediationAdSize.INTERSTITIAL;
        } else if (AdType.equals(BannerType.BANNER_320x50)) {
            mAdType = MediationAdSize.BANNER_320_50;
        } else if (AdType.equals(BannerType.BANNER_320x100)) {
            mAdType = MediationAdSize.BANNER_320_50;
        } else if (AdType.equals(BannerType.BANNER_300x250)) {
            mAdType = MediationAdSize.BANNER_300_250;
        }

        if (AdType.equals(BannerType.REWARD_VIDEO)) {
            isRewardAd = true;
            isRewardAdLoaded = false;
        }

    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }


    public void load(String type) {
        super.load(type);

        if (TextUtils.equals(type, BannerType.NATIVE_AD) || TextUtils.equals(type, BannerType.REWARD_VIDEO)) {
            loadNativeAd();
        } else if (TextUtils.equals(type, BannerType.INTERSTITIAL) || TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP)) {
            adsViewModel = new AdsViewModel(new AdsRequest(
                    mUnitId,
                    AdsCreativeSize.INTERSTITIAL,
                    AdsMode.AUTO,
                    "mobwithsdk_interstitial",
                    "mobwithsdk_interstitial",
                    "mobwithsdk_interstitial"
            ));

            adsViewModel.observeJava((LifecycleOwner) mContext, result -> {
                if (result != null && result.isSuccess()) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                } else {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다.");
                    }
                }
            });

            adsInterstitial = new AdsInterstitial();
            adsInterstitial.setListener(new AdsInterstitialListener() {
                @Override
                public boolean onClick(@NonNull AdsViewType adsViewType) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                    return false;
                }

                @Override
                public void onAdFailedToShow(@NonNull AdsException e) {
                    mediationAdListener.onAdFailedToLoad(e.getLocalizedMessage());
                }

                @Override
                public void onAdShowed() {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onAdDismissed() {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClosed();
                    }
                }
            });

            adsInterstitial.bindViewModel(adsViewModel);
            adsViewModel.loadAdData();
        } else if (TextUtils.equals(type, BannerType.ENDING)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else {
            AdsCreativeSize adSize = AdsCreativeSize._320x50;
            if (TextUtils.equals(type, BannerType.BANNER_300x250)) {
                adSize = AdsCreativeSize._300x250;
            } else if (TextUtils.equals(type, BannerType.BANNER_320x100)) {
                adSize = AdsCreativeSize._320x100;
            } else {
                adSize = AdsCreativeSize._320x50;
            }

            mAdView = new AdsBannerView(mContext);
            mAdView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            adsViewModel = new AdsViewModel(new AdsRequest(
                    mUnitId,
                    adSize,
                    AdsMode.AUTO,
                    "mobwithsdk_banner",
                    "mobwithsdk_banner",
                    "mobwithsdk_banner"
            ));

            adsViewModel.observeJava((LifecycleOwner) mContext, result -> {
                if (result != null && result.isSuccess()) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                } else {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("광고 로딩을 실패하였습니다. \n" + (result != null ? result.toString() : "result is null"));
                    }
                }
            });

            mAdView.bindViewModel((LifecycleOwner) mContext, adsViewModel);

            adsViewModel.loadAdData();

        }

//        sendImpression();
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        if (adsInterstitial != null) {
            adsInterstitial.showAds(activity);
            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            return true;
        }

        return false;
    }

    @Override
    public boolean show() {
        if (adsInterstitial != null && (mContext instanceof Activity)) {
            adsInterstitial.showAds(mContext);
            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            return true;
        }

        return false;
    }

    @Override
    public boolean isLoaded() {
        if (isRewardAd) {
            return isRewardAdLoaded;
        } else {
            return adsInterstitial != null && adsInterstitial.isAvailable();
        }
    }

    @Override
    public void destroy() {
        super.destroy();

        try {
            adsViewModel = null;
            mAdView = null;

            adsInterstitial.setListener(null);
            adsInterstitial = null;
        } catch (Exception e) {
            LogPrint.d("[CoupangAdapter] " + e.getLocalizedMessage());
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public Object getAdView() {
//        return mMainLayout;
        return mAdView;
    }


    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    @Override
    public void loadNativeAd() {
        AdsNativeView adsNativeView = makeNativeAdView();

        adsViewModel = new AdsViewModel(new AdsRequest(
                mUnitId,
                AdsCreativeSize.NATIVE,
                AdsMode.AUTO,
                "mobwithsdk_native_adview",
                "mobwithsdk_native_adview",
                AdsContext.Companion.generateAnonId()
        ));


        adsViewModel.observeJava((LifecycleOwner) mContext, result -> {
            if (result != null && result.isSuccess()) {
                if (isRewardAd) {
                    isRewardAdLoaded = true;
                }
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            } else {
                LogPrint.d("[CoupangAdapter] " + (result != null ? result.toString() : "result is null"));
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다.");
                }
            }

        });

        adsNativeView.bindViewModel((LifecycleOwner) mContext, adsViewModel);

        adsViewModel.loadAdData();
    }


    private AdsNativeView makeNativeAdView() {

        View inflatedView = View.inflate(mContext, mAdViewItem.mViewLayoutID, null);
        View markImgView = inflatedView.findViewById(R.id.img_mark);
        if (markImgView != null) {
            markImgView.setVisibility(View.GONE);
        }

        View info = inflatedView.findViewById(mAdViewItem.mInfoLogoImageViewID);
        View logo = inflatedView.findViewById(mAdViewItem.mADLogoImageViewID);

        View title = inflatedView.findViewById(mAdViewItem.mTitleViewID);
        View desc = inflatedView.findViewById(mAdViewItem.mDescViewID);
        View mainImageView = inflatedView.findViewById(mAdViewItem.mADImageViewID);
        View callToAction = inflatedView.findViewById(mAdViewItem.mGotoSiteViewID);


        AdsNativeView adsNativeView;

        if (inflatedView instanceof AdsNativeView) {
            adsNativeView = (AdsNativeView) inflatedView;
        } else {
            adsNativeView = new AdsNativeView(mContext);
            adsNativeView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            inflatedView.setLayoutParams(new AdsNativeView.LayoutParams(AdsNativeView.LayoutParams.MATCH_PARENT, AdsNativeView.LayoutParams.MATCH_PARENT));
            adsNativeView.addView(inflatedView);
        }

        if (mAdViewItem.mContainerView != null) {
            if (mAdViewItem.mContainerView.getChildCount() > 0) {
                mAdViewItem.mContainerView.removeAllViews();
            }

            mAdViewItem.mContainerView.addView(adsNativeView);
        }


        AdsProductLayout.Builder productBuilder = new AdsProductLayout.Builder();
        if (title != null) {
            if (title instanceof TextView) {
                title.setVisibility(View.VISIBLE);
                productBuilder.setTitleView((TextView) title);
            } else {
                title.setVisibility(View.GONE);
            }
        }
        if (mainImageView != null) {
            if (mainImageView instanceof ImageView) {
                mainImageView.setVisibility(View.VISIBLE);
                productBuilder.setMainImageView((ImageView) mainImageView);
            } else {
                mainImageView.setVisibility(View.GONE);
            }
        }
        if (desc != null) {
            if (desc instanceof TextView) {
                desc.setVisibility(View.VISIBLE);
                productBuilder.setPriceView((TextView) desc);
            } else {
                desc.setVisibility(View.GONE);
            }
        }
        if (callToAction != null) {
            productBuilder.setCallToActionView(callToAction);
        }

        AdsPlacementLayout.Builder placementBuilder = new AdsPlacementLayout.Builder();
        if (logo != null) {
            if (logo instanceof ImageView) {
                logo.setVisibility(View.VISIBLE);
                placementBuilder.setLogoView((ImageView) logo);
            } else {
                logo.setVisibility(View.GONE);
            }

        }
        if (info != null) {
            if (info instanceof ImageView) {
                info.setVisibility(View.VISIBLE);
                placementBuilder.setAdsInfoView((ImageView) info);
            } else {
                logo.setVisibility(View.GONE);
            }
        }

        placementBuilder.setProductLayout(productBuilder.build());
        adsNativeView.setAdsPlacementLayout(placementBuilder.build());

        return adsNativeView;
    }

}