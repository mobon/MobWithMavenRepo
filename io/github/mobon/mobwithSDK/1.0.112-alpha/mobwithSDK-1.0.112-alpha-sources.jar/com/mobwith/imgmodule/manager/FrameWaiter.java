package com.mobwith.imgmodule.manager;

import android.app.Activity;

interface FrameWaiter {
  void registerSelf(Activity activity);
}
