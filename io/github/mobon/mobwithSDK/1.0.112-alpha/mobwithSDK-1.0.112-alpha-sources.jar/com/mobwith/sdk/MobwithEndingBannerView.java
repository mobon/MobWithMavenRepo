package com.mobwith.sdk;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import com.mobwith.MobwithSDK;
import com.mobwith.adapters.AdapterObject;
import com.mobwith.sdk.models.SortListResponse;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationManager;
import com.mobwith.manager.iMobonMediationCallback;
import com.mobwith.sdk.api.MWRequestSortList;
import com.mobwith.sdk.api.callbacks.MobWithApiCallback;
import com.mobwith.sdk.api.common.MWCommonRequestInterface;
import com.mobwith.sdk.callback.iBannerCallback;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import javax.annotation.Nonnull;

public class MobwithEndingBannerView extends RelativeLayout implements MWCommonRequestInterface {
    private iBannerCallback mIBannerAdCallback;
    private MediationManager mediationManager;
    private AdapterObject mBannerAdapter;
    private final Context mContext;
    private String mSessionId;
    private String mUnitId;

    public MobwithEndingBannerView(@Nonnull Context context) {
        super(context);
        this.mContext = context;
        setGravity(Gravity.CENTER);
        MobwithSDK.initSDK(context);
    }

    public MobwithEndingBannerView setUnitId(String unitId) {
        this.mUnitId = unitId;
        return this;
    }

    public MobwithEndingBannerView setCategory(List<String> categories) {
        return this;
    }

    public MobwithEndingBannerView setListener(@Nonnull iBannerCallback listener) {
        this.mIBannerAdCallback = listener;
        return this;
    }

    public void loadAd() {
        MWRequestSortList requestSortList = new MWRequestSortList(mContext, mUnitId);
        requestSortList.execute(new MobWithApiCallback() {
            @Override
            public void onSuccess(String response) throws IOException {
                try {
                    SortListResponse sortList = new SortListResponse(new JSONObject(response));

                    if (!sortList.isSuccess()) {
                        if (mIBannerAdCallback != null)
                            mIBannerAdCallback.onLoadedAdInfo(false, Key.NOFILL);
                        return;
                    }

                    mSessionId = sortList.sessionId;

                    String mediaScriptSize = sortList.mediaScriptSize;
                    sendSortListImpression(mContext, mUnitId, sortList.advrtsPrdtCode, mSessionId);

                    mediationManager = new MediationManager(mContext, sortList.data, false, null, null);
                    mediationManager.LoadMediation(new iMobonMediationCallback() {
                        @Override
                        public void onLoadedAdData(String data, final AdapterObject adapter) {
                            if (adapter != null) {
                                LogPrint.d("onLoadedAdData : " + adapter.getName() + " : " + data);
                            } else {
                                LogPrint.d("onLoadedAdData : NoAdapter : " + data);
                            }
                        }

                        @Override
                        public void onAdAdapter(AdapterObject adapter) {
                            if (adapter == null) {
                                if (mIBannerAdCallback != null)
                                    mIBannerAdCallback.onLoadedAdInfo(false, Key.NOFILL);
                                return;
                            }

                            MainThreadHandler.post(() -> {

                                mBannerAdapter = adapter;

                                removeAllViews();
                                try {
                                    View adView = ((View) mBannerAdapter.getAdView());

                                    LayoutParams adParams = getLayoutParams(adView);

                                    if (adView.getId() == View.NO_ID) {
                                        adView.setId(View.generateViewId());
                                    }

                                    addView(adView, adParams);

                                    if (mIBannerAdCallback != null)
                                        mIBannerAdCallback.onLoadedAdInfo(true, "");

                                } catch (Exception e) {
                                    if (mIBannerAdCallback != null)
                                        mIBannerAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
                                }
                            });
                        }

                        @NonNull
                        private LayoutParams getLayoutParams(View adView) {
                            LayoutParams adParams;
                            ViewGroup.LayoutParams existing = adView.getLayoutParams();
                            if (existing != null) {
                                adParams = new LayoutParams(existing.width, existing.height);
                            } else {
                                adParams = new LayoutParams(
                                        LayoutParams.WRAP_CONTENT,
                                        LayoutParams.WRAP_CONTENT);
                            }
                            adParams.addRule(RelativeLayout.CENTER_IN_PARENT);
                            return adParams;
                        }

                        @Override
                        public void onAdRequest(AdapterObject adapter) {
                            sendDspImpression(mContext, mSessionId, mUnitId, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdFailedToLoad(AdapterObject adapter, String errorMsg) {
                            if (adapter != null) {
                                LogPrint.d("onAdFailedToLoad : " + adapter.getName());
                            }
                            if (mIBannerAdCallback != null)
                                mIBannerAdCallback.onLoadedAdInfo(false, errorMsg);
                        }

                        @Override
                        public void onAdFailedAdapterName(AdapterObject adapter) {
                            sendPassBackImpression(mContext, mSessionId, mUnitId, sortList.advrtsPrdtCode,
                                    adapter.getName(), adapter.getUnitId(), adapter.getExlItlSeq());
                        }

                        @Override
                        public void onAdClicked() {
                            if (mIBannerAdCallback != null) mIBannerAdCallback.onAdClicked();
                        }

                        @Override
                        public void onAdImpression() {
                        }

                        @Override
                        public void onAppFinish() {
                        }

                        @Override
                        public void onAdDisplayed() {
                        }

                        @Override
                        public void onAdComplete() {
                        }

                        @Override
                        public void onAdSkip() {
                        }

                        @Override
                        public void onAdClosed() {
                        }

                        @Override
                        public void onAdCancel() {
                        }

                        @Override
                        public void onAdFailedToOpen() {
                        }
                    });
                } catch (Exception e) {
                    if (mIBannerAdCallback != null)
                        mIBannerAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
                }
            }

            @Override
            public void onFailure(IOException e) {
                LogPrint.d("sendCallTime api error : " + e.getLocalizedMessage());
                if (mIBannerAdCallback != null)
                    mIBannerAdCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
            }
        });
    }

    public void destroy() {

    }
}
