package com.mobwith.manager;

import android.text.TextUtils;
import android.util.Log;

import com.mobwith.adapters.AdapterObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by yikim on 2018-02-09.
 */

public class IntegrationHelper {
    public static HashMap<String, Boolean> verifiedAdapters;
    public static final String SCRIPT = "SCRIPT";
    public static final String JSON = "JSON";
    public static final String FRAME = "FRAME";
    public static final String MOBMIXER = "MBMIXER";
    public static final String MOBWITHAD = "MOBWITHAD";
    public static final String MOBON = "MOBON";
    public static final String COUPANG = "COUPANG";
    public static final String ADFIT = "KAKAO_BIZ";
    public static final String INMOBI = "INMOBI";
    public static final String KAKAO_ADFIT = "KAKAO_ADFIT";
    public static final String NEW_ADOPSDK = "NEW_ADOPSDK";
    public static final String ADMOB = "ADMOB";
    public static final String COUPANGSDK = "COUPANGSDK";
    public static final String UNITYADSDK = "UNITYADSDK";
    public static final String LEVELPLAYSDK = "LEVELPLAYSDK";

    public static final String CAULYSDK = "CAULY";
    public static final String PANGLESDK = "PANGLE";
    public static final String DTEXCHANGESDK = "DTEXCHANGE";

    public interface PackageNames {
        String NONE = "";
        String ADFIT = "com.kakao.adfit.AdFitSdk";
        String NEW_ADOPSDK = "ad.helper.openbidding.BidmadCommon";
        String ADMOB = "com.google.android.gms.ads.AdView";
        String COUPANGSDK = "com.coupang.ads.viewmodels.AdsViewModel";
        String UNITYADSDK = "com.unity3d.ads.UnityAds";
        String LEVELPLAYSDK = "com.unity3d.mediation.LevelPlay";
        String CAULYSDK = "com.fsn.cauly.CaulyAdView";
        String PANGLESDK = "com.bytedance.sdk.openadsdk.api.init.PAGConfig";
        String DTEXCHANGE = "com.fyber.inneractive.sdk.external.InneractiveAdManager";
        String INMOBI = "com.inmobi.sdk.InMobiSdk";
    }



    public IntegrationHelper() {
    }

    public static void validateIntegration() {
        final AdapterObject scriptAdapter = new AdapterObject(SCRIPT, PackageNames.NONE);
        final AdapterObject jsonAdapter = new AdapterObject(JSON, PackageNames.NONE);
        final AdapterObject frameAdapter = new AdapterObject(FRAME, PackageNames.NONE);
        final AdapterObject adfitAdapter = new AdapterObject(ADFIT, PackageNames.ADFIT);
        final AdapterObject adfitBannerAdapter = new AdapterObject(KAKAO_ADFIT, PackageNames.ADFIT);
        final AdapterObject adopBidmadAdapter = new AdapterObject(NEW_ADOPSDK, PackageNames.NEW_ADOPSDK);
        final AdapterObject admobAdapter = new AdapterObject(ADMOB, PackageNames.ADMOB);
        final AdapterObject coupangAdapter = new AdapterObject(COUPANGSDK, PackageNames.COUPANGSDK);
        final AdapterObject unityAdAdapter = new AdapterObject(UNITYADSDK, PackageNames.UNITYADSDK);
        final AdapterObject levelPlayAdAdapter = new AdapterObject(LEVELPLAYSDK, PackageNames.LEVELPLAYSDK);
        final AdapterObject caulyAdAdapter = new AdapterObject(CAULYSDK, PackageNames.CAULYSDK);
        final AdapterObject pangleAdAdapter = new AdapterObject(PANGLESDK, PackageNames.PANGLESDK);
        final AdapterObject dtExchangeAdapter = new AdapterObject(DTEXCHANGESDK, PackageNames.DTEXCHANGE);
        final AdapterObject inmobiAdapter = new AdapterObject(INMOBI, PackageNames.INMOBI);

        ArrayList<AdapterObject> adapters = new ArrayList<AdapterObject>() {
            {
                this.add(scriptAdapter);
                this.add(jsonAdapter);
                this.add(frameAdapter);
                this.add(adfitAdapter);
                this.add(adopBidmadAdapter);
                this.add(adfitBannerAdapter);
                this.add(admobAdapter);
                this.add(coupangAdapter);
                this.add(unityAdAdapter);
                this.add(levelPlayAdAdapter);
                this.add(caulyAdAdapter);
                this.add(pangleAdAdapter);
                this.add(dtExchangeAdapter);
                this.add(inmobiAdapter);
            }
        };

        verifiedAdapters = new HashMap<String, Boolean>();
        Log.i("IntegrationHelper", "Verifying Integration:");

        for (AdapterObject adapterObject : adapters) {
            boolean verified = true;
            LogPrint.d("IntegrationHelper", "--------------- " + adapterObject.getName() + " --------------");
            if (!validateAdapter(adapterObject)) {
                verified = false;
            }

            if (verified) {
                LogPrint.d("IntegrationHelper", ">>>> " + adapterObject.getName() + " - VERIFIED");
            } else {
                LogPrint.d("IntegrationHelper", ">>>> " + adapterObject.getName() + " - NOT VERIFIED");
            }

            verifiedAdapters.put(adapterObject.getName(), verified);
        }
    }

    public static boolean verifiedAdapter(String sdkName) {

        if (TextUtils.isEmpty(sdkName)) {
            return false;
        }

        if (sdkName.equalsIgnoreCase(ADFIT.toLowerCase()) || sdkName.toLowerCase().contains(ADFIT.toLowerCase())) {
            sdkName = ADFIT;
        }
        else if (sdkName.equalsIgnoreCase(KAKAO_ADFIT.toLowerCase()) || sdkName.toLowerCase().contains(KAKAO_ADFIT.toLowerCase())) {
            sdkName = KAKAO_ADFIT;
        }
        else if (sdkName.equalsIgnoreCase(NEW_ADOPSDK.toLowerCase()) || sdkName.toLowerCase().contains(NEW_ADOPSDK.toLowerCase())) {
            sdkName = NEW_ADOPSDK;
        }
        else if (sdkName.equalsIgnoreCase(COUPANGSDK.toLowerCase()) || sdkName.toLowerCase().contains(COUPANGSDK.toLowerCase())) {
            sdkName = COUPANGSDK;
        }
        else if (sdkName.equalsIgnoreCase(ADMOB.toLowerCase()) || sdkName.toLowerCase().contains(ADMOB.toLowerCase())) {
            sdkName = ADMOB;
        }
        else if (sdkName.equalsIgnoreCase(UNITYADSDK.toLowerCase()) || sdkName.toLowerCase().contains(UNITYADSDK.toLowerCase())) {
            sdkName = UNITYADSDK;
        }
        else if (sdkName.equalsIgnoreCase(LEVELPLAYSDK.toLowerCase()) || sdkName.toLowerCase().contains(LEVELPLAYSDK.toLowerCase())) {
            sdkName = LEVELPLAYSDK;
        }
        else if (sdkName.equalsIgnoreCase(CAULYSDK.toLowerCase()) || sdkName.toLowerCase().contains(CAULYSDK.toLowerCase())) {
            sdkName = CAULYSDK;
        }
        else if (sdkName.equalsIgnoreCase(PANGLESDK.toLowerCase()) || sdkName.toLowerCase().contains(PANGLESDK.toLowerCase())) {
            sdkName = PANGLESDK;
        }
        else if (sdkName.equalsIgnoreCase(DTEXCHANGESDK.toLowerCase()) || sdkName.toLowerCase().contains(DTEXCHANGESDK.toLowerCase())) {
            sdkName = DTEXCHANGESDK;
        }
        else if (sdkName.equalsIgnoreCase(INMOBI.toLowerCase()) || sdkName.toLowerCase().contains(INMOBI.toLowerCase())) {
            sdkName = INMOBI;
        }
        else {
            return true;
        }

        Object obj = verifiedAdapters.get(sdkName);

        if (obj != null) {
            return (boolean) obj;
        }

        return false;
    }

    public static String getAdapterName(String sdkName) {

        if (sdkName.equalsIgnoreCase(ADFIT.toLowerCase()) || sdkName.toLowerCase().contains(ADFIT.toLowerCase())) {
            sdkName = ADFIT;
        }
        else if (sdkName.equalsIgnoreCase(KAKAO_ADFIT.toLowerCase()) || sdkName.toLowerCase().contains(KAKAO_ADFIT.toLowerCase())) {
            sdkName = KAKAO_ADFIT;
        }
        else if (sdkName.equalsIgnoreCase(NEW_ADOPSDK.toLowerCase()) || sdkName.toLowerCase().contains(NEW_ADOPSDK.toLowerCase())) {
            sdkName = NEW_ADOPSDK;
        }
        else if (sdkName.equalsIgnoreCase(COUPANGSDK.toLowerCase()) || sdkName.toLowerCase().contains(COUPANGSDK.toLowerCase())) {
            sdkName = COUPANGSDK;
        }
        else if (sdkName.equalsIgnoreCase(ADMOB.toLowerCase()) || sdkName.toLowerCase().contains(ADMOB.toLowerCase())) {
            sdkName = ADMOB;
        }
        else if (sdkName.equalsIgnoreCase(UNITYADSDK.toLowerCase()) || sdkName.toLowerCase().contains(UNITYADSDK.toLowerCase())) {
            sdkName = UNITYADSDK;
        }
        else if (sdkName.equalsIgnoreCase(LEVELPLAYSDK.toLowerCase()) || sdkName.toLowerCase().contains(LEVELPLAYSDK.toLowerCase())) {
            sdkName = LEVELPLAYSDK;
        }
        else if (sdkName.equalsIgnoreCase(CAULYSDK.toLowerCase()) || sdkName.toLowerCase().contains(CAULYSDK.toLowerCase())) {
            sdkName = CAULYSDK;
        }

        return sdkName;
    }

    private static boolean validateAdapter(AdapterObject adapter) {
        boolean result = false;
        try {

            if (adapter.getName().equalsIgnoreCase(SCRIPT) || adapter.getName().equalsIgnoreCase(JSON) || adapter.getName().equalsIgnoreCase(FRAME))  {
                return true;
            }

            Class.forName(adapter.getAdapterPackageName());
            result = true;
        }
        catch (ClassNotFoundException var8) {
            validationMessageIsPresent("Adapter", false);
        }

        if (result) {
            validationMessageIsVerified();
        }

        return result;
    }

    private static boolean validateSdk(String sdkName) {
        boolean result = false;

        try {
            Class.forName(sdkName);
            result = true;
            validationMessageIsPresent("SDK", true);
        } catch (ClassNotFoundException var3) {
            validationMessageIsPresent("SDK", false);
        }

        return result;
    }

    private static void validationMessageIsPresent(String paramToValidate, boolean successful) {
        if (successful) {
            LogPrint.d("IntegrationHelper", paramToValidate + " - VERIFIED");
        } else {
            LogPrint.d("IntegrationHelper", paramToValidate + " - MISSING");
        }

    }

    private static void validationMessageIsVerified() {
        LogPrint.d("IntegrationHelper", "Adapter" + " - VERIFIED");
    }
}
