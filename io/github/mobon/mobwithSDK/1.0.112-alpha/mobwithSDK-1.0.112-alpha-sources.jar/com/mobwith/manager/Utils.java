package com.mobwith.manager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.mobwith.sdk.Key;
import com.mobwith.sdk.callback.InAppLandingCallback;

import org.jetbrains.annotations.NotNull;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

@SuppressWarnings("MissingPermission")
public class Utils {

    /**
     * Added by 김현준 (2015-02-07) : DP를 density 가 반영된 PX로 바꿔주는 메서드
     *
     * @param pContext
     * @param pDp
     * @return
     */
    public static int convertDpToPx(Context pContext, int pDp) {
        try {
            return ((int) (pDp * pContext.getResources().getDisplayMetrics().density));
        } catch (Exception e) {
            LogPrint.e("convertDpToPx() Exception!", e);
            return 0;
        }
    }

    public static int convertpxTodp(Context pContext, int pPx) {
        try {
            return ((int) (pPx / pContext.getResources().getDisplayMetrics().density));
        } catch (Exception e) {
            LogPrint.e("convertPxToDp() Exception!", e);
            return 0;
        }
    }


    public static boolean isConnectNetwork(Context context) {

        ConnectivityManager connectivityManager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }


    public static Intent getDefaultBrowserIntent(Context context, String url) {
        PackageManager pm = context.getPackageManager();
        String[] browserPackages = {"com.android.browser", "com.sec.android.app.sbrowser", "com.android.chrome"};

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        for (String pkg : browserPackages) {
            intent.setPackage(pkg);
            if (intent.resolveActivity(pm) != null) {
                return intent;
            }
        }
        return intent.setPackage(null);
    }


    public static String checkAndFixUrlScheme(String url) {
        if (url == null || url.isEmpty()) {
            return url;
        }

        if (url.startsWith("//")) {
            return "https:" + url;
        }

        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();

        if (scheme == null) {
            return "https://" + url;
        }

        if (scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https")) {
            return url;
        }

        return url;
    }

    /**
     * 광고 랜딩 처리.
     * <p>
     * {@link InAppLandingCallback} 이 등록되어 있으면 먼저 매체쪽으로 URL을 전달하고,
     * 매체가 직접 처리(인앱 랜딩)한 경우에는 외부 브라우저를 실행하지 않는다.
     *
     */
    public static boolean getBrowserPackageName(Context _context, String strUrl, InAppLandingCallback callback) {
        String url = checkAndFixUrlScheme(strUrl);

        if (inAppLandingDispatch(url, callback)) {
            return true;
        }

        if (_context == null) {
            return false;
        }

        LogPrint.d("open url : " + url);
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            _context.startActivity(intent);
            return true;
        } catch (Exception e) {
            LogPrint.e("IntentError", "Failed to open URL: " + url);
            return false;
        }

    }

    //TODO: 인앱 랜딩 기능
    public static boolean inAppLandingDispatch(String url, InAppLandingCallback callback) {

        if (callback == null || TextUtils.isEmpty(url)) {
            LogPrint.d("inAppLandingDispatch return false");
            return false;
        }

//        url = "mobwithadScheme://inappLanding?bnrPsitDvCd=2&bnrLinkUrlAddr=https%3A%2F%2Fweb.paybooc.co.kr&linkTypCd=02&scrnId=01&bnrParmVal=";

        try {
            if (url.startsWith("mobwithadScheme")){
                Map<String, String> inAppData = parseInAppLanding(url);
                callback.onInAppLanding(inAppData);
                LogPrint.d("[Opened InAppLanding URL] " + url);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            LogPrint.e("AdLandingManager dispatch() Exception!", e);
            return false;
        }
    }

    public static Map<String, String> parseInAppLanding(String url) {
        Map<String, String> result = new LinkedHashMap<>();
        if (url == null || url.isEmpty()) return result;

        Uri uri = Uri.parse(url);
        if (!uri.isHierarchical()) return result; // "scheme:xxx" 형태 방어

        Set<String> keys = uri.getQueryParameterNames();
        for (String key : keys) {
            String value = uri.getQueryParameter(key);
            result.put(key, value != null ? value : "");
        }
        return result;
    }


    public static boolean isPackageInstalled(String packagename, Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packagename, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }


    public static String getDateTime() {
        String date = "";
        try {
            SimpleDateFormat formater = new SimpleDateFormat(Key.DATE_COMPARE_FORMAT_TIME);
            date = formater.format(new Date());
        } catch (Exception e) {
            LogPrint.e("getDateTime()", e);
        }

        return date;
    }

    public static final boolean isOverDays(final String pStartDate, final int pTargetHours) {
        try {
            if (!TextUtils.isEmpty(pStartDate)) {
                SimpleDateFormat dataFormat = new SimpleDateFormat(Key.DATE_COMPARE_FORMAT_DAY, Locale.KOREA);
                Date startDate = dataFormat.parse(pStartDate);
                Date endDate = new Date(); // dataFormat.parse("2015.02.05");
                // 시간 차이 계산 - milisec
                long duration = endDate.getTime() - startDate.getTime();
                // 경과 시간을 시간 단위로 환산
                long elapsedTime = (duration / (1000 * 60 * 60 * 24));
                // 비교
                return elapsedTime >= pTargetHours;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int getNavigationBarHeight(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            DisplayMetrics metrics = new DisplayMetrics();
            ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(metrics);
            int usableHeight = metrics.heightPixels;
            ((Activity) context).getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
            int realHeight = metrics.heightPixels;
            if (realHeight > usableHeight)
                return realHeight - usableHeight;
            else
                return 0;
        }
        return 0;
    }

    public static void setEdgeToEdgeLayout(Window window) {
        View content = Objects.requireNonNull(window).getDecorView().findViewById(android.R.id.content);

        if (content instanceof ViewGroup) {
            ((ViewGroup) content).setClipToPadding(false);
        }

        WindowCompat.setDecorFitsSystemWindows(window, false);

        ViewCompat.setOnApplyWindowInsetsListener(content, new OnApplyWindowInsetsListener() {
            @NonNull
            @Override
            public WindowInsetsCompat onApplyWindowInsets(@NonNull View view, @NonNull WindowInsetsCompat insets) {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            }
        });
    }

    public static boolean setScreenMode(Key.INTERSTITIAL_TYPE type) {
        boolean isFull = true;
        switch (type) {
            case RANDOM:
                int frameSize = new Random().nextInt(10);
                isFull = frameSize % 2 == 0;
                break;
            case FULL:
                break;
            case MODAL:
                isFull = false;
                break;
        }
        return isFull;
    }

    public static void setDialogSize(@NotNull Context context, Window window, boolean isFull) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();

        try {
            WindowManager.LayoutParams params = window.getAttributes();

            if (isFull) {
                params.width = dm.widthPixels;
                params.height = dm.heightPixels;
            } else {
                params.width = (int) (dm.widthPixels * 0.7f);
                params.height = (int) (dm.heightPixels * 0.7f);

                if (params.width < Utils.convertDpToPx(context, 320)) {
                    params.width = Utils.convertDpToPx(context, 320);
                }

                if (params.height < Utils.convertDpToPx(context, 560)) {
                    params.height = Utils.convertDpToPx(context, 560);
                }

            }

            float _alpha = SpManager.getFloat(context);
            if (_alpha < 0)
                _alpha = 0.6f;
            params.dimAmount = _alpha;

            window.addFlags(isFull ? WindowManager.LayoutParams.FLAG_FULLSCREEN : WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setAttributes(params);
            window.setGravity(Gravity.CENTER);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setFadeAnimation(View view, Runnable runnable) {
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f); // 투명도 0에서 1로 변화
        fadeIn.setDuration(500); // 0.5초 동안 애니메이션 실행
        fadeIn.setFillAfter(true); // 애니메이션 끝난 후 상태 유지
        view.startAnimation(fadeIn);
        view.removeCallbacks(runnable);
        view.setVisibility(View.VISIBLE);
    }

    public static String checkParallelYn(String isParallel){
        if (isParallel.equals("Y")){
            return "true";
        } else {
            return "false";
        }
    }

    public static String getCarrierName(Context context){
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String carrier = telephonyManager.getNetworkOperatorName();
        if (carrier == null || carrier.isEmpty()){
            carrier = "";
        }
        return carrier;
    }

    public static String encodeSubDelims(String input) {
        final String SUB_DELIMS = "!$&'()*+,;=";

        if (input == null || input.isEmpty()) {
            return input;
        }

        StringBuilder sb = new StringBuilder(input.length());

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (SUB_DELIMS.indexOf(c) >= 0) {
                sb.append(percentEncodeChar(c));
            } else {
                sb.append(c);
            }
        }

        return sb.toString();
    }

    /**
     * 단일 문자를 UTF-8 바이트 기준으로 percent-encoding 합니다.
     * (sub-delimiter는 전부 ASCII 1바이트이므로 단일 byte 처리로 충분)
     */
    private static String percentEncodeChar(char c) {
        byte[] bytes = String.valueOf(c).getBytes(StandardCharsets.UTF_8);
        StringBuilder encoded = new StringBuilder();
        for (byte b : bytes) {
            encoded.append('%').append(String.format("%02X", b & 0xFF));
        }
        return encoded.toString();
    }

    public static String getSystemLanguage(){
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    return Resources.getSystem().getConfiguration().getLocales().get(0).getLanguage();
                } catch (NoSuchMethodError ignored) {}
            }
            //noinspection deprecation
            return Resources.getSystem().getConfiguration().locale.getLanguage();
        } catch (Exception e){
            LogPrint.e("getSystemLanguage() Exception!", e);
            return "";
        }
    }

    public static void setEllipsizedText(TextView tv, String text) {
        final int MAX_LEN = 17;

        if (text == null) {
            tv.setText("");
            return;
        }
        if (text.length() > MAX_LEN) {
            // 16자 + … = 총 17자 폭으로 마무리
            tv.setText(text.substring(0, MAX_LEN - 1) + "…");
        } else {
            tv.setText(text);
        }
    }
}