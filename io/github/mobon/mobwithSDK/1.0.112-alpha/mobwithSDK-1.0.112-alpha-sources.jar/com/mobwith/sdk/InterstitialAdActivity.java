package com.mobwith.sdk;

import static com.mobwith.manager.Utils.setEdgeToEdgeLayout;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.mobwith.adapters.AdapterObject;
import com.mobwith.adapters.ApiAdapter;
import com.mobwith.adapters.ScriptAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.api.MWRequestSendDspImpression;
import com.mobwith.sdk.callback.iInterstitialCallback;
import com.mobwith.sdk.callback.iScriptAdViewCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.SortListItemModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class InterstitialAdActivity extends Activity implements View.OnClickListener {

    // Loader → Activity 로 전달 (Intent 직렬화 불가한 객체용)
    private static AdapterObject sAdapter;
    private static iInterstitialCallback sCallback;
    private static Key.INTERSTITIAL_TYPE sScreenType;
    private static String sSessionId;
    private static String sScriptNo;
    private static String sAdvrtsPrdtCode;
    private static String sCloseBtnDisplaySeconds;
    private static boolean sBackNotCancel;

    public static void bind(AdapterObject adapter,
                            iInterstitialCallback callback,
                            Key.INTERSTITIAL_TYPE screenType,
                            String sessionId,
                            String scriptNo,
                            String advrtsPrdtCode,
                            String closeBtnDisplaySeconds,
                            boolean backNotCancel) {
        sAdapter = adapter;
        sCallback = callback;
        sScreenType = screenType == null ? Key.INTERSTITIAL_TYPE.RANDOM : screenType;
        sSessionId = sessionId;
        sScriptNo = scriptNo;
        sAdvrtsPrdtCode = advrtsPrdtCode;
        sCloseBtnDisplaySeconds = closeBtnDisplaySeconds;
        sBackNotCancel = backNotCancel;
    }

    private AdapterObject mAdapter;
    private iInterstitialCallback mCallback;
    private Key.INTERSTITIAL_TYPE mScreenType;
    private String mSessionId, mScriptNo, mAdvrtsPrdtCode, mCloseBtnDisplaySeconds;
    private boolean mBackNotCancel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setEdgeToEdgeLayout(getWindow());

        // 정적 홀더 → 인스턴스로 옮긴 뒤 정적 참조 해제 (메모리 누수 방지)
        mAdapter = sAdapter;
        mCallback = sCallback;
        mScreenType = sScreenType;
        mSessionId = sSessionId;
        mScriptNo = sScriptNo;
        mAdvrtsPrdtCode = sAdvrtsPrdtCode;
        mCloseBtnDisplaySeconds = sCloseBtnDisplaySeconds;
        mBackNotCancel = sBackNotCancel;
        sAdapter = null;
        sCallback = null;

        if (mAdapter == null) {
            if (mCallback != null) mCallback.onFailOpened();
            finish();
            return;
        }

        showAd();
    }

    private void showAd() {
        MMAdData adData = mAdapter.getAdData();

        if (mAdapter.show(this)) {
            if (mCallback != null) mCallback.onOpened();
            return;
        }

        if (mAdapter instanceof ApiAdapter) {
            setScriptWebUi();
            return;
        }

        if (mAdapter instanceof VideoAdapter) {
            setVideoUI((VideoAdapter) mAdapter);
            return;
        }

        if (adData != null && !TextUtils.isEmpty(adData.jsonData)) {
            setMobwithUI(adData.jsonData);
//            if (mCallback != null) mCallback.onOpened();
            return;
        }

        if (mAdapter instanceof ScriptAdapter) {
            try {
                setContentView(mScreenType == Key.INTERSTITIAL_TYPE.FULL
                        ? R.layout.interstitial_full_layout
                        : R.layout.interstitial_normal_layout);

                findViewById(R.id.closeBtn).setOnClickListener(this);

                View adView = (View) mAdapter.getAdView();
                if (adView == null) {
                    failAndFinish();
                    return;
                }

                ViewParent parent = adView.getParent();
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(adView);
                }
                ((FrameLayout) findViewById(R.id.layout_root)).addView(adView);

                ((TextView) findViewById(R.id.textview_title)).setText("");
                ((TextView) findViewById(R.id.textview_desc)).setText("");
                ((TextView) findViewById(R.id.textview_price)).setText("");
                findViewById(R.id.infoBtn).setVisibility(View.GONE);

                if (mCallback != null) mCallback.onOpened();
            } catch (Exception e) {
                e.printStackTrace();
                failAndFinish();
            }
            return;
        }

        failAndFinish();
    }

    private void setMobwithUI(String adData) {
        new MobwithPresentationView(
                this, adData, mScreenType, mCloseBtnDisplaySeconds,
                MobwithPresentationView.AdPresentationFormat.INTERSTITIAL,
                new MobwithPresentationView.OnPresentationViewListener() {
                    @Override
                    public void onOpened() {
                        if (mCallback != null) mCallback.onOpened();
                    }

                    @Override
                    public void onClose() {
                        if (mCallback != null) mCallback.onClosed();
                        finish();
                    }

                    @Override
                    public void onAdClicked(String url) {
                        try {
                            Utils.getBrowserPackageName(InterstitialAdActivity.this, url, mCallback);
                            if (mCallback != null)
                                mCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.ADCLICK);

                            JSONArray clickTrackers = new JSONObject(adData)
                                    .optJSONObject("data").optJSONArray("data")
                                    .optJSONObject(0).optJSONArray("clickTrackers");

                            if (clickTrackers == null) {
                                return;
                            }

                            ArrayList<String> list = new ArrayList<>();
                            for (int i = 0; i < clickTrackers.length(); i++)
                                list.add(clickTrackers.optString(i));
                            CommonUtils.sendClickTrackersEvent(InterstitialAdActivity.this, list);
                        } catch (Exception e) {
                            if (mCallback != null) mCallback.onFailOpened();
                        }
                    }

                    @Override
                    public void onImpression(String type, boolean isFull, String styleCode) {
                        try {
                            CommonUtils.sendInterstitialData(InterstitialAdActivity.this,
                                    mSessionId, type, mScriptNo, isFull, styleCode, mAdvrtsPrdtCode);
                            if ("imp".equals(type)) {
                                JSONArray impTrackers = new JSONObject(adData)
                                        .optJSONObject("data").optJSONArray("data")
                                        .optJSONObject(0).optJSONArray("impTrackers");
                                ArrayList<String> list = new ArrayList<>();
                                for (int i = 0; i < impTrackers.length(); i++)
                                    list.add(impTrackers.optString(i));
                                CommonUtils.sendImpressTrackersEvent(InterstitialAdActivity.this, list);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailOpened() {
                        if (mCallback != null) mCallback.onFailOpened();
                    }
                });
    }

    private void setVideoUI(VideoAdapter adapter) {
        try {
            new MobwithPresentationVideoView(
                    this, adapter, mScreenType, mCloseBtnDisplaySeconds,
                    MobwithPresentationView.AdPresentationFormat.INTERSTITIAL,
                    new MobwithPresentationVideoView.OnPresentationVideoViewListener() {
                        @Override
                        public void onOpened() {
                            if (mCallback != null) mCallback.onOpened();
                        }

                        @Override
                        public void onClose() {
                            if (mCallback != null) mCallback.onClosed();
                            finish();
                        }

                        @Override
                        public void onAdClicked() {
                            if (mCallback != null)
                                mCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.ADCLICK);
                        }

                        @Override
                        public void onImpression(String type, boolean isFull, String styleCode) {
                            CommonUtils.sendInterstitialData(InterstitialAdActivity.this,
                                    mSessionId, type, mScriptNo, isFull, styleCode, mAdvrtsPrdtCode);
                        }
                    });
        } catch (Exception e) {
            if (mCallback != null) mCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
            finish();
        }
    }

    private void setScriptWebUi() {
        try {
            LogPrint.d("setScriptWebUi...");
            ApiAdapter adapter = (ApiAdapter) mAdapter;
            new MobwithScriptInterstitialView(this, adapter, new iScriptAdViewCallback() {

                @Override
                public void onOpened() {
                    if (mCallback != null) {
                        mCallback.onOpened();
                    }
                }

                @Override
                public void onClose() {
                    finish();
                    if (mCallback != null) {
                        mCallback.onClosed();
                    }
                }

                @Override
                public void onAdClicked(String url) {
                    if (url != null && !url.isEmpty()) {
                        Utils.getBrowserPackageName(InterstitialAdActivity.this, url, mCallback);
                    }

                    if (mCallback != null) {
                        mCallback.onClickEvent(Key.INTERSTITIAL_KEYCODE.ADCLICK);
                    }
                }

                @Override
                public void onImpression(SortListItemModel itemModel) {
                    LogPrint.d("itemModel.unitId : " + itemModel.unitId + " adapter.getUnitId() : " + adapter.getUnitId());
                    MWRequestSendDspImpression.requestWith(InterstitialAdActivity.this, itemModel.unitId, itemModel.sortlist, mAdvrtsPrdtCode, mSessionId, adapter.getUnitId(), itemModel.exlItlSeq);
                }

                @Override
                public void onFailOpened() {
                    if (mCallback != null) {
                        mCallback.onFailOpened();
                    }
                }
            });
        } catch (Exception e) {
            if (mCallback != null) mCallback.onLoadedAdInfo(false, e.getLocalizedMessage());
            finish();
        }
    }

    private void failAndFinish() {
        if (mCallback != null) mCallback.onFailOpened();
        finish();
    }

    /* ---------- Activity lifecycle ---------- */

    @Override
    protected void onResume() {
        super.onResume();
        if (mAdapter instanceof VideoAdapter) {
            VideoAdapter v = (VideoAdapter) mAdapter;
            if (v.isPaused()) v.resumeVideo();
            else v.playVideo();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAdapter instanceof VideoAdapter) {
            ((VideoAdapter) mAdapter).pauseVideo();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (mAdapter != null) {
                if (mAdapter instanceof VideoAdapter) {
                    VideoAdapter v = (VideoAdapter) mAdapter;
                    v.close();
                    v.reset();
                }
                mAdapter.onPause();
                mAdapter.destroy();
                mAdapter = null;
            }
        } catch (Exception e) {
            LogPrint.d("onDestroy() Error : " + e.getLocalizedMessage());
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (mBackNotCancel) {
            if (mCallback != null) mCallback.onClosed();
            finish();
        }
        // mBackNotCancel == false 이면 뒤로가기 무시
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.closeBtn) {
            if (mCallback != null) mCallback.onClosed();
            finish();
        }
    }
}
