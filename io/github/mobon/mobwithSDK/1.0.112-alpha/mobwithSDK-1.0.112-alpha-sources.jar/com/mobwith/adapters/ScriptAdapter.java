package com.mobwith.adapters;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;

import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.R;
import com.mobwith.sdk.ScriptSource;
import com.mobwith.sdk.Url;

public class ScriptAdapter extends AdapterObject {

    private static final String BASE_URL_MEDIACATEGORY = "https://mediacategory.com";
    private static final String BASE_URL_COUPANG = "https://ads-partners.coupang.com";
    private static final String BASE_URL_NHN = "https://cdn.nhnace.com/";
    private static final String POSTBACK_URL = "https://mobwithsdk/postback";

    /**
     * 광고 네트워크(exid) 종류.
     */
    private enum ExType {MBMIXER, COUPANG, MOBON, MEZZOM, ACRS, TOAST, OTHER}

    private MediationAdListener mediationAdListener;
    private final String mUnitId;
    private final Context mContext;
    private final String mScriptNo;
    private final String mSiteNo;
    private String mSiteUrl;
    private final String mExid;
    private String exlItlMemo;
    private RelativeLayout mMainLayout;
    private WebView mWebview;
    private boolean isFail;
    private boolean sendSuccessCallback;
    private boolean sendFailCallback;
    private final String[] mScriptInfo;
    private String mBannerType;
    private boolean isMezzoLoaded = false;
    private boolean isNhnFailed = false;

    private final int viewWidth;
    private final int viewHeight;

    public ScriptAdapter(final Context context, String name, String unitId,
                         String AdType, String adData, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);
        mUnitId = unitId;
        mContext = context;
        mSiteNo = siteNo;
        mScriptInfo = unitId.split("_");
        mScriptNo = mScriptInfo[0];
        mAdType = MediationAdSize.BANNER_320_50;
        mExid = name;

        viewHeight = -1;
        viewWidth = -1;
    }

    public ScriptAdapter(final Context context, String name, String unitId,
                         String AdType, String exlItlMemo, boolean isTestMode,
                         String siteNo, String siteUrl, int width, int height) {
        super(name, unitId, AdType, null, isTestMode);
        mUnitId = unitId;
        mContext = context;
        mSiteNo = siteNo;
        mScriptInfo = unitId.split("_");
        mScriptNo = mScriptInfo[0];
        mAdType = MediationAdSize.BANNER_320_50;
        mExid = name;
        mSiteUrl = siteUrl;
        this.exlItlMemo = exlItlMemo;

        viewHeight = height;
        viewWidth = width;

        LogPrint.d("mSiteNo : " + mSiteNo);
    }

    /**
     * mExid 를 기반으로 네트워크 종류를 판별합니다.
     * contains 우선순위(MBMIXER → COUPANG → MOBON) 후 정확 일치(MEZZOM/ACRS/TOAST) 순으로,
     * 기존 분기 로직과 동일하게 동작합니다.
     */
    private ExType exType() {
        String upper = mExid.toUpperCase();
        if (upper.contains("MBMIXER")) return ExType.MBMIXER;
        if (upper.contains("COUPANG")) return ExType.COUPANG;
        if (upper.contains("MOBON")) return ExType.MOBON;

        switch (mExid) {
            case "MEZZOM":
                return ExType.MEZZOM;
            case "ACRS":
                return ExType.ACRS;
            case "TOAST":
                return ExType.TOAST;
            default:
                return ExType.OTHER;
        }
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    public void load(String adtype) {
        setLayout(adtype);
        updateScriptUI();
    }

    // region WebView 생성/설정
    private void updateScriptUI() {
        try {
            new Handler(Looper.getMainLooper()).post(this::createAndLoadWebView);
        } catch (Exception e) {
            LogPrint.d("ERROR", "error => " + e.getLocalizedMessage());
            mediationAdListener.onAdFailedToLoad("NO FILL - " + e.getLocalizedMessage());
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private void createAndLoadWebView() {
        mWebview = new WebView(mContext);
        mMainLayout.addView(mWebview);
        WebView.setWebContentsDebuggingEnabled(false); // 배포 시 false

        configureWebSettings(mWebview.getSettings());

        mWebview.setVerticalScrollBarEnabled(false);
        mWebview.setHorizontalScrollBarEnabled(false);
        mWebview.setBackgroundColor(Color.TRANSPARENT);
        mWebview.setOnTouchListener((v, event) -> (event.getAction() == MotionEvent.ACTION_MOVE));

        mWebview.setWebChromeClient(createWebChromeClient());
        mWebview.setWebViewClient(createWebViewClient());

        if (exType() == ExType.MEZZOM) {
            mWebview.addJavascriptInterface(new MezzoScriptInterface(), "AndroidInterface");
        } else {
            mWebview.removeJavascriptInterface("AndroidInterface");
        }

        configureCookies(mWebview);

        CookieManager cookieManager = CookieManager.getInstance();
        String mediacategoryCookie = cookieManager.getCookie(BASE_URL_MEDIACATEGORY);

        if (TextUtils.isEmpty(mediacategoryCookie) || !mediacategoryCookie.contains("au_id")) {
            mMainLayout.setVisibility(View.INVISIBLE);
            String url = Url.API_AUID + "?adid=" + SpManager.getString(mContext, Key.ADID);
            mWebview.loadUrl(url);
        } else {
            mMainLayout.setVisibility(View.VISIBLE);
            loadSSPScript(mWebview);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebSettings(WebSettings settings) {
        settings.setJavaScriptEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);

        // 웹뷰 - HTML5 창 속성 추가
        String path = mContext.getDir("database", Context.MODE_PRIVATE).getPath();
        settings.setDatabaseEnabled(true);
        settings.setDatabasePath(path);
        settings.setDomStorageEnabled(true);
        settings.setBlockNetworkLoads(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { // https 이미지
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
    }

    private void configureCookies(WebView webView) {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }
    }
    // endregion

    // region SSP 스크립트 로드
    private void loadSSPScript(WebView wv) {
        if (viewWidth > 0 && mScriptInfo.length > 1) {
            mScriptInfo[1] = "" + Utils.convertpxTodp(mContext, viewWidth);
        }
        if (viewHeight > 0 && mScriptInfo.length > 2) {
            mScriptInfo[2] = "" + Utils.convertpxTodp(mContext, viewHeight);
        }

        final String frameCode;
        final String width;
        final String height;
        if (BannerType.BANNER_300x250.equals(mBannerType)) {
            frameCode = "42";
            width = "300";
            height = "250";
        } else if (BannerType.BANNER_320x100.equals(mBannerType)) {
            frameCode = "43";
            width = "320";
            height = "100";
        } else {
            frameCode = "37";
            width = "320";
            height = "50";
        }

        isFail = false;
        String htmlContent = "";

        switch (exType()) {
            case MBMIXER:
                htmlContent = ScriptSource.getMobMixerScript(mContext, mScriptNo, mScriptInfo);
                wv.loadDataWithBaseURL(BASE_URL_MEDIACATEGORY, htmlContent, "text/html; charset=utf-8", "UTF-8", null);
                break;
            case COUPANG:
                try {
                    LogPrint.d("COUPANG htmlContent");
                    htmlContent = ScriptSource.getCoupangScript(mContext, mScriptNo,
                            String.valueOf(Utils.convertDpToPx(mContext, Integer.parseInt(height))));
                    wv.loadDataWithBaseURL(BASE_URL_COUPANG, htmlContent, "text/html", "UTF8", null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case MOBON:
                htmlContent = ScriptSource.getMobonScript(mScriptNo, frameCode, width, height);
                wv.loadDataWithBaseURL(BASE_URL_MEDIACATEGORY, htmlContent, "text/html", "UTF8", null);
                break;
            case MEZZOM:
                htmlContent = ScriptSource.getMezzoScript(mContext, mUnitId);
                wv.loadDataWithBaseURL(BASE_URL_MEDIACATEGORY, htmlContent, "text/html; charset=utf-8", "UTF-8", null);
                break;
            case ACRS:
                htmlContent = ScriptSource.getAcrossScript(mUnitId, mSiteUrl);
                wv.loadDataWithBaseURL(BASE_URL_MEDIACATEGORY, htmlContent, "text/html", "UTF-8", null);
                LogPrint.d("acrs loadDataWithBaseURL");
                break;
            case TOAST:
                htmlContent = ScriptSource.getNhnToastScript(mUnitId, exlItlMemo, mSiteUrl, width, height);
                wv.loadDataWithBaseURL(BASE_URL_NHN, htmlContent, "text/html; charset=utf-8", "UTF-8", null);
                break;
            default:
                break;
        }
        LogPrint.d("htmlContent : " + htmlContent);
    }
    // endregion

    private void setLayout(String _adType) {
        LogPrint.d("_adType : " + _adType);
        mMainLayout = new RelativeLayout(mContext);
        mBannerType = _adType;

        RelativeLayout.LayoutParams layoutParam;
        if (BannerType.BANNER_300x250.equals(_adType)) {
            layoutParam = new RelativeLayout.LayoutParams(
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_width_300),
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_250));
        } else if (BannerType.BANNER_320x100.equals(_adType)) {
            layoutParam = new RelativeLayout.LayoutParams(
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_width),
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_100));
        } else if (BannerType.INTERSTITIAL.equals(_adType) || BannerType.ENDING.equals(_adType)) {
            layoutParam = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        } else {
            layoutParam = new RelativeLayout.LayoutParams(
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_width),
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_50));
        }

        mMainLayout.setLayoutParams(layoutParam);
        mMainLayout.setGravity(Gravity.CENTER);
    }

    @Override
    public void destroy() {
        super.destroy();
        try {
            if (mMainLayout != null && mMainLayout.getChildCount() > 0) {
                mMainLayout.removeAllViews();
                mMainLayout = null;
            }
            if (mWebview != null){
                mWebview.destroy();
            }
        } catch (Exception e) {
            LogPrint.d("[Script Adapter] " + e.getLocalizedMessage());
        }
    }

    public void onPause() {
        try {
            if (mWebview != null) {
                mWebview.onPause();
            }
        } catch (Exception e) {
            LogPrint.d("[Script Adapter] " + e.getLocalizedMessage());
        }
    }

    public void onResume() {
        if (mWebview != null) {
            mWebview.onResume();
        }
    }

    public Object getAdView() {
        LogPrint.d("getAdView");
        return mMainLayout;
    }

    @Override
    public boolean isLoaded() {
        LogPrint.d("isLoaded");
        return !isFail && (mMainLayout != null);
    }

    // ============================================================
    // region WebChromeClient 팩토리
    // ============================================================
    private WebChromeClient createWebChromeClient() {
        switch (exType()) {
            case MBMIXER:
                return mbmixerChromeClient();
            case COUPANG:
                return coupangChromeClient();
            case MOBON:
                return mobonChromeClient();
            case MEZZOM:
                return consoleLoggingChromeClient();
            case ACRS:
                return acrsChromeClient();
            case TOAST:
                return toastChromeClient();
            default:
                return new WebChromeClient();
        }
    }

    private WebChromeClient mbmixerChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                LogPrint.d("onCreateWindow");
                WebView newWebView = new WebView(mContext);
                view.addView(newWebView);
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(newWebView);
                resultMsg.sendToTarget();

                newWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        LogPrint.d("shouldOverrideUrlLoading(in NewWebView) : " + url);

                        Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                        if (url.contains("mediacategory.com")) {
                            url += "&au_id=" + SpManager.getString(mContext, Key.AUID);
                        }
                        browserIntent.setData(Uri.parse(url));
                        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivityWithChooser(browserIntent);

                        if (mediationAdListener != null) {
                            mediationAdListener.onAdClicked();
                        }
                        mWebview.loadUrl("javascript:mixerClickFn();");

                        if (url.contains("//img.mobon.net/ad/linfo.php")) {
                            mWebview.goBack();
                        }
                        return true;
                    }
                });
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogPrint.d("!!!!! onConsoleMessage " + consoleMessage.message() + " of " + consoleMessage.sourceId());

                String msg = consoleMessage.message();
                boolean isFailMessage = (msg.contains("TypeError:")
                        || msg.contains("Uncaught SyntaxError:")
                        || msg.contains("Uncaught ReferenceError:")
                        || msg.equals("AdapterFailCallback_" + mScriptNo)
                        || msg.equals("AdapterFailCallback"))
                        && !msg.contains("wp_json");

                if (isFailMessage) {
                    if (mMainLayout != null && !sendSuccessCallback) {
                        mMainLayout.removeAllViews();
                    }
                    if (mWebview == null || isFail) {
                        return true;
                    }
                    mWebview.onPause();

                    if (mediationAdListener != null && !sendFailCallback) {
                        sendFailCallback = true;
                        mediationAdListener.onAdFailedToLoad("NO FILL");
                    }
                } else if (msg.equals("AdapterSuccessCallback_" + mScriptNo)
                        || msg.equals("ad loaded, has ad: true")) {
                    if (mWebview != null && mediationAdListener != null && !sendSuccessCallback) {
                        sendSuccessCallback = true;
                        mediationAdListener.onAdLoaded();
                    }
                }
                return true;
            }
        };
    }

    private WebChromeClient coupangChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                LogPrint.d("COUPANG shouldOverrideUrlLoading");
                attachTransportWebView(view, resultMsg);
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogPrint.d("consoleMessage : " + consoleMessage.message());
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                LogPrint.d("COUPANG onShowCustomView");
                super.onShowCustomView(view, callback);
            }

            @Override
            public void onRequestFocus(WebView view) {
                LogPrint.d("COUPANG onRequestFocus");
                super.onRequestFocus(view);
            }
        };
    }

    private WebChromeClient mobonChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
                attachTransportWebView(view, resultMsg);
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogPrint.d("consoleMessage : " + consoleMessage.message());
                return true;
            }
        };
    }

    private WebChromeClient acrsChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                LogPrint.d("ACRS onCreateWindow");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
                attachTransportWebView(view, resultMsg);
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogPrint.d("consoleMessage : " + consoleMessage.message());
                return true;
            }
        };
    }

    private WebChromeClient toastChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // 기존 동작: TOAST 는 새 창을 띄우지 않고 무시한다.
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogPrint.d("consoleMessage : " + consoleMessage.message());
                return true;
            }
        };
    }

    private WebChromeClient consoleLoggingChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogPrint.d("consoleMessage : " + consoleMessage.message());
                return true;
            }
        };
    }
    // endregion

    // ============================================================
    // region WebViewClient 팩토리
    // ============================================================
    private WebViewClient createWebViewClient() {
        LogPrint.d("mExid : " + mExid);
        switch (exType()) {
            case MBMIXER:
                return mbmixerWebViewClient();
            case COUPANG:
                // 주의(기존 동작 보존): COUPANG/MOBON 은 여기서 직접 mWebview 에 클라이언트를 설정하고
                // null 을 반환한다. 호출부(createAndLoadWebView)가 이후 setWebViewClient(null) 을 한 번 더 호출한다.
                LogPrint.d("COUPANG");
                mWebview.setWebViewClient(coupangWebViewClient());
                return null;
            case MOBON:
                mWebview.setWebViewClient(mobonWebViewClient());
                return null;
            case MEZZOM:
                return mezzomWebViewClient();
            case ACRS:
                LogPrint.d("ACRS WebViewClient");
                return acrsWebViewClient();
            case TOAST:
                return toastWebViewClient();
            default:
                mediationAdListener.onAdFailedToLoad("NO AD");
                return new WebViewClient();
        }
    }

    private WebViewClient mbmixerWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                LogPrint.d("shouldOverrideUrlLoading : " + url);
                Intent browserIntent = new Intent(Intent.ACTION_VIEW);
                if (url.contains("mediacategory.com")) {
                    url += "&au_id=" + SpManager.getString(mContext, Key.AUID);
                }
                browserIntent.setData(Uri.parse(url));
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
                if (mWebview != null) {
                    mWebview.onResume();
                    mWebview.loadUrl("javascript:mixerClickFn();");
                }

                try {
                    mContext.startActivity(browserIntent);
                    return true;
                } catch (ActivityNotFoundException e) {
                    Intent chooserIntent = Intent.createChooser(browserIntent, "title");
                    chooserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(chooserIntent);
                }
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                if (sendSuccessCallback) {
                    return;
                }
                if (mWebview == null || isFail) {
                    return;
                }
                mWebview.onPause();

                if (mMainLayout != null) {
                    mMainLayout.removeAllViews();
                }

                isFail = true;
                if (mediationAdListener != null && !sendFailCallback) {
                    sendFailCallback = true;
                    mediationAdListener.onAdFailedToLoad(error.toString());
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (error.getErrorCode() == -1 || error.getErrorCode() == -10 || isFail) {
                        return;
                    }
                }
                if (sendSuccessCallback) {
                    return;
                }
                if (mWebview != null) {
                    mWebview.loadUrl("about:blank");
                    mWebview.onPause();
                }
                isFail = true;

                if (mMainLayout != null) {
                    mMainLayout.removeAllViews();
                }
                if (mediationAdListener != null && !sendFailCallback) {
                    sendFailCallback = true;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        mediationAdListener.onAdFailedToLoad(error.getDescription().toString());
                    }
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url.contains("/servlet/auid")) {
                    loadSSPScript(mWebview);
                }
            }
        };
    }

    private WebViewClient coupangWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                LogPrint.d("COUPANG shouldOverrideUrlLoading");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    startActivityForUrl(request.getUrl());
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                LogPrint.d("onPageFinished : " + url);
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                super.onPageFinished(view, url);
            }
        };
    }

    private WebViewClient mobonWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    startActivityForUrl(request.getUrl());
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                LogPrint.d("onPageFinished : " + url);
                if (url.contains(POSTBACK_URL)) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("MOBON - NO AD");
                    }
                } else {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                }
                super.onPageFinished(view, url);
            }
        };
    }

    private WebViewClient mezzomWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                openUrlInBrowser(view, request);
                return true;
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                LogPrint.d("MEZZOM onReceivedSslError");
                super.onReceivedSslError(view, handler, error);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                LogPrint.d("MEZZOM onReceivedError");
                super.onReceivedError(view, request, error);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        };
    }

    private WebViewClient acrsWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
                openUrlInBrowser(view, request);
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                LogPrint.d("ACRS onReceivedSslError");
                super.onReceivedSslError(view, handler, error);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                Log.e("onPageStarted", "url : " + url);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                LogPrint.d("onPageFinished url : " + url);
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                super.onPageFinished(view, url);
            }
        };
    }

    private WebViewClient toastWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
                openUrlInBrowser(view, request);
                return true;
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (request.getUrl().toString().equals(POSTBACK_URL)) {
                        isNhnFailed = true;
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                super.onReceivedSslError(view, handler, error);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                LogPrint.d("onPageFinished url : " + url);
                new Thread(() -> {
                    for (int i = 0; i < 5; i++) {
                        try {
                            if (isNhnFailed) {
                                if (mediationAdListener != null) {
                                    mediationAdListener.onAdFailedToLoad("NO AD");
                                    break;
                                }
                            } else {
                                if (i == 4 && mediationAdListener != null) {
                                    mediationAdListener.onAdLoaded();
                                }
                            }
                            Thread.sleep(500);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                super.onPageFinished(view, url);
            }
        };
    }
    // endregion

    // region WebView 공통 헬퍼

    /**
     * resultMsg 의 transport 에 새 WebView 를 연결합니다. (팝업 처리 공통 로직)
     */
    private void attachTransportWebView(WebView parent, Message resultMsg) {
        WebView newWebView = new WebView(mContext);
        parent.addView(newWebView);
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(newWebView);
        resultMsg.sendToTarget();
    }

    /**
     * ACTION_VIEW 인텐트로 URL 을 엽니다. (NEW_TASK | SINGLE_TOP)
     */
    private void startActivityForUrl(Uri uri) {
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        mContext.startActivity(intent);
    }

    /**
     * view 의 컨텍스트로 URL 을 엽니다. (MEZZOM/ACRS/TOAST 공통, 예외는 무시)
     */
    private void openUrlInBrowser(WebView view, WebResourceRequest request) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(request.getUrl().toString()));
                view.getContext().startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 인텐트를 실행하되 처리할 액티비티가 없으면 chooser 로 폴백합니다.
     */
    private void startActivityWithChooser(Intent browserIntent) {
        try {
            mContext.startActivity(browserIntent);
        } catch (ActivityNotFoundException e) {
            Intent chooserIntent = Intent.createChooser(browserIntent, "title");
            chooserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            mContext.startActivity(chooserIntent);
        }
    }
    // endregion

    public class MezzoScriptInterface {

        public MezzoScriptInterface() {
        }

        @JavascriptInterface
        public void onSuccess(String type, String status, String data) {
            LogPrint.d("WebViewCallback", "✅ SUCCESS - type: " + type + ", status: " + status + ", data: " + data);

            if (!isMezzoLoaded) {
                isMezzoLoaded = true;
                if (type.equals("house")) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad("HOUSE");
                    }
                } else {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                }
            }
        }

        @JavascriptInterface
        public void onFail(String type, String status, String data) {
            LogPrint.d("WebViewCallback", "❌ FAIL - type: " + type + ", status: " + status + ", data: " + data);
            if (!isMezzoLoaded) {
                isMezzoLoaded = true;
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("NO FILL");
                }
            }
        }

        @JavascriptInterface
        public void onEvent(String type, String status, String data) {
            LogPrint.d("WebViewCallback", "📢 EVENT - type: " + type + ", status: " + status + ", data: " + data);

            if (type.equals("adclick")) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }
        }
    }
}