package com.mobwith.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.mobwith.MobwithSDK;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.imgmodule.RequestManager;
import com.mobwith.manager.IntegrationHelper;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.manager.Utils;
import com.mobwith.sdk.BannerType;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.R;
import com.mobwith.sdk.api.MWRequestCustomURL;
import com.mobwith.sdk.api.MWRequestJsonAd;
import com.mobwith.sdk.api.MWRequestSplashAd;
import com.mobwith.sdk.api.callbacks.MobWithApiResponseCallback;
import com.mobwith.sdk.loader.MMAdData;
import com.mobwith.sdk.models.AdDataImageModel;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.AdDataResponseDataModel;
import com.mobwith.sdk.models.AdDataResponseModel;
import com.mobwith.sdk.models.MobwithAdCategoryModel;
import com.mobwith.sdk.models.SortList;
import com.mobwith.sdk.models.reward.MWRewardBannerModel;
import com.mobwith.sdk.models.splash.MWSplashAdResponse;
import com.mobwith.sdk.utils.MainThreadHandler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * JsonAdapter
 * JsonAdapter는 JSON 형식의 광고 데이터를 처리하고 애플리케이션에 다양한 유형의 배너 광고를 표시하는 역할을 하는 클래스입니다.
 * Mobwith SDK의 일부로, 특정 광고 네트워크 (Mobon, Coupang 등) 및 일반 Mobwith 광고에 대한 UI 렌더링을 처리합니다.
 * 광고 로드, 표시, 클릭 및 노출 추적과 관련된 로직을 포함합니다.
 */
public class JsonAdapter extends AdapterObject {

    private static final int PARALLEL_RETRY_COUNT = 4;
    private static final long PARALLEL_RETRY_DELAY_MS = 300L;

    private MediationAdListener mediationAdListener;
    private final String mUnitId;
    private final Context mContext;
    private final String mSiteNo;
    private final String mExid;
    private final String exlItlMemo;
    private final String isParallel;

    private RequestManager mRequestManager;
    private RelativeLayout mMainLayout;
    private String mBannerType;
    private final MobwithAdCategoryModel mMobwithAdCategoryModel;
    private final List<String> campaignCodes;
    private final List<String> categories;

    private boolean isRewardAD;
    private boolean isREwardAdLoaded;
    public boolean isPointBanner;
    public boolean useParallel = false;
    private boolean isMixerLoaded = false;
    private String adBname;
    private MWRewardBannerModel rewardBannerModel;

    private MixerState mixerState = MixerState.WAIT;

    public enum MixerState {
        WAIT, LOADING, LOADED, FAILED
    }

    /*
     * 광고 요청 및 표시에 필요한 컨텍스트, 광고 단위 ID, 광고 유형, 카테고리 모델 등의 초기 파라미터를 설정합니다.
     * */
    public JsonAdapter(final Context context, String name, String unitId,
                       String exlItlMemo, String adType, MobwithAdCategoryModel mobwithAdCategoryModel,
                       MMAdData adData, boolean isTestMode, String siteNo,
                       String isParallel, String adBname, List<String> campaignCodes, List<String> categories) {
        super(name, unitId, adType, adData, isTestMode);
        mUnitId = unitId;
        mContext = context;
        mSiteNo = siteNo;
        this.exlItlMemo = exlItlMemo;
        mAdType = MediationAdSize.BANNER_320_50;
        mExid = name;
        this.isParallel = isParallel;
        this.adBname = adBname;
        this.campaignCodes = campaignCodes;
        this.categories = categories;
        mMobwithAdCategoryModel = mobwithAdCategoryModel;
    }

    // 광고 로드 성공, 실패, 클릭과 같은 광고 수명 주기 이벤트를 수신할 MediationAdListener를 설정합니다.
    public void setAdListener(final MediationAdListener listener) {
        mediationAdListener = listener;
    }

    public void setRewardBannerModel(MWRewardBannerModel rewardBannerModel){
        this.rewardBannerModel = rewardBannerModel;
    }

    // 지정된 광고 유형(adtype)에 따라 JSON 광고 데이터를 요청하고 로드합니다.
    public void load(String adtype) {
        LogPrint.d("adtype : " + adtype);
        mBannerType = adtype;
        isREwardAdLoaded = false;
        if (mBannerType.equals(BannerType.REWARD_VIDEO)) {
            isRewardAD = true;
            isPointBanner = true;
        }

        if (mRequestManager == null) {
            mRequestManager = ImageModule.with(mContext.getApplicationContext());
        }

        if (adtype.equals(BannerType.SPLASH_AD)){
            //스플래시 광고
            MWRequestSplashAd.request(mContext, mExid, mSiteNo, mUnitId, new MobWithApiResponseCallback<MWSplashAdResponse>() {
                @Override
                public void onSuccess(MWSplashAdResponse response) {
                    setSplashData(response);
                }

                @Override
                public void onFailure(Exception e) {
                    sendOnAdFailedToLoad("NO FILL : " + e.getMessage());
                }
            });
        } else {
            if (useParallel) {
                // MIXER AD 병렬 호출
                checkParallelMixerAD();
            } else {
                MWRequestJsonAd.request(mContext, mExid, mSiteNo, mUnitId, exlItlMemo, "true", "Y",
                        mMobwithAdCategoryModel, "false", adBname, campaignCodes, categories, rewardBannerModel,
                        new MobWithApiResponseCallback<AdDataResponseModel>() {
                            @Override
                            public void onSuccess(AdDataResponseModel model) {
                                LogPrint.d("[DIAG] onSuccess " + getName() + " hash=" + System.identityHashCode(this));
                                setJsonData(model);
                            }

                            @Override
                            public void onFailure(Exception e) {
                                LogPrint.d("api error : " + e.getLocalizedMessage());
                                sendOnAdFailedToLoad("NO FILL");
                            }
                        });
            }
        }
    }

    private void sendOnLoadAd() {
        new Handler(Looper.getMainLooper()).post(() -> {
            isREwardAdLoaded = true;
            if (mediationAdListener != null) {
                mediationAdListener.onAdLoaded();
            }
        });
    }

    private void sendOnAdFailedToLoad(String message) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad(message);
            }
        });
    }

    private void setLayout(String adType) {
        mMainLayout = new RelativeLayout(mContext);
        RelativeLayout.LayoutParams layoutParam;

        if (TextUtils.equals(adType, BannerType.BANNER_300x250)) {
            layoutParam = new RelativeLayout.LayoutParams(
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_width_300),
                    (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_250));
        } else if (TextUtils.equals(adType, BannerType.BANNER_320x100)) {
            if (MobwithSDK.isFullScreenMode) {
                // 이미지 배너만, 상품 배너는 적용하면 안됨.....
                layoutParam = new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            } else {
                layoutParam = new RelativeLayout.LayoutParams(
                        (int) mContext.getResources().getDimension(R.dimen.rect_banner_width),
                        (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_100));
            }
        } else {
            // 320x50
            if (MobwithSDK.isFullScreenMode) {
                layoutParam = new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            } else {
                layoutParam = new RelativeLayout.LayoutParams(
                        (int) mContext.getResources().getDimension(R.dimen.rect_banner_width),
                        (int) mContext.getResources().getDimension(R.dimen.rect_banner_height_50));
            }
        }

        mMainLayout.setLayoutParams(layoutParam);
        mMainLayout.setGravity(Gravity.CENTER);
    }

    private void drawMobonUI(AdDataModel adDataModel, String logoUrl, String logoDefault, String impUrl) {
        AdDataImageModel imageModel = adDataModel.getAdImageModel();

        String pcode = adDataModel.getpCode();
        sendImpressionWith(adDataModel.getCustom08(), impUrl);
        CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);

        if (TextUtils.isEmpty(pcode)) { // 비상품
            final String purl = adDataModel.getpUrl();
            final ArrayList<String> imgArray = (imageModel != null)
                    ? imageModel.getImageArray(mBannerType) : new ArrayList<>();
            if (imgArray.isEmpty()) {
                imgArray.add(adDataModel.getpImg());
            }

            ImageView mContentIv;
            int size = imgArray.size();
            for (int i = 0; i < size; i++) {
                String ext = imgArray.get(i).substring(imgArray.get(i).lastIndexOf(".") + 1);
                if (!isSupportedImageExt(ext)) {
                    continue;
                }

                if (i >= size - 2) {
                    View.inflate(mContext, resolveBannerLayoutId(), mMainLayout);
                    mContentIv = mMainLayout.findViewById(R.id.t_img);
                    TextView mTitle = mMainLayout.findViewById(R.id.t_title);
                    TextView mPrice = mMainLayout.findViewById(R.id.t_price);
                    mTitle.setText(adDataModel.getaTitle());

                    if (isCtaReplaceCode(adDataModel.getAdvrtsReplcCode())) {
                        applyCtaPriceStyle(mPrice, adDataModel.getCtaText());
                    } else {
                        mPrice.setText(adDataModel.getaDesc3());
                    }

                    if (isPointBanner) {
                        mRequestManager.load(imgArray.get(i)).placeholder(new ColorDrawable(Color.WHITE)).fitCenter().into(mContentIv);
                        mMainLayout.findViewById(R.id.linearLayoutInfos).setVisibility(View.GONE);
                    } else {
                        mRequestManager.load(imgArray.get(i)).placeholder(new ColorDrawable(Color.WHITE)).fitCenter().centerCrop().into(mContentIv);
                    }
                } else {
                    View.inflate(mContext, R.layout.banner_ad_layout, mMainLayout);
                    mContentIv = mMainLayout.findViewById(R.id.t_img);
                    mRequestManager.load(imgArray.get(i)).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(mContentIv);
                    if (MobwithSDK.isFullScreenMode) {
                        mContentIv.setScaleType(ImageView.ScaleType.FIT_XY);
                    }
                }
                break;
            }

            setupMarkImage(mMainLayout.findViewById(R.id.mark_img), logoUrl, logoDefault);
            setProductClickListener(purl, adDataModel);

        } else { // 상품
            View.inflate(mContext, resolveBannerLayoutId(), mMainLayout);
            ImageView mContentIv = mMainLayout.findViewById(R.id.t_img);
            TextView mTitle = mMainLayout.findViewById(R.id.t_title);
            TextView mPrice = mMainLayout.findViewById(R.id.t_price);
            ImageView logo_img = mMainLayout.findViewById(R.id.logo_img);

            final String purl = adDataModel.getpUrl();
            final String adLogo = adDataModel.getaLogoSub();

            mTitle.setText(adDataModel.getpNm());

            if (isCtaReplaceCode(adDataModel.getAdvrtsReplcCode())) {
                applyCtaPriceStyle(mPrice, adDataModel.getCtaText());
            } else {
                mPrice.setText(adDataModel.getPrice());
            }

            if (logo_img != null) {
                if (TextUtils.isEmpty(adLogo)) {
                    logo_img.setVisibility(View.GONE);
                } else if (adLogo.startsWith("http")) {
                    mRequestManager.load(adLogo).fitCenter().into(logo_img);
                } else {
                    mRequestManager.load("https://" + adLogo).fitCenter().into(logo_img);
                }
            }

            setupMarkImage(mMainLayout.findViewById(R.id.mark_img), logoUrl, logoDefault);

            if (isPointBanner) {
                mRequestManager.load(adDataModel.getpImg()).placeholder(new ColorDrawable(Color.WHITE)).fitCenter().into(mContentIv);
                mMainLayout.findViewById(R.id.linearLayoutInfos).setVisibility(View.GONE);
            } else {
                mRequestManager.load(adDataModel.getpImg()).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().centerCrop().into(mContentIv);
            }

            setProductClickListener(purl, adDataModel);
        }
    }

    private void drawMobWithUI(AdDataModel adDataModel, String logoUrl, String logoDefault, String impUrl) {
        LogPrint.d("drawMobWithUI");
        AdDataImageModel imageModel = adDataModel.getAdImageModel();

        final String purl = adDataModel.getpUrl();
        final ArrayList<String> imgArray = (imageModel != null)
                ? imageModel.getImageArray(mBannerType) : new ArrayList<>();
        if (imgArray.isEmpty()) {
            imgArray.add(adDataModel.getpImg());
        }

        ImageView mContentIv;
        int size = imgArray.size();

        for (int i = 0; i < size; i++) {
            if (imgArray.get(i).isEmpty()) {
                continue;
            }

            if (i >= (size - 2)) {
                String title;
                String price;

                if (TextUtils.equals(mBannerType, BannerType.BANNER_300x250)) {
                    View.inflate(mContext, (isPointBanner ? R.layout.banner_300_250_point_layout : R.layout.banner_sr_300_250_layout), mMainLayout);
                    try {
                        mMainLayout.findViewById(R.id.logo_img).setVisibility(View.GONE);
                    } catch (Exception ignored) {
                    }

                    title = adDataModel.getaTitle();
                    price = adDataModel.getaDesc3();

                    if (title.isEmpty()) {
                        title = adDataModel.getpNm();
                    }
                    if (price.isEmpty()) {
                        price = adDataModel.getPrice();
                    }
                } else {
                    View.inflate(mContext, R.layout.banner_50_theme1_layout, mMainLayout);

                    if (TextUtils.isEmpty(adDataModel.getpCode())) { // 비상품
                        title = adDataModel.getpNm();
                        String desc = adDataModel.getDesc();
                        price = TextUtils.isEmpty(desc) ? adDataModel.getaDesc3() : desc;
                    } else {
                        title = adDataModel.getpNm();
                        price = adDataModel.getPrice();
                    }
                }

                mContentIv = mMainLayout.findViewById(R.id.t_img);
                TextView mTitle = mMainLayout.findViewById(R.id.t_title);
                TextView mPrice = mMainLayout.findViewById(R.id.t_price);

                mTitle.setText(title);
                mPrice.setText(price);

                if (isPointBanner) {
                    mRequestManager.load(imgArray.get(i)).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(mContentIv);
                    if (adDataModel.getpCode().isEmpty()) {
                        mMainLayout.findViewById(R.id.linearLayoutInfos).setVisibility(View.GONE);
                    }
                } else {
                    mRequestManager.load(imgArray.get(i)).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().centerCrop().into(mContentIv);
                }
            } else {
                View.inflate(mContext, R.layout.banner_ad_layout, mMainLayout);
                mContentIv = mMainLayout.findViewById(R.id.t_img);
                mRequestManager.load(imgArray.get(i)).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(mContentIv);
                if (MobwithSDK.isFullScreenMode) {
                    mContentIv.setScaleType(ImageView.ScaleType.FIT_XY);
                }
            }
            break;
        }

        mMainLayout.setOnClickListener(v -> {
            LogPrint.d("drawMobWithUI click");
            Utils.getBrowserPackageName(mContext, purl, mediationAdListener);

            if (mediationAdListener != null) {
                mediationAdListener.onAdClicked();
            }

            sendCustomClickEvent(adDataModel.getCustom09());
            CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
        });

        setupMarkImage(mMainLayout.findViewById(R.id.mark_img), logoUrl, logoDefault);

        sendImpressionWith(adDataModel.getCustom08(), impUrl);
        CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
    }

    private void drawCoupangUI(AdDataModel adDataModel, String impUrl) {
        View.inflate(mContext, resolveBannerLayoutId(), mMainLayout);

        ImageView mContentIv = mMainLayout.findViewById(R.id.t_img);
        TextView mTitle = mMainLayout.findViewById(R.id.t_title);
        TextView mPrice = mMainLayout.findViewById(R.id.t_price);
        ImageView mark_img = mMainLayout.findViewById(R.id.mark_img);
        final String purl = adDataModel.getpUrl();

        mark_img.setVisibility(View.GONE);
        mTitle.setText(adDataModel.getpNm());
        mPrice.setText(adDataModel.getPrice());

        if (isPointBanner) {
            mRequestManager.load(adDataModel.getpImg()).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(mContentIv);
        } else {
            mRequestManager.load(adDataModel.getpImg()).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().centerCrop().into(mContentIv);
        }

        setProductClickListener(purl, adDataModel);

        sendImpressionWith(adDataModel.getCustom08(), impUrl);
        CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
    }

    private boolean drawUIForHeight100(AdDataModel adDataModel, String logoUrl, String logoDefault, String impUrl) {
        AdDataImageModel adDataImageModel = adDataModel.getAdImageModel();

        final String purl = adDataModel.getpUrl();
        final boolean isUseOnlyImage = adDataImageModel.isUseOnlyImage(mBannerType);
        final String imageUrl = adDataImageModel.getImageUrlFor320x100();

        if (imageUrl.isEmpty()) {
            return false;
        }

        ImageView mContentIv;

        if (isUseOnlyImage) {
            View.inflate(mContext, R.layout.banner_ad_layout, mMainLayout);
            mContentIv = mMainLayout.findViewById(R.id.t_img);
            mRequestManager.load(imageUrl).placeholder(new ColorDrawable(Color.TRANSPARENT)).centerCrop().into(mContentIv);
            if (MobwithSDK.isFullScreenMode) {
                mContentIv.setScaleType(ImageView.ScaleType.FIT_XY);
            }
        } else {
            View.inflate(mContext, R.layout.banner_100_layout, mMainLayout);
            mContentIv = mMainLayout.findViewById(R.id.t_img);
            TextView mTitle = mMainLayout.findViewById(R.id.t_title);
            TextView mPrice = mMainLayout.findViewById(R.id.t_price);
            ImageView logo_img = mMainLayout.findViewById(R.id.logo_img);

            final String desc3 = adDataModel.getaDesc3();
            final String logoImage = adDataModel.getaLogoDefault();
            final String logoSubImage = adDataModel.getaLogoSub();

            mTitle.setText(desc3.isEmpty() ? adDataModel.getpNm() : desc3);
            mPrice.setText(adDataModel.getPrice());

            mRequestManager.load(imageUrl).placeholder(new ColorDrawable(Color.TRANSPARENT)).centerCrop().into(mContentIv);

            if (!logoImage.isEmpty()) {
                mRequestManager.load(logoImage).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(logo_img);
            } else if (!logoSubImage.isEmpty()) {
                mRequestManager.load(logoSubImage).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(logo_img);
            }
        }

        setupMarkImage(mMainLayout.findViewById(R.id.mark_img), logoUrl, logoDefault);

        mMainLayout.setOnClickListener(v -> {
            Utils.getBrowserPackageName(mContext, purl, mediationAdListener);
            if (mediationAdListener != null) {
                mediationAdListener.onAdClicked();
            }
            sendCustomClickEvent(adDataModel.getCustom09());
            CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
        });

        sendImpressionWith(adDataModel.getCustom08(), impUrl);
        CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);

        return true;
    }

    @Override
    public void destroy() {
        super.destroy();

        try {
            if (mMainLayout != null && mMainLayout.getChildCount() > 0) {
                mMainLayout.removeAllViews();
                mMainLayout = null;
            }
        } catch (Exception e) {
            LogPrint.d("[JSONAdapter] " + e.getLocalizedMessage());
        }
    }

    public Object getAdView() {
        return mMainLayout;
    }

    public boolean isMixerLoaded() {
        return isMixerLoaded;
    }

    public MixerState getMixerState() {
        return mixerState;
    }

    @Override
    public boolean isLoaded() {
        if (mBannerType.equals(BannerType.NATIVE_AD) || mBannerType.equals(BannerType.INTERSTITIAL)
                || mBannerType.equals(BannerType.ENDING) || mBannerType.equals(BannerType.TRANSITION)) {
            MMAdData adData = getAdData();
            return adData != null && !TextUtils.isEmpty(adData.jsonData);
        }
        return isREwardAdLoaded && isRewardAD;
    }

    private void sendImpressionWith(String custom08, String impUrl) {
        String realImpUrl;

        if (custom08 != null && !custom08.isEmpty()) {
            realImpUrl = custom08;
        } else if (impUrl != null && !impUrl.isEmpty()) {
            realImpUrl = impUrl;
        } else {
            return;
        }

        LogPrint.d("sendImpressionWith - JsonAdapter : " + realImpUrl);
        MWRequestCustomURL.requestWith(mContext, realImpUrl, "Custom Impression");
    }

    // Mezzo, 디켐 에서 클릭시 콜백 URL호출을 요구하는 부분에 대응하기 위함. 현 시점(mobon, coupang에서는 호출부분 구현할 필요 없음)
    private void sendCustomClickEvent(String clickUrl) {
        if (clickUrl == null || clickUrl.isEmpty()) {
            return;
        }
        MWRequestCustomURL.requestWith(mContext, clickUrl, "Custom Click");
    }

    private void setJsonData(AdDataResponseModel model) {
        LogPrint.d("setJsonData...");
        AdDataResponseDataModel dataModel = (model == null) ? null : model.getData();

        if (model == null || !model.isSuccess() || dataModel == null) {
            sendOnAdFailedToLoad("NO FILL");
            return;
        }

        setLayout(mBannerType);

        final String logoUrl = dataModel.getLogoUrl();
        final String logoDefault = dataModel.getLogoDefault();
        final String impUrl = dataModel.getImpUrl();

        final AdDataModel adDataModel = dataModel.getFirstAd();
        if (adDataModel == null) {
            sendOnAdFailedToLoad("NO FILL");
            return;
        }

        LogPrint.d("mBannerType : " + mBannerType);

        if (isStandardBanner()) {
            if (hasUnsupportedVideo(adDataModel)) {
                sendOnAdFailedToLoad("Unsupported video format for this ad type");
                return;
            }

            MainThreadHandler.post(() -> {
                if (mExid.startsWith(IntegrationHelper.COUPANG)) {
                    drawCoupangUI(adDataModel, impUrl);
                } else if (mExid.startsWith(IntegrationHelper.MOBON)) {
                    drawMobonUI(adDataModel, logoUrl, logoDefault, impUrl);
                } else {
                    drawMobWithUI(adDataModel, logoUrl, logoDefault, impUrl);
                }
                sendOnLoadAd();
            });
        } else if (mBannerType.equals(BannerType.BANNER_320x100)) {
            if (hasUnsupportedVideo(adDataModel)) {
                sendOnAdFailedToLoad("Unsupported video format for this ad type");
                return;
            }

            MainThreadHandler.post(() -> {
                if (drawUIForHeight100(adDataModel, logoUrl, logoDefault, impUrl)) {
                    sendOnLoadAd();
                } else {
                    sendOnAdFailedToLoad("NO FILL");
                }
            });
        } else if (mBannerType.equals(BannerType.TRANSITION)
                || mBannerType.equals(BannerType.ENDING)) {
            if (hasUnsupportedVideo(adDataModel)) {
                sendOnAdFailedToLoad("Unsupported video format for this ad type");
                return;
            }
            deliverJsonAdData(model);
        } else {
            // Video Data 확인
            if (containsNoAd(adDataModel.getVideoAd()) || containsNoAd(adDataModel.getCustom10())) {
                sendOnAdFailedToLoad("NO FILL");
                return;
            }
            deliverJsonAdData(model);
        }
    }

    private void setSplashData(MWSplashAdResponse model){
        if (model == null || !model.isSuccess() || model.getData() == null || model.getData().getAdvertInfo() == null) {
            sendOnAdFailedToLoad("NO FILL");
            return;
        }
        deliverSplashAdData(model);
    }

    public void setMixerState(MixerState mixerState) {
        this.mixerState = mixerState;
    }

    private void checkParallelMixerAD() {
        LogPrint.d("checkParallelMixerAD?");
        try {
            mixerState = MixerState.LOADING;

            if (getAdData() != null) {
                handleMixerAdData();
                return;
            }

            for (int i = 0; i < PARALLEL_RETRY_COUNT; i++) {
                Thread.sleep(PARALLEL_RETRY_DELAY_MS);
                LogPrint.d("Parallel 데이터 확인 : mExid : " + mExid);
                if (getAdData() != null) {
                    handleMixerAdData();
                    return;
                }
            }

            mixerState = MixerState.FAILED;
            sendOnAdFailedToLoad("NO FILL : Mixer Timeout");
        } catch (Exception e) {
            mixerState = MixerState.FAILED;
            sendOnAdFailedToLoad("NO FILL : " + e.getLocalizedMessage());
        }
    }

    private void handleMixerAdData() throws Exception {
        if (!getAdData().checkNoAD()) {
            isMixerLoaded = true;
            mixerState = MixerState.LOADED;
            setJsonData(new AdDataResponseModel(new JSONObject(getAdData().jsonData)));
        } else {
            sendOnAdFailedToLoad("NO FILL");
            mixerState = MixerState.FAILED;
        }
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    /**
     * 일반 상품/이미지 배너(네이티브·전면·320x100 등 특수 타입 제외) 여부.
     */
    private boolean isStandardBanner() {
        return !mBannerType.equals(BannerType.NATIVE_AD)
                && !mBannerType.equals(BannerType.INTERSTITIAL)
                && !mBannerType.equals(BannerType.TRANSITION)
                && !mBannerType.equals(BannerType.ENDING)
                && !mBannerType.equals(BannerType.SPLASH_AD)
                && !mBannerType.equals(BannerType.ENDING_BANNER)
                && !mBannerType.equals(BannerType.BANNER_320x100)
                && !mBannerType.equals(BannerType.REWARD_VIDEO);
    }

    private boolean hasUnsupportedVideo(AdDataModel ad) {
        return !ad.getVideoAd().isEmpty() || !ad.getCustom10().isEmpty();
    }

    private boolean containsNoAd(String value) {
        return value.contains("noad");
    }

    private void deliverJsonAdData(AdDataResponseModel model) {
        MMAdData adData = new MMAdData();
        adData.type = SortList.Type.NONE;
        adData.jsonData = model.getJsonString();
        adData.exid = mExid;

        setAdData(adData);
        sendOnLoadAd();
    }

    private void deliverSplashAdData(MWSplashAdResponse model) {
        MMAdData adData = new MMAdData();
        adData.type = SortList.Type.NONE;
        adData.jsonData = model.getJsonData();
        adData.exid = mExid;

        setSplashData(model.getData());
        sendOnLoadAd();
    }

    /**
     * 300x250 은 포인트 여부에 따라, 그 외는 theme1 레이아웃을 사용.
     */
    private int resolveBannerLayoutId() {
        if (TextUtils.equals(mBannerType, BannerType.BANNER_300x250)) {
            return isPointBanner ? R.layout.banner_300_250_point_layout : R.layout.banner_sr_300_250_layout;
        }
        return R.layout.banner_50_theme1_layout;
    }

    private boolean isSupportedImageExt(String ext) {
        return ext.equalsIgnoreCase("jpg") || ext.equalsIgnoreCase("png") || ext.equalsIgnoreCase("gif");
    }

    private boolean isCtaReplaceCode(String advrtsReplcCode) {
        return TextUtils.equals(advrtsReplcCode, "02") || TextUtils.equals(advrtsReplcCode, "2");
    }

    /**
     * advrtsReplcCode 가 CTA 치환 코드일 때 가격 영역을 CTA 버튼 형태로 스타일링.
     */
    private void applyCtaPriceStyle(TextView mPrice, String ctaText) {
        ViewGroup.LayoutParams params = mPrice.getLayoutParams();
        int width = Utils.convertDpToPx(mContext, 26);
        params.width = Utils.convertDpToPx(mContext, width);
        params.height = Utils.convertDpToPx(mContext, 3);
        mPrice.setLayoutParams(params);
        mPrice.setGravity(Gravity.CENTER);
        mPrice.setTextColor(Color.WHITE);
        mPrice.setText(ctaText);
        mPrice.setPadding(Utils.convertDpToPx(mContext, 10), 0, Utils.convertDpToPx(mContext, 10), 0);
        mPrice.setTextSize(Utils.convertDpToPx(mContext, 4));
        mPrice.setBackground(ContextCompat.getDrawable(mContext, R.drawable.round_banner_text));
    }

    /**
     * 광고 마크(로고) 이미지 표시 및 클릭 처리. logoUrl/logoDefault 가 없으면 숨김.
     */
    private void setupMarkImage(ImageView markImg, String logoUrl, String logoDefault) {
        if (markImg == null) {
            return;
        }
        if (TextUtils.isEmpty(logoUrl) || logoDefault == null || logoDefault.isEmpty()) {
            markImg.setVisibility(View.GONE);
            return;
        }

        markImg.setImageBitmap(null);
        markImg.setBackground(null);
        mRequestManager.load(logoDefault).placeholder(new ColorDrawable(Color.TRANSPARENT)).fitCenter().into(markImg);
        markImg.setOnClickListener(v -> Utils.getBrowserPackageName(mContext, logoUrl, mediationAdListener));
    }

    /**
     * Mobon/Coupang 상품 배너 클릭 처리 (클릭 트래커는 리스너가 있을 때만 전송).
     */
    private void setProductClickListener(String purl, AdDataModel adDataModel) {
        mMainLayout.setOnClickListener(v -> {
            Utils.getBrowserPackageName(mContext, purl, mediationAdListener);
            if (mediationAdListener != null) {
                mediationAdListener.onAdClicked();
                CommonUtils.sendClickTrackersEvent(mContext, adDataModel);
            }
        });
    }


}