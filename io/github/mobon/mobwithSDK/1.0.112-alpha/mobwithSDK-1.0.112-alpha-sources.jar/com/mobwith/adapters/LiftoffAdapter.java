//package com.mobwith.adapters;
//
//import android.content.Context;
//import android.os.Handler;
//import android.os.Looper;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.view.ViewTreeObserver;
//import android.widget.Button;
//import android.widget.FrameLayout;
//import android.widget.ImageView;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//
//import com.mobwith.manager.LogPrint;
//import com.mobwith.manager.MediationAdListener;
//import com.mobwith.manager.MediationAdSize;
//import com.mobwith.sdk.BannerType;
//import com.mobwith.sdk.api.MWRequestImpression;
//import com.mobwith.sdk.loader.MMAdData;
//import com.vungle.ads.AdConfig;
//import com.vungle.ads.BannerAdListener;
//import com.vungle.ads.BaseAd;
//import com.vungle.ads.InitializationListener;
//import com.vungle.ads.InterstitialAd;
//import com.vungle.ads.InterstitialAdListener;
//import com.vungle.ads.NativeAd;
//import com.vungle.ads.NativeAdListener;
//import com.vungle.ads.RewardedAd;
//import com.vungle.ads.RewardedAdListener;
//import com.vungle.ads.VungleAdSize;
//import com.vungle.ads.VungleAds;
//import com.vungle.ads.VungleBannerView;
//import com.vungle.ads.VungleError;
//import com.vungle.ads.internal.ui.view.MediaView;
//import java.util.ArrayList;
//
//public class LiftoffAdapter extends AdapterObject {
//
//    private static String appKey = "";
//    private Context mContext;
//    private String mUnitId;
//    private String mScriptNo;
//    private boolean isInitialized = false;
//    private boolean isInterstitialAdLoaded = false;
//    private boolean isRewardedVideoAdLoaded = false;
//    private MediationAdListener mediationAdListener;
//    private VungleBannerView bannerView;
//    private InterstitialAd interstitialAd;
//    private RewardedAd rewardedAd;
//    private NativeAd nativeAd;
//    public LiftoffAdapter(Context context, String name, String mediaKey, String unitId, String AdType, MMAdData adData, boolean isTestMode, boolean isAdapter, String siteNo) {
//        super(name, mediaKey, unitId, AdType, adData, isTestMode, isAdapter);
//
//        mContext = context;
//        mUnitId = unitId;
//        mScriptNo = siteNo;
//
//        if (AdType.equals(BannerType.INTERSTITIAL)) {
//            mAdType = MediationAdSize.INTERSTITIAL;
//        } else if (AdType.equals(BannerType.BANNER_320x50)) {
//            mAdType = MediationAdSize.BANNER_320_50;
//        } else if (AdType.equals(BannerType.BANNER_320x100)) {
//            mAdType = MediationAdSize.BANNER_320_50;
//        } else if (AdType.equals(BannerType.BANNER_300x250)) {
//            mAdType = MediationAdSize.BANNER_300_250;
//        } else if (AdType.equals(BannerType.REWARD_VIDEO)) {
//            mAdType = MediationAdSize.REWARD_VIDEO;
//        }
//
//        initialize();
//    }
//
//    public static void initSDK(String appKey) {
//        LiftoffAdapter.appKey = appKey;
//    }
//
//    private void initialize() {
//
//        if (isInitialized) {
//            return;
//        }
//
//        VungleAds.init(mContext, appKey, new InitializationListener() {
//            @Override
//            public void onSuccess() {
//                LogPrint.d("Liftoff Init Successful");
//                isInitialized = true;
//            }
//
//            @Override
//            public void onError(@NonNull VungleError vungleError) {
//                LogPrint.d("Liftoff Init failed -" + vungleError.getMessage());
//                isInitialized = false;
//            }
//        });
//    }
//
//    @Override
//    public void setAdListner(MediationAdListener _listner) {
//        mediationAdListener = _listner;
//    }
//
//    @Override
//    public void onPause() {
//        super.onPause();
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//    }
//
//    @Override
//    public void destroy() {
//        super.destroy();
//    }
//
//    @Override
//    public boolean canUseNativeAdView() {
//        return true;
//    }
//
//    @Override
//    public void load(String AdType) {
//        super.load(AdType);
//
//        if (appKey.isEmpty()) {
//            //SDK 초기화 실패 (AppId 누락)
//            if (mediationAdListener != null) {
//                mediationAdListener.onAdFailedToLoad("Liftoff SDK 초기화 실패(AppId 누락)");
//            }
//            return;
//        }
//
//        if (!isInitialized) {
//            initialize();
//
//            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    load(AdType);
//                }
//            }, 500);
//
//            return;
//        }
//
//        if (TextUtils.equals(AdType, BannerType.NATIVE_AD)) {
//            loadNativeAd();
//        } else if (TextUtils.equals(AdType, BannerType.INTERSTITIAL) || TextUtils.equals(AdType, BannerType.INTERSTITIAL_POPUP)) {
//            loadAdInterstitial();
//        } else if (TextUtils.equals(AdType, BannerType.REWARD_VIDEO)) {
//            loadAdRewardedVideo();
//        } else {
//            loadAdBanner();
//        }
//
//        sendImpression();
//    }
//
//    @Override
//    public Object getAdView() {
//        return bannerView;
//    }
//
//    @Override
//    public boolean show() {
//        if (mAdType == MediationAdSize.INTERSTITIAL) {
//            if (interstitialAd != null && interstitialAd.canPlayAd()) {
//                interstitialAd.play(mContext);
//                return true;
//            } else {
//                return false;
//            }
//        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
//            // Show the ad using the Activity's context
//            if (rewardedAd != null && rewardedAd.canPlayAd()) {
//                rewardedAd.play(mContext);
//                return true;
//            } else {
//                return false;
//            }
//        } else {
//            return false;
//        }
//    }
//
//    @Override
//    public boolean isLoaded() {
//        if (mAdType == MediationAdSize.INTERSTITIAL) {
//            return isInterstitialAdLoaded;
//        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
//            return isRewardedVideoAdLoaded;
//        } else {
//            return false;
//        }
//    }
//
//    @Override
//    public void loadNativeAd() {
//        nativeAd = new NativeAd(mContext, mUnitId);
//        nativeAd.setAdListener(new NativeAdListener() {
//            @Override
//            public void onAdLoaded(@NonNull BaseAd baseAd) {
//
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdLoaded();
//                }
//
//                try {
//                    View inflatedView = LayoutInflater.from(mContext).inflate(mAdViewItem.mViewLayoutID, null);
//
//                    ImageView logo = inflatedView.findViewById(mAdViewItem.mADLogoImageViewID);
//
//                    TextView title = inflatedView.findViewById(mAdViewItem.mTitleViewID);
//                    TextView desc = inflatedView.findViewById(mAdViewItem.mDescViewID);
//                    FrameLayout mediaViewContainer = inflatedView.findViewById(mAdViewItem.mMediaViewContainerID);
//                    View callToAction = inflatedView.findViewById(mAdViewItem.mGotoSiteViewID);
//                    FrameLayout root = mAdViewItem.mContainerView;
//                    MediaView mediaView = new MediaView(mContext);
//                    mediaViewContainer.addView(mediaView);
//
//                    ArrayList<View> clickableViews = new ArrayList<>();
//                    clickableViews.add(root);
//                    clickableViews.add(callToAction);
//
//                    nativeAd.registerViewForInteraction(root, mediaView, logo, clickableViews);
//
//                    if (title != null) {
//                        title.setText(nativeAd.getAdTitle());
//                    }
//
//                    if (desc != null) {
//                        desc.setText(nativeAd.getAdBodyText());
//                    }
//
//                    if (callToAction != null) {
//                        if (callToAction instanceof Button) {
//                            Button callTextView = (Button) callToAction;
//                            callTextView.setText(nativeAd.getAdCallToActionText());
//                        } else if (callToAction instanceof TextView) {
//                            TextView callTextView = (TextView) callToAction;
//                            callTextView.setText(nativeAd.getAdCallToActionText());
//                        }
//                    }
//
//                    mAdViewItem.mContainerView.removeAllViews();
//                    mAdViewItem.mContainerView.addView(inflatedView);
//
//                    if (mediationAdListener != null) {
//                        mediationAdListener.onAdDisplayed();
//                    }
//
//                } catch (Exception e) {
//                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - " + e.getLocalizedMessage());
//                }
//            }
//
//            @Override
//            public void onAdStart(@NonNull BaseAd baseAd) {
//                LogPrint.d("onAdStart");
//            }
//
//            @Override
//            public void onAdImpression(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdImpression();
//                }
//            }
//
//            @Override
//            public void onAdEnd(@NonNull BaseAd baseAd) {
//
//            }
//
//            @Override
//            public void onAdClicked(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdClicked();
//                }
//            }
//
//            @Override
//            public void onAdLeftApplication(@NonNull BaseAd baseAd) {
//
//            }
//
//            @Override
//            public void onAdFailedToLoad(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - " + vungleError.getErrorMessage());
//                }
//            }
//
//            @Override
//            public void onAdFailedToPlay(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdFailedToLoad("광고를 불러오는데 실패하였습니다 - " + vungleError.getErrorMessage());
//                }
//            }
//        });
//
//        nativeAd.load("");
//    }
//
//    private void loadAdBanner() {
//        //"BANNER_NON_BIDDING-4570799"
//        VungleAdSize vungleAdSize = VungleAdSize.BANNER;
//
//        if (mAdType == MediationAdSize.BANNER_300_250){
//            vungleAdSize = VungleAdSize.MREC;
//        }
//
//        bannerView = new VungleBannerView(mContext, mUnitId, vungleAdSize);
//        bannerView.setAdListener(new BannerAdListener() {
//            @Override
//            public void onAdLoaded(@NonNull BaseAd baseAd) {
//                LogPrint.d("onAdLoaded");
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdLoaded();
//                }
//            }
//
//            @Override
//            public void onAdStart(@NonNull BaseAd baseAd) {
//                LogPrint.d("onAdStart");
//            }
//
//            @Override
//            public void onAdImpression(@NonNull BaseAd baseAd) {
//                LogPrint.d("onAdImpression");
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdImpression();
//                }
//            }
//
//            @Override
//            public void onAdEnd(@NonNull BaseAd baseAd) {
//                LogPrint.d("onAdEnd");
//            }
//
//            @Override
//            public void onAdClicked(@NonNull BaseAd baseAd) {
//                LogPrint.d("onAdClicked");
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdClicked();
//                }
//            }
//
//            @Override
//            public void onAdLeftApplication(@NonNull BaseAd baseAd) {LogPrint.d("onAdLeftApplication");}
//
//            @Override
//            public void onAdFailedToLoad(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {
//                LogPrint.d("onAdFailedToLoad");
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdFailedToLoad("Liftoff 배너 광고 로드 실패 : " + vungleError.getLocalizedMessage());
//                }
//            }
//
//            @Override
//            public void onAdFailedToPlay(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {LogPrint.d("onAdFailedToPlay");}
//        });
//
//        bannerView.load("");
//    }
//
//    private void loadAdInterstitial() {
//        interstitialAd = new InterstitialAd(mContext, mUnitId, new AdConfig());
//        interstitialAd.setAdListener(new InterstitialAdListener() {
//            @Override
//            public void onAdLoaded(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    isInterstitialAdLoaded = true;
//                    mediationAdListener.onAdLoaded();
//                }
//            }
//
//
//            @Override
//            public void onAdStart(@NonNull BaseAd baseAd) {}
//
//            @Override
//            public void onAdImpression(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdImpression();
//                }
//            }
//
//            @Override
//            public void onAdEnd(@NonNull BaseAd baseAd) {}
//
//            @Override
//            public void onAdClicked(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdClicked();
//                }
//            }
//
//            @Override
//            public void onAdLeftApplication(@NonNull BaseAd baseAd) {}
//
//            @Override
//            public void onAdFailedToLoad(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {
//                if (mediationAdListener != null) {
//                    isInterstitialAdLoaded = false;
//                    mediationAdListener.onAdFailedToLoad("Liftoff 전면 광고 로드 실패 : " + vungleError.getLocalizedMessage());
//                }
//            }
//
//            @Override
//            public void onAdFailedToPlay(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {}
//        });
//        interstitialAd.load(null);
//    }
//
//    private void loadAdRewardedVideo() {
//        rewardedAd = new RewardedAd(mContext, mUnitId, new AdConfig());
//        rewardedAd.setAdListener(new RewardedAdListener() {
//            @Override
//            public void onAdRewarded(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdComplete();
//                }
//            }
//
//            @Override
//            public void onAdLoaded(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    isRewardedVideoAdLoaded = true;
//                    mediationAdListener.onAdLoaded();
//                }
//            }
//
//            @Override
//            public void onAdStart(@NonNull BaseAd baseAd) {}
//
//            @Override
//            public void onAdImpression(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdImpression();
//                }
//            }
//
//            @Override
//            public void onAdEnd(@NonNull BaseAd baseAd) {}
//
//            @Override
//            public void onAdClicked(@NonNull BaseAd baseAd) {
//                if (mediationAdListener != null) {
//                    mediationAdListener.onAdClicked();
//                }
//            }
//
//            @Override
//            public void onAdLeftApplication(@NonNull BaseAd baseAd) {}
//
//            @Override
//            public void onAdFailedToLoad(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {
//                if (mediationAdListener != null) {
//                    isRewardedVideoAdLoaded = false;
//                    mediationAdListener.onAdFailedToLoad("Liftoff 리워드 광고 로드 실패 : " + vungleError.getLocalizedMessage());
//                }
//            }
//
//            @Override
//            public void onAdFailedToPlay(@NonNull BaseAd baseAd, @NonNull VungleError vungleError) {}
//        });
//        rewardedAd.load(null);
//    }
//
//    private void sendImpression() {
//        MWRequestImpression.requestWith(mContext, mScriptNo, "LiftOff", null);
//    }
//}
