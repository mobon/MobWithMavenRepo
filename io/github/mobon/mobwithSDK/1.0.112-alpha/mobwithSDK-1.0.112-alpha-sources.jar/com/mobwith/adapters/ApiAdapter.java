package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.getApplicationName;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.R;
import com.mobwith.sdk.Url;
import com.mobwith.sdk.callback.iScriptAdViewCallback;
import com.mobwith.sdk.models.SortListItemModel;

import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class ApiAdapter extends AdapterObject {

    private static final String JS_BRIDGE_NAME = "mobwithBridge";
    private static final String POSTBACK_URL = "https://mobwithsdk/postback";
    private View root;
    private WebView mWebview;
    private Context mContext;
    private SortListItemModel itemModel;
    private String mediaScriptSize;
    private String zone;
    private MediationAdListener mediationAdListener;
    private iScriptAdViewCallback callback;
    private boolean isAdLoaded = false;
    private boolean isFailed = false;

    private Thread checkAdLoaded = new Thread(() -> {
        for (int i = 0; i < 5; i++) {
            try {
                if (isFailed) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(Key.NOFILL);
                    }
                    break;
                } else {
                    if ((isAdLoaded || i == 4) && mediationAdListener != null) {
                        isAdLoaded = true;
                        mediationAdListener.onAdLoaded();
                        if (callback != null) {
                            callback.onImpression(itemModel);
                        }
                        break;
                    }
                }
                Thread.sleep(500);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });

    public ApiAdapter(Context context, String name, String unitId, String zoneId, String AdType, SortListItemModel itemModel, String mediaScriptSize) {
        super(name, unitId, AdType, null, false);
        this.zone = zoneId;
        this.mContext = context;
        this.itemModel = itemModel;
        this.mediaScriptSize = mediaScriptSize;
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }

    public void setScriptAdViewCallback(iScriptAdViewCallback callback) {
        this.callback = callback;
    }

    @Override
    public void load(String AdType) {
        super.load(AdType);

        isAdLoaded = false;
        isFailed = false;

        if (AdType.contains("INTERSTITIAL") || AdType.contains("REWARD")) {
            setUi();
        } else {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("Unsupported video format for this ad type");
            }
        }
    }

    public String getScriptAdUrl() {
        int w;
        int h;
        switch (mediaScriptSize) {
            case "300px*250px":
                w = 300;
                h = 250;
                break;
            case "320px*100px":
                w = 320;
                h = 100;
                break;
            default:
                w = 320;
                h = 50;
                break;
        }

        return new BannerUrlBuilder()
                .zone(zone)
                .exId(itemModel.sortlist)
                .unitId(itemModel.unitId)
                .adStyle("interstitial")
                .size(w, h)
                .adid(CommonUtils.getAdid(mContext))
                .appId(mContext.getPackageName())       //패키지명
                .appName(getApplicationName(mContext))  //앱 이름
                .appVersion(CommonUtils.getAppVersion(mContext))
                .exlItlSeq(itemModel.exlItlSeq)
                .appStoreUrl("https://play.google.com/store/apps/details?id= " + mContext.getPackageName())
                .build();
    }

    @Override
    public boolean isLoaded() {
        return isAdLoaded;
    }

    @Override
    public Object getAdView() {
        return root;
    }

    @Override
    public boolean show() {
        try {
            if (mWebview != null) {
                String script =
                        "(function() {" +
                                "  window.MobwithAD.startExposure();" +
                                "})();";
                mWebview.evaluateJavascript(script, null);
            }
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
        return super.show();
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        try {
            if (mWebview != null) {
                String script =
                        "(function() {" +
                                "  window.MobwithAD.startExposure();" +
                                "})();";
                mWebview.evaluateJavascript(script, null);
            }
        } catch (Exception e) {
            LogPrint.d(e.getMessage());
        }
        return super.show(activity);
    }

    @Override
    public void destroy() {
        super.destroy();
        try {
            if (mWebview != null) {
                mWebview.stopLoading();
                mWebview.setWebViewClient(null);
                mWebview.setWebChromeClient(null);
                mWebview.removeJavascriptInterface(JS_BRIDGE_NAME);
                ViewParent parent = mWebview.getParent();
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(mWebview);
                }
                mWebview.destroy();
                mWebview = null;
            }
            root = null;
        } catch (Exception e) {
            LogPrint.d("[ApiAdapter] " + e.getLocalizedMessage());
        }
    }

    private void setUi() {
        try {
            root = LayoutInflater.from(mContext).inflate(R.layout.banner_script_interstitial_layout, new FrameLayout(mContext), true);
            mWebview = root.findViewById(R.id.webView);
            setupWebView(mWebview);
            String scriptAdUrl = getScriptAdUrl();
            LogPrint.d("scriptAdUrl : " + scriptAdUrl);
            mWebview.loadUrl(scriptAdUrl);
        } catch (Exception e) {
            callback.onFailOpened();
        }
    }

    private void setupWebView(WebView webView) {
        WebSettings settings = webView.getSettings();

        // 자바스크립트 실행 허용
        settings.setJavaScriptEnabled(true);

        // DOM 스토리지 (localStorage 등) 사용 허용
        settings.setDomStorageEnabled(true);

        // 줌 컨트롤 (필요에 따라 조절)
        settings.setSupportZoom(false);
        settings.setDisplayZoomControls(false);

        // 화면 크기에 맞게 콘텐츠 조정
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // 캐시 모드
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.addJavascriptInterface(new AdBridge(), JS_BRIDGE_NAME);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (request.getUrl() != null) {
                        LogPrint.d("shouldOverrideUrlLoading : " + request.getUrl().toString());
                        if (callback != null) {
                            callback.onAdClicked(request.getUrl().toString());
                        }
                    }
                }
                return true;
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (request.getUrl().toString().equals(POSTBACK_URL)) {
                        isFailed = true;
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                checkAdLoaded.start();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                String msg = consoleMessage.message();
                LogPrint.d("console : " + msg);
                try {
                    if (msg.startsWith("{") && msg.endsWith("}")) {
                        JSONObject jsonObject = new JSONObject(msg);
                        LogPrint.d("result : " + jsonObject.optString("result"));
                        String result = jsonObject.optString("result");
                        if (result.equals("success")) {
                            isAdLoaded = true;
                            if (callback != null) {
                                callback.onImpression(itemModel);
                            }
                        } else if (result.equals("fail")) {
                            if (checkAdLoaded != null){
                                checkAdLoaded.interrupt();
                            }
                            if (mediationAdListener != null) {
                                mediationAdListener.onAdFailedToLoad(Key.NOFILL);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return super.onConsoleMessage(consoleMessage);
            }
        });
    }

    private final class AdBridge {

        @JavascriptInterface
        public void postMessage(String message) {
            try {
                LogPrint.d("bridge message: " + message);
                JSONObject json = new JSONObject(message);
                String type = json.optString("type");

                switch (type) {
                    case "close":
                        if (callback != null) {
                            callback.onClose();
                            checkAdLoaded = null;
                        }
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public final class BannerUrlBuilder {
        public static final String KEY_ZONE = "zone";
        public static final String KEY_EX_ID = "exId";
        public static final String KEY_UNIT_ID = "unitId";
        public static final String KEY_AD_STYLE = "adStyle";
        public static final String KEY_WIDTH = "w";
        public static final String KEY_HEIGHT = "h";
        public static final String KEY_ADID = "adid";
        public static final String KEY_APP_ID = "appId";
        public static final String KEY_APP_NAME = "appName";
        public static final String KEY_APP_VERSION = "appVersion";
        public static final String KEY_EXLITL_SEQ = "exlItlSeq";
        public static final String KEY_APP_STORE_URL = "appStoreUrl";
        /**
         * 입력 순서를 유지해서 URL 파라미터 순서가 항상 일정하도록 LinkedHashMap 사용
         */
        private final Map<String, String> params = new LinkedHashMap<>();

        public BannerUrlBuilder() {
        }

        // ------------------------------------------------------------------------
        // 타입이 정해진 setter
        // ------------------------------------------------------------------------

        public BannerUrlBuilder zone(@Nullable String zone) {
            return put(KEY_ZONE, zone);
        }

        public BannerUrlBuilder exId(@Nullable String exId) {
            return put(KEY_EX_ID, exId);
        }

        public BannerUrlBuilder unitId(@Nullable String unitId) {
            return put(KEY_UNIT_ID, unitId);
        }

        public BannerUrlBuilder adStyle(@Nullable String adStyle) {
            return put(KEY_AD_STYLE, adStyle);
        }

        public BannerUrlBuilder size(int width, int height) {
            put(KEY_WIDTH, width > 0 ? String.valueOf(width) : null);
            return put(KEY_HEIGHT, height > 0 ? String.valueOf(height) : null);
        }

        public BannerUrlBuilder adid(@Nullable String adid) {
            return put(KEY_ADID, adid);
        }

        public BannerUrlBuilder appId(@Nullable String appId) {
            return put(KEY_APP_ID, appId);
        }

        public BannerUrlBuilder appName(@Nullable String appName) {
            return put(KEY_APP_NAME, appName);
        }

        public BannerUrlBuilder appVersion(@Nullable String appVersion) {
            return put(KEY_APP_VERSION, appVersion);
        }

        public BannerUrlBuilder exlItlSeq(@Nullable String exlItlSeq) {
            return put(KEY_EXLITL_SEQ, exlItlSeq);
        }

        /**
         * 인코딩하지 않은 원본 URL을 넣으세요. build() 시점에 %3A%2F... 로 인코딩됩니다.
         */
        public BannerUrlBuilder appStoreUrl(@Nullable String appStoreUrl) {
            return put(KEY_APP_STORE_URL, appStoreUrl);
        }

        // ------------------------------------------------------------------------
        // 내부 공통
        // ------------------------------------------------------------------------

        /**
         * 값이 null/빈 문자열이면 해당 파라미터를 제외합니다. 같은 키는 나중 값으로 덮어씁니다.
         */
        private BannerUrlBuilder put(@NonNull String key, @Nullable String value) {
            if (TextUtils.isEmpty(value)) {
                params.remove(key);
            } else {
                params.put(key, value);
            }
            return this;
        }

        // ------------------------------------------------------------------------
        // 조립
        // ------------------------------------------------------------------------

        @NonNull
        public String build() {
            Uri.Builder builder = Uri.parse(Url.REQUEST_SCRIPT_INTERSTITIAL_AD).buildUpon();
            for (Map.Entry<String, String> e : params.entrySet()) {
                builder.appendQueryParameter(e.getKey(), e.getValue()); // 키/값 자동 인코딩
            }
            return builder.build().toString();
        }

        @Override
        public String toString() {
            return build();
        }
    }
}
