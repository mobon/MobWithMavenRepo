package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.sdk.BannerType;
import com.unity3d.mediation.LevelPlay;
import com.unity3d.mediation.LevelPlayAdError;
import com.unity3d.mediation.LevelPlayAdInfo;
import com.unity3d.mediation.LevelPlayAdSize;
import com.unity3d.mediation.LevelPlayConfiguration;
import com.unity3d.mediation.LevelPlayInitError;
import com.unity3d.mediation.LevelPlayInitListener;
import com.unity3d.mediation.LevelPlayInitRequest;
import com.unity3d.mediation.banner.LevelPlayBannerAdView;
import com.unity3d.mediation.banner.LevelPlayBannerAdViewListener;
import com.unity3d.mediation.interstitial.LevelPlayInterstitialAd;
import com.unity3d.mediation.interstitial.LevelPlayInterstitialAdListener;
import com.unity3d.mediation.rewarded.LevelPlayReward;
import com.unity3d.mediation.rewarded.LevelPlayRewardedAd;
import com.unity3d.mediation.rewarded.LevelPlayRewardedAdListener;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class LevelPlayAdapter extends AdapterObject {

    private final AtomicInteger RetryCount = new AtomicInteger(0);
    private final Context mContext;
    private final String mUnitId;
    private final String mScriptNo;
    private MediationAdListener mediationAdListener;
    private LevelPlayBannerAdView mAdView = null;
    private static boolean isInitialized = false;
    private static boolean isInInitialize = false;
    private static String appKey = "";
    private LevelPlayInterstitialAd mInterstitialAd;
    private LevelPlayRewardedAd mRewardedAd;

    public static void initSDK(Context context, String appKey) {
        LevelPlayAdapter.appKey = appKey;

        LevelPlayInitRequest initRequest = new LevelPlayInitRequest.Builder(appKey)
                .build();

        isInInitialize = true;

        List<LevelPlay.AdFormat> legacyAdFormats = Arrays.asList(
                LevelPlay.AdFormat.BANNER,
                LevelPlay.AdFormat.INTERSTITIAL,
                LevelPlay.AdFormat.REWARDED
//                LevelPlay.AdFormat.NATIVE_AD
        );

        LevelPlayInitListener initListener = new LevelPlayInitListener() {
            @Override
            public void onInitSuccess(@NonNull LevelPlayConfiguration configuration) {
                isInitialized = true;
                isInInitialize = false;
                LogPrint.d("[LevelPlayAdapter] init success\n");
            }

            @Override
            public void onInitFailed(@NonNull LevelPlayInitError error) {
                isInitialized = false;
                isInInitialize = false;
                LogPrint.d("[LevelPlayAdapter] init fail with -----\n" + error.getErrorMessage());
            }
        };

        LevelPlay.init(context, initRequest, initListener);
    }

    public LevelPlayAdapter(final Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mUnitId = unitId;
        mContext = context;
        mScriptNo = siteNo;

        switch (AdType) {
            case BannerType.INTERSTITIAL:
                mAdType = MediationAdSize.INTERSTITIAL;
                break;
            case BannerType.BANNER_320x50:
            case BannerType.BANNER_320x100:
                mAdType = MediationAdSize.BANNER_320_50;
                break;
            case BannerType.BANNER_300x250:
                mAdType = MediationAdSize.BANNER_300_250;
                break;
            case BannerType.REWARD_VIDEO:
                mAdType = MediationAdSize.REWARD_VIDEO;
                break;
        }
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }


    public void load(String type) {
        super.load(type);

        if (RetryCount.incrementAndGet() > 10) {
            RetryCount.set(0);

            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("LevelPlay SDK 초기화 실패");
            }

            return;
        }

        if (!isInInitialize && !isInitialized) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> load(type), 500);
            return;
        }

        if (isInInitialize) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> load(type), 500);
            return;
        }

        RetryCount.set(0);

        if (!isInitialized) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("LevelPlay SDK 초기화 실패");
            }
            return;
        }

        if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else if (TextUtils.equals(type, BannerType.INTERSTITIAL) || TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP)) {

            mInterstitialAd = new LevelPlayInterstitialAd(mUnitId);
            mInterstitialAd.setListener(new LevelPlayInterstitialAdListener() {

                @Override
                public void onAdLoaded(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                }

                @Override
                public void onAdLoadFailed(@NonNull LevelPlayAdError levelPlayAdError) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(levelPlayAdError.getErrorMessage());
                    }
                }

                @Override
                public void onAdDisplayed(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onAdDisplayFailed(@NonNull LevelPlayAdError levelPlayAdError, @NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToOpen(levelPlayAdError.getErrorMessage(), getName());
                    }
                }

                @Override
                public void onAdClicked(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }

                @Override
                public void onAdClosed(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClosed();
                    }
                }

                @Override
                public void onAdInfoChanged(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                }
            });

            mInterstitialAd.loadAd();
        } else if (TextUtils.equals(type, BannerType.REWARD_VIDEO)) {
            loadRewardAd();
        } else if (TextUtils.equals(type, BannerType.ENDING)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else {
            // Create the banner view and set the ad unit id
            LevelPlayBannerAdView.Config config;
            if (TextUtils.equals(type, BannerType.BANNER_300x250)) {
                config = new LevelPlayBannerAdView.Config.Builder().setAdSize(LevelPlayAdSize.MEDIUM_RECTANGLE).build();
            } else if (TextUtils.equals(type, BannerType.BANNER_320x100)) {
                config = new LevelPlayBannerAdView.Config.Builder().setAdSize(LevelPlayAdSize.LARGE).build();
            } else {
                config = new LevelPlayBannerAdView.Config.Builder().setAdSize(LevelPlayAdSize.BANNER).build();
            }
            mAdView = new LevelPlayBannerAdView(mContext, mUnitId, config);

            mAdView.setBannerListener(new LevelPlayBannerAdViewListener() {
                @Override
                public void onAdLoaded(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                }

                @Override
                public void onAdLoadFailed(@NonNull LevelPlayAdError levelPlayAdError) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(levelPlayAdError.getErrorMessage());
                    }
                }

                @Override
                public void onAdClicked(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }
            });

            mAdView.loadAd();
        }

//        sendImpression();
    }

    @Override
    public boolean show(@NonNull Activity activity) {
        if (mAdType == MediationAdSize.INTERSTITIAL && (mInterstitialAd != null && mInterstitialAd.isAdReady())) {
            if (mInterstitialAd != null) {
                mInterstitialAd.showAd(activity);
                sendAdSDKImpression(activity, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (mRewardedAd != null) {
                mRewardedAd.showAd(activity);
                sendAdSDKImpression(activity, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean show() {
        if (!(mContext instanceof Activity)){
            return false;
        }
        if (mAdType == MediationAdSize.INTERSTITIAL && (mInterstitialAd != null && mInterstitialAd.isAdReady())) {
            if (mInterstitialAd != null) {
                mInterstitialAd.showAd((Activity) mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            if (mRewardedAd != null) {
                mRewardedAd.showAd((Activity) mContext);
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }

    }


    @Override
    public boolean isLoaded() {
        if (mAdType == MediationAdSize.INTERSTITIAL) {
            return (mInterstitialAd != null && mInterstitialAd.isAdReady());
        } else if (mAdType == MediationAdSize.REWARD_VIDEO) {
            return (mRewardedAd != null && mRewardedAd.isAdReady());
        } else {
            return false;
        }
    }


    @Override
    public void destroy() {
        super.destroy();

        try {
            if (mAdView != null) {
                mAdView.destroy();
                mAdView = null;
            }

            mInterstitialAd = null;
        } catch (Exception e) {
            LogPrint.d("[UnityAdapter] " + e.getLocalizedMessage());
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resumeAutoRefresh();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mAdView != null) {
            mAdView.pauseAutoRefresh();
        }
    }

    public Object getAdView() {
        return mAdView;
    }

    private void loadRewardAd() {
        LogPrint.d("loadRewardAd : " + mUnitId);
        mRewardedAd = new LevelPlayRewardedAd(mUnitId);
        mRewardedAd.setListener(new LevelPlayRewardedAdListener() {
            @Override
            public void onAdLoaded(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                LogPrint.d("onAdLoaded");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
            }

            @Override
            public void onAdLoadFailed(@NonNull LevelPlayAdError levelPlayAdError) {
                LogPrint.d("onAdLoadFailed");
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(levelPlayAdError.getErrorMessage());
                }
            }

            @Override
            public void onAdDisplayed(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdDisplayed();
                }
            }

            @Override
            public void onAdDisplayFailed(@NonNull LevelPlayAdError levelPlayAdError, @NonNull LevelPlayAdInfo levelPlayAdInfo) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen(levelPlayAdError.getErrorMessage(), getName());
                }
            }

            @Override
            public void onAdRewarded(@NonNull LevelPlayReward levelPlayReward, @NonNull LevelPlayAdInfo levelPlayAdInfo) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdComplete();
                }
            }

            @Override
            public void onAdClosed(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClosed();
                }
            }

            @Override
            public void onAdClicked(@NonNull LevelPlayAdInfo levelPlayAdInfo) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }
        });
        mRewardedAd.loadAd();
    }


}