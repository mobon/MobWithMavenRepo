package com.mobwith.manager.nativeadview;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobwith.adapters.AdfitAdapter;
import com.mobwith.adapters.VideoAdapter;
import com.mobwith.httpmodule.Call;
import com.mobwith.httpmodule.Callback;
import com.mobwith.httpmodule.MobonResponse;
import com.mobwith.imgmodule.ImageModule;
import com.mobwith.imgmodule.RequestManager;
import com.mobwith.imgmodule.load.resource.drawable.DrawableTransitionOptions;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.MobonHttpService;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.R;
import com.mobwith.sdk.custom.rewarded.AffordanceView;
import com.mobwith.sdk.custom.rewarded.AffordanceViewManager;
import com.mobwith.sdk.models.AdDataModel;
import com.mobwith.sdk.models.reward.MWRewardBannerModel;

import org.json.JSONObject;

import java.io.IOException;
import java.lang.ref.WeakReference;

/**
 * 네이티브 광고를 표시하기 위한 커스텀 FrameLayout 입니다.
 * 이 뷰는 광고 데이터를 받아 UI 구성요소를 동적으로 채웁니다.
 */
public class NativeAdView extends FrameLayout {

    private static final int DEFAULT_SOUND_BUTTON_MARGIN_DP = 10;
    private static final long PAUSE_RECHECK_DELAY_MS = 300L;
    // 영상을 재생하기 위해 필요한 최소 노출 비율. (0.5 = 광고 뷰의 절반 이상이 보여야 재생)
    private static final float VIDEO_PLAY_VISIBLE_RATIO = 0.5f;

    private NativeAdViewItem mAdViewItems;

    // UI 구성요소
    private FrameLayout mAdMediaView;
    private ImageView mADImageView;
    private ImageView mADLogoImageView;
    private TextView mTitleView;
    private TextView mDescView;
    private Button mGotoSiteView;
    private ImageView mInfoLogoImageView;

    private boolean useScaleType = false;

    // 인플레이트된 네이티브 레이아웃의 루트 뷰
    private View mLayoutRoot;
    // 현재 네이티브 레이아웃에 부착되어 있는 영상 광고 컨테이너 (영상 뷰 + 사운드 버튼)
    private VideoOverlayLayout mVideoContainer;
    // 현재 재생 중인 영상 광고 어댑터
    private VideoAdapter mVideoAdapter;
    // 광고 뷰가 절반 미만으로 보이면 영상을 자동으로 일시정지할지 여부
    private boolean useVideoAutoPause = true;
    // 영상 재생을 시작했는지 여부 (화면에 절반 이상 처음 보일 때 재생을 시작합니다)
    private boolean isVideoStarted = false;
    // 영상 광고를 재생해도 되는 상태인지 여부 (노출 비율 + 액티비티 상태를 모두 만족)
    private boolean isVideoPlayable = false;
    // 광고 뷰가 올라가 있는 액티비티가 포그라운드(onResume ~ onPause) 상태인지 여부
    private boolean isHostActivityResumed = true;

    // 스크롤/레이아웃 변화로 광고 뷰의 노출 상태가 바뀌는지 감시합니다.
    private final ViewTreeObserver.OnScrollChangedListener mVisibilityChangeListener = this::updateVideoPlayback;
    private final ViewTreeObserver.OnGlobalLayoutListener mLayoutChangeListener = this::updateVideoPlayback;

    // 화면 꺼짐 / 다른 액티비티 진입을 감지하기 위한 액티비티 참조 (누수를 막기 위해 약한 참조로 보관합니다)
    private WeakReference<Activity> mHostActivityRef;
    // 라이프사이클 콜백을 해제하기 위해 등록에 사용한 Application 을 보관합니다.
    private Application mRegisteredApplication;
    // 호스트 액티비티를 찾지 못했을 때(Application Context 로 생성된 경우) 사용하는 포그라운드 액티비티 수
    private int resumedActivityCount = 0;

    /**
     * 광고 뷰가 올라가 있는 액티비티의 상태 변화를 감지합니다.
     * 화면이 꺼지거나 다른 액티비티가 위에 올라오면 액티비티가 onPause 되므로 영상을 일시정지하고,
     * 다시 화면으로 돌아오면(onResume) 이어서 재생합니다.
     */
    private final Application.ActivityLifecycleCallbacks mActivityLifecycleCallbacks = new Application.ActivityLifecycleCallbacks() {
        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        }

        @Override
        public void onActivityStarted(Activity activity) {
        }

        @Override
        public void onActivityResumed(Activity activity) {
            if (mHostActivityRef != null) {
                if (!isHostActivity(activity)) {
                    return;
                }
            } else {
                // 호스트 액티비티를 모르면 앱 전체의 포그라운드 여부로 판단합니다.
                resumedActivityCount++;
            }

            LogPrint.d("video : activity resumed");
            isHostActivityResumed = true;
            updateVideoPlayback();
        }

        @Override
        public void onActivityPaused(Activity activity) {
            if (mHostActivityRef != null) {
                if (!isHostActivity(activity)) {
                    return;
                }
            } else {
                resumedActivityCount = Math.max(0, resumedActivityCount - 1);
                if (resumedActivityCount > 0) {
                    // 아직 다른 액티비티가 포그라운드에 있습니다.
                    return;
                }
            }

            LogPrint.d("video : activity paused");
            isHostActivityResumed = false;
            updateVideoPlayback();
        }

        @Override
        public void onActivityStopped(Activity activity) {
        }

        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        }

        @Override
        public void onActivityDestroyed(Activity activity) {
            if (!isHostActivity(activity)) {
                return;
            }
            unregisterActivityLifecycle();
        }
    };

    // 영상 광고 사운드 버튼 설정
    private boolean useSoundButton = true;
    private int soundButtonGravity = Gravity.BOTTOM | Gravity.START;
    private int soundButtonMarginDp = DEFAULT_SOUND_BUTTON_MARGIN_DP;
    private boolean isSoundOn = false;

    private RequestManager mRequestManager;
    private Context mContext;

    private MWRewardBannerModel rewardBannerModel;

    /**
     * NativeAdView 생성자
     *
     * @param context     컨텍스트
     * @param adViewItems 광고 뷰의 UI 항목들을 정의하는 객체
     */
    public NativeAdView(Context context, NativeAdViewItem adViewItems) {
        super(context);
        this.mAdViewItems = adViewItems;
        this.mContext = context;

        initView();
    }

    /**
     * 레이아웃을 인플레이트하고 UI 위젯을 초기화합니다.
     */
    private void initView() {
        // 지정된 레이아웃 ID를 사용하여 뷰를 인플레이트합니다.
        inflate(getContext(), mAdViewItems.mViewLayoutID, this);

        // 영상 광고를 덮어씌울 기준이 되는 레이아웃 루트를 기억합니다.
        // 레이아웃 종류(LinearLayout / ConstraintLayout / ...)와 상관없이 루트 뷰의 영역에 영상을 배치합니다.
        // (merge 레이아웃처럼 루트가 하나가 아니면 이 뷰 전체를 기준으로 삼습니다.)
        if (getChildCount() == 1) {
            mLayoutRoot = getChildAt(0);
        }

        // ID를 통해 각 UI 구성요소를 찾습니다.
        View adMediaView = findViewById(mAdViewItems.mMediaViewContainerID);
        View adImageView = findViewById(mAdViewItems.mADImageViewID);
        View adLogoImageView = findViewById(mAdViewItems.mADLogoImageViewID);
        View titleView = findViewById(mAdViewItems.mTitleViewID);
        View descriptionView = findViewById(mAdViewItems.mDescViewID);
        View gotoSiteView = findViewById(mAdViewItems.mGotoSiteViewID);
        View infoLogoImageView = findViewById(mAdViewItems.mInfoLogoImageViewID);

        // 뷰의 타입이 맞는지 확인하고 멤버 변수에 할당합니다.
        if (adMediaView instanceof FrameLayout) {
            mAdMediaView = (FrameLayout) adMediaView;
        }

        if (adImageView instanceof ImageView) {
            mADImageView = (ImageView) adImageView;
        }

        if (adLogoImageView instanceof ImageView) {
            mADLogoImageView = (ImageView) adLogoImageView;
        }

        if (titleView instanceof TextView) {
            mTitleView = (TextView) titleView;
        }

        if (descriptionView instanceof TextView) {
            mDescView = (TextView) descriptionView;
        }

        if (gotoSiteView instanceof Button) {
            mGotoSiteView = (Button) gotoSiteView;
        }

        if (infoLogoImageView instanceof ImageView) {
            mInfoLogoImageView = (ImageView) infoLogoImageView;
        }
    }

    /**
     * CTA(Call-to-Action) 버튼에 대한 클릭 리스너를 설정합니다.
     *
     * @param listener 버튼 클릭 시 호출될 리스너
     */
    public void setCtaButtonOnClickListener(View.OnClickListener listener) {
        if (mGotoSiteView != null) {
            mGotoSiteView.setOnClickListener(listener);
        }
    }

    /**
     * 정보 아이콘 뷰에 대한 클릭 리스너를 설정합니다.
     *
     * @param listener 아이콘 클릭 시 호출될 리스너
     */
    public void setInfoLogoViewOnClickListener(View.OnClickListener listener) {
        if (mInfoLogoImageView != null) {
            mInfoLogoImageView.setOnClickListener(listener);
        }
    }

    public void setVideoViewOnClickListener(View.OnClickListener listener) {
        try {
            if (mAdViewItems.mContainerView != null) {
                mAdViewItems.mContainerView.setOnClickListener(listener);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void setRewardBannerModel(MWRewardBannerModel rewardBannerModel) {
        this.rewardBannerModel = rewardBannerModel;
    }

    /**
     * 이전 광고의 흔적이 남지 않도록 표시 중인 광고를 모두 정리합니다.
     * 영상 뷰와 사운드 버튼을 제거하고, 채워둔 UI 를 비운 뒤 컨테이너에서 광고 뷰를 분리합니다.
     */
    public void clearAdView() {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                detachVideoView();

                if (mADImageView != null) {
                    mADImageView.setImageBitmap(null);
                }
                if (mADLogoImageView != null) {
                    mADLogoImageView.setImageBitmap(null);
                }
                if (mInfoLogoImageView != null) {
                    mInfoLogoImageView.setImageBitmap(null);
                }
                if (mTitleView != null) {
                    mTitleView.setText("");
                }
                if (mDescView != null) {
                    mDescView.setText("");
                }

                // 광고 뷰 자체를 컨테이너에서 분리합니다.
                if (getParent() instanceof ViewGroup) {
                    ((ViewGroup) getParent()).removeView(this);
                }
                if (mAdViewItems != null && mAdViewItems.mContainerView != null) {
                    mAdViewItems.mContainerView.removeAllViews();
                }
            } catch (Exception e) {
                LogPrint.d("clearAdView error : " + e.getLocalizedMessage());
            }
        });
    }

    /**
     * 뷰와 관련된 리소스를 해제합니다. (주로 이미지 로딩 라이브러리)
     */
    public void destroyView() {
        if (mRequestManager != null) {
            try {
                mRequestManager.onDestroy();
            } catch (Exception ignored) {
            }
            mRequestManager = null;
        }
    }

    public void useScaleType(boolean isUse) {
        useScaleType = isUse;
    }

    /**
     * 광고 뷰가 절반 미만으로 보일 때 영상을 자동으로 일시정지할지 설정합니다. (기본값 : true)
     * false 로 설정하면 노출 여부와 상관없이 계속 재생합니다.
     * 단, 화면이 꺼지거나 다른 액티비티가 위에 올라온 경우에는 이 설정과 상관없이 항상 일시정지합니다.
     */
    public void useVideoAutoPause(boolean isUse) {
        useVideoAutoPause = isUse;
    }

    /**
     * 영상 광고의 사운드 버튼 사용 여부를 설정합니다. (기본값 : true)
     */
    public void useSoundButton(boolean isUse) {
        useSoundButton = isUse;
    }

    /**
     * 영상 광고 사운드 버튼의 위치를 설정합니다. (기본값 : Gravity.BOTTOM | Gravity.START)
     *
     * @param gravity Gravity 조합 값. 예) Gravity.BOTTOM | Gravity.START 이면 좌측 하단
     */
    public void setSoundButtonGravity(int gravity) {
        soundButtonGravity = gravity;
    }

    /**
     * 영상 광고 사운드 버튼의 여백을 설정합니다. (기본값 : 10dp)
     *
     * @param marginDp 여백 (dp)
     */
    public void setSoundButtonMargin(int marginDp) {
        soundButtonMarginDp = marginDp;
    }

    /**
     * JSON 형태의 광고 데이터로 UI를 업데이트합니다.
     *
     * @param jsonString     광고 데이터가 포함된 JSON 문자열
     * @param isShowInfoLogo 정보 아이콘의 표시 여부
     * @param videoAdapter   영상 광고를 위한 어댑터
     */
    public void updateUIWith(String jsonString, boolean isShowInfoLogo, VideoAdapter videoAdapter) {
        // 이미지 로딩을 위한 RequestManager 초기화
        if (mRequestManager == null) {
            mRequestManager = ImageModule.with(mAdViewItems.mContext.getApplicationContext());
        }

        // 메인 스레드에서 UI 업데이트를 수행합니다.
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                // 컨테이너 뷰의 모든 자식 뷰를 제거하여 초기화합니다.
                if (mAdViewItems != null && mAdViewItems.mContainerView != null) {
                    mAdViewItems.mContainerView.removeAllViews();
                }

                // JSON 파싱
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);
                AdDataModel adDataModel = new AdDataModel(adData);


//                final String logoIcon = "https:" + jsonObject.getJSONObject("data").optString("logoDefault", "");
                final String logoIcon = jsonObject.getJSONObject("data").optString("logoDefault", "");
                final String impUrl = jsonObject.getJSONObject("data").optString("impUrl", "");

                // 광고 데이터 추출
                final String adImage = adData.optString("pImg", "");
                final String logoDefault = adData.optString("aLogoDefault", "");
                final String logoSub = adData.optString("aLogoSub", "");
                final String pNm = adData.optString("pNm", "");
                final String desc = adData.optString("desc", "");
                final String desc1 = adData.optString("aDesc1", "");
                final String desc2 = adData.optString("aDesc2", "");
                final String desc3 = adData.optString("aDesc3", "");
                final String pPrice = CommonUtils.getCommaNumeric(adData.optString("pPrice", ""));
                final String custom03 = adData.optString("custom03", "");

                String price;

                if (!custom03.isEmpty()) {
                    price = custom03;
                } else {
                    price = pPrice;
                }

                final String advrtsReplcCode = adData.optString("advrtsReplcCode", "");
                final String defaultCtaText = mContext.getString(R.string.mobwith_cta_default);
                final String cta_text = adData.optString("cta_text", defaultCtaText);
                String advrts = defaultCtaText;
                // advrtsReplcCode에 따라 CTA 버튼 텍스트를 설정합니다.
                if (TextUtils.equals(advrtsReplcCode, "02") || TextUtils.equals(advrtsReplcCode, "2")) {
                    advrts = cta_text;
                }

                // 메인 광고 이미지 설정
                // 영상 광고일 때도 네이티브 광고의 크기가 동일하도록 UI 는 그대로 구성하고,
                // 영상 뷰를 네이티브 뷰 전체에 덮어씌웁니다.
                detachVideoView();
                showAdImage(adImage);

                if (videoAdapter != null && attachVideoView(videoAdapter)) {
                    if (videoAdapter.isLoaded()) {
                        videoAdapter.setLoop(true);
                        // 광고 뷰가 화면에 보일 때 재생을 시작합니다.
                        updateVideoPlayback();
                    }
                }

                // 광고주 로고 이미지 설정 (기본 로고 > 서브 로고 순서)
                if (mADLogoImageView != null) {
                    if (!logoDefault.isEmpty()) {
                        mRequestManager.load(logoDefault).fitCenter().into(mADLogoImageView);
                    } else if (!logoSub.isEmpty()) {
                        mRequestManager.load(logoSub).fitCenter().into(mADLogoImageView);
                    } else {
                        mADLogoImageView.setImageBitmap(null);
                    }
                }

                // 제목 설정
                if (mTitleView != null) {
                    String title = (pNm.isEmpty() ? (desc1.isEmpty() ? desc2 : desc1) : pNm);
                    mTitleView.setText(title.isEmpty() || title.equals("null") ? "" : title);
                }

                // 설명 설정 (가격 > 설명3 > 설명2 > 설명1 > 기본 설명 순서)
                if (mDescView != null) {
                    String realDesc = (
                            price.isEmpty() ?
                                    (desc3.isEmpty() ?
                                            (desc2.isEmpty() ?
                                                    (desc1.isEmpty() ?
                                                            desc
                                                            : desc1)
                                                    : desc2)
                                            : desc3)
                                    : price);

                    mDescView.setText(realDesc.isEmpty() || realDesc.equals("null") ? "" : realDesc);
                }

                // 영상 광고일 땐 영상이 레이아웃 전체를 덮으므로 정보 아이콘과 CTA 버튼은 감춥니다.
                // 크기는 일반 네이티브 광고와 동일해야 하므로 GONE 이 아닌 INVISIBLE 로 처리합니다.
                final boolean isVideoAd = mVideoContainer != null;

                // CTA 버튼 텍스트 설정
                if (mGotoSiteView != null) {
                    mGotoSiteView.setText(advrts);
                    mGotoSiteView.setVisibility(isVideoAd ? View.INVISIBLE : View.VISIBLE);
                }

                // 정보 아이콘 로고 설정 및 표시 여부 제어
                if (mInfoLogoImageView != null) {
                    if (!logoIcon.isEmpty()) {
                        mRequestManager.load(logoIcon).fitCenter().into(mInfoLogoImageView);
                    } else {
                        mInfoLogoImageView.setImageBitmap(null);
                    }

                    if (!isShowInfoLogo) {
                        mInfoLogoImageView.setVisibility(View.GONE);
                    } else {
                        mInfoLogoImageView.setVisibility(isVideoAd ? View.INVISIBLE : View.VISIBLE);
                    }
                }

                // 완성된 네이티브 광고 뷰를 컨테이너에 추가합니다.
                if (mAdViewItems.mContainerView != null) {
                    mAdViewItems.mContainerView.addView(this);
                }

                //TODO:리워드 배너
                if (rewardBannerModel != null) {
                    AffordanceViewManager.getInstance().show(mAdViewItems.mContainerView, rewardBannerModel, Gravity.TOP | Gravity.END, 6);
                }

                // 노출(Impression) 트래킹 URL 전송
                sendImpressionWith(adData.optString("custom08"), impUrl);
                // 추가적인 노출 트래커 이벤트 전송
                CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    /**
     * 메인 광고 이미지를 표시합니다.
     *
     * @param adImage 광고 이미지 URL
     */
    private void showAdImage(String adImage) {
        if (mADImageView == null) {
            return;
        }

        if (adImage.isEmpty()) {
            mADImageView.setImageBitmap(null);
            return;
        }

        if (useScaleType) {
            mRequestManager.load(adImage)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .placeholder(new ColorDrawable(Color.WHITE))
                    .into(mADImageView);
        } else {
            mRequestManager.load(adImage)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .placeholder(new ColorDrawable(Color.WHITE))
                    .fitCenter()
                    .into(mADImageView);
        }
    }

    /**
     * 영상 광고 뷰를 네이티브 레이아웃의 루트 뷰 영역 전체에 덮어씌웁니다.
     *
     * <p>영상 컨테이너는 레이아웃 루트의 자식이 아니라 <b>루트와 같은 레벨(이 뷰의 자식)</b>로 올린 뒤,
     * {@link #layoutVideoOverlay()} 에서 루트 뷰와 똑같은 위치/크기로 배치합니다.
     * 이렇게 하면 루트가 LinearLayout 처럼 자식을 쌓는 레이아웃이어도 영상이 항목 사이에 끼지 않고 전체를 덮고,
     * wrap_content + padding 을 가진 레이아웃의 크기를 영상 컨테이너가 밀어내지 않습니다.
     * (루트의 자식으로 넣으면 루트 크기가 매 레이아웃마다 커져 영상 크기 변경이 무한 반복됩니다.)</p>
     *
     * @param videoAdapter 영상 광고 어댑터
     * @return 부착에 성공하면 true
     */
    private boolean attachVideoView(VideoAdapter videoAdapter) {
        View videoView = (View) videoAdapter.getAdView();
        if (videoView == null) {
            LogPrint.d("attachVideoView : videoView is null");
            return false;
        }

        // 다른 부모에 남아있는 경우 먼저 분리합니다. (중복 addView 로 인한 예외 방지)
        if (videoView.getParent() instanceof ViewGroup) {
            ((ViewGroup) videoView.getParent()).removeView(videoView);
        }

        // 영상은 소리가 꺼진 상태로 시작합니다.
        isSoundOn = false;
        videoAdapter.setMuteMode(true);

        mVideoAdapter = videoAdapter;
        isVideoStarted = false;
        isVideoPlayable = false;

        // 영상 뷰와 사운드 버튼을 함께 담아 레이아웃에 올립니다.
        VideoOverlayLayout videoContainer = new VideoOverlayLayout(getContext());
        videoContainer.addView(videoView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        addSoundButton(videoContainer, videoAdapter);

        // 크기는 배치 단계에서 루트 뷰에 맞춰 직접 지정하므로 LayoutParams 는 쓰이지 않습니다.
        addView(videoContainer, new FrameLayout.LayoutParams(0, 0));
        mVideoContainer = videoContainer;
        bringVideoViewToTop(this, videoContainer);

        LogPrint.d("attachVideoView : layout root " + (mLayoutRoot != null ? mLayoutRoot.getClass().getSimpleName() : "none"));
        return true;
    }

    /**
     * 영상 광고를 네이티브 레이아웃 위에 덮어씌우기 위한 컨테이너입니다.
     *
     * <p>일반 측정 단계에서는 0x0 으로 측정되어 네이티브 레이아웃(wrap_content)의 크기에 영향을 주지 않고,
     * 실제 크기는 부모가 {@link #measureAsOverlay(int, int)} 로 직접 지정합니다.</p>
     */
    private static final class VideoOverlayLayout extends FrameLayout {

        private boolean measuringAsOverlay = false;

        VideoOverlayLayout(Context context) {
            super(context);
        }

        /**
         * 덮어씌울 영역의 크기로 직접 측정합니다.
         */
        void measureAsOverlay(int width, int height) {
            measuringAsOverlay = true;
            try {
                // 이전 측정값이 캐시되어 건너뛰지 않도록 다시 측정하게 합니다.
                forceLayout();
                measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
            } finally {
                measuringAsOverlay = false;
            }
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            if (!measuringAsOverlay) {
                // 네이티브 레이아웃의 크기 계산에서 빠집니다.
                setMeasuredDimension(0, 0);
                return;
            }
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        }
    }

    /**
     * 영상 광고의 소리를 켜고 끄는 버튼을 추가합니다.
     * 소리가 꺼져 있을 때 mobwith_sound_on, 켜져 있을 때 mobwith_sound_off 이미지를 표시합니다.
     */
    private void addSoundButton(FrameLayout videoContainer, VideoAdapter videoAdapter) {
        if (!useSoundButton) {
            return;
        }

        ImageView soundButton = new ImageView(getContext());
        soundButton.setImageResource(R.drawable.mobwith_sound_off);
        soundButton.setOnClickListener(v -> {
            isSoundOn = !isSoundOn;
            videoAdapter.setVolume(isSoundOn);
            soundButton.setImageResource(isSoundOn
                    ? R.drawable.mobwith_sound_on
                    : R.drawable.mobwith_sound_off);
        });

        int margin = dpToPx(soundButtonMarginDp);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                soundButtonGravity);
        params.setMargins(margin, margin, margin, margin);
        params.setMarginStart(margin);
        params.setMarginEnd(margin);

        videoContainer.addView(soundButton, params);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }

    /**
     * 영상 뷰를 같은 레벨의 다른 뷰들보다 위에 그리도록 Z 순서를 조정합니다.
     * Material Button 처럼 elevation 을 가진 위젯은 추가 순서만으로는 가려지지 않습니다.
     */
    private void bringVideoViewToTop(ViewGroup host, View videoView) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            // elevation 이 없는 버전에서는 추가 순서가 곧 그리는 순서입니다.
            return;
        }

        float topZ = 0f;
        for (int i = 0; i < host.getChildCount(); i++) {
            View child = host.getChildAt(i);
            if (child != videoView) {
                topZ = Math.max(topZ, child.getZ());
            }
        }

        // Z 값에 의한 그림자가 생기지 않도록 outline 은 제거합니다.
        videoView.setOutlineProvider(null);
        videoView.setZ(topZ + 1f);
    }

    /**
     * 부착되어 있는 영상 광고 뷰를 네이티브 레이아웃에서 분리합니다.
     */
    private void detachVideoView() {
        mVideoAdapter = null;
        isVideoStarted = false;
        isVideoPlayable = false;

        if (mVideoContainer == null) {
            return;
        }

        if (mVideoContainer.getParent() instanceof ViewGroup) {
            ((ViewGroup) mVideoContainer.getParent()).removeView(mVideoContainer);
        }
        mVideoContainer = null;
    }

    /**
     * 광고 뷰의 노출 상태와 액티비티 상태에 따라 영상을 재생하거나 일시정지합니다.
     * 스크롤로 광고 뷰가 절반 미만으로 보이면 일시정지하고, 절반 이상 다시 보이면 이어서 재생합니다.
     * 화면이 꺼지거나 다른 액티비티가 위에 올라와 액티비티가 일시정지되면 노출 비율과 상관없이 영상을 멈춥니다.
     */
    private void updateVideoPlayback() {
        if (mVideoAdapter == null) {
            return;
        }

        // useVideoAutoPause 를 끄면 노출 비율은 보지 않지만, 액티비티가 백그라운드일 때는 항상 멈춥니다.
        boolean playable = isHostActivityResumed && (!useVideoAutoPause || isAdViewVisible());
        if (playable == isVideoPlayable) {
            return;
        }
        isVideoPlayable = playable;

        if (!playable) {
            LogPrint.d("video pause : not playable (activity resumed : " + isHostActivityResumed + ")");
            mVideoAdapter.pauseVideo();
            // 재생이 막 시작되는 중이었다면(재생 대기) 일시정지가 적용되지 않으므로 한 번 더 확인합니다.
            postDelayed(() -> {
                if (!isVideoPlayable && mVideoAdapter != null) {
                    mVideoAdapter.pauseVideo();
                }
            }, PAUSE_RECHECK_DELAY_MS);
            return;
        }

        if (!isVideoStarted) {
            LogPrint.d("video play : playable");
            isVideoStarted = true;
            mVideoAdapter.playVideo();
        } else {
            LogPrint.d("video resume : playable");
            mVideoAdapter.resumeVideo();
        }
    }

    /**
     * 전달된 액티비티가 이 광고 뷰를 담고 있는 액티비티인지 확인합니다.
     */
    private boolean isHostActivity(Activity activity) {
        return mHostActivityRef != null && activity != null && activity == mHostActivityRef.get();
    }

    /**
     * 광고 뷰를 담고 있는 액티비티의 라이프사이클 콜백을 등록합니다.
     * 호스트 액티비티를 찾지 못하면(Application Context 로 생성된 경우) 앱 전체의 포그라운드 여부로 판단합니다.
     */
    private void registerActivityLifecycle() {
        if (mRegisteredApplication != null) {
            return;
        }

        Activity activity = resolveHostActivity();
        Application application = findApplication(activity);
        if (application == null) {
            LogPrint.d("video : application not found, lifecycle pause disabled");
            return;
        }

        mHostActivityRef = (activity != null) ? new WeakReference<>(activity) : null;
        mRegisteredApplication = application;
        // 뷰가 붙는 시점은 화면에 액티비티가 떠 있는 상태이므로 포그라운드로 간주하고 시작합니다.
        resumedActivityCount = 1;
        isHostActivityResumed = true;
        application.registerActivityLifecycleCallbacks(mActivityLifecycleCallbacks);

        LogPrint.d("video : lifecycle registered (host activity : "
                + (activity != null ? activity.getLocalClassName() : "unknown") + ")");
    }

    /**
     * 등록해 둔 액티비티 라이프사이클 콜백을 해제합니다.
     */
    private void unregisterActivityLifecycle() {
        if (mRegisteredApplication != null) {
            try {
                mRegisteredApplication.unregisterActivityLifecycleCallbacks(mActivityLifecycleCallbacks);
            } catch (Exception e) {
                LogPrint.d("unregisterActivityLifecycle error : " + e.getLocalizedMessage());
            }
            mRegisteredApplication = null;
        }
        mHostActivityRef = null;
        resumedActivityCount = 0;
    }

    /**
     * 광고 뷰가 올라가 있는 액티비티를 찾습니다.
     * 생성 시 전달받은 컨텍스트가 Application Context 일 수 있으므로,
     * 컨테이너 뷰와 실제로 부착된 뷰 계층(루트 뷰)의 컨텍스트까지 확인합니다.
     */
    private Activity resolveHostActivity() {
        Activity activity = findActivity(getContext());
        if (activity == null) {
            activity = findActivity(mContext);
        }
        if (activity == null && mAdViewItems != null && mAdViewItems.mContainerView != null) {
            activity = findActivity(mAdViewItems.mContainerView.getContext());
        }
        if (activity == null) {
            // 윈도우에 부착된 뒤라면 루트 뷰(DecorView)의 컨텍스트가 액티비티입니다.
            View rootView = getRootView();
            if (rootView != null) {
                activity = findActivity(rootView.getContext());
            }
        }
        return activity;
    }

    /**
     * 라이프사이클 콜백을 등록할 Application 을 찾습니다.
     */
    private Application findApplication(Activity activity) {
        if (activity != null && activity.getApplication() != null) {
            return activity.getApplication();
        }

        Context appContext = getContext() != null ? getContext().getApplicationContext() : null;
        if (appContext == null && mContext != null) {
            appContext = mContext.getApplicationContext();
        }
        return (appContext instanceof Application) ? (Application) appContext : null;
    }

    /**
     * 컨텍스트 래퍼를 따라가며 액티비티를 찾습니다.
     */
    private static Activity findActivity(Context context) {
        Context current = context;
        while (current instanceof ContextWrapper) {
            if (current instanceof Activity) {
                return (Activity) current;
            }
            current = ((ContextWrapper) current).getBaseContext();
        }
        return null;
    }

    /**
     * 광고 뷰가 영상을 재생해도 될 만큼 화면에 보이는 상태인지 확인합니다.
     * 광고 뷰 전체 면적 중 실제로 보이는 면적이 {@link #VIDEO_PLAY_VISIBLE_RATIO} 이상일 때만 true 입니다.
     * (절반 미만으로 보이면 일시정지하고, 절반 이상 다시 보이면 이어서 재생합니다.)
     */
    private boolean isAdViewVisible() {
        if (mVideoContainer == null || !isShown() || getWindowVisibility() != View.VISIBLE) {
            return false;
        }

        final int width = getWidth();
        final int height = getHeight();
        if (width <= 0 || height <= 0) {
            // 아직 레이아웃이 측정되지 않았으면 노출 비율을 계산할 수 없습니다.
            return false;
        }

        Rect visibleRect = new Rect();
        if (!getGlobalVisibleRect(visibleRect)) {
            return false;
        }

        // 스크롤로 잘린 부분을 제외한 실제 노출 면적을 구합니다.
        final int visibleWidth = Math.min(visibleRect.width(), width);
        final int visibleHeight = Math.min(visibleRect.height(), height);
        if (visibleWidth <= 0 || visibleHeight <= 0) {
            return false;
        }

        final float visibleArea = (float) visibleWidth * visibleHeight;
        final float totalArea = (float) width * height;
        final float visibleRatio = visibleArea / totalArea;

        return visibleRatio >= VIDEO_PLAY_VISIBLE_RATIO;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ViewTreeObserver observer = getViewTreeObserver();
        observer.addOnScrollChangedListener(mVisibilityChangeListener);
        observer.addOnGlobalLayoutListener(mLayoutChangeListener);
        registerActivityLifecycle();
        updateVideoPlayback();
    }

    @Override
    protected void onDetachedFromWindow() {
        ViewTreeObserver observer = getViewTreeObserver();
        if (observer.isAlive()) {
            observer.removeOnScrollChangedListener(mVisibilityChangeListener);
            observer.removeOnGlobalLayoutListener(mLayoutChangeListener);
        }

        unregisterActivityLifecycle();

        // 화면에서 분리되면 재생을 멈춥니다.
        if (mVideoAdapter != null && isVideoPlayable) {
            isVideoPlayable = false;
            LogPrint.d("video pause : detached");
            mVideoAdapter.pauseVideo();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateVideoPlayback();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        updateVideoPlayback();
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        layoutVideoOverlay();
    }

    /**
     * 영상 광고를 네이티브 레이아웃의 루트 뷰와 똑같은 위치/크기로 배치합니다.
     * 영상 컨테이너는 일반 측정 단계에서 빠져 있으므로(0x0) 여기에서 직접 측정한 뒤 배치합니다.
     * 루트 뷰를 찾지 못한 레이아웃(merge 등)에서는 이 뷰 전체를 덮습니다.
     */
    private void layoutVideoOverlay() {
        if (mVideoContainer == null || mVideoContainer.getParent() != this) {
            return;
        }

        final boolean hasRoot = mLayoutRoot != null && mLayoutRoot.getParent() == this;
        final int left = hasRoot ? mLayoutRoot.getLeft() : 0;
        final int top = hasRoot ? mLayoutRoot.getTop() : 0;
        final int right = hasRoot ? mLayoutRoot.getRight() : getWidth();
        final int bottom = hasRoot ? mLayoutRoot.getBottom() : getHeight();

        final int width = right - left;
        final int height = bottom - top;
        if (width <= 0 || height <= 0) {
            // 아직 레이아웃이 측정되지 않았습니다. 측정이 끝나면 다시 호출됩니다.
            return;
        }

        mVideoContainer.measureAsOverlay(width, height);
        mVideoContainer.layout(left, top, right, bottom);
    }

    public void updateUIVideo(String jsonString, VideoAdapter videoAdapter) {
        // 메인 스레드에서 UI 업데이트를 수행합니다.
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                // JSON 파싱
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONObject adData = jsonObject.getJSONObject("data").getJSONArray("data").getJSONObject(0);
                AdDataModel adDataModel = new AdDataModel(adData);
                final String impUrl = jsonObject.getJSONObject("data").optString("impUrl", "");

                //Video UI 설정 (미디어 타입일 땐 전체 화면에 비디오를 보임)

                if (mAdViewItems != null && mAdViewItems.mContainerView != null) {
                    mAdViewItems.mContainerView.removeAllViews();
                    if (videoAdapter != null && videoAdapter.isLoaded()) {
                        videoAdapter.setLoop(true);
                        videoAdapter.playVideo();
                        mAdViewItems.mContainerView.addView((View) videoAdapter.getAdView());
                    }
                }

                //TODO:리워드 배너
                if (rewardBannerModel != null) {
                    AffordanceViewManager.getInstance().show(mAdViewItems.mContainerView, rewardBannerModel, Gravity.TOP | Gravity.END, 6);
                }

                // 노출(Impression) 트래킹 URL 전송
                sendImpressionWith(adData.optString("custom08"), impUrl);
                // 추가적인 노출 트래커 이벤트 전송
                CommonUtils.sendImpressTrackersEvent(mContext, adDataModel);
            } catch (Exception e) {

            }
        });
    }

    public void updateUIBizBoard(AdfitAdapter adfitAdapter) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                // 컨테이너 뷰의 모든 자식 뷰를 제거하여 초기화합니다.
                if (mAdViewItems == null || mAdViewItems.mContainerView == null) {
                    return;
                }

                if (adfitAdapter.getAdView() == null) {
                    return;
                }

                mAdViewItems.mContainerView.removeAllViews();
                mAdViewItems.mContainerView.addView((View) adfitAdapter.getAdView());
            } catch (Exception ignored) {
            }
        });
    }

    /**
     * 광고 노출(Impression)을 서버로 전송합니다.
     *
     * @param custom08 우선적으로 사용할 노출 URL
     * @param impUrl   custom08이 없을 경우 사용할 노출 URL
     */
    private void sendImpressionWith(String custom08, String impUrl) {
        LogPrint.d("sendImpressionWith : nativeAdview");
        String realImpUrl = "";


        // 사용할 노출 URL을 결정합니다.
        if (custom08 != null && !custom08.isEmpty()) {
            realImpUrl = custom08;
        } else if (impUrl != null && !impUrl.isEmpty()) {
            realImpUrl = impUrl;
        } else {
            return; // 전송할 URL이 없으면 종료
        }

        // HTTP GET 요청으로 노출을 전송합니다.
        MobonHttpService.get(mContext, realImpUrl, null).enqueue(new Callback() {
            @Override
            public void onResponse(Call call, final MobonResponse mobonResponse) throws IOException {
                if (mobonResponse != null && mobonResponse.isSuccessful() && mobonResponse.body() != null) {
                    // 성공적으로 전송됨
                }
            }

            @Override
            public void onFailure(Call call, IOException e) {
                LogPrint.d("impression api error : " + e.getLocalizedMessage());
            }
        });

    }

}
