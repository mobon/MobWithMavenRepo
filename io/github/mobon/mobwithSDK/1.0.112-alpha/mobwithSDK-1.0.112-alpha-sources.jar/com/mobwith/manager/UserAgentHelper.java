package com.mobwith.manager;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebSettings;

import com.mobwith.sdk.Key;

public class UserAgentHelper {

    private UserAgentHelper() {
        // 유틸리티 클래스, 인스턴스화 방지
    }

    /** 어느 스레드에서 호출해도 됩니다 — 내부적으로 메인 스레드로 넘겨서 실행합니다. */
    public static void fetchAndCacheUserAgent(Context context) {
        Context appContext = context.getApplicationContext();

        if (Looper.myLooper() == Looper.getMainLooper()) {
            fetchAndCacheUserAgentOnMainThread(appContext);
        } else {
            new Handler(Looper.getMainLooper()).post(() -> fetchAndCacheUserAgentOnMainThread(appContext));
        }
    }

    private static void fetchAndCacheUserAgentOnMainThread(Context context) {
        String ua;
        try {
            // new WebView(context)로 직접 인스턴스를 만들지 않고,
            // 동일한 기본 UA를 반환하는 공식 정적 API를 사용합니다.
            // (WebView 인스턴스를 만들면 destroy() 안 하는 이상 리소스도 샙니다.)
            ua = WebSettings.getDefaultUserAgent(context);
        } catch (Throwable e) {
            // WebView 프로바이더가 비활성화된 기기/프로세스 등에서는 예외가 날 수 있습니다.
            LogPrint.w("getDefaultUserAgent 실패 : " + e.getMessage());
            ua = null;
        }

        String resolved = null;
        if (ua != null && !ua.trim().isEmpty()) {
            resolved = ua;
        } else {
            // WebView와 무관한 폴백 소스
            String httpAgent = System.getProperty("http.agent");
            if (httpAgent != null && !httpAgent.trim().isEmpty()) {
                resolved = httpAgent;
            }
        }

        if (resolved != null) {
            LogPrint.d("userAgent : " + resolved);
            SpManager.setString(context, Key.USER_AGENT, resolved);
        } else {
            // 빈 값으로 덮어쓰지 않고 기존 캐시를 유지 → 다음 프로세스/앱 실행 때 재시도
            LogPrint.w("User-Agent를 가져오지 못함, 캐시 값 유지");
        }
    }
}
