package com.mobwith.adapters;

import static com.mobwith.sdk.CommonUtils.sendAdSDKImpression;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.adop.sdk.BMAdError;
import com.adop.sdk.BMAdInfo;
import com.adop.sdk.adview.AdViewListener;
import com.adop.sdk.interstitial.InterstitialListener;
import com.adop.sdk.nativead.NativeListener;
import com.adop.sdk.reward.RewardListener;
import com.mobwith.manager.MediationAdListener;
import com.mobwith.manager.MediationAdSize;
import com.mobwith.manager.nativeadview.NativeAdViewItem;
import com.mobwith.sdk.BannerType;

import ad.helper.openbidding.BidmadCommon;
import ad.helper.openbidding.adview.BidmadBannerAd;
import ad.helper.openbidding.initialize.BidmadInitializeListener;
import ad.helper.openbidding.interstitial.BidmadInterstitialAd;
import ad.helper.openbidding.nativead.BidmadNativeAd;
import ad.helper.openbidding.reward.BidmadRewardAd;

public class AdopBidmadAdapter extends AdapterObject {

    private Context mContext;
    private String mUnitId;
    private String mScriptNo;

    private MediationAdListener mediationAdListener;
    public NativeAdViewItem mAdViewItem;

    BidmadBannerAd mAdView;
    BidmadNativeAd nativeAd;
    BidmadInterstitialAd mInterstitial;

    BidmadRewardAd mRewardAd;

    private boolean isInitialized = false;

    private boolean needLoadAd = false;
    private String loadAdType = "";


    public AdopBidmadAdapter(final Context context, String name, String unitId, String AdType, boolean isTestMode, String siteNo) {
        super(name, unitId, AdType, null, isTestMode);

        mUnitId = unitId;
        mContext = context;
        mScriptNo = siteNo;

        if (AdType.equals(BannerType.INTERSTITIAL)) {
            mAdType = MediationAdSize.INTERSTITIAL;
        } else if (AdType.equals(BannerType.BANNER_320x50)) {
            mAdType = MediationAdSize.BANNER_320_50;
        } else if (AdType.equals(BannerType.BANNER_320x100)) {
            mAdType = MediationAdSize.BANNER_320_100;
        } else if (AdType.equals(BannerType.BANNER_300x250)) {
            mAdType = MediationAdSize.BANNER_300_250;
        } else if (AdType.equals(BannerType.REWARD_VIDEO)) {
            mAdType = MediationAdSize.REWARD_VIDEO;
        }

        BidmadCommon.initializeSdk(mContext, new BidmadInitializeListener() {
            @Override
            public void onInitialized(boolean result) {
                isInitialized = result;

                if (needLoadAd) {
                    load(loadAdType);
                }
            }
        });
    }

    public void setAdListener(final MediationAdListener _listener) {
        mediationAdListener = _listener;
    }


    public void load(String type) {
        super.load(type);

        loadAdType = type;
        if (!isInitialized) {
            needLoadAd = true;
            return;
        }

        if (TextUtils.equals(type, BannerType.NATIVE_AD)) {
            loadNativeAd();
        } else if (TextUtils.equals(type, BannerType.INTERSTITIAL) || TextUtils.equals(type, BannerType.INTERSTITIAL_POPUP)) {
            if (!(mContext instanceof Activity)) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad("Need Activity Context");
                }
                return;
            }

            mInterstitial = new BidmadInterstitialAd((Activity) mContext, mUnitId);
            mInterstitial.setListener(new InterstitialListener() {

                @Override
                public void onLoadAd(@NonNull BMAdInfo info) {
                    super.onLoadAd(info);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                }

                @Override
                public void onShowAd(@NonNull BMAdInfo info) {
                    super.onShowAd(info);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdDisplayed();
                    }
                }

                @Override
                public void onShowFailAd(@NonNull BMAdError error, @NonNull BMAdInfo info) {
                    super.onShowFailAd(error, info);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToOpen(error.getMsg(), getName());
                    }
                }

                @Override
                public void onLoadFailAd(BMAdError bmAdError) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(bmAdError.getMsg());
                    }
                }

                @Override
                public void onCloseAd(@NonNull BMAdInfo info) {
                    super.onCloseAd(info);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClosed();
                    }
                }
            });
            mInterstitial.load();

        } else if (TextUtils.equals(type, BannerType.ENDING)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("해당 DSP에서는 지원하지 않는 기능 입니다.");
            }
        } else if (TextUtils.equals(type, BannerType.REWARD_VIDEO)) {
            loadRewardAd();
        } else {
            mAdView = new BidmadBannerAd(mContext, mUnitId);
            mAdView.setListener(new AdViewListener() {

                @Override
                public void onLoadAd(@NonNull BMAdInfo info) {
                    super.onLoadAd(info);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdLoaded();
                    }
                    sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
                }

                @Override
                public void onLoadFailAd(BMAdError error) {
                    if (mediationAdListener != null) {
                        mediationAdListener.onAdFailedToLoad(error.getMsg());
                    }
                }

                @Override
                public void onClickAd(@NonNull BMAdInfo info) {
                    super.onClickAd(info);

                    if (mediationAdListener != null) {
                        mediationAdListener.onAdClicked();
                    }
                }
            });

            // mAdView.setInterval(120); //Refresh Interval 60~120s
            mAdView.onceload(); //Banner Ad Load
        }

    }

    @Override
    public boolean show(@NonNull Activity activity) {
        if ((mInterstitial != null && mInterstitial.isLoaded())) {
            mInterstitial.show();
            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            return true;
        } else if (mRewardAd != null && mRewardAd.isLoaded()) {
            mRewardAd.show();
            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            return true;
        }

        return false;
    }

    @Override
    public boolean show() {
        if ((mInterstitial != null && mInterstitial.isLoaded())) {
            mInterstitial.show();
            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            return true;
        } else if (mRewardAd != null && mRewardAd.isLoaded()) {
            mRewardAd.show();
            sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            return true;
        }

        return false;
    }

    @Override
    public boolean isLoaded() {
        return (mInterstitial != null && mInterstitial.isLoaded()) ||
                (mRewardAd != null && mRewardAd.isLoaded());
    }

    @Override
    public void destroy() {
        super.destroy();

        mAdView = null;
        mInterstitial = null;
        nativeAd = null;
        mRewardAd = null;
    }


    public Object getAdView() {
        return mAdView.getView();
    }

    @Override
    public boolean canUseNativeAdView() {
        return true;
    }

    @Override
    public void loadNativeAd() {
        nativeAd = new BidmadNativeAd(mContext, mUnitId);

        nativeAd.setViewForInteraction(
                mAdViewItem.mViewLayoutID,
                mAdViewItem.mADImageViewID,
                mAdViewItem.mADLogoImageViewID,
                mAdViewItem.mDescViewID,
                mAdViewItem.mTitleViewID,
                mAdViewItem.mGotoSiteViewID
        );

        nativeAd.setListener(new NativeListener() {
            @Override
            public void onLoadAd(@NonNull BMAdInfo info) {
                super.onLoadAd(info);

                if (mAdViewItem != null && mAdViewItem.mContainerView != null) {
                    mAdViewItem.mContainerView.removeAllViews();
                    mAdViewItem.mContainerView.addView(nativeAd.getNativeLayout());
                }

                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }

                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }

            @Override
            public void onLoadFailAd(BMAdError error) {
                if (mAdViewItem.mContainerView != null) {
                    mAdViewItem.mContainerView.removeAllViews();
                }

                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(error.getMsg());
                }
            }

            @Override
            public void onClickAd(@NonNull BMAdInfo info) {
                super.onClickAd(info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }
        });

        nativeAd.load();
    }


    private void loadRewardAd() {
        if (!(mContext instanceof Activity)) {
            if (mediationAdListener != null) {
                mediationAdListener.onAdFailedToLoad("Need Activity Context");
            }
            return;
        }


        mRewardAd = new BidmadRewardAd((Activity) mContext, mUnitId);
        mRewardAd.setListener(new RewardListener() {
            @Override
            public void onLoadAd(@NonNull BMAdInfo info) {
                super.onLoadAd(info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdLoaded();
                }
                sendAdSDKImpression(mContext, mScriptNo, getName(), mUnitId, getExlItlSeq());
            }

            @Override
            public void onShowAd(@NonNull BMAdInfo info) {
                super.onShowAd(info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdDisplayed();
                }
            }

            @Override
            public void onLoadFailAd(BMAdError bmAdError) {
                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToLoad(bmAdError.getMsg());
                }
            }

            @Override
            public void onCloseAd(@NonNull BMAdInfo info) {
                super.onCloseAd(info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdClosed();
                }
            }

            @Override
            public void onShowFailAd(@NonNull BMAdError error, @NonNull BMAdInfo info) {
                super.onShowFailAd(error, info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdFailedToOpen(error.getMsg(), getName());
                }
            }

            @Override
            public void onCompleteAd(@NonNull BMAdInfo info) {
                super.onCompleteAd(info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdComplete();
                }
            }

            @Override
            public void onClickAd(@NonNull BMAdInfo info) {
                super.onClickAd(info);

                if (mediationAdListener != null) {
                    mediationAdListener.onAdClicked();
                }
            }

            @Override
            public void onSkipAd(@NonNull BMAdInfo info) {
                super.onSkipAd(info);
                if (mediationAdListener != null) {
                    mediationAdListener.onAdSkip();
                }
            }
        });

        mRewardAd.load();
    }

}
