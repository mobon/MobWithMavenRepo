package com.mobwith.imgmodule.load.resource.file;

import com.mobwith.imgmodule.load.resource.SimpleResource;

import java.io.File;

/** A simple {@link com.mobwith.imgmodule.load.engine.Resource} that wraps a {@link File}. */
// Public API.
@SuppressWarnings("WeakerAccess")
public class FileResource extends SimpleResource<File> {
  public FileResource(File file) {
    super(file);
  }
}
