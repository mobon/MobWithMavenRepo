package com.mobwith;

import android.content.Context;
import android.text.TextUtils;

import com.mobwith.adapters.AdViewAdapter;
import com.mobwith.adapters.DTExchangeAdapter;
import com.mobwith.adapters.InMobiAdapter;
import com.mobwith.adapters.LevelPlayAdapter;
import com.mobwith.adapters.PangleAdapter;
import com.mobwith.adapters.UnityAdapter;
import com.mobwith.manager.AppierSDK;
import com.mobwith.manager.LogPrint;
import com.mobwith.manager.SpManager;
import com.mobwith.manager.UserAgentHelper;
import com.mobwith.sdk.CommonUtils;
import com.mobwith.sdk.Key;
import com.mobwith.sdk.Url;

public class MobwithSDK {

    private static final String COUPANG_ADS_CONTEXT = "com.coupang.ads.AdsContext";
    private static final String UNITY_ADS_CLASS = "com.unity3d.ads.UnityAds";
    private static final String LEVELPLAY_CLASS = "com.unity3d.mediation.LevelPlay";

    private static volatile MobwithSDK instance;
    private static boolean isInited = false;

    protected boolean isTestMode = false;
    protected boolean isLogPrint = false;
    public static boolean isFullScreenMode = false;

    protected String unityGameId = "";
    protected String levelPlaySDKAppKey = "";

    private MobwithSDK() {}

    public static MobwithSDK getInstance() {
        if (instance == null) {
            synchronized (MobwithSDK.class) {
                if (instance == null) {
                    instance = new MobwithSDK();
                }
            }
        }
        return instance;
    }

    public void setTestMode(boolean testMode) {
        isTestMode = testMode;
        Url.setUrl();
    }

    public boolean isTestMode() {
        return isTestMode;
    }

    public void setLogPrint(boolean isShow) {
        LogPrint.setLogPrint(isShow);
        isLogPrint = isShow;
    }

    public boolean isShowLog() {
        return isLogPrint;
    }

    public void setFullScreenMode(boolean isFullScreenMode) {
        MobwithSDK.isFullScreenMode = isFullScreenMode;
    }

    public static void initSDK(Context context) {
        try{
            CommonUtils.getAdId(context);

            if (TextUtils.isEmpty(SpManager.getString(context, Key.USER_AGENT))) {
                UserAgentHelper.fetchAndCacheUserAgent(context);
            }
            initAppier(context);
            initCoupangSDK(context);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private static void initCoupangSDK(Context context) {
        if (isInited) {
            return;
        }

        try {
            Class<?> clazz = Class.forName(COUPANG_ADS_CONTEXT);
            clazz.getConstructor(Context.class).newInstance(context);

            LogPrint.d("initSDK - Coupang SDK init success");
            isInited = true;
        } catch (ClassNotFoundException e) {
            LogPrint.d("initSDK - Coupang SDK init fail : ClassNotFoundException");
        } catch (Exception e) {
            LogPrint.d("initSDK - Coupang SDK init fail");
            LogPrint.d(e.getLocalizedMessage());
        }
    }

    /**
     * UnityAds를 미디에이션 하는 경우 해당 UnityGameID를 설정해 주셔야 합니다.
     *
     * @param context Android Context. Application Context를 내부적으로 접근하도록 되어 있습니다.
     * @param gameId  발급받은 UnityGameId값을 설정해 주시면 됩니다.
     */
    public void setUnityGameId(Context context, String gameId) {
        unityGameId = gameId;
        initMediationAdapter("Unity Ad", UNITY_ADS_CLASS,
                () -> UnityAdapter.initSDK(context, gameId));
    }

    /**
     * LevelPlay SDK를 미디에이션 하는 경우 해당 AppKey를 설정해 주셔야 합니다.
     *
     * @param context Android Context. Application Context를 내부적으로 접근하도록 되어 있습니다.
     * @param appKey  발급 받은 LevelPlay AppKey값을 설정해 주시면 됩니다.
     */
    public void setLevelPlayAppKey(Context context, String appKey) {
        levelPlaySDKAppKey = appKey;
        initMediationAdapter("LevelPlay", LEVELPLAY_CLASS,
                () -> LevelPlayAdapter.initSDK(context, appKey));
    }

    /**
     * Pangle SDK를 미디에이션 하는 경우 해당 AppKey를 설정해 주셔야 합니다.
     *
     * @param appKey 발급받은 Pangle AppId값을 설정해 주시면 됩니다.
     */
    public void setPangleAppKey(String appKey) {
        initMediationAdapter("Pangle", null, () -> PangleAdapter.initSDK(appKey));
    }

    /**
     * DTExchange SDK를 미디에이션 하는 경우 해당 AppKey를 설정해 주셔야 합니다.
     *
     * @param appKey 발급받은 DTExchange AppId값을 설정해 주시면 됩니다.
     */
    public void setDTExChangeAppKey(String appKey) {
        initMediationAdapter("DTExchange", null, () -> DTExchangeAdapter.initSDK(appKey));
    }

    /**
     * InMobi SDK를 미디에이션 하는 경우 해당 AppKey를 설정해 주셔야 합니다.
     *
     * @param appKey 발급받은 InMobi AppId값을 설정해 주시면 됩니다.
     */
    public void setInMobiAppKey(String appKey) {
        initMediationAdapter("InMobi", null, () -> InMobiAdapter.initSDK(appKey));
    }

    /**
     * ADView SDK를 미디에이션 하는 경우 해당 AppKey를 설정해 주셔야 합니다.
     *
     * @param appKey 발급받은 ADView AppId값을 설정해 주시면 됩니다.
     */
    public void setADViewAppKey(String appKey) {
        initMediationAdapter("ADVIEW", null, () -> AdViewAdapter.initSDK(appKey));
    }

    /**
     * 미디에이션 어댑터 초기화 공통 처리.
     *
     * @param sdkName       로그에 표시할 SDK 이름
     * @param requiredClass 의존 클래스 존재 여부를 확인할 FQCN. 확인이 필요 없으면 null
     * @param initAction    실제 어댑터 초기화 동작
     */
    private void initMediationAdapter(String sdkName, String requiredClass, Runnable initAction) {
        try {
            if (requiredClass != null) {
                Class.forName(requiredClass);
            }
            initAction.run();
            LogPrint.d("initSDK - " + sdkName + " SDK init success");
        } catch (ClassNotFoundException e) {
            LogPrint.d("initSDK - " + sdkName + " SDK init fail - ClassNotFoundException");
        } catch (Exception e) {
            LogPrint.d("initSDK - " + sdkName + " SDK init fail - " + e.getLocalizedMessage());
        }
    }

    private static void initAppier(Context context) {
        // AISTRA SDK 존재 여부 확인과 예외 처리는 AppierSDK 내부(리플렉션)에서 모두 처리한다.
        // 여기서 구버전 클래스(com.appier.argus.api.Argus)로 확인하면
        // argus만 들어있는 앱에서 가드를 통과해 NoClassDefFoundError가 발생한다.
        AppierSDK.initArgus(context);
    }
}